# Assigned

A live streaming and social platform where users can connect with creators, join dialogues, and share live experiences with communities worldwide.

## Features

- **Live Streaming** - Go live and broadcast to your audience
- **Direct Messages** - Private messaging between users
- **Dialogues** - Group conversations that users can create, join, or be invited to
- **Following Feed** - Stay updated with content from creators you follow
- **Clips & VODs** - Create and share highlights from streams
- **Wallet System** - Virtual currency for gifts and donations
- **Analytics** - Track your streaming performance

## Tech Stack

- React + TypeScript
- Vite
- Tailwind CSS
- Supabase (Backend & Real-time)

## Getting Started

```bash
npm install
npm run dev
```

## License

All rights reserved © 2025 Assigned
