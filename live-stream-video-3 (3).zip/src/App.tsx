
import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import { ThemeProvider } from "@/components/theme-provider";
import { AuthProvider } from "@/contexts/AuthContext";
import { StreamProvider } from "@/contexts/StreamContext";
import Index from "./pages/Index";
import NotFound from "./pages/NotFound";
import LoginPage from "./pages/LoginPage";
import SignupPage from "./pages/SignupPage";
import ProfilePage from "./pages/ProfilePage";
import BroadcastPage from "./pages/BroadcastPage";
import WatchPage from "./pages/WatchPage";
import SubscriptionsPage from "./pages/SubscriptionsPage";
import EarningsPage from "./pages/EarningsPage";
import AnalyticsPage from "./pages/AnalyticsPage";
import FeedPage from "./pages/FeedPage";
import WalletPage from "./pages/WalletPage";
import MessagesPage from "./pages/MessagesPage";
import MonetizationPage from "./pages/MonetizationPage";
import MiningPage from "./pages/MiningPage";
import TradingPage from "./pages/TradingPage";
import VoiceRoomsPage from "./pages/VoiceRoomsPage";

const queryClient = new QueryClient();

const App = () => (
  <ThemeProvider defaultTheme="light">
    <QueryClientProvider client={queryClient}>
      <AuthProvider>
        <StreamProvider>
          <TooltipProvider>
            <Toaster />
            <Sonner />
            <BrowserRouter>
              <Routes>
                <Route path="/" element={<Index />} />
                <Route path="/login" element={<LoginPage />} />
                <Route path="/signup" element={<SignupPage />} />
                <Route path="/profile" element={<ProfilePage />} />
                <Route path="/profile/:username" element={<ProfilePage />} />
                <Route path="/broadcast" element={<BroadcastPage />} />
                <Route path="/watch/:streamId" element={<WatchPage />} />
                <Route path="/subscriptions" element={<SubscriptionsPage />} />
                <Route path="/earnings" element={<EarningsPage />} />
                <Route path="/analytics" element={<AnalyticsPage />} />
                <Route path="/feed" element={<FeedPage />} />
                <Route path="/wallet" element={<WalletPage />} />
                <Route path="/messages" element={<MessagesPage />} />
                <Route path="/monetization" element={<MonetizationPage />} />
                <Route path="/mining" element={<MiningPage />} />
                <Route path="/trading" element={<TradingPage />} />
                <Route path="/voice" element={<VoiceRoomsPage />} />
                <Route path="/voice/:roomId" element={<VoiceRoomsPage />} />
                <Route path="*" element={<NotFound />} />
              </Routes>
            </BrowserRouter>
          </TooltipProvider>
        </StreamProvider>
      </AuthProvider>
    </QueryClientProvider>
  </ThemeProvider>
);

export default App;
