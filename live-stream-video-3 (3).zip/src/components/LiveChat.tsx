
import React, { useState, useEffect, useRef } from 'react';
import { Send, Shield, Trash2, Clock, Crown, Star, Lock, Smile, Sparkles, Diamond } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/contexts/AuthContext';
import { ChatMessageItem } from './ChatMessageItem';

export interface ChatMsg {
  id: string;
  stream_id: string;
  user_id: string;

  username: string;
  display_name: string;
  message: string;
  badge: string | null;
  is_deleted: boolean;
  created_at: string;
  is_highlighted?: boolean;
  vip_tier_level?: number;
  vip_badge_color?: string;
}

interface LiveChatProps {
  streamId: string;
  streamerId: string;
  isStreamer?: boolean;
  subOnlyMode?: boolean;
  onToggleSubOnly?: () => void;
}

const EMOTES = [
  { code: ':hype:', emoji: '🔥' },
  { code: ':love:', emoji: '💜' },
  { code: ':gg:', emoji: '🎮' },
  { code: ':pog:', emoji: '😮' },
  { code: ':lul:', emoji: '😂' },
  { code: ':sad:', emoji: '😢' },
];

export const LiveChat: React.FC<LiveChatProps> = ({ streamId, streamerId, isStreamer = false, subOnlyMode = false, onToggleSubOnly }) => {
  const { user } = useAuth();
  const [messages, setMessages] = useState<ChatMsg[]>([]);
  const [newMessage, setNewMessage] = useState('');
  const [isMod, setIsMod] = useState(false);
  const [isSubscribed, setIsSubscribed] = useState(false);
  const [timeoutUser, setTimeoutUser] = useState<string | null>(null);
  const [banError, setBanError] = useState<string | null>(null);
  const [showEmotes, setShowEmotes] = useState(false);
  const [userVip, setUserVip] = useState<any>(null);
  const chatRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    loadMessages();
    checkModStatus();
    checkSubscription();
    loadUserVIP();
    const channel = supabase
      .channel(`chat:${streamId}`)
      .on('postgres_changes', { event: 'INSERT', schema: 'public', table: 'chat_messages', filter: `stream_id=eq.${streamId}` },
        (payload) => { if (!payload.new.is_deleted) setMessages(prev => [...prev, payload.new as ChatMsg]); }
      )
      .on('postgres_changes', { event: 'UPDATE', schema: 'public', table: 'chat_messages', filter: `stream_id=eq.${streamId}` },
        (payload) => { if (payload.new.is_deleted) setMessages(prev => prev.filter(m => m.id !== payload.new.id)); }
      )
      .subscribe();
    return () => { supabase.removeChannel(channel); };
  }, [streamId]);

  useEffect(() => {
    if (chatRef.current) chatRef.current.scrollTop = chatRef.current.scrollHeight;
  }, [messages]);

  const loadMessages = async () => {
    const { data } = await supabase.functions.invoke('chat-manager', { body: { action: 'get_messages', stream_id: streamId } });
    if (data?.messages) setMessages(data.messages);
  };

  const loadUserVIP = async () => {
    if (!user) return;
    const { data } = await supabase.functions.invoke('vip-manager', { body: { action: 'get_user_vip', user_id: user.user_id } });
    if (data?.status?.current_tier) setUserVip(data.status.current_tier);
  };

  const checkModStatus = async () => {
    if (!user) return;
    const { data } = await supabase.from('stream_moderators').select('id').eq('stream_id', streamId).eq('user_id', user.user_id).single();
    setIsMod(!!data);
  };

  const checkSubscription = async () => {
    if (!user) return;
    const { data } = await supabase.functions.invoke('subscription-manager', {
      body: { action: 'check_subscription', subscriber_id: user.user_id, streamer_id: streamerId }
    });
    setIsSubscribed(data?.subscribed || false);
  };

  const sendMessage = async () => {
    if (!newMessage.trim() || !user) return;
    if (subOnlyMode && !isSubscribed && !isStreamer && !isMod) {
      setBanError('This chat is in subscriber-only mode');
      return;
    }
    setBanError(null);
    let badge = null;
    if (user.user_id === streamerId) badge = 'STREAMER';
    else if (isMod) badge = 'MOD';
    else if (isSubscribed) badge = 'SUB';
    
    const { data, error } = await supabase.functions.invoke('chat-manager', {
      body: { 
        action: 'send_message', stream_id: streamId, user_id: user.user_id, 
        username: user.username, display_name: user.display_name, message: newMessage.trim(), badge,
        vip_tier_level: userVip?.tier_level, vip_badge_color: userVip?.badge_color
      }
    });
    if (data?.error) { setBanError(data.error); return; }
    setNewMessage('');
  };

  const deleteMessage = async (msgId: string) => {
    if (!user) return;
    await supabase.functions.invoke('chat-manager', { body: { action: 'delete_message', stream_id: streamId, user_id: user.user_id, message_id: msgId } });
  };

  const timeoutUserAction = async (targetUserId: string, minutes: number) => {
    if (!user) return;
    await supabase.functions.invoke('chat-manager', { body: { action: 'timeout_user', stream_id: streamId, user_id: user.user_id, target_user_id: targetUserId, duration_minutes: minutes } });
    setTimeoutUser(null);
  };

  const addEmote = (code: string) => { setNewMessage(prev => prev + code); setShowEmotes(false); };
  const renderMessage = (msg: string) => { let r = msg; EMOTES.forEach(e => { r = r.replaceAll(e.code, e.emoji); }); return r; };
  const canModerate = isStreamer || isMod;
  const canChat = !subOnlyMode || isSubscribed || isStreamer || isMod;

  return (
    <div className="flex flex-col h-full">
      {subOnlyMode && <div className="px-3 py-2 bg-purple-600/20 border-b border-purple-500/30 flex items-center gap-2"><Lock className="w-4 h-4 text-purple-400" /><span className="text-purple-300 text-sm">Subscriber-only chat</span></div>}
      {isStreamer && <div className="px-3 py-2 border-b border-gray-700 flex items-center justify-between"><span className="text-gray-400 text-sm">Chat Mode</span><button onClick={onToggleSubOnly} className={`px-3 py-1 rounded-full text-sm font-medium ${subOnlyMode ? 'bg-purple-600 text-white' : 'bg-gray-700 text-gray-300'}`}>{subOnlyMode ? 'Sub-only ON' : 'Sub-only OFF'}</button></div>}
      <div ref={chatRef} className="flex-1 overflow-y-auto p-3 space-y-2">
        {messages.map((msg) => <ChatMessageItem key={msg.id} msg={msg} canModerate={canModerate} onDelete={deleteMessage} onTimeout={() => setTimeoutUser(msg.user_id)} currentUserId={user?.user_id} renderMessage={renderMessage} />)}
      </div>
      {banError && <div className="px-3 py-2 bg-red-500/20 text-red-400 text-sm">{banError}</div>}
      {timeoutUser && <TimeoutPanel onTimeout={(m) => timeoutUserAction(timeoutUser, m)} onCancel={() => setTimeoutUser(null)} />}
      {showEmotes && <div className="p-3 bg-[#1a1a2e] border-t border-gray-700 grid grid-cols-6 gap-2">{EMOTES.map(e => <button key={e.code} onClick={() => addEmote(e.code)} className="p-2 hover:bg-gray-700 rounded text-xl" title={e.code}>{e.emoji}</button>)}</div>}
      <div className="p-3 border-t border-gray-700 flex gap-2">
        <button onClick={() => setShowEmotes(!showEmotes)} className="p-2 bg-gray-700 hover:bg-gray-600 rounded-lg"><Smile className="w-5 h-5 text-gray-400" /></button>
        <input value={newMessage} onChange={(e) => setNewMessage(e.target.value)} onKeyDown={(e) => e.key === 'Enter' && sendMessage()} placeholder={!user ? "Login to chat" : !canChat ? "Subscribe to chat" : "Send a message..."} disabled={!user || !canChat} className="flex-1 bg-[#1a1a2e] text-white px-3 py-2 rounded-lg border border-gray-700 focus:border-purple-500 focus:outline-none text-sm disabled:opacity-50" />
        <button onClick={sendMessage} disabled={!user || !canChat} className="bg-purple-600 hover:bg-purple-700 disabled:opacity-50 p-2 rounded-lg"><Send className="w-5 h-5 text-white" /></button>
      </div>
    </div>
  );
};

const TimeoutPanel = ({ onTimeout, onCancel }: { onTimeout: (m: number) => void; onCancel: () => void }) => (
  <div className="p-3 bg-[#1a1a2e] border-t border-gray-700"><p className="text-sm text-gray-300 mb-2">Timeout duration:</p><div className="flex gap-2">{[1, 5, 10, 60].map(m => <button key={m} onClick={() => onTimeout(m)} className="px-3 py-1 bg-red-600 hover:bg-red-700 text-white text-sm rounded">{m}m</button>)}<button onClick={onCancel} className="px-3 py-1 bg-gray-600 hover:bg-gray-700 text-white text-sm rounded">Cancel</button></div></div>
);
