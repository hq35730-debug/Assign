import React, { useState } from 'react';
import { Phone, MessageSquare, PhoneCall, PhoneOff, Send, Loader2, CheckCircle, XCircle } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/contexts/AuthContext';
import { Button } from '@/components/ui/button';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';

interface PhoneCapabilitiesProps {
  isOpen: boolean;
  onClose: () => void;
}

export function PhoneCapabilities({ isOpen, onClose }: PhoneCapabilitiesProps) {
  const { user } = useAuth();
  const [activeTab, setActiveTab] = useState<'sms' | 'call'>('sms');
  const [toNumber, setToNumber] = useState('');
  const [message, setMessage] = useState('');
  const [sending, setSending] = useState(false);
  const [result, setResult] = useState<{ success: boolean; message: string } | null>(null);

  const handleSendSMS = async () => {
    if (!user || !toNumber || !message) return;
    
    setSending(true);
    setResult(null);
    
    try {
      const { data, error } = await supabase.functions.invoke('phone-manager', {
        body: {
          action: 'send_sms',
          user_id: user.user_id,
          to_number: toNumber,
          message: message
        }
      });
      
      if (error) throw error;
      
      if (data?.success) {
        setResult({ success: true, message: 'SMS sent successfully!' });
        setMessage('');
      } else {
        setResult({ success: false, message: data?.error || 'Failed to send SMS' });
      }
    } catch (err: any) {
      setResult({ success: false, message: err.message || 'Failed to send SMS' });
    } finally {
      setSending(false);
    }
  };

  const handleMakeCall = async () => {
    if (!user || !toNumber) return;
    
    setSending(true);
    setResult(null);
    
    try {
      // For now, we'll use a simple TwiML that says a greeting
      const twimlUrl = 'http://demo.twilio.com/docs/voice.xml';
      
      const { data, error } = await supabase.functions.invoke('phone-manager', {
        body: {
          action: 'make_call',
          user_id: user.user_id,
          to_number: toNumber,
          twiml_url: twimlUrl
        }
      });
      
      if (error) throw error;
      
      if (data?.success) {
        setResult({ success: true, message: 'Call initiated successfully!' });
      } else {
        setResult({ success: false, message: data?.error || 'Failed to make call' });
      }
    } catch (err: any) {
      setResult({ success: false, message: err.message || 'Failed to make call' });
    } finally {
      setSending(false);
    }
  };

  const formatPhoneInput = (value: string) => {
    // Remove all non-digits
    const digits = value.replace(/\D/g, '');
    
    // Format as +1 (XXX) XXX-XXXX
    if (digits.length <= 1) return digits;
    if (digits.length <= 4) return `+${digits.slice(0, 1)} (${digits.slice(1)}`;
    if (digits.length <= 7) return `+${digits.slice(0, 1)} (${digits.slice(1, 4)}) ${digits.slice(4)}`;
    return `+${digits.slice(0, 1)} (${digits.slice(1, 4)}) ${digits.slice(4, 7)}-${digits.slice(7, 11)}`;
  };

  if (!user?.phone_number) {
    return (
      <Dialog open={isOpen} onOpenChange={onClose}>
        <DialogContent className="bg-[#16213e] border-gray-800 text-white max-w-md">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Phone className="w-5 h-5 text-purple-400" />
              Phone Capabilities
            </DialogTitle>
          </DialogHeader>
          <div className="text-center py-8">
            <PhoneOff className="w-16 h-16 text-gray-500 mx-auto mb-4" />
            <p className="text-gray-400">You don't have a phone number assigned yet.</p>
            <p className="text-gray-500 text-sm mt-2">Phone numbers are assigned when you create an account.</p>
          </div>
        </DialogContent>
      </Dialog>
    );
  }

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="bg-[#16213e] border-gray-800 text-white max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Phone className="w-5 h-5 text-purple-400" />
            Phone Capabilities
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-4">
          {/* Your Phone Number */}
          <div className="bg-[#1a1a2e] rounded-lg p-4 border border-gray-700">
            <p className="text-gray-400 text-sm mb-1">Your Phone Number</p>
            <p className="text-green-400 font-mono text-lg">{user.phone_number}</p>
          </div>

          {/* Tab Buttons */}
          <div className="flex gap-2">
            <button
              onClick={() => setActiveTab('sms')}
              className={`flex-1 flex items-center justify-center gap-2 py-2 rounded-lg transition-colors ${
                activeTab === 'sms' 
                  ? 'bg-purple-600 text-white' 
                  : 'bg-[#1a1a2e] text-gray-400 hover:text-white'
              }`}
            >
              <MessageSquare className="w-4 h-4" />
              Send SMS
            </button>
            <button
              onClick={() => setActiveTab('call')}
              className={`flex-1 flex items-center justify-center gap-2 py-2 rounded-lg transition-colors ${
                activeTab === 'call' 
                  ? 'bg-purple-600 text-white' 
                  : 'bg-[#1a1a2e] text-gray-400 hover:text-white'
              }`}
            >
              <PhoneCall className="w-4 h-4" />
              Make Call
            </button>
          </div>

          {/* To Number Input */}
          <div>
            <label className="text-gray-300 text-sm mb-2 block">To Phone Number</label>
            <input
              type="tel"
              value={toNumber}
              onChange={(e) => setToNumber(formatPhoneInput(e.target.value))}
              placeholder="+1 (555) 123-4567"
              className="w-full bg-[#1a1a2e] text-white px-4 py-3 rounded-lg border border-gray-700 focus:border-purple-500 focus:outline-none"
            />
          </div>

          {/* SMS Message Input */}
          {activeTab === 'sms' && (
            <div>
              <label className="text-gray-300 text-sm mb-2 block">Message</label>
              <textarea
                value={message}
                onChange={(e) => setMessage(e.target.value)}
                placeholder="Type your message..."
                rows={4}
                className="w-full bg-[#1a1a2e] text-white px-4 py-3 rounded-lg border border-gray-700 focus:border-purple-500 focus:outline-none resize-none"
              />
              <p className="text-gray-500 text-xs mt-1">{message.length}/160 characters</p>
            </div>
          )}

          {/* Result Message */}
          {result && (
            <div className={`flex items-center gap-2 p-3 rounded-lg ${
              result.success 
                ? 'bg-green-500/20 border border-green-500/30' 
                : 'bg-red-500/20 border border-red-500/30'
            }`}>
              {result.success 
                ? <CheckCircle className="w-5 h-5 text-green-400" />
                : <XCircle className="w-5 h-5 text-red-400" />
              }
              <span className={result.success ? 'text-green-400' : 'text-red-400'}>
                {result.message}
              </span>
            </div>
          )}

          {/* Action Button */}
          <Button
            onClick={activeTab === 'sms' ? handleSendSMS : handleMakeCall}
            disabled={sending || !toNumber || (activeTab === 'sms' && !message)}
            className="w-full bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-500 hover:to-pink-500"
          >
            {sending ? (
              <>
                <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                {activeTab === 'sms' ? 'Sending...' : 'Calling...'}
              </>
            ) : (
              <>
                {activeTab === 'sms' ? (
                  <>
                    <Send className="w-4 h-4 mr-2" />
                    Send SMS
                  </>
                ) : (
                  <>
                    <PhoneCall className="w-4 h-4 mr-2" />
                    Make Call
                  </>
                )}
              </>
            )}
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}
