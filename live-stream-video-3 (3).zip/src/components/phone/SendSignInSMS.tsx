import React, { useState, useEffect } from 'react';
import { 
  Smartphone, Send, Loader2, CheckCircle, XCircle, Shield, 
  MessageSquare, Clock, ChevronDown, ChevronUp, Info, Copy, 
  Eye, EyeOff, AlertTriangle, Phone
} from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/contexts/AuthContext';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';

interface SendSignInSMSProps {
  isOpen: boolean;
  onClose: () => void;
  /** Pre-fill for post-signup flow when user data may not be in context yet */
  prefillData?: {
    username?: string;
    email?: string;
    unique_id?: number;
    phone_number?: string;
    user_id?: string;
  };
}

interface SMSHistoryItem {
  id: string;
  to_number: string;
  message_type: string;
  success: boolean;
  sent_at: string;
}

export function SendSignInSMS({ isOpen, onClose, prefillData }: SendSignInSMSProps) {
  const { user } = useAuth();
  const [phoneNumber, setPhoneNumber] = useState('');
  const [sending, setSending] = useState(false);
  const [result, setResult] = useState<{ success: boolean; message: string } | null>(null);
  const [showPreview, setShowPreview] = useState(false);
  const [showHistory, setShowHistory] = useState(false);
  const [history, setHistory] = useState<SMSHistoryItem[]>([]);
  const [loadingHistory, setLoadingHistory] = useState(false);
  const [confirmSend, setConfirmSend] = useState(false);
  const [maskInfo, setMaskInfo] = useState(true);
  const [copied, setCopied] = useState(false);

  const currentUser = prefillData || user;
  const userId = prefillData?.user_id || user?.user_id || user?.id;

  useEffect(() => {
    if (isOpen) {
      setResult(null);
      setConfirmSend(false);
      setShowPreview(false);
    }
  }, [isOpen]);

  // Load SMS history
  useEffect(() => {
    if (isOpen && userId && showHistory) {
      loadHistory();
    }
  }, [isOpen, userId, showHistory]);

  const loadHistory = async () => {
    if (!userId) return;
    setLoadingHistory(true);
    try {
      const { data, error } = await supabase
        .from('sms_log')
        .select('*')
        .eq('user_id', userId)
        .eq('message_type', 'signin_info')
        .order('sent_at', { ascending: false })
        .limit(10);
      
      if (!error && data) {
        setHistory(data);
      }
    } catch (err) {
      console.error('Failed to load SMS history:', err);
    } finally {
      setLoadingHistory(false);
    }
  };

  const formatPhoneInput = (value: string) => {
    const digits = value.replace(/\D/g, '');
    if (digits.length === 0) return '';
    if (digits.length <= 1) return `+${digits}`;
    if (digits.length <= 4) return `+${digits.slice(0, 1)} (${digits.slice(1)}`;
    if (digits.length <= 7) return `+${digits.slice(0, 1)} (${digits.slice(1, 4)}) ${digits.slice(4)}`;
    return `+${digits.slice(0, 1)} (${digits.slice(1, 4)}) ${digits.slice(4, 7)}-${digits.slice(7, 11)}`;
  };

  const getRawPhoneNumber = (formatted: string) => {
    const digits = formatted.replace(/\D/g, '');
    if (digits.length > 0 && !digits.startsWith('+')) {
      return `+${digits}`;
    }
    return `+${digits}`;
  };

  const maskString = (str: string) => {
    if (!str || str.length <= 4) return str;
    return str.slice(0, 2) + '*'.repeat(str.length - 4) + str.slice(-2);
  };

  const getPreviewMessage = () => {
    const username = currentUser?.username || 'N/A';
    const email = currentUser?.email || 'N/A';
    const uniqueId = (currentUser as any)?.unique_id;
    const assignedPhone = (currentUser as any)?.phone_number;
    const loginUrl = `${window.location.origin}/login`;

    let msg = `Assigned - Your Sign-In Info\n\n`;
    msg += `Username: ${maskInfo ? maskString(username) : username}\n`;
    msg += `Email: ${maskInfo ? maskString(email) : email}\n`;
    if (uniqueId) {
      msg += `Unique ID: ${uniqueId}\n`;
    }
    if (assignedPhone) {
      msg += `Assigned Phone: ${maskInfo ? maskString(assignedPhone) : assignedPhone}\n`;
    }
    msg += `\nSign in here: ${loginUrl}\n`;
    msg += `\nKeep this message safe. Do not share your credentials.`;
    return msg;
  };

  const handleSend = async () => {
    if (!phoneNumber || !currentUser) return;

    if (!confirmSend) {
      setConfirmSend(true);
      return;
    }

    setSending(true);
    setResult(null);

    try {
      const rawPhone = getRawPhoneNumber(phoneNumber);
      const loginUrl = `${window.location.origin}/login`;

      const { data, error } = await supabase.functions.invoke('phone-manager', {
        body: {
          action: 'send_signin_sms',
          user_id: userId,
          to_number: rawPhone,
          login_url: loginUrl,
          // Fallback fields for prefill mode
          username: currentUser?.username,
          email: currentUser?.email,
          unique_id_value: (currentUser as any)?.unique_id,
          assigned_phone: (currentUser as any)?.phone_number
        }
      });

      if (error) throw error;

      if (data?.success) {
        setResult({ success: true, message: 'Sign-in information sent successfully via SMS!' });
        setConfirmSend(false);
        // Refresh history
        if (showHistory) loadHistory();
      } else {
        setResult({ success: false, message: data?.error || 'Failed to send SMS. Please try again.' });
        setConfirmSend(false);
      }
    } catch (err: any) {
      console.error('SMS send error:', err);
      setResult({ success: false, message: err.message || 'Failed to send SMS. Please check the phone number and try again.' });
      setConfirmSend(false);
    } finally {
      setSending(false);
    }
  };

  const handleCopyInfo = () => {
    const username = currentUser?.username || '';
    const email = currentUser?.email || '';
    const loginUrl = `${window.location.origin}/login`;
    const text = `Assigned Sign-In Info\nUsername: ${username}\nEmail: ${email}\nLogin: ${loginUrl}`;
    navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const isValidPhone = phoneNumber.replace(/\D/g, '').length >= 10;

  if (!currentUser) {
    return (
      <Dialog open={isOpen} onOpenChange={onClose}>
        <DialogContent className="bg-[#16213e] border-gray-800 text-white max-w-md">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Smartphone className="w-5 h-5 text-purple-400" />
              Send Sign-In Info via SMS
            </DialogTitle>
          </DialogHeader>
          <div className="text-center py-8">
            <AlertTriangle className="w-16 h-16 text-yellow-500 mx-auto mb-4" />
            <p className="text-gray-400">You need to be signed in to send your sign-in information.</p>
            <p className="text-gray-500 text-sm mt-2">Please sign up or log in first.</p>
          </div>
        </DialogContent>
      </Dialog>
    );
  }

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="bg-[#16213e] border-gray-800 text-white max-w-lg max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-green-500 to-emerald-600 flex items-center justify-center">
              <Smartphone className="w-4 h-4 text-white" />
            </div>
            Send Sign-In Info via SMS
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-4">
          {/* Info Banner */}
          <div className="bg-gradient-to-r from-blue-500/10 to-cyan-500/10 rounded-xl p-4 border border-blue-500/20">
            <div className="flex items-start gap-3">
              <Info className="w-5 h-5 text-blue-400 mt-0.5 flex-shrink-0" />
              <div>
                <p className="text-blue-300 text-sm font-medium">SMS Sign-In Delivery</p>
                <p className="text-gray-400 text-xs mt-1">
                  Your account credentials will be securely sent to the phone number you provide. 
                  This is useful for keeping a backup of your sign-in details or sharing access info with yourself on another device.
                </p>
              </div>
            </div>
          </div>

          {/* Account Info Summary */}
          <div className="bg-[#1a1a2e] rounded-xl p-4 border border-gray-700">
            <div className="flex items-center justify-between mb-3">
              <h3 className="text-gray-300 text-sm font-medium">Account Information</h3>
              <div className="flex items-center gap-2">
                <button
                  onClick={() => setMaskInfo(!maskInfo)}
                  className="p-1.5 text-gray-400 hover:text-white rounded-lg hover:bg-gray-700 transition-colors"
                  title={maskInfo ? 'Show details' : 'Hide details'}
                >
                  {maskInfo ? <Eye className="w-4 h-4" /> : <EyeOff className="w-4 h-4" />}
                </button>
                <button
                  onClick={handleCopyInfo}
                  className="p-1.5 text-gray-400 hover:text-white rounded-lg hover:bg-gray-700 transition-colors"
                  title="Copy info"
                >
                  {copied ? <CheckCircle className="w-4 h-4 text-green-400" /> : <Copy className="w-4 h-4" />}
                </button>
              </div>
            </div>
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-gray-500 text-xs">Username</span>
                <span className="text-white text-sm font-mono">
                  {maskInfo ? maskString(currentUser.username || '') : currentUser.username}
                </span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-gray-500 text-xs">Email</span>
                <span className="text-white text-sm font-mono">
                  {maskInfo ? maskString(currentUser.email || '') : currentUser.email}
                </span>
              </div>
              {(currentUser as any)?.unique_id && (
                <div className="flex items-center justify-between">
                  <span className="text-gray-500 text-xs">Unique ID</span>
                  <span className="text-purple-400 text-sm font-mono">{(currentUser as any).unique_id}</span>
                </div>
              )}
              {(currentUser as any)?.phone_number && (
                <div className="flex items-center justify-between">
                  <span className="text-gray-500 text-xs">Assigned Phone</span>
                  <span className="text-green-400 text-sm font-mono">
                    {maskInfo ? maskString((currentUser as any).phone_number) : (currentUser as any).phone_number}
                  </span>
                </div>
              )}
            </div>
          </div>

          {/* Phone Number Input */}
          <div>
            <label className="text-gray-300 text-sm mb-2 block font-medium">
              Send To Phone Number
            </label>
            <div className="relative">
              <Phone className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-500" />
              <input
                type="tel"
                value={phoneNumber}
                onChange={(e) => {
                  setPhoneNumber(formatPhoneInput(e.target.value));
                  setConfirmSend(false);
                  setResult(null);
                }}
                placeholder="+1 (555) 123-4567"
                className="w-full bg-[#1a1a2e] text-white pl-11 pr-4 py-3 rounded-xl border border-gray-700 focus:border-green-500 focus:outline-none transition-colors text-lg font-mono"
              />
            </div>
            <p className="text-gray-500 text-xs mt-1.5">
              Enter the phone number where you want to receive your sign-in details
            </p>
          </div>

          {/* Message Preview Toggle */}
          <button
            onClick={() => setShowPreview(!showPreview)}
            className="w-full flex items-center justify-between px-4 py-3 bg-[#1a1a2e] rounded-xl border border-gray-700 hover:border-gray-600 transition-colors"
          >
            <div className="flex items-center gap-2">
              <MessageSquare className="w-4 h-4 text-gray-400" />
              <span className="text-gray-300 text-sm">Preview SMS Message</span>
            </div>
            {showPreview ? (
              <ChevronUp className="w-4 h-4 text-gray-400" />
            ) : (
              <ChevronDown className="w-4 h-4 text-gray-400" />
            )}
          </button>

          {showPreview && (
            <div className="bg-[#0d1117] rounded-xl p-4 border border-gray-700">
              <div className="flex items-center gap-2 mb-3">
                <div className="w-8 h-8 rounded-full bg-green-500/20 flex items-center justify-center">
                  <Smartphone className="w-4 h-4 text-green-400" />
                </div>
                <div>
                  <p className="text-white text-sm font-medium">Assigned</p>
                  <p className="text-gray-500 text-xs">SMS Message</p>
                </div>
              </div>
              <div className="bg-[#1a1a2e] rounded-lg p-3 border border-gray-700">
                <pre className="text-gray-300 text-xs whitespace-pre-wrap font-mono leading-relaxed">
                  {getPreviewMessage()}
                </pre>
              </div>
              <p className="text-gray-500 text-xs mt-2 flex items-center gap-1">
                <Shield className="w-3 h-3" />
                Message is sent securely via Twilio
              </p>
            </div>
          )}

          {/* Security Notice */}
          <div className="flex items-start gap-2 px-3 py-2 rounded-lg bg-yellow-500/10 border border-yellow-500/20">
            <Shield className="w-4 h-4 text-yellow-400 mt-0.5 flex-shrink-0" />
            <p className="text-yellow-300/80 text-xs">
              Only send your sign-in information to phone numbers you own or trust. 
              Standard SMS rates may apply.
            </p>
          </div>

          {/* Result Message */}
          {result && (
            <div className={`flex items-start gap-3 p-4 rounded-xl ${
              result.success 
                ? 'bg-green-500/10 border border-green-500/20' 
                : 'bg-red-500/10 border border-red-500/20'
            }`}>
              {result.success ? (
                <CheckCircle className="w-5 h-5 text-green-400 mt-0.5 flex-shrink-0" />
              ) : (
                <XCircle className="w-5 h-5 text-red-400 mt-0.5 flex-shrink-0" />
              )}
              <div>
                <p className={`text-sm font-medium ${result.success ? 'text-green-400' : 'text-red-400'}`}>
                  {result.success ? 'SMS Sent Successfully' : 'Failed to Send'}
                </p>
                <p className={`text-xs mt-1 ${result.success ? 'text-green-400/70' : 'text-red-400/70'}`}>
                  {result.message}
                </p>
              </div>
            </div>
          )}

          {/* Confirm / Send Button */}
          {confirmSend && !sending && !result?.success ? (
            <div className="space-y-3">
              <div className="bg-orange-500/10 border border-orange-500/20 rounded-xl p-4">
                <div className="flex items-start gap-3">
                  <AlertTriangle className="w-5 h-5 text-orange-400 mt-0.5 flex-shrink-0" />
                  <div>
                    <p className="text-orange-300 text-sm font-medium">Confirm Send</p>
                    <p className="text-gray-400 text-xs mt-1">
                      You're about to send your sign-in credentials to <span className="text-white font-mono">{phoneNumber}</span>. 
                      Make sure this is your phone number.
                    </p>
                  </div>
                </div>
              </div>
              <div className="flex gap-3">
                <Button
                  onClick={() => setConfirmSend(false)}
                  variant="outline"
                  className="flex-1 border-gray-600 text-gray-300 hover:bg-gray-700"
                >
                  Cancel
                </Button>
                <Button
                  onClick={handleSend}
                  className="flex-1 bg-gradient-to-r from-green-600 to-emerald-600 hover:from-green-500 hover:to-emerald-500"
                >
                  <Send className="w-4 h-4 mr-2" />
                  Confirm & Send
                </Button>
              </div>
            </div>
          ) : (
            <Button
              onClick={handleSend}
              disabled={sending || !isValidPhone || result?.success === true}
              className="w-full bg-gradient-to-r from-green-600 to-emerald-600 hover:from-green-500 hover:to-emerald-500 disabled:opacity-50 disabled:cursor-not-allowed h-12 text-base"
            >
              {sending ? (
                <>
                  <Loader2 className="w-5 h-5 mr-2 animate-spin" />
                  Sending SMS...
                </>
              ) : result?.success ? (
                <>
                  <CheckCircle className="w-5 h-5 mr-2" />
                  Sent Successfully
                </>
              ) : (
                <>
                  <Send className="w-5 h-5 mr-2" />
                  Send Sign-In Info via SMS
                </>
              )}
            </Button>
          )}

          {/* Send Another */}
          {result?.success && (
            <button
              onClick={() => {
                setResult(null);
                setPhoneNumber('');
                setConfirmSend(false);
              }}
              className="w-full text-center text-purple-400 hover:text-purple-300 text-sm font-medium py-2 transition-colors"
            >
              Send to another number
            </button>
          )}

          {/* SMS History */}
          <div className="border-t border-gray-700 pt-4">
            <button
              onClick={() => setShowHistory(!showHistory)}
              className="w-full flex items-center justify-between px-2 py-1"
            >
              <div className="flex items-center gap-2">
                <Clock className="w-4 h-4 text-gray-400" />
                <span className="text-gray-400 text-sm">SMS History</span>
              </div>
              {showHistory ? (
                <ChevronUp className="w-4 h-4 text-gray-400" />
              ) : (
                <ChevronDown className="w-4 h-4 text-gray-400" />
              )}
            </button>

            {showHistory && (
              <div className="mt-3 space-y-2">
                {loadingHistory ? (
                  <div className="flex items-center justify-center py-4">
                    <Loader2 className="w-5 h-5 text-gray-400 animate-spin" />
                  </div>
                ) : history.length === 0 ? (
                  <p className="text-gray-500 text-sm text-center py-4">No SMS history yet</p>
                ) : (
                  history.map((item) => (
                    <div
                      key={item.id}
                      className="flex items-center justify-between bg-[#1a1a2e] rounded-lg px-3 py-2 border border-gray-700"
                    >
                      <div className="flex items-center gap-2">
                        {item.success ? (
                          <CheckCircle className="w-4 h-4 text-green-400" />
                        ) : (
                          <XCircle className="w-4 h-4 text-red-400" />
                        )}
                        <span className="text-gray-300 text-sm font-mono">{item.to_number}</span>
                      </div>
                      <span className="text-gray-500 text-xs">
                        {new Date(item.sent_at).toLocaleDateString()} {new Date(item.sent_at).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                      </span>
                    </div>
                  ))
                )}
              </div>
            )}
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
