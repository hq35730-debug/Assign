import React, { useState } from 'react';
import { Search, Hash, Phone, User, Loader2, XCircle, CheckCircle } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { Button } from '@/components/ui/button';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Link } from 'react-router-dom';

interface UserLookupProps {
  isOpen: boolean;
  onClose: () => void;
}

interface FoundProfile {
  user_id: string;
  username: string;
  display_name: string;
  avatar_url: string;
  phone_number: string;
  unique_id: number;
}

export function UserLookup({ isOpen, onClose }: UserLookupProps) {
  const [lookupType, setLookupType] = useState<'id' | 'phone'>('id');
  const [searchValue, setSearchValue] = useState('');
  const [searching, setSearching] = useState(false);
  const [result, setResult] = useState<{ found: boolean; profile?: FoundProfile } | null>(null);

  const handleSearch = async () => {
    if (!searchValue.trim()) return;
    
    setSearching(true);
    setResult(null);
    
    try {
      const action = lookupType === 'id' ? 'lookup_by_unique_id' : 'lookup_by_phone';
      const payload = lookupType === 'id' 
        ? { action, unique_id: parseInt(searchValue) }
        : { action, phone_number: searchValue.replace(/\D/g, '').length === 10 ? `+1${searchValue.replace(/\D/g, '')}` : searchValue };
      
      const { data, error } = await supabase.functions.invoke('phone-manager', {
        body: payload
      });
      
      if (error) throw error;
      
      setResult({
        found: data?.success && data?.profile,
        profile: data?.profile
      });
    } catch (err: any) {
      setResult({ found: false });
    } finally {
      setSearching(false);
    }
  };

  const formatPhoneInput = (value: string) => {
    const digits = value.replace(/\D/g, '');
    if (digits.length <= 3) return digits;
    if (digits.length <= 6) return `(${digits.slice(0, 3)}) ${digits.slice(3)}`;
    return `(${digits.slice(0, 3)}) ${digits.slice(3, 6)}-${digits.slice(6, 10)}`;
  };

  const formatPhoneDisplay = (phone: string) => {
    const cleaned = phone.replace(/\D/g, '');
    if (cleaned.length === 11 && cleaned.startsWith('1')) {
      return `+1 (${cleaned.slice(1, 4)}) ${cleaned.slice(4, 7)}-${cleaned.slice(7)}`;
    }
    return phone;
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="bg-[#16213e] border-gray-800 text-white max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Search className="w-5 h-5 text-purple-400" />
            Find User
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-4">
          {/* Lookup Type Toggle */}
          <div className="flex gap-2">
            <button
              onClick={() => { setLookupType('id'); setSearchValue(''); setResult(null); }}
              className={`flex-1 flex items-center justify-center gap-2 py-2 rounded-lg transition-colors ${
                lookupType === 'id' 
                  ? 'bg-purple-600 text-white' 
                  : 'bg-[#1a1a2e] text-gray-400 hover:text-white'
              }`}
            >
              <Hash className="w-4 h-4" />
              By ID
            </button>
            <button
              onClick={() => { setLookupType('phone'); setSearchValue(''); setResult(null); }}
              className={`flex-1 flex items-center justify-center gap-2 py-2 rounded-lg transition-colors ${
                lookupType === 'phone' 
                  ? 'bg-purple-600 text-white' 
                  : 'bg-[#1a1a2e] text-gray-400 hover:text-white'
              }`}
            >
              <Phone className="w-4 h-4" />
              By Phone
            </button>
          </div>

          {/* Search Input */}
          <div>
            <label className="text-gray-300 text-sm mb-2 block">
              {lookupType === 'id' ? 'Unique ID' : 'Phone Number'}
            </label>
            <div className="relative">
              {lookupType === 'id' ? (
                <Hash className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-500" />
              ) : (
                <Phone className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-500" />
              )}
              <input
                type={lookupType === 'id' ? 'number' : 'tel'}
                value={searchValue}
                onChange={(e) => setSearchValue(
                  lookupType === 'id' ? e.target.value : formatPhoneInput(e.target.value)
                )}
                placeholder={lookupType === 'id' ? 'Enter user ID (e.g., 1000000)' : '(555) 123-4567'}
                className="w-full bg-[#1a1a2e] text-white pl-11 pr-4 py-3 rounded-lg border border-gray-700 focus:border-purple-500 focus:outline-none"
                onKeyDown={(e) => e.key === 'Enter' && handleSearch()}
              />
            </div>
          </div>

          {/* Search Button */}
          <Button
            onClick={handleSearch}
            disabled={searching || !searchValue.trim()}
            className="w-full bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-500 hover:to-pink-500"
          >
            {searching ? (
              <>
                <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                Searching...
              </>
            ) : (
              <>
                <Search className="w-4 h-4 mr-2" />
                Search
              </>
            )}
          </Button>

          {/* Results */}
          {result && (
            <div className={`rounded-lg p-4 ${
              result.found 
                ? 'bg-green-500/10 border border-green-500/30' 
                : 'bg-red-500/10 border border-red-500/30'
            }`}>
              {result.found && result.profile ? (
                <div className="space-y-4">
                  <div className="flex items-center gap-2 text-green-400 mb-3">
                    <CheckCircle className="w-5 h-5" />
                    <span className="font-medium">User Found!</span>
                  </div>
                  
                  <div className="flex items-center gap-4">
                    <div className="w-16 h-16 rounded-full overflow-hidden bg-gradient-to-br from-purple-500 to-pink-500 p-0.5">
                      <div className="w-full h-full rounded-full overflow-hidden bg-[#1a1a2e]">
                        {result.profile.avatar_url ? (
                          <img src={result.profile.avatar_url} alt="" className="w-full h-full object-cover" />
                        ) : (
                          <div className="w-full h-full flex items-center justify-center text-2xl font-bold text-purple-400">
                            {result.profile.username[0].toUpperCase()}
                          </div>
                        )}
                      </div>
                    </div>
                    <div className="flex-1">
                      <p className="text-white font-semibold text-lg">
                        {result.profile.display_name || result.profile.username}
                      </p>
                      <p className="text-gray-400">@{result.profile.username}</p>
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-3">
                    <div className="bg-[#1a1a2e] rounded-lg p-3">
                      <div className="flex items-center gap-2 text-gray-400 text-xs mb-1">
                        <Hash className="w-3 h-3" />
                        Unique ID
                      </div>
                      <p className="text-purple-400 font-mono font-semibold">{result.profile.unique_id}</p>
                    </div>
                    <div className="bg-[#1a1a2e] rounded-lg p-3">
                      <div className="flex items-center gap-2 text-gray-400 text-xs mb-1">
                        <Phone className="w-3 h-3" />
                        Phone
                      </div>
                      <p className="text-green-400 font-mono text-sm">{formatPhoneDisplay(result.profile.phone_number)}</p>
                    </div>
                  </div>

                  <Link 
                    to={`/profile/${result.profile.username}`}
                    onClick={onClose}
                    className="block w-full bg-purple-600 hover:bg-purple-500 text-white text-center py-2 rounded-lg font-medium transition-colors"
                  >
                    View Profile
                  </Link>
                </div>
              ) : (
                <div className="flex items-center gap-2 text-red-400">
                  <XCircle className="w-5 h-5" />
                  <span>No user found with that {lookupType === 'id' ? 'ID' : 'phone number'}</span>
                </div>
              )}
            </div>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
}
