
import React, { useState, useRef, useEffect } from 'react';
import { X, Play, Pause, Volume2, VolumeX, Maximize, SkipBack, SkipForward, Settings } from 'lucide-react';
import { VOD } from './VODCard';

interface VODPlayerProps {
  vod: VOD;
  isOpen: boolean;
  onClose: () => void;
}

const formatTime = (seconds: number): string => {
  const hrs = Math.floor(seconds / 3600);
  const mins = Math.floor((seconds % 3600) / 60);
  const secs = Math.floor(seconds % 60);
  if (hrs > 0) return `${hrs}:${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  return `${mins}:${secs.toString().padStart(2, '0')}`;
};

export const VODPlayer: React.FC<VODPlayerProps> = ({ vod, isOpen, onClose }) => {
  const [isPlaying, setIsPlaying] = useState(false);
  const [currentTime, setCurrentTime] = useState(0);
  const [volume, setVolume] = useState(1);
  const [isMuted, setIsMuted] = useState(false);
  const [showControls, setShowControls] = useState(true);
  const progressRef = useRef<HTMLDivElement>(null);
  const controlsTimeout = useRef<NodeJS.Timeout>();

  useEffect(() => {
    if (isOpen) {
      setCurrentTime(0);
      setIsPlaying(false);
    }
  }, [isOpen, vod.id]);

  useEffect(() => {
    let interval: NodeJS.Timeout;
    if (isPlaying && currentTime < vod.duration) {
      interval = setInterval(() => setCurrentTime(prev => Math.min(prev + 1, vod.duration)), 1000);
    }
    return () => clearInterval(interval);
  }, [isPlaying, currentTime, vod.duration]);

  const handleProgressClick = (e: React.MouseEvent<HTMLDivElement>) => {
    if (!progressRef.current) return;
    const rect = progressRef.current.getBoundingClientRect();
    const percent = (e.clientX - rect.left) / rect.width;
    setCurrentTime(Math.floor(percent * vod.duration));
  };

  const handleMouseMove = () => {
    setShowControls(true);
    if (controlsTimeout.current) clearTimeout(controlsTimeout.current);
    controlsTimeout.current = setTimeout(() => isPlaying && setShowControls(false), 3000);
  };

  const skip = (seconds: number) => setCurrentTime(prev => Math.max(0, Math.min(vod.duration, prev + seconds)));

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black z-50 flex flex-col" onMouseMove={handleMouseMove}>
      <div className={`absolute top-0 left-0 right-0 p-4 bg-gradient-to-b from-black/80 to-transparent z-10 transition-opacity ${showControls ? 'opacity-100' : 'opacity-0'}`}>
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-white font-bold text-lg">{vod.title}</h2>
            <p className="text-gray-400 text-sm">{vod.streamer_name} • {vod.category}</p>
          </div>
          <button onClick={onClose} className="text-white hover:text-purple-400 p-2"><X className="w-6 h-6" /></button>
        </div>
      </div>

      <div className="flex-1 flex items-center justify-center cursor-pointer" onClick={() => setIsPlaying(!isPlaying)}>
        <img src={vod.thumbnail_url || 'https://d64gsuwffb70l.cloudfront.net/6927ca8790687cc18bcac914_1764565042610_75ffd34f.webp'} alt={vod.title} className="max-h-full max-w-full object-contain" />
        {!isPlaying && (
          <div className="absolute inset-0 flex items-center justify-center">
            <div className="w-20 h-20 rounded-full bg-purple-600/90 flex items-center justify-center cursor-pointer hover:bg-purple-500 transition-colors">
              <Play className="w-10 h-10 text-white ml-1" fill="white" />
            </div>
          </div>
        )}
      </div>

      <div className={`absolute bottom-0 left-0 right-0 p-4 bg-gradient-to-t from-black/80 to-transparent transition-opacity ${showControls ? 'opacity-100' : 'opacity-0'}`}>
        <div ref={progressRef} className="h-1 bg-gray-700 rounded-full cursor-pointer mb-4 group" onClick={handleProgressClick}>
          <div className="h-full bg-purple-600 rounded-full relative" style={{ width: `${(currentTime / vod.duration) * 100}%` }}>
            <div className="absolute right-0 top-1/2 -translate-y-1/2 w-3 h-3 bg-white rounded-full opacity-0 group-hover:opacity-100 transition-opacity" />
          </div>
        </div>
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-4">
            <button onClick={() => skip(-10)} className="text-white hover:text-purple-400"><SkipBack className="w-5 h-5" /></button>
            <button onClick={() => setIsPlaying(!isPlaying)} className="text-white hover:text-purple-400">{isPlaying ? <Pause className="w-6 h-6" /> : <Play className="w-6 h-6" />}</button>
            <button onClick={() => skip(10)} className="text-white hover:text-purple-400"><SkipForward className="w-5 h-5" /></button>
            <span className="text-white text-sm">{formatTime(currentTime)} / {formatTime(vod.duration)}</span>
          </div>
          <div className="flex items-center gap-4">
            <button onClick={() => setIsMuted(!isMuted)} className="text-white hover:text-purple-400">{isMuted ? <VolumeX className="w-5 h-5" /> : <Volume2 className="w-5 h-5" />}</button>
            <button className="text-white hover:text-purple-400"><Settings className="w-5 h-5" /></button>
            <button className="text-white hover:text-purple-400"><Maximize className="w-5 h-5" /></button>
          </div>
        </div>
      </div>
    </div>
  );
};
