import React, { useState } from 'react';
import { Dialog, DialogContent, DialogTitle } from '@/components/ui/dialog';
import { VisuallyHidden } from '@/components/ui/visually-hidden';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { X, Heart, Share2, Eye, Copy, Twitter, Facebook, Check } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { useToast } from '@/hooks/use-toast';

interface Clip {
  id: string;
  title: string;
  streamer_name: string;
  creator_name: string;
  thumbnail_url: string;
  video_url: string;
  duration: number;
  views: number;
  likes: number;
  shares: number;
  created_at: string;
}

interface ClipModalProps {
  clip: Clip | null;
  isOpen: boolean;
  onClose: () => void;
}

export const ClipModal: React.FC<ClipModalProps> = ({ clip, isOpen, onClose }) => {
  const [liked, setLiked] = useState(false);
  const [copied, setCopied] = useState(false);
  const { toast } = useToast();

  if (!clip) return null;

  const clipUrl = `${window.location.origin}/clip/${clip.id}`;

  const handleLike = async () => {
    if (liked) return;
    setLiked(true);
    await supabase.functions.invoke('clips-manager', { body: { action: 'like_clip', clip_id: clip.id } });
  };

  const handleShare = async (platform: string) => {
    await supabase.functions.invoke('clips-manager', { body: { action: 'share_clip', clip_id: clip.id } });
    const text = `Check out this clip: ${clip.title}`;
    if (platform === 'twitter') window.open(`https://twitter.com/intent/tweet?text=${encodeURIComponent(text)}&url=${encodeURIComponent(clipUrl)}`, '_blank');
    else if (platform === 'facebook') window.open(`https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(clipUrl)}`, '_blank');
    else {
      navigator.clipboard.writeText(clipUrl);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
      toast({ title: 'Link Copied!', description: 'Clip URL copied to clipboard' });
    }
  };

  const formatViews = (n: number) => n >= 1000 ? `${(n/1000).toFixed(1)}K` : n.toString();

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="bg-gray-900 border-gray-700 text-white max-w-3xl p-0 overflow-hidden">
        <VisuallyHidden>
          <DialogTitle>{clip.title}</DialogTitle>
        </VisuallyHidden>
        <Button variant="ghost" size="icon" onClick={onClose} className="absolute top-2 right-2 z-10 text-white hover:bg-gray-800"><X className="w-5 h-5" /></Button>
        
        <div className="aspect-video bg-black relative">
          <img src={clip.thumbnail_url} alt={clip.title} className="w-full h-full object-cover" />
          <div className="absolute inset-0 flex items-center justify-center">
            <div className="w-20 h-20 rounded-full bg-purple-600/80 flex items-center justify-center cursor-pointer hover:bg-purple-600 transition-colors">
              <svg className="w-8 h-8 text-white ml-1" fill="currentColor" viewBox="0 0 24 24"><path d="M8 5v14l11-7z"/></svg>
            </div>
          </div>
        </div>

        <div className="p-4 space-y-4">
          <div>
            <h2 className="text-xl font-bold">{clip.title}</h2>
            <p className="text-gray-400 text-sm mt-1">Clipped from <span className="text-purple-400">{clip.streamer_name}</span> by {clip.creator_name}</p>
          </div>
          <div className="flex items-center gap-4">
            <span className="flex items-center gap-1 text-gray-400"><Eye className="w-4 h-4" />{formatViews(clip.views)} views</span>
            <Button variant={liked ? "default" : "outline"} size="sm" onClick={handleLike} className={liked ? "bg-pink-600" : "border-gray-600"}>
              <Heart className={`w-4 h-4 mr-1 ${liked ? 'fill-white' : ''}`} />{clip.likes + (liked ? 1 : 0)}
            </Button>
            <span className="flex items-center gap-1 text-gray-400"><Share2 className="w-4 h-4" />{clip.shares}</span>
          </div>
          <div className="border-t border-gray-700 pt-4">
            <p className="text-sm text-gray-400 mb-2">Share this clip</p>
            <div className="flex gap-2">
              <Button onClick={() => handleShare('twitter')} className="bg-[#1DA1F2] hover:bg-[#1a8cd8]"><Twitter className="w-4 h-4 mr-2" />Twitter</Button>
              <Button onClick={() => handleShare('facebook')} className="bg-[#4267B2] hover:bg-[#375695]"><Facebook className="w-4 h-4 mr-2" />Facebook</Button>
              <div className="flex-1 flex gap-2">
                <Input value={clipUrl} readOnly className="bg-gray-800 border-gray-600 text-sm" />
                <Button onClick={() => handleShare('copy')} variant="outline" className="border-gray-600">{copied ? <Check className="w-4 h-4" /> : <Copy className="w-4 h-4" />}</Button>
              </div>
            </div>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
};
