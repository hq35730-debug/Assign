
import { Shield, Star, Crown, Diamond } from 'lucide-react';

interface VIPChatBadgeProps {
  tierLevel?: number;
  badgeColor?: string;
}

export function VIPChatBadge({ tierLevel, badgeColor }: VIPChatBadgeProps) {
  if (!tierLevel || !badgeColor) return null;

  const className = "w-4 h-4";
  const style = { color: badgeColor };

  switch (tierLevel) {
    case 1: return <Shield className={className} style={style} />;
    case 2: return <Star className={className} style={style} fill={badgeColor} />;
    case 3: return <Crown className={className} style={style} fill={badgeColor} />;
    case 4: return <Diamond className={className} style={style} fill={badgeColor} />;
    default: return null;
  }
}
