import { Check, Lock, Coins, MessageSquare, Tv, Smile, Crown } from 'lucide-react';
import { Card } from '@/components/ui/card';
import { VIPBadge } from './VIPBadge';

interface Tier {
  id: string;
  name: string;
  tier_level: number;
  badge_color: string;
  min_coins_spent: number;
  benefits: string[];
  bonus_coin_percent: number;
  priority_chat: boolean;
  ad_free: boolean;
  exclusive_emotes: boolean;
}

interface VIPBenefitsProps {
  tiers: Tier[];
  currentTierLevel: number;
}

export function VIPBenefits({ tiers, currentTierLevel }: VIPBenefitsProps) {
  const getBenefitIcon = (benefit: string) => {
    if (benefit.includes('Bonus Coins')) return <Coins className="w-4 h-4" />;
    if (benefit.includes('Priority') || benefit.includes('Chat')) return <MessageSquare className="w-4 h-4" />;
    if (benefit.includes('Ad-Free')) return <Tv className="w-4 h-4" />;
    if (benefit.includes('Emotes')) return <Smile className="w-4 h-4" />;
    if (benefit.includes('Badge')) return <Crown className="w-4 h-4" />;
    return <Check className="w-4 h-4" />;
  };

  const safeTiers = Array.isArray(tiers) ? tiers : [];

  if (safeTiers.length === 0) {
    return (
      <Card className="p-8 text-center text-muted-foreground">
        <Crown className="w-12 h-12 mx-auto mb-4 opacity-50" />
        <p>No VIP tiers available</p>
      </Card>
    );
  }

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
      {safeTiers.map((tier) => {
        const isUnlocked = tier.tier_level <= currentTierLevel;
        const isCurrent = tier.tier_level === currentTierLevel;
        const safeBenefits = Array.isArray(tier.benefits) ? tier.benefits : [];
        
        return (
          <Card 
            key={tier.id} 
            className={`p-4 relative overflow-hidden transition-all ${
              isCurrent ? 'ring-2' : isUnlocked ? 'opacity-80' : 'opacity-60'
            }`}
            style={{ 
              borderColor: isCurrent ? tier.badge_color : undefined,
              boxShadow: isCurrent ? `0 0 20px ${tier.badge_color}40` : undefined
            }}
          >
            {isCurrent && (
              <div className="absolute top-0 right-0 px-2 py-1 text-xs font-bold text-white rounded-bl" style={{ backgroundColor: tier.badge_color }}>
                CURRENT
              </div>
            )}
            
            <div className="flex items-center gap-2 mb-3">
              <VIPBadge tier={tier} size="lg" />
              <div>
                <h3 className="font-bold" style={{ color: tier.badge_color }}>{tier.name}</h3>
                <p className="text-xs text-muted-foreground">{(tier.min_coins_spent || 0).toLocaleString()} coins</p>
              </div>
            </div>

            <ul className="space-y-2">
              {safeBenefits.map((benefit, i) => (
                <li key={i} className="flex items-start gap-2 text-sm">
                  {isUnlocked ? (
                    <span style={{ color: tier.badge_color }}>{getBenefitIcon(benefit)}</span>
                  ) : (
                    <Lock className="w-4 h-4 text-gray-500" />
                  )}
                  <span className={isUnlocked ? 'text-foreground' : 'text-muted-foreground'}>{benefit}</span>
                </li>
              ))}
            </ul>
          </Card>
        );
      })}
    </div>
  );
}
