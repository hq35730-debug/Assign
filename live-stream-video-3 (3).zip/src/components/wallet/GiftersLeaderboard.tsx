import { useState, useEffect } from 'react';
import { Gift, Trophy, Medal } from 'lucide-react';
import { Card } from '@/components/ui/card';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { supabase } from '@/lib/supabase';

interface Gifter {
  user_id: string;
  total_spent: number;
  username?: string;
  avatar?: string;
}

export function GiftersLeaderboard() {
  const [gifters, setGifters] = useState<Gifter[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadGifters();
  }, []);

  const loadGifters = async () => {
    try {
      const { data } = await supabase.functions.invoke('gifts-manager', {
        body: { action: 'get_top_gifters', limit: 10 }
      });
      const giftersData = Array.isArray(data?.gifters) ? data.gifters : [];
      setGifters(giftersData.map((g: any, i: number) => ({
        ...g,
        username: `User${i + 1}`,
        avatar: `https://api.dicebear.com/7.x/avataaars/svg?seed=${g.user_id}`
      })));
    } catch (err) {
      console.error('Error loading gifters:', err);
      setGifters([]);
    }
    setLoading(false);
  };

  const getRankIcon = (rank: number) => {
    if (rank === 0) return <Trophy className="w-5 h-5 text-yellow-500" />;
    if (rank === 1) return <Medal className="w-5 h-5 text-gray-400" />;
    if (rank === 2) return <Medal className="w-5 h-5 text-amber-600" />;
    return <span className="w-5 h-5 text-center text-sm font-bold">{rank + 1}</span>;
  };

  if (loading) return <div className="text-center py-4">Loading...</div>;

  const safeGifters = Array.isArray(gifters) ? gifters : [];

  return (
    <Card className="p-4">
      <h3 className="text-lg font-semibold mb-4 flex items-center gap-2">
        <Gift className="w-5 h-5 text-purple-500" /> Top Gifters
      </h3>
      <div className="space-y-3">
        {safeGifters.length === 0 ? (
          <p className="text-center text-muted-foreground py-4">No gifters yet</p>
        ) : (
          safeGifters.map((gifter, index) => (
            <div key={gifter.user_id || index} className="flex items-center gap-3">
              <div className="w-6 flex justify-center">{getRankIcon(index)}</div>
              <Avatar className="w-8 h-8">
                <AvatarImage src={gifter.avatar} />
                <AvatarFallback>{gifter.username?.[0] || 'U'}</AvatarFallback>
              </Avatar>
              <span className="flex-1 font-medium">{gifter.username || 'Unknown'}</span>
              <span className="text-purple-500 font-bold">
                {(gifter.total_spent || 0).toLocaleString()} coins
              </span>
            </div>
          ))
        )}
      </div>
    </Card>
  );
}
