
import { Shield, Star, Crown, Diamond } from 'lucide-react';

interface VIPBadgeProps {
  tier?: {
    name: string;
    tier_level: number;
    badge_color: string;
  } | null;
  size?: 'sm' | 'md' | 'lg';
  showLabel?: boolean;
}

export function VIPBadge({ tier, size = 'sm', showLabel = false }: VIPBadgeProps) {
  if (!tier) return null;

  const sizeClasses = {
    sm: 'w-4 h-4',
    md: 'w-5 h-5',
    lg: 'w-6 h-6'
  };

  const getIcon = () => {
    const className = sizeClasses[size];
    const style = { color: tier.badge_color };
    
    switch (tier.tier_level) {
      case 1: return <Shield className={className} style={style} />;
      case 2: return <Star className={className} style={style} fill={tier.badge_color} />;
      case 3: return <Crown className={className} style={style} fill={tier.badge_color} />;
      case 4: return <Diamond className={className} style={style} fill={tier.badge_color} />;
      default: return null;
    }
  };

  if (showLabel) {
    return (
      <div className="flex items-center gap-1.5 px-2 py-0.5 rounded-full" style={{ backgroundColor: `${tier.badge_color}20` }}>
        {getIcon()}
        <span className="text-xs font-semibold" style={{ color: tier.badge_color }}>{tier.name}</span>
      </div>
    );
  }

  return getIcon();
}
