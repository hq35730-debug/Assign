import React, { useState, useEffect } from 'react';
import { 
  Building2, 
  CreditCard, 
  CheckCircle, 
  AlertCircle, 
  ExternalLink, 
  Shield, 
  Clock,
  DollarSign,
  RefreshCw,
  ChevronRight,
  Banknote,
  Wallet,
  ArrowUpRight,
  FileText,
  Lock,
  Globe
} from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { useToast } from '@/hooks/use-toast';

interface BankAccountSettingsProps {
  userId: string;
  email?: string;
  onAccountConnected?: () => void;
}

interface AccountStatus {
  connected: boolean;
  complete: boolean;
  account_id?: string;
  payouts_enabled?: boolean;
  charges_enabled?: boolean;
  details_submitted?: boolean;
  bank_accounts?: BankAccount[];
  pending_verification?: boolean;
  requirements?: string[];
}

interface BankAccount {
  id: string;
  bank_name: string;
  last4: string;
  currency: string;
  country: string;
  default: boolean;
  status: 'verified' | 'pending' | 'errored';
}

interface PayoutSchedule {
  interval: 'daily' | 'weekly' | 'monthly' | 'manual';
  delay_days: number;
  anchor?: number;
}

export function BankAccountSettings({ userId, email, onAccountConnected }: BankAccountSettingsProps) {
  const { toast } = useToast();
  const [loading, setLoading] = useState(true);
  const [processing, setProcessing] = useState(false);
  const [accountStatus, setAccountStatus] = useState<AccountStatus>({
    connected: false,
    complete: false
  });
  const [payoutSchedule, setPayoutSchedule] = useState<PayoutSchedule>({
    interval: 'daily',
    delay_days: 2
  });
  const [showScheduleModal, setShowScheduleModal] = useState(false);
  const [availableBalance, setAvailableBalance] = useState(0);
  const [pendingBalance, setPendingBalance] = useState(0);

  useEffect(() => {
    loadAccountStatus();
  }, [userId]);

  const loadAccountStatus = async () => {
    setLoading(true);
    try {
      const { data, error } = await supabase.functions.invoke('earnings-manager', {
        body: { action: 'check_account_status', streamer_id: userId }
      });

      if (data) {
        setAccountStatus({
          connected: data.connected || false,
          complete: data.complete || false,
          account_id: data.account_id,
          payouts_enabled: data.payouts_enabled,
          charges_enabled: data.charges_enabled,
          details_submitted: data.details_submitted,
          bank_accounts: data.bank_accounts || [],
          pending_verification: data.pending_verification,
          requirements: data.requirements || []
        });

        if (data.balance) {
          setAvailableBalance(data.balance.available || 0);
          setPendingBalance(data.balance.pending || 0);
        }

        if (data.payout_schedule) {
          setPayoutSchedule(data.payout_schedule);
        }
      }
    } catch (error) {
      console.error('Failed to load account status:', error);
    }
    setLoading(false);
  };

  const connectStripeAccount = async () => {
    setProcessing(true);
    try {
      const { data, error } = await supabase.functions.invoke('earnings-manager', {
        body: { 
          action: 'create_connect_account', 
          streamer_id: userId, 
          email: email 
        }
      });

      if (data?.url) {
        window.location.href = data.url;
      } else {
        toast({
          title: 'Error',
          description: error?.message || 'Failed to connect account',
          variant: 'destructive'
        });
      }
    } catch (error) {
      toast({
        title: 'Error',
        description: 'Failed to connect account',
        variant: 'destructive'
      });
    }
    setProcessing(false);
  };

  const openStripeDashboard = async () => {
    setProcessing(true);
    try {
      const { data, error } = await supabase.functions.invoke('earnings-manager', {
        body: { 
          action: 'create_dashboard_link', 
          streamer_id: userId 
        }
      });

      if (data?.url) {
        window.open(data.url, '_blank');
      } else {
        toast({
          title: 'Error',
          description: 'Failed to open dashboard',
          variant: 'destructive'
        });
      }
    } catch (error) {
      toast({
        title: 'Error',
        description: 'Failed to open dashboard',
        variant: 'destructive'
      });
    }
    setProcessing(false);
  };

  const updatePayoutSchedule = async (schedule: PayoutSchedule) => {
    setProcessing(true);
    try {
      const { data, error } = await supabase.functions.invoke('earnings-manager', {
        body: { 
          action: 'update_payout_schedule', 
          streamer_id: userId,
          schedule
        }
      });

      if (data?.success) {
        setPayoutSchedule(schedule);
        setShowScheduleModal(false);
        toast({
          title: 'Schedule Updated',
          description: 'Your payout schedule has been updated'
        });
      } else {
        toast({
          title: 'Error',
          description: error?.message || 'Failed to update schedule',
          variant: 'destructive'
        });
      }
    } catch (error) {
      toast({
        title: 'Error',
        description: 'Failed to update schedule',
        variant: 'destructive'
      });
    }
    setProcessing(false);
  };

  const requestInstantPayout = async () => {
    if (availableBalance < 100) {
      toast({
        title: 'Insufficient Balance',
        description: 'Minimum payout is $1.00',
        variant: 'destructive'
      });
      return;
    }

    setProcessing(true);
    try {
      const { data, error } = await supabase.functions.invoke('earnings-manager', {
        body: { 
          action: 'request_payout', 
          streamer_id: userId,
          amount: availableBalance
        }
      });

      if (data?.success) {
        toast({
          title: 'Payout Initiated',
          description: `$${(availableBalance / 100).toFixed(2)} is being transferred to your bank`
        });
        loadAccountStatus();
        onAccountConnected?.();
      } else {
        toast({
          title: 'Error',
          description: error?.message || 'Payout failed',
          variant: 'destructive'
        });
      }
    } catch (error) {
      toast({
        title: 'Error',
        description: 'Payout failed',
        variant: 'destructive'
      });
    }
    setProcessing(false);
  };

  if (loading) {
    return (
      <div className="bg-[#16213e] rounded-2xl p-8 border border-gray-800">
        <div className="flex items-center justify-center gap-3">
          <RefreshCw className="w-6 h-6 text-purple-400 animate-spin" />
          <span className="text-gray-400">Loading account status...</span>
        </div>
      </div>
    );
  }

  // Not connected state
  if (!accountStatus.connected) {
    return (
      <div className="bg-gradient-to-br from-purple-900/40 to-pink-900/40 rounded-2xl p-8 border border-purple-500/30">
        <div className="flex flex-col md:flex-row items-start gap-6">
          <div className="p-4 bg-gradient-to-r from-purple-600 to-pink-600 rounded-2xl flex-shrink-0">
            <Building2 className="w-10 h-10 text-white" />
          </div>
          <div className="flex-1">
            <h3 className="text-2xl font-bold text-white mb-2">Connect Your Bank Account</h3>
            <p className="text-gray-300 mb-6">
              Set up your payout account to receive earnings directly to your bank. 
              We use Stripe for secure, reliable payments.
            </p>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
              <div className="flex items-center gap-3 p-3 bg-[#1a1a2e] rounded-lg">
                <Shield className="w-5 h-5 text-green-400" />
                <div>
                  <p className="text-white text-sm font-medium">Bank-Level Security</p>
                  <p className="text-gray-500 text-xs">256-bit encryption</p>
                </div>
              </div>
              <div className="flex items-center gap-3 p-3 bg-[#1a1a2e] rounded-lg">
                <Clock className="w-5 h-5 text-blue-400" />
                <div>
                  <p className="text-white text-sm font-medium">Fast Payouts</p>
                  <p className="text-gray-500 text-xs">1-2 business days</p>
                </div>
              </div>
              <div className="flex items-center gap-3 p-3 bg-[#1a1a2e] rounded-lg">
                <Globe className="w-5 h-5 text-purple-400" />
                <div>
                  <p className="text-white text-sm font-medium">Global Support</p>
                  <p className="text-gray-500 text-xs">40+ countries</p>
                </div>
              </div>
            </div>

            <button
              onClick={connectStripeAccount}
              disabled={processing}
              className="bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-500 hover:to-pink-500 text-white px-8 py-3 rounded-xl font-semibold transition-all flex items-center gap-2 disabled:opacity-50"
            >
              {processing ? (
                <>
                  <RefreshCw className="w-5 h-5 animate-spin" />
                  Connecting...
                </>
              ) : (
                <>
                  <CreditCard className="w-5 h-5" />
                  Connect with Stripe
                  <ExternalLink className="w-4 h-4" />
                </>
              )}
            </button>
          </div>
        </div>
      </div>
    );
  }

  // Connected but incomplete
  if (!accountStatus.complete) {
    return (
      <div className="bg-yellow-900/30 rounded-2xl p-8 border border-yellow-500/30">
        <div className="flex items-start gap-4">
          <div className="p-3 bg-yellow-600 rounded-xl">
            <AlertCircle className="w-6 h-6 text-white" />
          </div>
          <div className="flex-1">
            <h3 className="text-xl font-bold text-white mb-2">Complete Your Account Setup</h3>
            <p className="text-gray-300 mb-4">
              Your account is connected but requires additional information before you can receive payouts.
            </p>
            
            {accountStatus.requirements && accountStatus.requirements.length > 0 && (
              <div className="bg-[#1a1a2e] rounded-lg p-4 mb-4">
                <p className="text-yellow-400 text-sm font-medium mb-2">Required Information:</p>
                <ul className="space-y-1">
                  {accountStatus.requirements.map((req, i) => (
                    <li key={i} className="text-gray-400 text-sm flex items-center gap-2">
                      <div className="w-1.5 h-1.5 bg-yellow-400 rounded-full" />
                      {req}
                    </li>
                  ))}
                </ul>
              </div>
            )}

            <button
              onClick={connectStripeAccount}
              disabled={processing}
              className="bg-yellow-600 hover:bg-yellow-500 text-white px-6 py-2 rounded-lg font-semibold transition-colors flex items-center gap-2 disabled:opacity-50"
            >
              {processing ? 'Loading...' : 'Complete Setup'}
              <ExternalLink className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>
    );
  }

  // Fully connected state
  return (
    <div className="space-y-6">
      {/* Account Status Card */}
      <div className="bg-gradient-to-r from-green-900/30 to-emerald-900/30 rounded-2xl p-6 border border-green-500/30">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-green-600 rounded-lg">
              <CheckCircle className="w-5 h-5 text-white" />
            </div>
            <div>
              <h3 className="text-white font-semibold">Bank Account Connected</h3>
              <p className="text-green-400 text-sm">Ready to receive payouts</p>
            </div>
          </div>
          <button
            onClick={openStripeDashboard}
            disabled={processing}
            className="text-green-400 hover:text-green-300 flex items-center gap-1 text-sm"
          >
            Manage Account <ExternalLink className="w-4 h-4" />
          </button>
        </div>

        {/* Bank Account Info */}
        {accountStatus.bank_accounts && accountStatus.bank_accounts.length > 0 && (
          <div className="bg-[#1a1a2e] rounded-xl p-4 mb-4">
            {accountStatus.bank_accounts.map((bank) => (
              <div key={bank.id} className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <Building2 className="w-5 h-5 text-gray-400" />
                  <div>
                    <p className="text-white font-medium">{bank.bank_name}</p>
                    <p className="text-gray-500 text-sm">
                      ••••{bank.last4} • {bank.currency.toUpperCase()}
                    </p>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  {bank.default && (
                    <span className="text-xs bg-green-600/20 text-green-400 px-2 py-1 rounded">
                      Default
                    </span>
                  )}
                  {bank.status === 'verified' ? (
                    <CheckCircle className="w-5 h-5 text-green-400" />
                  ) : bank.status === 'pending' ? (
                    <Clock className="w-5 h-5 text-yellow-400" />
                  ) : (
                    <AlertCircle className="w-5 h-5 text-red-400" />
                  )}
                </div>
              </div>
            ))}
          </div>
        )}

        {/* Balance Overview */}
        <div className="grid grid-cols-2 gap-4">
          <div className="bg-[#1a1a2e] rounded-xl p-4">
            <div className="flex items-center gap-2 text-gray-400 mb-1">
              <Wallet className="w-4 h-4" />
              <span className="text-sm">Available Balance</span>
            </div>
            <p className="text-2xl font-bold text-white">
              ${(availableBalance / 100).toFixed(2)}
            </p>
          </div>
          <div className="bg-[#1a1a2e] rounded-xl p-4">
            <div className="flex items-center gap-2 text-gray-400 mb-1">
              <Clock className="w-4 h-4" />
              <span className="text-sm">Pending</span>
            </div>
            <p className="text-2xl font-bold text-gray-400">
              ${(pendingBalance / 100).toFixed(2)}
            </p>
          </div>
        </div>
      </div>

      {/* Payout Actions */}
      <div className="bg-[#16213e] rounded-2xl p-6 border border-gray-800">
        <h3 className="text-lg font-bold text-white mb-4 flex items-center gap-2">
          <Banknote className="w-5 h-5 text-green-400" />
          Payout Options
        </h3>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {/* Instant Payout */}
          <button
            onClick={requestInstantPayout}
            disabled={processing || availableBalance < 100}
            className="p-4 bg-gradient-to-r from-green-600/20 to-emerald-600/20 border border-green-500/30 rounded-xl text-left hover:border-green-500/50 transition-all disabled:opacity-50 disabled:cursor-not-allowed"
          >
            <div className="flex items-center justify-between mb-2">
              <div className="flex items-center gap-2">
                <ArrowUpRight className="w-5 h-5 text-green-400" />
                <span className="text-white font-medium">Instant Payout</span>
              </div>
              <ChevronRight className="w-5 h-5 text-gray-500" />
            </div>
            <p className="text-gray-400 text-sm">
              Transfer ${(availableBalance / 100).toFixed(2)} to your bank now
            </p>
            <p className="text-green-400 text-xs mt-1">1.5% fee • Arrives in minutes</p>
          </button>

          {/* Payout Schedule */}
          <button
            onClick={() => setShowScheduleModal(true)}
            className="p-4 bg-[#1a1a2e] border border-gray-700 rounded-xl text-left hover:border-gray-600 transition-all"
          >
            <div className="flex items-center justify-between mb-2">
              <div className="flex items-center gap-2">
                <Clock className="w-5 h-5 text-blue-400" />
                <span className="text-white font-medium">Payout Schedule</span>
              </div>
              <ChevronRight className="w-5 h-5 text-gray-500" />
            </div>
            <p className="text-gray-400 text-sm">
              Currently: {payoutSchedule.interval.charAt(0).toUpperCase() + payoutSchedule.interval.slice(1)}
            </p>
            <p className="text-blue-400 text-xs mt-1">No fee • 1-2 business days</p>
          </button>
        </div>
      </div>

      {/* Tax Documents */}
      <div className="bg-[#16213e] rounded-2xl p-6 border border-gray-800">
        <h3 className="text-lg font-bold text-white mb-4 flex items-center gap-2">
          <FileText className="w-5 h-5 text-purple-400" />
          Tax Documents
        </h3>
        <p className="text-gray-400 text-sm mb-4">
          Access your tax forms and earnings statements for tax filing purposes.
        </p>
        <button
          onClick={openStripeDashboard}
          className="text-purple-400 hover:text-purple-300 flex items-center gap-2 text-sm"
        >
          View Tax Documents <ExternalLink className="w-4 h-4" />
        </button>
      </div>

      {/* Security Info */}
      <div className="bg-[#1a1a2e] rounded-xl p-4 border border-gray-700">
        <div className="flex items-center gap-3">
          <Lock className="w-5 h-5 text-gray-400" />
          <div>
            <p className="text-gray-300 text-sm">
              Your banking information is securely stored by Stripe and never touches our servers.
            </p>
          </div>
        </div>
      </div>

      {/* Payout Schedule Modal */}
      {showScheduleModal && (
        <div className="fixed inset-0 bg-black/80 flex items-center justify-center z-50 p-4">
          <div className="bg-[#16213e] rounded-2xl p-6 w-full max-w-md border border-gray-700">
            <h3 className="text-xl font-bold text-white mb-4">Payout Schedule</h3>
            <p className="text-gray-400 text-sm mb-6">
              Choose how often you want to receive automatic payouts to your bank account.
            </p>

            <div className="space-y-3 mb-6">
              {[
                { value: 'daily', label: 'Daily', desc: 'Every business day' },
                { value: 'weekly', label: 'Weekly', desc: 'Every Monday' },
                { value: 'monthly', label: 'Monthly', desc: 'First of each month' },
                { value: 'manual', label: 'Manual', desc: 'Only when you request' }
              ].map((option) => (
                <button
                  key={option.value}
                  onClick={() => setPayoutSchedule(prev => ({ ...prev, interval: option.value as any }))}
                  className={`w-full p-4 rounded-xl border text-left transition-all ${
                    payoutSchedule.interval === option.value
                      ? 'border-purple-500 bg-purple-600/10'
                      : 'border-gray-700 hover:border-gray-600'
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-white font-medium">{option.label}</p>
                      <p className="text-gray-500 text-sm">{option.desc}</p>
                    </div>
                    {payoutSchedule.interval === option.value && (
                      <CheckCircle className="w-5 h-5 text-purple-400" />
                    )}
                  </div>
                </button>
              ))}
            </div>

            <div className="flex gap-3">
              <button
                onClick={() => setShowScheduleModal(false)}
                className="flex-1 py-3 bg-gray-700 hover:bg-gray-600 text-white rounded-lg font-semibold"
              >
                Cancel
              </button>
              <button
                onClick={() => updatePayoutSchedule(payoutSchedule)}
                disabled={processing}
                className="flex-1 py-3 bg-purple-600 hover:bg-purple-500 text-white rounded-lg font-semibold disabled:opacity-50"
              >
                {processing ? 'Saving...' : 'Save Schedule'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
