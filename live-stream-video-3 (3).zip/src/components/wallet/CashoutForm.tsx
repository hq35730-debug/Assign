
import { useState, useEffect } from 'react';
import { Banknote, AlertCircle } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { supabase } from '@/lib/supabase';

interface CashoutFormProps {
  userId: string;
  balance: number;
  onSuccess?: () => void;
}

export function CashoutForm({ userId, balance, onSuccess }: CashoutFormProps) {
  const [amount, setAmount] = useState('');
  const [method, setMethod] = useState('paypal');
  const [email, setEmail] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const coinsAmount = parseInt(amount) || 0;
  const usdAmount = coinsAmount / 100;
  const minCashout = 5000;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (coinsAmount < minCashout) {
      setError(`Minimum cashout is ${minCashout} coins ($${minCashout / 100})`);
      return;
    }
    if (coinsAmount > balance) {
      setError('Insufficient balance');
      return;
    }
    if (!email) {
      setError('Please enter your payout email');
      return;
    }

    setLoading(true);
    setError('');

    const { data, error: err } = await supabase.functions.invoke('cashout-manager', {
      body: {
        action: 'request_cashout',
        user_id: userId,
        coins_amount: coinsAmount,
        payout_method: method,
        payout_details: { email }
      }
    });

    if (err || data?.error) {
      setError(data?.error || 'Cashout failed');
    } else {
      onSuccess?.();
      setAmount('');
      setEmail('');
    }
    setLoading(false);
  };

  return (
    <Card className="p-6">
      <h3 className="text-lg font-semibold mb-4 flex items-center gap-2">
        <Banknote className="w-5 h-5" /> Request Cashout
      </h3>
      <form onSubmit={handleSubmit} className="space-y-4">
        {error && (
          <Alert variant="destructive">
            <AlertCircle className="w-4 h-4" />
            <AlertDescription>{error}</AlertDescription>
          </Alert>
        )}
        <div>
          <Label>Coins to Cash Out</Label>
          <Input type="number" value={amount} onChange={(e) => setAmount(e.target.value)} placeholder="5000" min={minCashout} max={balance} />
          <p className="text-sm text-muted-foreground mt-1">= ${usdAmount.toFixed(2)} USD (100 coins = $1)</p>
        </div>
        <div>
          <Label>Payout Method</Label>
          <Select value={method} onValueChange={setMethod}>
            <SelectTrigger><SelectValue /></SelectTrigger>
            <SelectContent>
              <SelectItem value="paypal">PayPal</SelectItem>
              <SelectItem value="bank">Bank Transfer</SelectItem>
            </SelectContent>
          </Select>
        </div>
        <div>
          <Label>Payout Email</Label>
          <Input type="email" value={email} onChange={(e) => setEmail(e.target.value)} placeholder="your@email.com" />
        </div>
        <Button type="submit" className="w-full" disabled={loading || coinsAmount < minCashout}>
          {loading ? 'Processing...' : `Cash Out $${usdAmount.toFixed(2)}`}
        </Button>
      </form>
    </Card>
  );
}
