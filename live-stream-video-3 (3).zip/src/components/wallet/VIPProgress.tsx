
import { Coins, ChevronRight } from 'lucide-react';
import { Progress } from '@/components/ui/progress';
import { VIPBadge } from './VIPBadge';

interface VIPProgressProps {
  currentTier?: {
    name: string;
    tier_level: number;
    badge_color: string;
  } | null;
  nextTier?: {
    name: string;
    tier_level: number;
    badge_color: string;
    min_coins_spent: number;
  } | null;
  totalSpent: number;
  progressPercent: number;
  coinsToNext: number;
}

export function VIPProgress({ currentTier, nextTier, totalSpent, progressPercent, coinsToNext }: VIPProgressProps) {
  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          {currentTier ? (
            <>
              <VIPBadge tier={currentTier} size="lg" />
              <div>
                <p className="font-bold text-lg" style={{ color: currentTier.badge_color }}>{currentTier.name} VIP</p>
                <p className="text-sm text-muted-foreground">{totalSpent.toLocaleString()} coins spent</p>
              </div>
            </>
          ) : (
            <div>
              <p className="font-bold text-lg text-gray-400">No VIP Status</p>
              <p className="text-sm text-muted-foreground">Spend coins to unlock VIP!</p>
            </div>
          )}
        </div>
        {nextTier && (
          <div className="flex items-center gap-2 text-muted-foreground">
            <ChevronRight className="w-4 h-4" />
            <VIPBadge tier={nextTier} size="md" />
            <span className="text-sm">{nextTier.name}</span>
          </div>
        )}
      </div>

      {nextTier ? (
        <div className="space-y-2">
          <Progress value={progressPercent} className="h-3" style={{ '--progress-color': nextTier.badge_color } as any} />
          <div className="flex items-center justify-between text-sm">
            <span className="text-muted-foreground">Progress to {nextTier.name}</span>
            <div className="flex items-center gap-1 text-yellow-500">
              <Coins className="w-4 h-4" />
              <span>{coinsToNext.toLocaleString()} coins to go</span>
            </div>
          </div>
        </div>
      ) : (
        <div className="text-center py-2 bg-gradient-to-r from-purple-500/20 to-pink-500/20 rounded-lg">
          <p className="text-sm font-medium text-purple-300">Maximum VIP tier achieved!</p>
        </div>
      )}
    </div>
  );
}
