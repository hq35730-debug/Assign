import { useState, useEffect } from 'react';
import { Coins, Sparkles, Loader2, LogIn } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { supabase } from '@/lib/supabase';
import { useToast } from '@/hooks/use-toast';
import { useAuth } from '@/contexts/AuthContext';
import { useNavigate } from 'react-router-dom';

interface CoinPackage {
  id: string;
  name: string;
  coins: number;
  price_cents: number;
  bonus_coins: number;
  is_popular: boolean;
}

const DEFAULT_PACKAGES: CoinPackage[] = [
  { id: 'pkg-100', name: 'Starter', coins: 100, price_cents: 99, bonus_coins: 0, is_popular: false },
  { id: 'pkg-500', name: 'Basic', coins: 500, price_cents: 499, bonus_coins: 25, is_popular: false },
  { id: 'pkg-1000', name: 'Popular', coins: 1000, price_cents: 999, bonus_coins: 100, is_popular: true },
  { id: 'pkg-2500', name: 'Value', coins: 2500, price_cents: 1999, bonus_coins: 300, is_popular: false },
  { id: 'pkg-5000', name: 'Premium', coins: 5000, price_cents: 3999, bonus_coins: 750, is_popular: false },
  { id: 'pkg-10000', name: 'Ultimate', coins: 10000, price_cents: 7499, bonus_coins: 2000, is_popular: false },
];

interface CoinPackagesProps {
  onPurchase?: () => void;
}

export function CoinPackages({ onPurchase }: CoinPackagesProps) {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [packages, setPackages] = useState<CoinPackage[]>(DEFAULT_PACKAGES);
  const [loading, setLoading] = useState<string | null>(null);
  const { toast } = useToast();

  useEffect(() => {
    loadPackages();
  }, []);

  const loadPackages = async () => {
    try {
      const { data } = await supabase.functions.invoke('coins-manager', {
        body: { action: 'get_packages' }
      });
      const pkgData = Array.isArray(data?.packages) ? data.packages : [];
      if (pkgData.length > 0) {
        setPackages(pkgData);
      }
    } catch (error) {
      console.log('Using default packages');
    }
  };

  const handlePurchase = async (pkg: CoinPackage) => {
    if (!user?.id) {
      toast({ title: "Sign In Required", description: "Please sign in to purchase coins.", variant: "destructive" });
      navigate('/login');
      return;
    }

    setLoading(pkg.id);
    try {
      const { data, error } = await supabase.functions.invoke('coins-manager', {
        body: { 
          action: 'create_checkout', 
          user_id: user.id, 
          package_id: pkg.id, 
          package_data: pkg,
          origin: window.location.origin
        }
      });
      
      if (error) throw error;
      
      if (data?.url) {
        window.location.href = data.url;
      } else if (data?.error) {
        toast({ title: "Error", description: data.error, variant: "destructive" });
      } else {
        toast({ title: "Purchase Initiated", description: `Processing ${pkg.coins + pkg.bonus_coins} coins.` });
        onPurchase?.();
      }
    } catch (error: any) {
      toast({ title: "Error", description: error.message || "Failed to process purchase", variant: "destructive" });
    }
    setLoading(null);
  };

  const safePackages = Array.isArray(packages) ? packages : DEFAULT_PACKAGES;

  if (!user) {
    return (
      <Card className="p-8 text-center space-y-4">
        <Coins className="w-12 h-12 text-yellow-500 mx-auto" />
        <h3 className="text-lg font-semibold">Sign In to Purchase Coins</h3>
        <p className="text-muted-foreground text-sm">Create an account or sign in to buy coins and support your favorite creators.</p>
        <Button onClick={() => navigate('/login')} className="gap-2"><LogIn className="w-4 h-4" /> Sign In</Button>
      </Card>
    );
  }

  return (
    <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
      {safePackages.map((pkg) => (
        <Card key={pkg.id} className={`p-4 relative ${pkg.is_popular ? 'border-purple-500 border-2' : ''}`}>
          {pkg.is_popular && (
            <Badge className="absolute -top-2 left-1/2 -translate-x-1/2 bg-purple-500">Popular</Badge>
          )}
          <div className="text-center space-y-3">
            <div className="flex items-center justify-center gap-2">
              <Coins className="w-6 h-6 text-yellow-500" />
              <span className="text-2xl font-bold">{(pkg.coins || 0).toLocaleString()}</span>
            </div>
            {pkg.bonus_coins > 0 && (
              <div className="flex items-center justify-center gap-1 text-green-500 text-sm">
                <Sparkles className="w-4 h-4" />
                <span>+{pkg.bonus_coins} bonus</span>
              </div>
            )}
            <p className="text-muted-foreground text-sm">{pkg.name}</p>
            <Button 
              className="w-full" 
              onClick={() => handlePurchase(pkg)}
              disabled={loading === pkg.id}
            >
              {loading === pkg.id ? <Loader2 className="w-4 h-4 animate-spin" /> : `$${((pkg.price_cents || 0) / 100).toFixed(2)}`}
            </Button>
          </div>
        </Card>
      ))}
    </div>
  );
}
