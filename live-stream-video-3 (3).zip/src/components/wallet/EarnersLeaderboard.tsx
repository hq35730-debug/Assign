import { useState, useEffect } from 'react';
import { Star, Trophy, Medal } from 'lucide-react';
import { Card } from '@/components/ui/card';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { supabase } from '@/lib/supabase';

interface Earner {
  user_id: string;
  total_earned: number;
  username?: string;
  avatar?: string;
}

export function EarnersLeaderboard() {
  const [earners, setEarners] = useState<Earner[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadEarners();
  }, []);

  const loadEarners = async () => {
    try {
      const { data } = await supabase.functions.invoke('gifts-manager', {
        body: { action: 'get_top_earners', limit: 10 }
      });
      const earnersData = Array.isArray(data?.earners) ? data.earners : [];
      setEarners(earnersData.map((e: any, i: number) => ({
        ...e,
        username: `Streamer${i + 1}`,
        avatar: `https://api.dicebear.com/7.x/avataaars/svg?seed=${e.user_id}`
      })));
    } catch (err) {
      console.error('Error loading earners:', err);
      setEarners([]);
    }
    setLoading(false);
  };

  const getRankIcon = (rank: number) => {
    if (rank === 0) return <Trophy className="w-5 h-5 text-yellow-500" />;
    if (rank === 1) return <Medal className="w-5 h-5 text-gray-400" />;
    if (rank === 2) return <Medal className="w-5 h-5 text-amber-600" />;
    return <span className="w-5 h-5 text-center text-sm font-bold">{rank + 1}</span>;
  };

  if (loading) return <div className="text-center py-4">Loading...</div>;

  const safeEarners = Array.isArray(earners) ? earners : [];

  return (
    <Card className="p-4">
      <h3 className="text-lg font-semibold mb-4 flex items-center gap-2">
        <Star className="w-5 h-5 text-yellow-500" /> Top Earners
      </h3>
      <div className="space-y-3">
        {safeEarners.length === 0 ? (
          <p className="text-center text-muted-foreground py-4">No earners yet</p>
        ) : (
          safeEarners.map((earner, index) => (
            <div key={earner.user_id || index} className="flex items-center gap-3">
              <div className="w-6 flex justify-center">{getRankIcon(index)}</div>
              <Avatar className="w-8 h-8">
                <AvatarImage src={earner.avatar} />
                <AvatarFallback>{earner.username?.[0] || 'S'}</AvatarFallback>
              </Avatar>
              <span className="flex-1 font-medium">{earner.username || 'Unknown'}</span>
              <span className="text-green-500 font-bold">
                {(earner.total_earned || 0).toLocaleString()} coins
              </span>
            </div>
          ))
        )}
      </div>
    </Card>
  );
}
