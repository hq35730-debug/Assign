import { useState, useEffect } from 'react';
import { ArrowUpRight, ArrowDownLeft, Gift, Coins, Banknote, RefreshCw, ShoppingCart, Heart } from 'lucide-react';
import { Card } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { supabase } from '@/lib/supabase';

interface Transaction {
  id: string;
  type: string;
  amount: number;
  coins: number;
  description: string;
  created_at: string;
  reference_id?: string;
}

interface TransactionHistoryProps {
  userId: string;
}

export function TransactionHistory({ userId }: TransactionHistoryProps) {
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadTransactions();
  }, [userId]);

  const loadTransactions = async () => {
    setLoading(true);
    try {
      const { data } = await supabase.functions.invoke('coins-manager', {
        body: { action: 'get_transactions', user_id: userId }
      });
      const txData = Array.isArray(data?.transactions) ? data.transactions : [];
      setTransactions(txData);
    } catch (err) {
      console.error('Error loading transactions:', err);
      setTransactions([]);
    }
    setLoading(false);
  };

  const getIcon = (type: string) => {
    switch (type) {
      case 'purchase': return <ShoppingCart className="w-5 h-5 text-green-500" />;
      case 'gift_sent': return <ArrowUpRight className="w-5 h-5 text-red-500" />;
      case 'gift_received': return <Heart className="w-5 h-5 text-pink-500" />;
      case 'cashout': return <Banknote className="w-5 h-5 text-blue-500" />;
      case 'bonus': return <Gift className="w-5 h-5 text-yellow-500" />;
      case 'refund': return <RefreshCw className="w-5 h-5 text-orange-500" />;
      default: return <Coins className="w-5 h-5" />;
    }
  };

  const getTypeBadge = (type: string) => {
    const variants: Record<string, string> = {
      purchase: 'bg-green-500/20 text-green-400',
      gift_sent: 'bg-red-500/20 text-red-400',
      gift_received: 'bg-pink-500/20 text-pink-400',
      cashout: 'bg-blue-500/20 text-blue-400',
      bonus: 'bg-yellow-500/20 text-yellow-400'
    };
    const labels: Record<string, string> = {
      purchase: 'Purchase', gift_sent: 'Gift Sent', gift_received: 'Gift Received',
      cashout: 'Cash Out', bonus: 'Bonus'
    };
    return <Badge className={variants[type] || 'bg-gray-500/20'}>{labels[type] || type}</Badge>;
  };

  if (loading) {
    return (
      <div className="space-y-2">
        {Array.from({ length: 5 }).map((_, i) => (
          <div key={i} className="h-16 bg-gray-800 animate-pulse rounded-lg" />
        ))}
      </div>
    );
  }

  const safeTransactions = Array.isArray(transactions) ? transactions : [];

  if (safeTransactions.length === 0) {
    return (
      <Card className="p-8 text-center text-muted-foreground">
        <Coins className="w-12 h-12 mx-auto mb-4 opacity-50" />
        <p>No transactions yet</p>
        <p className="text-sm mt-2">Your transaction history will appear here</p>
      </Card>
    );
  }

  return (
    <div className="space-y-2">
      {safeTransactions.map((tx) => (
        <Card key={tx.id} className="p-4 flex items-center justify-between hover:bg-accent/50 transition-colors">
          <div className="flex items-center gap-3">
            <div className="p-2 rounded-full bg-accent">{getIcon(tx.type)}</div>
            <div>
              <div className="flex items-center gap-2">
                <p className="font-medium">{tx.description}</p>
                {getTypeBadge(tx.type)}
              </div>
              <p className="text-sm text-muted-foreground">
                {new Date(tx.created_at).toLocaleDateString()} at {new Date(tx.created_at).toLocaleTimeString()}
              </p>
            </div>
          </div>
          <div className="text-right">
            <div className={`font-bold flex items-center gap-1 justify-end ${tx.coins > 0 ? 'text-green-500' : 'text-red-500'}`}>
              <Coins className="w-4 h-4" />
              {tx.coins > 0 ? '+' : ''}{tx.coins.toLocaleString()}
            </div>
            {tx.amount > 0 && <div className="text-xs text-muted-foreground">${tx.amount.toFixed(2)}</div>}
          </div>
        </Card>
      ))}
    </div>
  );
}
