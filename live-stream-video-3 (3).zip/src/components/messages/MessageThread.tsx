import { useRef, useEffect } from 'react';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { ScrollArea } from '@/components/ui/scroll-area';
import { format } from 'date-fns';

interface Message {
  id: string;
  sender_id: string;
  receiver_id: string;
  content: string;
  created_at: string;
  is_read: boolean;
}

interface Props {
  messages: Message[];
  currentUserId: string;
  otherUser?: { username: string; avatar_url?: string; display_name?: string };
}

export function MessageThread({ messages, currentUserId, otherUser }: Props) {
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages]);

  const groupMessagesByDate = (msgs: Message[]) => {
    const groups: { [key: string]: Message[] } = {};
    msgs.forEach(msg => {
      const date = format(new Date(msg.created_at), 'MMMM d, yyyy');
      if (!groups[date]) groups[date] = [];
      groups[date].push(msg);
    });
    return groups;
  };

  const grouped = groupMessagesByDate(messages);

  return (
    <ScrollArea className="flex-1 p-4" ref={scrollRef}>
      {Object.entries(grouped).map(([date, msgs]) => (
        <div key={date}>
          <div className="flex items-center justify-center my-4">
            <span className="text-xs text-gray-500 bg-gray-800 px-3 py-1 rounded-full">{date}</span>
          </div>
          {msgs.map((msg, idx) => {
            const isOwn = msg.sender_id === currentUserId;
            const showAvatar = idx === 0 || msgs[idx - 1].sender_id !== msg.sender_id;
            
            return (
              <div key={msg.id} className={`flex items-end gap-2 mb-2 ${isOwn ? 'flex-row-reverse' : ''}`}>
                {!isOwn && showAvatar ? (
                  <Avatar className="h-8 w-8">
                    <AvatarImage src={otherUser?.avatar_url} />
                    <AvatarFallback className="bg-purple-600 text-xs">{otherUser?.username?.[0]?.toUpperCase()}</AvatarFallback>
                  </Avatar>
                ) : !isOwn ? <div className="w-8" /> : null}
                <div className={`max-w-[70%] ${isOwn ? 'items-end' : 'items-start'}`}>
                  <div className={`px-4 py-2 rounded-2xl ${
                    isOwn 
                      ? 'bg-purple-600 text-white rounded-br-md' 
                      : 'bg-gray-800 text-white rounded-bl-md'
                  }`}>
                    <p className="text-sm whitespace-pre-wrap break-words">{msg.content}</p>
                  </div>
                  <span className={`text-xs text-gray-500 mt-1 block ${isOwn ? 'text-right' : ''}`}>
                    {format(new Date(msg.created_at), 'h:mm a')}
                    {isOwn && msg.is_read && <span className="ml-1 text-purple-400">Read</span>}
                  </span>
                </div>
              </div>
            );
          })}
        </div>
      ))}
    </ScrollArea>
  );
}
