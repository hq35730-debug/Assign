import { useRef, useEffect } from 'react';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Badge } from '@/components/ui/badge';

interface Message {
  id: string;
  sender_id: string;
  content: string;
  message_type: string;
  created_at: string;
}

interface Member {
  user_id: string;
  role: string;
  profile: { username: string; avatar_url?: string; display_name?: string };
}

interface DialogueThreadProps {
  messages: Message[];
  members: Member[];
  currentUserId: string;
}

export function DialogueThread({ messages, members, currentUserId }: DialogueThreadProps) {
  const bottomRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  const getMember = (userId: string) => members.find(m => m.user_id === userId);

  const formatTime = (date: string) => new Date(date).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  
  const formatDate = (date: string) => {
    const d = new Date(date);
    const today = new Date();
    if (d.toDateString() === today.toDateString()) return 'Today';
    const yesterday = new Date(today);
    yesterday.setDate(yesterday.getDate() - 1);
    if (d.toDateString() === yesterday.toDateString()) return 'Yesterday';
    return d.toLocaleDateString([], { weekday: 'long', month: 'short', day: 'numeric' });
  };

  const groupedMessages: { date: string; messages: Message[] }[] = [];
  messages.forEach((msg) => {
    const date = formatDate(msg.created_at);
    const lastGroup = groupedMessages[groupedMessages.length - 1];
    if (lastGroup?.date === date) {
      lastGroup.messages.push(msg);
    } else {
      groupedMessages.push({ date, messages: [msg] });
    }
  });

  const getRoleBadge = (role: string) => {
    if (role === 'owner') return <Badge className="bg-yellow-500/20 text-yellow-400 text-xs ml-2">Owner</Badge>;
    if (role === 'admin') return <Badge className="bg-blue-500/20 text-blue-400 text-xs ml-2">Admin</Badge>;
    return null;
  };

  return (
    <div className="flex-1 overflow-y-auto p-4 space-y-6">
      {groupedMessages.map((group, gi) => (
        <div key={gi}>
          <div className="flex items-center justify-center mb-4">
            <div className="bg-gray-800 px-3 py-1 rounded-full text-xs text-gray-400">{group.date}</div>
          </div>
          <div className="space-y-4">
            {group.messages.map((msg) => {
              const isOwn = msg.sender_id === currentUserId;
              const isSystem = msg.message_type === 'system';
              const member = getMember(msg.sender_id);

              if (isSystem) {
                return (
                  <div key={msg.id} className="flex justify-center">
                    <div className="bg-gray-800/50 px-4 py-2 rounded-full text-sm text-gray-400">{msg.content}</div>
                  </div>
                );
              }

              return (
                <div key={msg.id} className={`flex gap-3 ${isOwn ? 'flex-row-reverse' : ''}`}>
                  {!isOwn && (
                    <Avatar className="h-8 w-8 flex-shrink-0">
                      <AvatarImage src={member?.profile.avatar_url} />
                      <AvatarFallback className="bg-purple-600 text-xs">
                        {member?.profile.username?.[0]?.toUpperCase() || 'U'}
                      </AvatarFallback>
                    </Avatar>
                  )}
                  <div className={`max-w-[70%] ${isOwn ? 'items-end' : 'items-start'}`}>
                    {!isOwn && (
                      <div className="flex items-center mb-1">
                        <span className="text-sm font-medium text-purple-400">
                          {member?.profile.display_name || member?.profile.username || 'User'}
                        </span>
                        {member && getRoleBadge(member.role)}
                      </div>
                    )}
                    <div className={`rounded-2xl px-4 py-2 ${isOwn ? 'bg-purple-600 text-white' : 'bg-gray-800 text-gray-100'}`}>
                      <p className="break-words">{msg.content}</p>
                    </div>
                    <span className={`text-xs text-gray-500 mt-1 block ${isOwn ? 'text-right' : ''}`}>
                      {formatTime(msg.created_at)}
                    </span>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      ))}
      <div ref={bottomRef} />
    </div>
  );
}
