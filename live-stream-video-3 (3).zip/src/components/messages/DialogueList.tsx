import { useState } from 'react';
import { Users, Plus, Globe, Lock, Search } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Badge } from '@/components/ui/badge';

interface Dialogue {
  id: string;
  name: string;
  description?: string;
  avatar_url?: string;
  is_public: boolean;
  last_message_at: string;
  last_message_preview?: string;
  member_count?: number;
}

interface DialogueListProps {
  dialogues: Dialogue[];
  selectedId: string | null;
  onSelect: (dialogue: Dialogue) => void;
  onCreateNew: () => void;
  onBrowsePublic: () => void;
}

export function DialogueList({ dialogues, selectedId, onSelect, onCreateNew, onBrowsePublic }: DialogueListProps) {
  const [search, setSearch] = useState('');

  const filtered = dialogues.filter(d => 
    d.name.toLowerCase().includes(search.toLowerCase())
  );

  const formatTime = (date: string) => {
    const d = new Date(date);
    const now = new Date();
    const diff = now.getTime() - d.getTime();
    if (diff < 86400000) return d.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    if (diff < 604800000) return d.toLocaleDateString([], { weekday: 'short' });
    return d.toLocaleDateString([], { month: 'short', day: 'numeric' });
  };

  return (
    <div className="h-full flex flex-col border-r border-gray-800">
      <div className="p-4 border-b border-gray-800">
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-xl font-bold text-white flex items-center gap-2">
            <Users className="h-5 w-5 text-purple-500" /> Dialogues
          </h2>
          <div className="flex gap-2">
            <Button size="sm" variant="outline" onClick={onBrowsePublic} className="border-gray-700">
              <Globe className="h-4 w-4" />
            </Button>
            <Button size="sm" onClick={onCreateNew} className="bg-purple-600 hover:bg-purple-700">
              <Plus className="h-4 w-4" />
            </Button>
          </div>
        </div>
        <div className="relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-gray-500" />
          <Input placeholder="Search dialogues..." value={search} onChange={(e) => setSearch(e.target.value)}
            className="pl-10 bg-gray-800 border-gray-700" />
        </div>
      </div>
      <div className="flex-1 overflow-y-auto">
        {filtered.length === 0 ? (
          <div className="p-8 text-center text-gray-400">
            <Users className="h-12 w-12 mx-auto mb-3 opacity-50" />
            <p>No dialogues yet</p>
            <p className="text-sm mt-1">Create one or join a public dialogue</p>
          </div>
        ) : (
          filtered.map((dialogue) => (
            <div key={dialogue.id} onClick={() => onSelect(dialogue)}
              className={`p-4 cursor-pointer hover:bg-gray-800/50 transition-colors border-b border-gray-800/50 ${selectedId === dialogue.id ? 'bg-gray-800' : ''}`}>
              <div className="flex items-start gap-3">
                <Avatar className="h-12 w-12">
                  <AvatarImage src={dialogue.avatar_url} />
                  <AvatarFallback className="bg-gradient-to-br from-purple-600 to-pink-600 text-white">
                    {dialogue.name.substring(0, 2).toUpperCase()}
                  </AvatarFallback>
                </Avatar>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <span className="font-medium text-white truncate">{dialogue.name}</span>
                      {dialogue.is_public ? <Globe className="h-3 w-3 text-green-500" /> : <Lock className="h-3 w-3 text-gray-500" />}
                    </div>
                    <span className="text-xs text-gray-500">{formatTime(dialogue.last_message_at)}</span>
                  </div>
                  <p className="text-sm text-gray-400 truncate mt-1">{dialogue.last_message_preview || 'No messages yet'}</p>
                  {dialogue.member_count && <Badge variant="secondary" className="mt-1 text-xs">{dialogue.member_count} members</Badge>}
                </div>
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );
}
