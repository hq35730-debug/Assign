import { useState } from 'react';
import { UserPlus, Search, Check } from 'lucide-react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { supabase } from '@/lib/supabase';

interface User {
  user_id: string;
  username: string;
  display_name?: string;
  avatar_url?: string;
}

interface InviteToDialogueModalProps {
  open: boolean;
  onClose: () => void;
  dialogueId: string;
  dialogueName: string;
  currentUserId: string;
  existingMemberIds: string[];
}

export function InviteToDialogueModal({ open, onClose, dialogueId, dialogueName, currentUserId, existingMemberIds }: InviteToDialogueModalProps) {
  const [search, setSearch] = useState('');
  const [users, setUsers] = useState<User[]>([]);
  const [loading, setLoading] = useState(false);
  const [invited, setInvited] = useState<Set<string>>(new Set());
  const [sending, setSending] = useState<string | null>(null);

  const searchUsers = async (query: string) => {
    if (query.length < 2) {
      setUsers([]);
      return;
    }
    setLoading(true);
    try {
      const { data } = await supabase.functions.invoke('messages-manager', {
        body: { action: 'search_users', query }
      });
      setUsers((data?.users || []).filter((u: User) => 
        u.user_id !== currentUserId && !existingMemberIds.includes(u.user_id)
      ));
    } catch (error) {
      console.error('Search users error:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleInvite = async (userId: string) => {
    setSending(userId);
    try {
      await supabase.functions.invoke('messages-manager', {
        body: { action: 'invite_to_dialogue', dialogue_id: dialogueId, inviter_id: currentUserId, invitee_id: userId }
      });
      setInvited(prev => new Set([...prev, userId]));
    } catch (error) {
      console.error('Invite error:', error);
    } finally {
      setSending(null);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="bg-gray-900 border-gray-800 max-w-md">
        <DialogHeader>
          <DialogTitle className="text-white flex items-center gap-2">
            <UserPlus className="h-5 w-5 text-purple-500" />
            Invite to {dialogueName}
          </DialogTitle>
        </DialogHeader>

        <div className="relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-gray-500" />
          <Input
            placeholder="Search users by username..."
            value={search}
            onChange={(e) => { setSearch(e.target.value); searchUsers(e.target.value); }}
            className="pl-10 bg-gray-800 border-gray-700"
          />
        </div>

        <div className="max-h-64 overflow-y-auto space-y-2">
          {loading ? (
            <div className="flex justify-center py-4">
              <div className="animate-spin rounded-full h-6 w-6 border-b-2 border-purple-500" />
            </div>
          ) : users.length === 0 && search.length >= 2 ? (
            <p className="text-center text-gray-400 py-4">No users found</p>
          ) : (
            users.map((user) => (
              <div key={user.user_id} className="flex items-center justify-between p-3 bg-gray-800/50 rounded-lg">
                <div className="flex items-center gap-3">
                  <Avatar>
                    <AvatarImage src={user.avatar_url} />
                    <AvatarFallback className="bg-purple-600">
                      {user.username?.[0]?.toUpperCase()}
                    </AvatarFallback>
                  </Avatar>
                  <div>
                    <p className="font-medium text-white">{user.display_name || user.username}</p>
                    <p className="text-sm text-gray-400">@{user.username}</p>
                  </div>
                </div>
                <Button
                  size="sm"
                  disabled={invited.has(user.user_id) || sending === user.user_id}
                  onClick={() => handleInvite(user.user_id)}
                  className={invited.has(user.user_id) ? 'bg-green-600' : 'bg-purple-600 hover:bg-purple-700'}
                >
                  {invited.has(user.user_id) ? <><Check className="h-4 w-4 mr-1" /> Invited</> : sending === user.user_id ? '...' : 'Invite'}
                </Button>
              </div>
            ))
          )}
        </div>

        {search.length < 2 && (
          <p className="text-sm text-gray-400 text-center">Type at least 2 characters to search</p>
        )}
      </DialogContent>
    </Dialog>
  );
}
