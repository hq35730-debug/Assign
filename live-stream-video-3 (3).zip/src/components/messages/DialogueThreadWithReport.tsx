
import { useRef, useEffect, useState } from 'react';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from '@/components/ui/dropdown-menu';
import { MoreVertical, Flag, Trash2 } from 'lucide-react';
import { ReportModal } from '@/components/moderation/ReportModal';

interface Message {
  id: string;
  sender_id: string;
  content: string;
  message_type: string;
  created_at: string;
}

interface Member {
  user_id: string;
  role: string;
  profile: { username: string; avatar_url?: string; display_name?: string };
}

interface Props {
  messages: Message[];
  members: Member[];
  currentUserId: string;
  currentUsername: string;
  dialogueId: string;
  userRole: string;
  onDeleteMessage?: (messageId: string) => void;
}

export function DialogueThreadWithReport({ messages, members, currentUserId, currentUsername, dialogueId, userRole, onDeleteMessage }: Props) {
  const bottomRef = useRef<HTMLDivElement>(null);
  const [reportModal, setReportModal] = useState<{ open: boolean; message?: Message; member?: Member }>({ open: false });

  useEffect(() => { bottomRef.current?.scrollIntoView({ behavior: 'smooth' }); }, [messages]);

  const getMember = (userId: string) => members.find(m => m.user_id === userId);
  const formatTime = (date: string) => new Date(date).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  const canModerate = userRole === 'owner' || userRole === 'admin';

  const getRoleBadge = (role: string) => {
    if (role === 'owner') return <Badge className="bg-yellow-500/20 text-yellow-400 text-xs ml-2">Owner</Badge>;
    if (role === 'admin') return <Badge className="bg-blue-500/20 text-blue-400 text-xs ml-2">Admin</Badge>;
    return null;
  };

  return (
    <div className="flex-1 overflow-y-auto p-4 space-y-4">
      {messages.map((msg) => {
        const isOwn = msg.sender_id === currentUserId;
        const isSystem = msg.message_type === 'system';
        const member = getMember(msg.sender_id);

        if (isSystem) {
          return (
            <div key={msg.id} className="flex justify-center">
              <div className="bg-gray-800/50 px-4 py-2 rounded-full text-sm text-gray-400">{msg.content}</div>
            </div>
          );
        }

        return (
          <div key={msg.id} className={`flex gap-3 group ${isOwn ? 'flex-row-reverse' : ''}`}>
            {!isOwn && (
              <Avatar className="h-8 w-8 flex-shrink-0">
                <AvatarImage src={member?.profile.avatar_url} />
                <AvatarFallback className="bg-purple-600 text-xs">{member?.profile.username?.[0]?.toUpperCase() || 'U'}</AvatarFallback>
              </Avatar>
            )}
            <div className={`max-w-[70%] ${isOwn ? 'items-end' : 'items-start'}`}>
              {!isOwn && (
                <div className="flex items-center mb-1">
                  <span className="text-sm font-medium text-purple-400">{member?.profile.display_name || member?.profile.username || 'User'}</span>
                  {member && getRoleBadge(member.role)}
                </div>
              )}
              <div className="flex items-center gap-1">
                {isOwn && (
                  <DropdownMenu>
                    <DropdownMenuTrigger asChild>
                      <Button variant="ghost" size="icon" className="h-6 w-6 opacity-0 group-hover:opacity-100"><MoreVertical className="h-4 w-4" /></Button>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent className="bg-gray-800 border-gray-700">
                      {canModerate && <DropdownMenuItem onClick={() => onDeleteMessage?.(msg.id)} className="text-red-400"><Trash2 className="h-4 w-4 mr-2" />Delete</DropdownMenuItem>}
                    </DropdownMenuContent>
                  </DropdownMenu>
                )}
                <div className={`rounded-2xl px-4 py-2 ${isOwn ? 'bg-purple-600 text-white' : 'bg-gray-800 text-gray-100'}`}>
                  <p className="break-words">{msg.content}</p>
                </div>
                {!isOwn && (
                  <DropdownMenu>
                    <DropdownMenuTrigger asChild>
                      <Button variant="ghost" size="icon" className="h-6 w-6 opacity-0 group-hover:opacity-100"><MoreVertical className="h-4 w-4" /></Button>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent className="bg-gray-800 border-gray-700">
                      <DropdownMenuItem onClick={() => setReportModal({ open: true, message: msg, member })} className="text-red-400"><Flag className="h-4 w-4 mr-2" />Report</DropdownMenuItem>
                      {canModerate && <DropdownMenuItem onClick={() => onDeleteMessage?.(msg.id)} className="text-red-400"><Trash2 className="h-4 w-4 mr-2" />Delete</DropdownMenuItem>}
                    </DropdownMenuContent>
                  </DropdownMenu>
                )}
              </div>
              <span className={`text-xs text-gray-500 mt-1 block ${isOwn ? 'text-right' : ''}`}>{formatTime(msg.created_at)}</span>
            </div>
          </div>
        );
      })}
      <div ref={bottomRef} />
      <ReportModal
        open={reportModal.open}
        onClose={() => setReportModal({ open: false })}
        dialogueId={dialogueId}
        reporterId={currentUserId}
        reporterUsername={currentUsername}
        targetUserId={reportModal.member?.user_id}
        targetUsername={reportModal.member?.profile.username}
        messageId={reportModal.message?.id}
        messageContent={reportModal.message?.content}
      />
    </div>
  );
}
