import { useState } from 'react';
import { Search, Plus, MessageCircle } from 'lucide-react';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { ScrollArea } from '@/components/ui/scroll-area';
import { formatDistanceToNow } from 'date-fns';

interface Conversation {
  id: string;
  participant_1: string;
  participant_2: string;
  last_message_at: string;
  last_message_preview: string;
  other_user?: { username: string; avatar_url?: string; display_name?: string };
  unread_count?: number;
}

interface Props {
  conversations: Conversation[];
  selectedId: string | null;
  onSelect: (conv: Conversation) => void;
  onNewMessage: () => void;
  currentUserId: string;
}

export function ConversationList({ conversations, selectedId, onSelect, onNewMessage, currentUserId }: Props) {
  const [search, setSearch] = useState('');

  const filtered = conversations.filter(c => 
    c.other_user?.username?.toLowerCase().includes(search.toLowerCase()) ||
    c.other_user?.display_name?.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div className="flex flex-col h-full border-r border-gray-800">
      <div className="p-4 border-b border-gray-800">
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-xl font-bold text-white">Messages</h2>
          <Button size="icon" variant="ghost" onClick={onNewMessage} className="text-purple-400 hover:text-purple-300">
            <Plus className="h-5 w-5" />
          </Button>
        </div>
        <div className="relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-gray-400" />
          <Input
            placeholder="Search conversations..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="pl-10 bg-gray-800 border-gray-700"
          />
        </div>
      </div>
      <ScrollArea className="flex-1">
        {filtered.length === 0 ? (
          <div className="p-8 text-center text-gray-400">
            <MessageCircle className="h-12 w-12 mx-auto mb-3 opacity-50" />
            <p>No conversations yet</p>
          </div>
        ) : (
          filtered.map((conv) => (
            <div
              key={conv.id}
              onClick={() => onSelect(conv)}
              className={`p-4 cursor-pointer hover:bg-gray-800/50 transition-colors ${
                selectedId === conv.id ? 'bg-gray-800' : ''
              }`}
            >
              <div className="flex items-center gap-3">
                <Avatar>
                  <AvatarImage src={conv.other_user?.avatar_url} />
                  <AvatarFallback className="bg-purple-600">{conv.other_user?.username?.[0]?.toUpperCase()}</AvatarFallback>
                </Avatar>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center justify-between">
                    <span className="font-medium text-white truncate">{conv.other_user?.display_name || conv.other_user?.username}</span>
                    <span className="text-xs text-gray-500">{formatDistanceToNow(new Date(conv.last_message_at), { addSuffix: true })}</span>
                  </div>
                  <p className="text-sm text-gray-400 truncate">{conv.last_message_preview}</p>
                </div>
                {conv.unread_count && conv.unread_count > 0 && (
                  <span className="bg-purple-600 text-white text-xs rounded-full px-2 py-0.5">{conv.unread_count}</span>
                )}
              </div>
            </div>
          ))
        )}
      </ScrollArea>
    </div>
  );
}
