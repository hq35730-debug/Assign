import { useState } from 'react';
import { Search, X, User } from 'lucide-react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { ScrollArea } from '@/components/ui/scroll-area';
import { supabase } from '@/lib/supabase';

interface UserProfile {
  id: string;
  user_id: string;
  username: string;
  display_name?: string;
  avatar_url?: string;
  is_streamer: boolean;
}

interface Props {
  open: boolean;
  onClose: () => void;
  onSelectUser: (user: UserProfile) => void;
}

export function NewMessageModal({ open, onClose, onSelectUser }: Props) {
  const [search, setSearch] = useState('');
  const [users, setUsers] = useState<UserProfile[]>([]);
  const [loading, setLoading] = useState(false);

  const handleSearch = async (query: string) => {
    setSearch(query);
    if (query.length < 2) {
      setUsers([]);
      return;
    }

    setLoading(true);
    try {
      const { data } = await supabase.functions.invoke('messages-manager', {
        body: { action: 'search_users', query }
      });
      setUsers(data?.users || []);
    } catch (error) {
      console.error('Search error:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleSelect = (user: UserProfile) => {
    onSelectUser(user);
    setSearch('');
    setUsers([]);
    onClose();
  };

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="bg-gray-900 border-gray-800 max-w-md">
        <DialogHeader>
          <DialogTitle className="text-white">New Message</DialogTitle>
        </DialogHeader>
        <div className="space-y-4">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-gray-400" />
            <Input
              placeholder="Search users..."
              value={search}
              onChange={(e) => handleSearch(e.target.value)}
              className="pl-10 bg-gray-800 border-gray-700"
              autoFocus
            />
          </div>
          <ScrollArea className="h-64">
            {loading ? (
              <div className="flex items-center justify-center py-8">
                <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-purple-500" />
              </div>
            ) : users.length === 0 ? (
              <div className="text-center py-8 text-gray-400">
                {search.length < 2 ? (
                  <p>Type at least 2 characters to search</p>
                ) : (
                  <>
                    <User className="h-12 w-12 mx-auto mb-3 opacity-50" />
                    <p>No users found</p>
                  </>
                )}
              </div>
            ) : (
              <div className="space-y-1">
                {users.map((user) => (
                  <div
                    key={user.id}
                    onClick={() => handleSelect(user)}
                    className="flex items-center gap-3 p-3 rounded-lg cursor-pointer hover:bg-gray-800 transition-colors"
                  >
                    <Avatar>
                      <AvatarImage src={user.avatar_url} />
                      <AvatarFallback className="bg-purple-600">{user.username[0].toUpperCase()}</AvatarFallback>
                    </Avatar>
                    <div>
                      <p className="font-medium text-white">{user.display_name || user.username}</p>
                      <p className="text-sm text-gray-400">@{user.username}</p>
                    </div>
                    {user.is_streamer && (
                      <span className="ml-auto text-xs bg-purple-600/20 text-purple-400 px-2 py-1 rounded">Streamer</span>
                    )}
                  </div>
                ))}
              </div>
            )}
          </ScrollArea>
        </div>
      </DialogContent>
    </Dialog>
  );
}
