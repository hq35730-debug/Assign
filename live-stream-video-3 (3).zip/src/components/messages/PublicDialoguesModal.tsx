import { useState, useEffect } from 'react';
import { Globe, Users, Search, UserPlus } from 'lucide-react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Badge } from '@/components/ui/badge';
import { supabase } from '@/lib/supabase';

interface Dialogue {
  id: string;
  name: string;
  description?: string;
  avatar_url?: string;
  is_public: boolean;
  member_count?: number;
}

interface PublicDialoguesModalProps {
  open: boolean;
  onClose: () => void;
  onJoin: (dialogueId: string) => void;
  userDialogueIds: string[];
}

export function PublicDialoguesModal({ open, onClose, onJoin, userDialogueIds }: PublicDialoguesModalProps) {
  const [dialogues, setDialogues] = useState<Dialogue[]>([]);
  const [search, setSearch] = useState('');
  const [loading, setLoading] = useState(false);
  const [joining, setJoining] = useState<string | null>(null);

  useEffect(() => {
    if (open) loadPublicDialogues();
  }, [open]);

  const loadPublicDialogues = async () => {
    setLoading(true);
    try {
      const { data } = await supabase.functions.invoke('messages-manager', {
        body: { action: 'get_public_dialogues' }
      });
      setDialogues(data?.dialogues || []);
    } catch (error) {
      console.error('Load public dialogues error:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleJoin = async (dialogueId: string) => {
    setJoining(dialogueId);
    try {
      await onJoin(dialogueId);
    } finally {
      setJoining(null);
    }
  };

  const filtered = dialogues.filter(d =>
    d.name.toLowerCase().includes(search.toLowerCase()) ||
    d.description?.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="bg-gray-900 border-gray-800 max-w-lg max-h-[80vh] flex flex-col">
        <DialogHeader>
          <DialogTitle className="text-white flex items-center gap-2">
            <Globe className="h-5 w-5 text-green-500" />
            Browse Public Dialogues
          </DialogTitle>
        </DialogHeader>

        <div className="relative mb-4">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-gray-500" />
          <Input
            placeholder="Search dialogues..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="pl-10 bg-gray-800 border-gray-700"
          />
        </div>

        <div className="flex-1 overflow-y-auto space-y-3">
          {loading ? (
            <div className="flex justify-center py-8">
              <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-purple-500" />
            </div>
          ) : filtered.length === 0 ? (
            <div className="text-center py-8 text-gray-400">
              <Globe className="h-12 w-12 mx-auto mb-3 opacity-50" />
              <p>No public dialogues found</p>
            </div>
          ) : (
            filtered.map((dialogue) => {
              const isMember = userDialogueIds.includes(dialogue.id);
              return (
                <div key={dialogue.id} className="p-4 bg-gray-800/50 rounded-lg border border-gray-700">
                  <div className="flex items-start gap-3">
                    <Avatar className="h-12 w-12">
                      <AvatarImage src={dialogue.avatar_url} />
                      <AvatarFallback className="bg-gradient-to-br from-green-600 to-teal-600 text-white">
                        {dialogue.name.substring(0, 2).toUpperCase()}
                      </AvatarFallback>
                    </Avatar>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2">
                        <h3 className="font-medium text-white truncate">{dialogue.name}</h3>
                        <Badge variant="secondary" className="text-xs">
                          <Users className="h-3 w-3 mr-1" />
                          {dialogue.member_count || 1}
                        </Badge>
                      </div>
                      {dialogue.description && (
                        <p className="text-sm text-gray-400 mt-1 line-clamp-2">{dialogue.description}</p>
                      )}
                    </div>
                    <Button
                      size="sm"
                      disabled={isMember || joining === dialogue.id}
                      onClick={() => handleJoin(dialogue.id)}
                      className={isMember ? 'bg-gray-700' : 'bg-green-600 hover:bg-green-700'}
                    >
                      {isMember ? 'Joined' : joining === dialogue.id ? '...' : <><UserPlus className="h-4 w-4 mr-1" /> Join</>}
                    </Button>
                  </div>
                </div>
              );
            })
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
}
