import { useState } from 'react';
import { Send, Smile, Image, AlertCircle, Scale } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';

interface Props {
  onSend: (content: string) => void;
  disabled?: boolean;
  isMuted?: boolean;
  onAppeal?: () => void;
}

export function MessageInput({ onSend, disabled, isMuted, onAppeal }: Props) {
  const [content, setContent] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (content.trim() && !disabled && !isMuted) {
      onSend(content.trim());
      setContent('');
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSubmit(e);
    }
  };

  if (isMuted) {
    return (
      <div className="p-4 border-t border-gray-800 bg-red-900/20">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2 text-red-400">
            <AlertCircle className="h-5 w-5" />
            <span className="text-sm">You are muted in this dialogue</span>
          </div>
          {onAppeal && (
            <Button size="sm" variant="outline" onClick={onAppeal} className="border-red-700 text-red-400 hover:bg-red-900/50">
              <Scale className="h-4 w-4 mr-2" />Appeal
            </Button>
          )}
        </div>
      </div>
    );
  }

  return (
    <form onSubmit={handleSubmit} className="p-4 border-t border-gray-800">
      <div className="flex items-end gap-2">
        <div className="flex-1 relative">
          <Textarea
            value={content}
            onChange={(e) => setContent(e.target.value)}
            onKeyDown={handleKeyDown}
            placeholder="Type a message..."
            disabled={disabled}
            className="min-h-[44px] max-h-32 bg-gray-800 border-gray-700 resize-none pr-20"
            rows={1}
          />
          <div className="absolute right-2 bottom-2 flex items-center gap-1">
            <Button type="button" size="icon" variant="ghost" className="h-8 w-8 text-gray-400 hover:text-white">
              <Smile className="h-5 w-5" />
            </Button>
            <Button type="button" size="icon" variant="ghost" className="h-8 w-8 text-gray-400 hover:text-white">
              <Image className="h-5 w-5" />
            </Button>
          </div>
        </div>
        <Button 
          type="submit" 
          size="icon"
          disabled={!content.trim() || disabled}
          className="h-11 w-11 bg-purple-600 hover:bg-purple-700"
        >
          <Send className="h-5 w-5" />
        </Button>
      </div>
    </form>
  );
}
