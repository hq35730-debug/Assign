import { useState } from 'react';
import { Users, Globe, Lock } from 'lucide-react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';

interface CreateDialogueModalProps {
  open: boolean;
  onClose: () => void;
  onCreate: (data: { name: string; description: string; is_public: boolean }) => void;
}

export function CreateDialogueModal({ open, onClose, onCreate }: CreateDialogueModalProps) {
  const [name, setName] = useState('');
  const [description, setDescription] = useState('');
  const [isPublic, setIsPublic] = useState(false);
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) return;
    
    setLoading(true);
    try {
      await onCreate({ name: name.trim(), description: description.trim(), is_public: isPublic });
      setName('');
      setDescription('');
      setIsPublic(false);
      onClose();
    } finally {
      setLoading(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="bg-gray-900 border-gray-800 max-w-md">
        <DialogHeader>
          <DialogTitle className="text-white flex items-center gap-2">
            <Users className="h-5 w-5 text-purple-500" />
            Create New Dialogue
          </DialogTitle>
        </DialogHeader>
        
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="name" className="text-gray-300">Dialogue Name</Label>
            <Input
              id="name"
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="Enter dialogue name..."
              className="bg-gray-800 border-gray-700"
              maxLength={100}
            />
          </div>
          
          <div className="space-y-2">
            <Label htmlFor="description" className="text-gray-300">Description (optional)</Label>
            <Textarea
              id="description"
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="What's this dialogue about?"
              className="bg-gray-800 border-gray-700 resize-none"
              rows={3}
              maxLength={500}
            />
          </div>
          
          <div className="flex items-center justify-between p-4 bg-gray-800/50 rounded-lg">
            <div className="flex items-center gap-3">
              {isPublic ? (
                <Globe className="h-5 w-5 text-green-500" />
              ) : (
                <Lock className="h-5 w-5 text-gray-400" />
              )}
              <div>
                <p className="text-white font-medium">
                  {isPublic ? 'Public Dialogue' : 'Private Dialogue'}
                </p>
                <p className="text-sm text-gray-400">
                  {isPublic ? 'Anyone can find and join' : 'Invite only'}
                </p>
              </div>
            </div>
            <Switch checked={isPublic} onCheckedChange={setIsPublic} />
          </div>
          
          <div className="flex gap-3 pt-2">
            <Button type="button" variant="outline" onClick={onClose} className="flex-1 border-gray-700">
              Cancel
            </Button>
            <Button type="submit" disabled={!name.trim() || loading} className="flex-1 bg-purple-600 hover:bg-purple-700">
              {loading ? 'Creating...' : 'Create Dialogue'}
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}
