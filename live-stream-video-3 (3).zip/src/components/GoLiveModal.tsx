import React, { useState, useRef, useEffect } from 'react';
import { X, Upload, Video, Loader2, Camera, CameraOff, AlertCircle, Sparkles, Settings, Zap, Monitor, MonitorPlay } from 'lucide-react';
import { useStream } from '@/contexts/StreamContext';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/contexts/AuthContext';

interface GoLiveModalProps {
  isOpen: boolean;
  onClose: () => void;
  onStreamStarted: () => void;
}

const categories = ['Gaming', 'Music', 'Beauty', 'Talk', 'Talent', 'Sports', 'Education', 'Art'];

const qualityPresets = [
  { id: 'crystal_clear', label: 'Crystal Clear 4K', desc: '4K @ 60fps • Maximum quality', icon: Sparkles, color: 'from-purple-500 to-pink-500', resolution: '2160p', bitrate: 45000, fps: 60 },
  { id: 'ultra_hd', label: 'Ultra HD 1440p', desc: '1440p @ 60fps • High quality', icon: Monitor, color: 'from-blue-500 to-cyan-500', resolution: '1440p', bitrate: 20000, fps: 60 },
  { id: 'full_hd', label: 'Full HD 1080p', desc: '1080p @ 60fps • Recommended', icon: Video, color: 'from-green-500 to-emerald-500', resolution: '1080p', bitrate: 8000, fps: 60 },
  { id: 'performance', label: 'Performance', desc: '720p @ 30fps • Low bandwidth', icon: Zap, color: 'from-yellow-500 to-orange-500', resolution: '720p', bitrate: 4500, fps: 30 }
];

type StreamSourceType = 'camera' | 'screen' | 'screen_camera';

export const GoLiveModal: React.FC<GoLiveModalProps> = ({ isOpen, onClose, onStreamStarted }) => {
  const [title, setTitle] = useState('');
  const [category, setCategory] = useState('Talk');
  const [thumbnail, setThumbnail] = useState<File | null>(null);
  const [thumbnailPreview, setThumbnailPreview] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [cameraReady, setCameraReady] = useState(false);
  const [cameraError, setCameraError] = useState('');
  const [localStream, setLocalStream] = useState<MediaStream | null>(null);
  const [screenStream, setScreenStream] = useState<MediaStream | null>(null);
  const [selectedQuality, setSelectedQuality] = useState('full_hd');
  const [showQualityOptions, setShowQualityOptions] = useState(false);
  const [streamSource, setStreamSource] = useState<StreamSourceType>('camera');
  const [showSourceOptions, setShowSourceOptions] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const videoRef = useRef<HTMLVideoElement>(null);
  const { startStream, setMediaStream, setScreenStream: setContextScreenStream, setIsScreenSharing } = useStream();
  const { user } = useAuth();
  const streamStartedRef = useRef(false);

  useEffect(() => {
    if (isOpen) {
      streamStartedRef.current = false;
      if (streamSource === 'camera') {
        setupCamera();
      } else {
        setupScreenShare();
      }
    }
    return () => {
      if (!streamStartedRef.current) {
        if (localStream) {
          localStream.getTracks().forEach(track => track.stop());
        }
        if (screenStream) {
          screenStream.getTracks().forEach(track => track.stop());
        }
      }
    };
  }, [isOpen]);

  const setupCamera = async () => {
    setCameraError('');
    setCameraReady(false);
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ video: true, audio: true });
      setLocalStream(stream);
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
      }
      setCameraReady(true);
    } catch (err: any) {
      if (err.name === 'NotAllowedError') {
        setCameraError('Camera/microphone access denied. Please allow access.');
      } else if (err.name === 'NotFoundError') {
        setCameraError('No camera or microphone found.');
      } else {
        setCameraError('Failed to access camera: ' + err.message);
      }
    }
  };

  const setupScreenShare = async () => {
    setCameraError('');
    setCameraReady(false);
    try {
      const displayStream = await navigator.mediaDevices.getDisplayMedia({
        video: {
          cursor: 'always',
          displaySurface: 'monitor'
        } as any,
        audio: true
      });

      // Handle when user stops sharing via browser controls
      displayStream.getVideoTracks()[0].onended = () => {
        setStreamSource('camera');
        setupCamera();
      };

      setScreenStream(displayStream);
      
      if (videoRef.current) {
        videoRef.current.srcObject = displayStream;
      }
      
      // If screen + camera, also get camera stream
      if (streamSource === 'screen_camera') {
        try {
          const camStream = await navigator.mediaDevices.getUserMedia({ video: true, audio: true });
          setLocalStream(camStream);
        } catch (e) {
          console.log('Could not get camera for PiP');
        }
      }
      
      setCameraReady(true);
    } catch (err: any) {
      if (err.name === 'AbortError') {
        // User cancelled, go back to camera
        setStreamSource('camera');
        setupCamera();
      } else {
        setCameraError('Failed to share screen: ' + err.message);
      }
    }
  };

  const handleSourceChange = async (source: StreamSourceType) => {
    // Stop existing streams
    if (localStream) {
      localStream.getTracks().forEach(track => track.stop());
      setLocalStream(null);
    }
    if (screenStream) {
      screenStream.getTracks().forEach(track => track.stop());
      setScreenStream(null);
    }
    
    setStreamSource(source);
    setShowSourceOptions(false);
    setCameraReady(false);
    
    if (source === 'camera') {
      await setupCamera();
    } else {
      await setupScreenShare();
    }
  };

  const handleClose = () => {
    if (!streamStartedRef.current) {
      if (localStream) {
        localStream.getTracks().forEach(track => track.stop());
        setLocalStream(null);
      }
      if (screenStream) {
        screenStream.getTracks().forEach(track => track.stop());
        setScreenStream(null);
      }
    }
    setCameraReady(false);
    setCameraError('');
    setTitle('');
    setError('');
    setStreamSource('camera');
    onClose();
  };

  if (!isOpen) return null;

  const handleThumbnailChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      setThumbnail(file);
      setThumbnailPreview(URL.createObjectURL(file));
    }
  };

  const handleStartStream = async () => {
    if (!title.trim()) { setError('Please enter a stream title'); return; }
    if (!user) { setError('Please sign in to go live'); return; }
    if (!cameraReady) { setError('Media source not ready. Please allow access.'); return; }
    
    setLoading(true);
    setError('');
    
    try {
      let thumbnailUrl = '';
      if (thumbnail) {
        const fileName = `${user.user_id}_${Date.now()}.${thumbnail.name.split('.').pop()}`;
        const { error: uploadError } = await supabase.storage.from('stream-thumbnails').upload(fileName, thumbnail);
        if (!uploadError) {
          const { data } = supabase.storage.from('stream-thumbnails').getPublicUrl(fileName);
          thumbnailUrl = data.publicUrl;
        }
      }
      
      const stream = await startStream(title, category, thumbnailUrl);
      streamStartedRef.current = true;
      
      // Set up streams based on source type
      if (streamSource === 'camera') {
        setMediaStream(localStream);
        setIsScreenSharing(false);
      } else if (streamSource === 'screen') {
        setMediaStream(screenStream);
        setContextScreenStream(screenStream);
        setIsScreenSharing(true);
      } else if (streamSource === 'screen_camera') {
        setMediaStream(localStream);
        setContextScreenStream(screenStream);
        setIsScreenSharing(true);
      }
      
      onStreamStarted();
      onClose();
    } catch (e: any) {
      console.error('Stream start error:', e);
      setError(e.message || 'Failed to start stream. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  const selectedPreset = qualityPresets.find(p => p.id === selectedQuality) || qualityPresets[2];
  const SelectedIcon = selectedPreset.icon;

  const getSourceLabel = () => {
    switch (streamSource) {
      case 'camera': return 'Camera';
      case 'screen': return 'Screen Share';
      case 'screen_camera': return 'Screen + Camera';
    }
  };

  const getSourceIcon = () => {
    switch (streamSource) {
      case 'camera': return <Camera className="w-4 h-4" />;
      case 'screen': return <Monitor className="w-4 h-4" />;
      case 'screen_camera': return <MonitorPlay className="w-4 h-4" />;
    }
  };

  return (
    <div className="fixed inset-0 bg-black/80 flex items-center justify-center z-50 p-4">
      <div className="bg-[#16213e] rounded-2xl w-full max-w-lg overflow-hidden max-h-[90vh] overflow-y-auto">
        <div className="flex items-center justify-between p-4 border-b border-gray-700">
          <h2 className="text-xl font-bold text-white flex items-center gap-2"><Video className="w-5 h-5 text-red-500" /> Go Live</h2>
          <button onClick={handleClose} className="text-gray-400 hover:text-white"><X className="w-6 h-6" /></button>
        </div>
        <div className="p-6 space-y-4">
          {/* Camera/Screen Preview */}
          <div className="relative aspect-video bg-black rounded-lg overflow-hidden">
            {cameraReady ? (
              <video ref={videoRef} autoPlay muted playsInline className="w-full h-full object-cover" />
            ) : cameraError ? (
              <div className="absolute inset-0 flex flex-col items-center justify-center text-center p-4">
                <CameraOff className="w-12 h-12 text-red-400 mb-3" />
                <p className="text-red-400 text-sm mb-3">{cameraError}</p>
                <button onClick={() => streamSource === 'camera' ? setupCamera() : setupScreenShare()} className="px-4 py-2 bg-purple-600 hover:bg-purple-700 text-white rounded-lg text-sm">Retry</button>
              </div>
            ) : (
              <div className="absolute inset-0 flex flex-col items-center justify-center">
                <Loader2 className="w-10 h-10 text-purple-400 animate-spin mb-2" />
                <p className="text-gray-400 text-sm">
                  {streamSource === 'camera' ? 'Setting up camera...' : 'Setting up screen share...'}
                </p>
              </div>
            )}
            {cameraReady && (
              <>
                <div className={`absolute top-2 left-2 flex items-center gap-2 px-2 py-1 rounded text-xs text-white ${
                  streamSource === 'camera' ? 'bg-green-500/80' : 'bg-blue-500/80'
                }`}>
                  {getSourceIcon()} {getSourceLabel()} Ready
                </div>
                {/* Quality Badge */}
                <div className={`absolute top-2 right-2 flex items-center gap-1.5 bg-gradient-to-r ${selectedPreset.color} px-2 py-1 rounded text-xs text-white`}>
                  <SelectedIcon className="w-3 h-3" />
                  {selectedPreset.resolution} @ {selectedPreset.fps}fps
                </div>
              </>
            )}
          </div>
          
          {error && <div className="bg-red-500/20 text-red-400 px-4 py-2 rounded-lg text-sm flex items-center gap-2"><AlertCircle className="w-4 h-4" />{error}</div>}
          
          {/* Stream Source Selection */}
          <div>
            <label className="block text-gray-300 text-sm mb-2">Stream Source</label>
            <button
              onClick={() => setShowSourceOptions(!showSourceOptions)}
              className="w-full flex items-center justify-between p-3 bg-[#1a1a2e] rounded-lg border border-gray-700 hover:border-gray-600 transition-colors"
            >
              <div className="flex items-center gap-3">
                <div className={`p-2 rounded-lg ${streamSource === 'camera' ? 'bg-green-600' : 'bg-blue-600'}`}>
                  {getSourceIcon()}
                </div>
                <div className="text-left">
                  <p className="text-white font-medium text-sm">{getSourceLabel()}</p>
                  <p className="text-gray-500 text-xs">
                    {streamSource === 'camera' && 'Use your webcam'}
                    {streamSource === 'screen' && 'Share your screen only'}
                    {streamSource === 'screen_camera' && 'Screen with camera overlay'}
                  </p>
                </div>
              </div>
              <Settings className={`w-5 h-5 text-gray-400 transition-transform ${showSourceOptions ? 'rotate-90' : ''}`} />
            </button>

            {showSourceOptions && (
              <div className="mt-2 space-y-2">
                <button
                  onClick={() => handleSourceChange('camera')}
                  className={`w-full flex items-center gap-3 p-3 rounded-lg border transition-all ${
                    streamSource === 'camera' 
                      ? 'border-green-500 bg-green-600/10' 
                      : 'border-gray-700 hover:border-gray-600 bg-[#1a1a2e]'
                  }`}
                >
                  <div className="p-2 rounded-lg bg-green-600">
                    <Camera className="w-4 h-4 text-white" />
                  </div>
                  <div className="text-left flex-1">
                    <p className="text-white font-medium text-sm">Camera Only</p>
                    <p className="text-gray-500 text-xs">Stream using your webcam</p>
                  </div>
                  {streamSource === 'camera' && <div className="w-2 h-2 bg-green-500 rounded-full" />}
                </button>
                
                <button
                  onClick={() => handleSourceChange('screen')}
                  className={`w-full flex items-center gap-3 p-3 rounded-lg border transition-all ${
                    streamSource === 'screen' 
                      ? 'border-blue-500 bg-blue-600/10' 
                      : 'border-gray-700 hover:border-gray-600 bg-[#1a1a2e]'
                  }`}
                >
                  <div className="p-2 rounded-lg bg-blue-600">
                    <Monitor className="w-4 h-4 text-white" />
                  </div>
                  <div className="text-left flex-1">
                    <p className="text-white font-medium text-sm">Screen Share</p>
                    <p className="text-gray-500 text-xs">Share your screen without camera</p>
                  </div>
                  {streamSource === 'screen' && <div className="w-2 h-2 bg-blue-500 rounded-full" />}
                </button>
                
                <button
                  onClick={() => handleSourceChange('screen_camera')}
                  className={`w-full flex items-center gap-3 p-3 rounded-lg border transition-all ${
                    streamSource === 'screen_camera' 
                      ? 'border-purple-500 bg-purple-600/10' 
                      : 'border-gray-700 hover:border-gray-600 bg-[#1a1a2e]'
                  }`}
                >
                  <div className="p-2 rounded-lg bg-gradient-to-r from-blue-600 to-purple-600">
                    <MonitorPlay className="w-4 h-4 text-white" />
                  </div>
                  <div className="text-left flex-1">
                    <p className="text-white font-medium text-sm">Screen + Camera</p>
                    <p className="text-gray-500 text-xs">Screen share with picture-in-picture camera</p>
                  </div>
                  {streamSource === 'screen_camera' && <div className="w-2 h-2 bg-purple-500 rounded-full" />}
                </button>
              </div>
            )}
          </div>
          
          {/* Stream Title */}
          <div>
            <label className="block text-gray-300 text-sm mb-2">Stream Title</label>
            <input type="text" value={title} onChange={(e) => setTitle(e.target.value)} placeholder="What are you streaming today?" className="w-full bg-[#1a1a2e] text-white px-4 py-3 rounded-lg border border-gray-700 focus:border-purple-500 focus:outline-none" />
          </div>
          
          {/* Category */}
          <div>
            <label className="block text-gray-300 text-sm mb-2">Category</label>
            <select value={category} onChange={(e) => setCategory(e.target.value)} className="w-full bg-[#1a1a2e] text-white px-4 py-3 rounded-lg border border-gray-700 focus:border-purple-500 focus:outline-none">
              {categories.map(cat => <option key={cat} value={cat}>{cat}</option>)}
            </select>
          </div>

          {/* Quality Selection */}
          <div>
            <button
              onClick={() => setShowQualityOptions(!showQualityOptions)}
              className="w-full flex items-center justify-between p-3 bg-[#1a1a2e] rounded-lg border border-gray-700 hover:border-gray-600 transition-colors"
            >
              <div className="flex items-center gap-3">
                <div className={`p-2 rounded-lg bg-gradient-to-r ${selectedPreset.color}`}>
                  <SelectedIcon className="w-4 h-4 text-white" />
                </div>
                <div className="text-left">
                  <p className="text-white font-medium text-sm">{selectedPreset.label}</p>
                  <p className="text-gray-500 text-xs">{selectedPreset.desc}</p>
                </div>
              </div>
              <Settings className={`w-5 h-5 text-gray-400 transition-transform ${showQualityOptions ? 'rotate-90' : ''}`} />
            </button>

            {showQualityOptions && (
              <div className="mt-2 space-y-2">
                {qualityPresets.map((preset) => {
                  const Icon = preset.icon;
                  return (
                    <button
                      key={preset.id}
                      onClick={() => { setSelectedQuality(preset.id); setShowQualityOptions(false); }}
                      className={`w-full flex items-center gap-3 p-3 rounded-lg border transition-all ${
                        selectedQuality === preset.id 
                          ? 'border-purple-500 bg-purple-600/10' 
                          : 'border-gray-700 hover:border-gray-600 bg-[#1a1a2e]'
                      }`}
                    >
                      <div className={`p-2 rounded-lg bg-gradient-to-r ${preset.color}`}>
                        <Icon className="w-4 h-4 text-white" />
                      </div>
                      <div className="text-left flex-1">
                        <p className="text-white font-medium text-sm">{preset.label}</p>
                        <p className="text-gray-500 text-xs">{preset.desc}</p>
                      </div>
                      {selectedQuality === preset.id && (
                        <div className="w-2 h-2 bg-purple-500 rounded-full" />
                      )}
                    </button>
                  );
                })}
              </div>
            )}
          </div>

          {/* Crystal Clear Info Banner */}
          {selectedQuality === 'crystal_clear' && (
            <div className="bg-gradient-to-r from-purple-900/30 to-pink-900/30 rounded-lg p-3 border border-purple-500/30">
              <div className="flex items-center gap-2 mb-1">
                <Sparkles className="w-4 h-4 text-purple-400" />
                <span className="text-purple-300 font-medium text-sm">Crystal Clear Mode</span>
              </div>
              <p className="text-gray-400 text-xs">
                Automatic quality optimization with HDR, noise reduction, and adaptive bitrate for the best viewing experience.
              </p>
            </div>
          )}

          {/* Screen Share Info Banner */}
          {(streamSource === 'screen' || streamSource === 'screen_camera') && (
            <div className="bg-gradient-to-r from-blue-900/30 to-cyan-900/30 rounded-lg p-3 border border-blue-500/30">
              <div className="flex items-center gap-2 mb-1">
                <Monitor className="w-4 h-4 text-blue-400" />
                <span className="text-blue-300 font-medium text-sm">Screen Sharing</span>
              </div>
              <p className="text-gray-400 text-xs">
                {streamSource === 'screen' 
                  ? 'Your screen will be shared with viewers. You can switch to camera during the stream.'
                  : 'Your screen will be shared with a camera overlay. You can toggle the camera during the stream.'
                }
              </p>
            </div>
          )}
          
          {/* Start Button */}
          <button 
            onClick={handleStartStream} 
            disabled={loading || !cameraReady} 
            className={`w-full py-3 rounded-lg font-semibold transition-all disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2 ${
              streamSource !== 'camera'
                ? 'bg-gradient-to-r from-blue-600 to-cyan-600 text-white hover:shadow-lg hover:shadow-blue-500/50'
                : selectedQuality === 'crystal_clear'
                  ? 'bg-gradient-to-r from-purple-600 to-pink-600 text-white hover:shadow-lg hover:shadow-purple-500/50'
                  : 'bg-gradient-to-r from-red-600 to-pink-600 text-white hover:shadow-lg hover:shadow-red-500/50'
            }`}
          >
            {loading ? (
              <><Loader2 className="w-5 h-5 animate-spin" /> Starting...</>
            ) : (
              <>
                {streamSource !== 'camera' ? (
                  <><Monitor className="w-5 h-5" /> Start Screen Share</>
                ) : selectedQuality === 'crystal_clear' ? (
                  <><Sparkles className="w-5 h-5" /> Start Crystal Clear Stream</>
                ) : (
                  <><Video className="w-5 h-5" /> Start Streaming</>
                )}
              </>
            )}
          </button>
        </div>
      </div>
    </div>
  );
};
