import React from 'react';
import { Mic, Users, Lock, Crown } from 'lucide-react';

interface VoiceRoom {
  id: string;
  name: string;
  description?: string;
  host_id: string;
  is_private: boolean;
  is_active: boolean;
  max_participants: number;
  participant_count: number;
  created_at: string;
  host?: {
    id: string;
    username: string;
    avatar_url?: string;
    unique_id?: string;
  };
}

interface VoiceRoomCardProps {
  room: VoiceRoom;
  onJoin: (roomId: string) => void;
}

export function VoiceRoomCard({ room, onJoin }: VoiceRoomCardProps) {
  return (
    <div className="bg-gradient-to-br from-[#1a1a2e] to-[#16213e] rounded-xl border border-gray-700 hover:border-purple-500/50 transition-all overflow-hidden group">
      {/* Room Header */}
      <div className="p-4 border-b border-gray-700/50">
        <div className="flex items-start justify-between gap-3">
          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-2">
              <h3 className="text-white font-semibold truncate">{room.name}</h3>
              {room.is_private && (
                <Lock className="w-4 h-4 text-amber-400 flex-shrink-0" />
              )}
            </div>
            {room.description && (
              <p className="text-gray-400 text-sm mt-1 line-clamp-2">{room.description}</p>
            )}
          </div>
          <div className="flex items-center gap-1 bg-green-500/20 text-green-400 px-2 py-1 rounded-full text-xs font-medium">
            <span className="w-2 h-2 bg-green-400 rounded-full animate-pulse" />
            Live
          </div>
        </div>
      </div>

      {/* Host Info */}
      <div className="px-4 py-3 flex items-center gap-3 bg-purple-500/5">
        <div className="w-10 h-10 rounded-full bg-gradient-to-br from-purple-500 to-pink-500 flex items-center justify-center overflow-hidden ring-2 ring-amber-400/50">
          {room.host?.avatar_url ? (
            <img src={room.host.avatar_url} alt="" className="w-full h-full object-cover" />
          ) : (
            <span className="text-white font-bold text-sm">
              {room.host?.username?.[0]?.toUpperCase() || 'H'}
            </span>
          )}
        </div>
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2">
            <Crown className="w-4 h-4 text-amber-400" />
            <span className="text-white text-sm font-medium truncate">
              {room.host?.username || 'Unknown Host'}
            </span>
          </div>
          {room.host?.unique_id && (
            <span className="text-gray-500 text-xs font-mono">#{room.host.unique_id}</span>
          )}
        </div>
      </div>

      {/* Room Stats & Join */}
      <div className="p-4 flex items-center justify-between">
        <div className="flex items-center gap-4">
          <div className="flex items-center gap-2 text-gray-400">
            <Users className="w-4 h-4" />
            <span className="text-sm">
              {room.participant_count}/{room.max_participants}
            </span>
          </div>
          <div className="flex items-center gap-2 text-gray-400">
            <Mic className="w-4 h-4" />
            <span className="text-sm">Voice</span>
          </div>
        </div>
        <button
          onClick={() => onJoin(room.id)}
          disabled={room.participant_count >= room.max_participants}
          className="bg-gradient-to-r from-purple-600 to-pink-600 text-white px-4 py-2 rounded-full text-sm font-semibold hover:shadow-lg hover:shadow-purple-500/30 transition-all disabled:opacity-50 disabled:cursor-not-allowed"
        >
          {room.participant_count >= room.max_participants ? 'Full' : 'Join'}
        </button>
      </div>
    </div>
  );
}
