import React, { useState } from 'react';
import { X, Mic, Lock, Users, Globe } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/contexts/AuthContext';

interface CreateVoiceRoomModalProps {
  isOpen: boolean;
  onClose: () => void;
  onRoomCreated: (roomId: string) => void;
}

export function CreateVoiceRoomModal({ isOpen, onClose, onRoomCreated }: CreateVoiceRoomModalProps) {
  const { user } = useAuth();
  const [name, setName] = useState('');
  const [description, setDescription] = useState('');
  const [isPrivate, setIsPrivate] = useState(false);
  const [maxParticipants, setMaxParticipants] = useState(20);
  const [isCreating, setIsCreating] = useState(false);
  const [error, setError] = useState('');

  if (!isOpen) return null;

  const handleCreate = async () => {
    if (!user) return;
    if (!name.trim()) {
      setError('Room name is required');
      return;
    }

    setIsCreating(true);
    setError('');

    try {
      const { data, error: createError } = await supabase.functions.invoke('voice-room-manager', {
        body: {
          action: 'create_room',
          user_id: user.id || user.user_id,
          name: name.trim(),
          description: description.trim() || undefined,
          is_private: isPrivate,
          max_participants: maxParticipants
        }
      });

      if (createError) throw createError;
      if (data?.error) throw new Error(data.error);

      onRoomCreated(data.room.id);
      onClose();
    } catch (err: any) {
      setError(err.message || 'Failed to create room');
    } finally {
      setIsCreating(false);
    }
  };

  return (
    <div className="fixed inset-0 bg-black/80 flex items-center justify-center z-50 p-4">
      <div className="bg-[#16213e] rounded-2xl max-w-md w-full overflow-hidden">
        {/* Header */}
        <div className="bg-gradient-to-r from-purple-600 to-pink-600 p-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-white/20 rounded-full flex items-center justify-center">
              <Mic className="w-5 h-5 text-white" />
            </div>
            <div>
              <h2 className="text-white font-bold text-lg">Create Voice Room</h2>
              <p className="text-white/70 text-sm">Start a group voice chat</p>
            </div>
          </div>
          <button onClick={onClose} className="text-white/80 hover:text-white">
            <X className="w-6 h-6" />
          </button>
        </div>

        {/* Form */}
        <div className="p-6 space-y-4">
          {error && (
            <div className="bg-red-500/20 border border-red-500/50 text-red-400 px-4 py-2 rounded-lg text-sm">
              {error}
            </div>
          )}

          <div>
            <label className="block text-gray-300 text-sm font-medium mb-2">
              Room Name *
            </label>
            <input
              type="text"
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="e.g., Chill Hangout, Gaming Squad"
              className="w-full bg-[#1a1a2e] text-white px-4 py-3 rounded-lg border border-gray-700 focus:border-purple-500 focus:outline-none"
              maxLength={50}
            />
          </div>

          <div>
            <label className="block text-gray-300 text-sm font-medium mb-2">
              Description (optional)
            </label>
            <textarea
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="What's this room about?"
              className="w-full bg-[#1a1a2e] text-white px-4 py-3 rounded-lg border border-gray-700 focus:border-purple-500 focus:outline-none resize-none"
              rows={3}
              maxLength={200}
            />
          </div>

          <div>
            <label className="block text-gray-300 text-sm font-medium mb-2">
              Max Participants
            </label>
            <select
              value={maxParticipants}
              onChange={(e) => setMaxParticipants(Number(e.target.value))}
              className="w-full bg-[#1a1a2e] text-white px-4 py-3 rounded-lg border border-gray-700 focus:border-purple-500 focus:outline-none"
            >
              <option value={5}>5 people</option>
              <option value={10}>10 people</option>
              <option value={20}>20 people</option>
              <option value={50}>50 people</option>
              <option value={100}>100 people</option>
            </select>
          </div>

          {/* Privacy Toggle */}
          <div className="flex items-center justify-between p-4 bg-[#1a1a2e] rounded-lg">
            <div className="flex items-center gap-3">
              {isPrivate ? (
                <Lock className="w-5 h-5 text-amber-400" />
              ) : (
                <Globe className="w-5 h-5 text-green-400" />
              )}
              <div>
                <p className="text-white font-medium">
                  {isPrivate ? 'Private Room' : 'Public Room'}
                </p>
                <p className="text-gray-400 text-sm">
                  {isPrivate ? 'Only invited users can join' : 'Anyone can discover and join'}
                </p>
              </div>
            </div>
            <button
              onClick={() => setIsPrivate(!isPrivate)}
              className={`w-12 h-6 rounded-full transition-colors ${
                isPrivate ? 'bg-amber-500' : 'bg-gray-600'
              }`}
            >
              <div
                className={`w-5 h-5 bg-white rounded-full transition-transform ${
                  isPrivate ? 'translate-x-6' : 'translate-x-0.5'
                }`}
              />
            </button>
          </div>

          {/* Create Button */}
          <button
            onClick={handleCreate}
            disabled={isCreating || !name.trim()}
            className="w-full bg-gradient-to-r from-purple-600 to-pink-600 text-white py-3 rounded-lg font-semibold hover:shadow-lg hover:shadow-purple-500/30 transition-all disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2"
          >
            {isCreating ? (
              <>
                <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                Creating...
              </>
            ) : (
              <>
                <Mic className="w-5 h-5" />
                Create Voice Room
              </>
            )}
          </button>
        </div>
      </div>
    </div>
  );
}
