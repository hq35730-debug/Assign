import React from 'react';
import { Mic, MicOff, Crown, Shield, MoreVertical, UserMinus, UserPlus } from 'lucide-react';

interface Participant {
  id: string;
  user_id: string;
  is_muted: boolean;
  is_speaking: boolean;
  is_host: boolean;
  is_co_host: boolean;
  profile?: {
    id: string;
    username: string;
    avatar_url?: string;
    unique_id?: string;
  };
}

interface VoiceRoomParticipantProps {
  participant: Participant;
  isCurrentUser: boolean;
  canManage: boolean;
  onMute: () => void;
  onKick: () => void;
  onPromote: () => void;
}

export function VoiceRoomParticipant({
  participant,
  isCurrentUser,
  canManage,
  onMute,
  onKick,
  onPromote
}: VoiceRoomParticipantProps) {
  const [showMenu, setShowMenu] = React.useState(false);

  return (
    <div className="relative group">
      <div
        className={`flex flex-col items-center p-3 rounded-xl transition-all ${
          participant.is_speaking && !participant.is_muted
            ? 'bg-green-500/20 ring-2 ring-green-400 animate-pulse'
            : 'bg-[#1a1a2e]'
        }`}
      >
        {/* Avatar */}
        <div className="relative">
          <div
            className={`w-16 h-16 rounded-full flex items-center justify-center overflow-hidden ${
              participant.is_speaking && !participant.is_muted
                ? 'ring-4 ring-green-400/50'
                : 'ring-2 ring-gray-700'
            } ${
              participant.is_host
                ? 'bg-gradient-to-br from-amber-500 to-orange-600'
                : participant.is_co_host
                ? 'bg-gradient-to-br from-blue-500 to-cyan-600'
                : 'bg-gradient-to-br from-purple-500 to-pink-500'
            }`}
          >
            {participant.profile?.avatar_url ? (
              <img
                src={participant.profile.avatar_url}
                alt=""
                className="w-full h-full object-cover"
              />
            ) : (
              <span className="text-white font-bold text-xl">
                {participant.profile?.username?.[0]?.toUpperCase() || '?'}
              </span>
            )}
          </div>

          {/* Role Badge */}
          {(participant.is_host || participant.is_co_host) && (
            <div
              className={`absolute -top-1 -right-1 w-6 h-6 rounded-full flex items-center justify-center ${
                participant.is_host ? 'bg-amber-500' : 'bg-blue-500'
              }`}
            >
              {participant.is_host ? (
                <Crown className="w-3 h-3 text-white" />
              ) : (
                <Shield className="w-3 h-3 text-white" />
              )}
            </div>
          )}

          {/* Mute Indicator */}
          <div
            className={`absolute -bottom-1 -right-1 w-6 h-6 rounded-full flex items-center justify-center ${
              participant.is_muted ? 'bg-red-500' : 'bg-green-500'
            }`}
          >
            {participant.is_muted ? (
              <MicOff className="w-3 h-3 text-white" />
            ) : (
              <Mic className="w-3 h-3 text-white" />
            )}
          </div>
        </div>

        {/* Username */}
        <p className="text-white text-sm font-medium mt-2 truncate max-w-full">
          {participant.profile?.username || 'Unknown'}
          {isCurrentUser && <span className="text-purple-400 ml-1">(You)</span>}
        </p>

        {/* Speaking Indicator */}
        {participant.is_speaking && !participant.is_muted && (
          <div className="flex items-center gap-1 mt-1">
            <div className="w-1 h-3 bg-green-400 rounded-full animate-bounce" style={{ animationDelay: '0ms' }} />
            <div className="w-1 h-4 bg-green-400 rounded-full animate-bounce" style={{ animationDelay: '150ms' }} />
            <div className="w-1 h-2 bg-green-400 rounded-full animate-bounce" style={{ animationDelay: '300ms' }} />
          </div>
        )}

        {/* Management Menu */}
        {canManage && !isCurrentUser && !participant.is_host && (
          <div className="absolute top-2 right-2 opacity-0 group-hover:opacity-100 transition-opacity">
            <button
              onClick={() => setShowMenu(!showMenu)}
              className="p-1 text-gray-400 hover:text-white hover:bg-white/10 rounded"
            >
              <MoreVertical className="w-4 h-4" />
            </button>

            {showMenu && (
              <div className="absolute right-0 top-8 bg-[#16213e] border border-gray-700 rounded-lg shadow-xl z-10 overflow-hidden min-w-[140px]">
                <button
                  onClick={() => { onMute(); setShowMenu(false); }}
                  className="w-full flex items-center gap-2 px-3 py-2 text-sm text-gray-300 hover:bg-purple-600/20 hover:text-white"
                >
                  {participant.is_muted ? <Mic className="w-4 h-4" /> : <MicOff className="w-4 h-4" />}
                  {participant.is_muted ? 'Unmute' : 'Mute'}
                </button>
                {!participant.is_co_host && (
                  <button
                    onClick={() => { onPromote(); setShowMenu(false); }}
                    className="w-full flex items-center gap-2 px-3 py-2 text-sm text-gray-300 hover:bg-blue-600/20 hover:text-blue-400"
                  >
                    <UserPlus className="w-4 h-4" />
                    Make Co-Host
                  </button>
                )}
                <button
                  onClick={() => { onKick(); setShowMenu(false); }}
                  className="w-full flex items-center gap-2 px-3 py-2 text-sm text-red-400 hover:bg-red-600/20"
                >
                  <UserMinus className="w-4 h-4" />
                  Kick
                </button>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
}
