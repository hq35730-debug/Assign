import React, { useState, useEffect, useCallback } from 'react';
import { X, Mic, MicOff, PhoneOff, Users, Settings, Crown, Copy, Check, Phone, Volume2, VolumeX } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/contexts/AuthContext';
import { VoiceRoomParticipant } from './VoiceRoomParticipant';

interface Participant {
  id: string;
  user_id: string;
  is_muted: boolean;
  is_speaking: boolean;
  is_host: boolean;
  is_co_host: boolean;
  profile?: {
    id: string;
    username: string;
    avatar_url?: string;
    unique_id?: string;
  };
}

interface Room {
  id: string;
  name: string;
  description?: string;
  host_id: string;
  is_active: boolean;
  max_participants: number;
  host?: {
    id: string;
    username: string;
    avatar_url?: string;
    unique_id?: string;
    phone_number?: string;
  };
}

interface ActiveVoiceRoomProps {
  roomId: string;
  onLeave: () => void;
}

export function ActiveVoiceRoom({ roomId, onLeave }: ActiveVoiceRoomProps) {
  const { user } = useAuth();
  const [room, setRoom] = useState<Room | null>(null);
  const [participants, setParticipants] = useState<Participant[]>([]);
  const [isMuted, setIsMuted] = useState(true);
  const [isSpeakerOn, setIsSpeakerOn] = useState(true);
  const [isLoading, setIsLoading] = useState(true);
  const [copied, setCopied] = useState(false);
  const [showSettings, setShowSettings] = useState(false);
  const [isInCall, setIsInCall] = useState(false);
  const [callStatus, setCallStatus] = useState<string>('');

  const userId = user?.id || user?.user_id;
  const currentParticipant = participants.find(p => p.user_id === userId);
  const isHost = currentParticipant?.is_host || room?.host_id === userId;
  const isCoHost = currentParticipant?.is_co_host;
  const canManage = isHost || isCoHost;

  // Load room details
  const loadRoomDetails = useCallback(async () => {
    try {
      const { data, error } = await supabase.functions.invoke('voice-room-manager', {
        body: { action: 'get_room_details', room_id: roomId }
      });

      if (error) throw error;
      if (data?.error) throw new Error(data.error);

      setRoom(data.room);
      setParticipants(data.participants || []);
      
      // Update local mute state
      const me = data.participants?.find((p: Participant) => p.user_id === userId);
      if (me) {
        setIsMuted(me.is_muted);
      }
    } catch (err) {
      console.error('Failed to load room:', err);
    } finally {
      setIsLoading(false);
    }
  }, [roomId, userId]);

  useEffect(() => {
    loadRoomDetails();
    const interval = setInterval(loadRoomDetails, 3000);
    return () => clearInterval(interval);
  }, [loadRoomDetails]);

  // Toggle mute
  const handleToggleMute = async () => {
    try {
      const { data, error } = await supabase.functions.invoke('voice-room-manager', {
        body: {
          action: 'toggle_mute',
          user_id: userId,
          room_id: roomId
        }
      });

      if (error) throw error;
      if (data?.error) throw new Error(data.error);

      setIsMuted(data.is_muted);
    } catch (err) {
      console.error('Failed to toggle mute:', err);
    }
  };

  // Mute another participant
  const handleMuteParticipant = async (targetUserId: string) => {
    try {
      await supabase.functions.invoke('voice-room-manager', {
        body: {
          action: 'toggle_mute',
          user_id: userId,
          room_id: roomId,
          target_user_id: targetUserId
        }
      });
      loadRoomDetails();
    } catch (err) {
      console.error('Failed to mute participant:', err);
    }
  };

  // Kick participant
  const handleKickParticipant = async (targetUserId: string) => {
    try {
      await supabase.functions.invoke('voice-room-manager', {
        body: {
          action: 'kick_participant',
          user_id: userId,
          room_id: roomId,
          target_user_id: targetUserId
        }
      });
      loadRoomDetails();
    } catch (err) {
      console.error('Failed to kick participant:', err);
    }
  };

  // Promote to co-host
  const handlePromoteParticipant = async (targetUserId: string) => {
    try {
      await supabase.functions.invoke('voice-room-manager', {
        body: {
          action: 'promote_co_host',
          user_id: userId,
          room_id: roomId,
          target_user_id: targetUserId
        }
      });
      loadRoomDetails();
    } catch (err) {
      console.error('Failed to promote participant:', err);
    }
  };

  // Leave room
  const handleLeaveRoom = async () => {
    try {
      await supabase.functions.invoke('voice-room-manager', {
        body: {
          action: 'leave_room',
          user_id: userId,
          room_id: roomId
        }
      });
      onLeave();
    } catch (err) {
      console.error('Failed to leave room:', err);
    }
  };

  // End room (host only)
  const handleEndRoom = async () => {
    if (!confirm('Are you sure you want to end this room for everyone?')) return;
    
    try {
      await supabase.functions.invoke('voice-room-manager', {
        body: {
          action: 'end_room',
          user_id: userId,
          room_id: roomId
        }
      });
      onLeave();
    } catch (err) {
      console.error('Failed to end room:', err);
    }
  };

  // Initiate phone call
  const handleJoinCall = async () => {
    setCallStatus('Connecting...');
    try {
      const { data, error } = await supabase.functions.invoke('voice-room-manager', {
        body: {
          action: 'initiate_call',
          user_id: userId,
          room_id: roomId
        }
      });

      if (error) throw error;
      if (data?.error) throw new Error(data.error);

      setIsInCall(true);
      setCallStatus('Connected');
    } catch (err: any) {
      setCallStatus(`Failed: ${err.message}`);
      setTimeout(() => setCallStatus(''), 3000);
    }
  };

  // Copy room link
  const handleCopyLink = () => {
    navigator.clipboard.writeText(`${window.location.origin}/voice/${roomId}`);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  // Simulate speaking (for demo purposes)
  useEffect(() => {
    if (!isMuted && isInCall) {
      const interval = setInterval(() => {
        const isSpeaking = Math.random() > 0.7;
        supabase.functions.invoke('voice-room-manager', {
          body: {
            action: 'update_speaking',
            user_id: userId,
            room_id: roomId,
            is_speaking: isSpeaking
          }
        });
      }, 500);
      return () => clearInterval(interval);
    }
  }, [isMuted, isInCall, userId, roomId]);

  if (isLoading) {
    return (
      <div className="fixed inset-0 bg-[#1a1a2e] flex items-center justify-center z-50">
        <div className="text-center">
          <div className="w-16 h-16 border-4 border-purple-500/30 border-t-purple-500 rounded-full animate-spin mx-auto mb-4" />
          <p className="text-gray-400">Joining voice room...</p>
        </div>
      </div>
    );
  }

  if (!room) {
    return (
      <div className="fixed inset-0 bg-[#1a1a2e] flex items-center justify-center z-50">
        <div className="text-center">
          <p className="text-red-400 mb-4">Room not found or has ended</p>
          <button onClick={onLeave} className="text-purple-400 hover:text-purple-300">
            Go Back
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="fixed inset-0 bg-[#1a1a2e] z-50 flex flex-col">
      {/* Header */}
      <div className="bg-[#16213e] border-b border-gray-700 p-4">
        <div className="max-w-4xl mx-auto flex items-center justify-between">
          <div className="flex items-center gap-4">
            <div className="w-12 h-12 bg-gradient-to-br from-purple-500 to-pink-500 rounded-xl flex items-center justify-center">
              <Mic className="w-6 h-6 text-white" />
            </div>
            <div>
              <h1 className="text-white font-bold text-lg">{room.name}</h1>
              <div className="flex items-center gap-2 text-gray-400 text-sm">
                <Users className="w-4 h-4" />
                <span>{participants.length} participants</span>
                <span className="w-2 h-2 bg-green-400 rounded-full animate-pulse" />
                <span className="text-green-400">Live</span>
              </div>
            </div>
          </div>

          <div className="flex items-center gap-3">
            <button
              onClick={handleCopyLink}
              className="flex items-center gap-2 px-3 py-2 bg-[#1a1a2e] text-gray-300 rounded-lg hover:bg-purple-600/20 hover:text-white transition-colors"
            >
              {copied ? <Check className="w-4 h-4 text-green-400" /> : <Copy className="w-4 h-4" />}
              <span className="text-sm">{copied ? 'Copied!' : 'Share'}</span>
            </button>

            {isHost && (
              <button
                onClick={() => setShowSettings(!showSettings)}
                className="p-2 text-gray-400 hover:text-white hover:bg-white/10 rounded-lg transition-colors"
              >
                <Settings className="w-5 h-5" />
              </button>
            )}

            <button
              onClick={handleLeaveRoom}
              className="p-2 text-red-400 hover:text-red-300 hover:bg-red-500/20 rounded-lg transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>
      </div>

      {/* Room Description */}
      {room.description && (
        <div className="bg-purple-500/10 border-b border-purple-500/20 px-4 py-3">
          <p className="text-gray-300 text-sm text-center max-w-2xl mx-auto">{room.description}</p>
        </div>
      )}

      {/* Call Status */}
      {callStatus && (
        <div className="bg-blue-500/20 border-b border-blue-500/30 px-4 py-2">
          <p className="text-blue-400 text-sm text-center">{callStatus}</p>
        </div>
      )}

      {/* Participants Grid */}
      <div className="flex-1 overflow-y-auto p-6">
        <div className="max-w-4xl mx-auto">
          <div className="grid grid-cols-3 sm:grid-cols-4 md:grid-cols-5 lg:grid-cols-6 gap-4">
            {participants.map((participant) => (
              <VoiceRoomParticipant
                key={participant.id}
                participant={participant}
                isCurrentUser={participant.user_id === userId}
                canManage={canManage && participant.user_id !== userId}
                onMute={() => handleMuteParticipant(participant.user_id)}
                onKick={() => handleKickParticipant(participant.user_id)}
                onPromote={() => handlePromoteParticipant(participant.user_id)}
              />
            ))}
          </div>

          {participants.length === 0 && (
            <div className="text-center py-12">
              <Users className="w-16 h-16 text-gray-600 mx-auto mb-4" />
              <p className="text-gray-400">No participants yet</p>
              <p className="text-gray-500 text-sm">Share the room link to invite others</p>
            </div>
          )}
        </div>
      </div>

      {/* Controls */}
      <div className="bg-[#16213e] border-t border-gray-700 p-4">
        <div className="max-w-4xl mx-auto flex items-center justify-center gap-4">
          {/* Join Call Button */}
          {!isInCall && (
            <button
              onClick={handleJoinCall}
              className="flex items-center gap-2 px-6 py-3 bg-gradient-to-r from-green-500 to-emerald-600 text-white rounded-full font-semibold hover:shadow-lg hover:shadow-green-500/30 transition-all"
            >
              <Phone className="w-5 h-5" />
              Join Voice Call
            </button>
          )}

          {isInCall && (
            <>
              {/* Mute Button */}
              <button
                onClick={handleToggleMute}
                className={`w-14 h-14 rounded-full flex items-center justify-center transition-all ${
                  isMuted
                    ? 'bg-red-500 hover:bg-red-600'
                    : 'bg-green-500 hover:bg-green-600'
                }`}
              >
                {isMuted ? (
                  <MicOff className="w-6 h-6 text-white" />
                ) : (
                  <Mic className="w-6 h-6 text-white" />
                )}
              </button>

              {/* Speaker Button */}
              <button
                onClick={() => setIsSpeakerOn(!isSpeakerOn)}
                className={`w-14 h-14 rounded-full flex items-center justify-center transition-all ${
                  isSpeakerOn
                    ? 'bg-[#1a1a2e] hover:bg-gray-700'
                    : 'bg-gray-600 hover:bg-gray-500'
                }`}
              >
                {isSpeakerOn ? (
                  <Volume2 className="w-6 h-6 text-white" />
                ) : (
                  <VolumeX className="w-6 h-6 text-white" />
                )}
              </button>

              {/* End Call Button */}
              <button
                onClick={handleLeaveRoom}
                className="w-14 h-14 rounded-full bg-red-500 hover:bg-red-600 flex items-center justify-center transition-all"
              >
                <PhoneOff className="w-6 h-6 text-white" />
              </button>
            </>
          )}

          {/* End Room Button (Host Only) */}
          {isHost && (
            <button
              onClick={handleEndRoom}
              className="flex items-center gap-2 px-4 py-2 bg-red-500/20 text-red-400 rounded-lg hover:bg-red-500/30 transition-colors ml-4"
            >
              <Crown className="w-4 h-4" />
              End Room
            </button>
          )}
        </div>

        {/* Mute Status */}
        <p className="text-center text-gray-500 text-sm mt-3">
          {isMuted ? 'You are muted' : 'You are unmuted'}
          {isHost && ' • You are the host'}
          {isCoHost && !isHost && ' • You are a co-host'}
        </p>
      </div>

      {/* Settings Panel */}
      {showSettings && isHost && (
        <div className="absolute top-20 right-4 bg-[#16213e] border border-gray-700 rounded-xl shadow-xl p-4 w-64 z-10">
          <h3 className="text-white font-semibold mb-3">Room Settings</h3>
          <div className="space-y-3">
            <button
              onClick={() => {/* Mute all */}}
              className="w-full flex items-center gap-2 px-3 py-2 text-gray-300 hover:bg-purple-600/20 rounded-lg transition-colors"
            >
              <MicOff className="w-4 h-4" />
              Mute All Participants
            </button>
            <button
              onClick={handleEndRoom}
              className="w-full flex items-center gap-2 px-3 py-2 text-red-400 hover:bg-red-500/20 rounded-lg transition-colors"
            >
              <PhoneOff className="w-4 h-4" />
              End Room for Everyone
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
