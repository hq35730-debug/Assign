import React, { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { StreamCard } from './StreamCard';
import { CategoryFilter } from './CategoryFilter';
import { TrendingSection } from './TrendingSection';
import { StatsBar } from './StatsBar';
import { Footer } from './Footer';
import { GoLiveModal } from './GoLiveModal';
import { TopClips } from './TopClips';
import { UpcomingSchedules } from './UpcomingSchedules';
import { StoriesBar } from './stories/StoriesBar';
import { UserLookup } from './phone/UserLookup';
import { SignupQRModal } from './qr/SignupQRModal';
import { SendSignInSMS } from './phone/SendSignInSMS';
import { streams } from '../data/streamData';
import { useAuth } from '@/contexts/AuthContext';
import { useStream } from '@/contexts/StreamContext';
import { supabase } from '@/lib/supabase';
import { User, LogOut, ChevronDown, Radio, Users, Star, Wallet, BarChart3, Coins, MessageCircle, Pickaxe, Bot, Blocks, Sparkles, ArrowUpDown, Image, Film, CirclePlus, Search, Hash, Phone, Mic, QrCode, Smartphone } from 'lucide-react';



export default function AppLayout() {
  const navigate = useNavigate();
  const [activeCategory, setActiveCategory] = useState('All');
  const [searchQuery, setSearchQuery] = useState('');
  const [showUserMenu, setShowUserMenu] = useState(false);
  const [showGoLiveModal, setShowGoLiveModal] = useState(false);
  const [showUserLookup, setShowUserLookup] = useState(false);
  const [showQRModal, setShowQRModal] = useState(false);
  const [showSMSSignIn, setShowSMSSignIn] = useState(false);
  const [unreadMessages, setUnreadMessages] = useState(0);
  const [miningBalance, setMiningBalance] = useState<number | null>(null);

  const { user, signOut } = useAuth();
  const { liveStreams } = useStream();

  useEffect(() => {
    if (user) {
      const loadUnread = async () => {
        const { data } = await supabase.functions.invoke('messages-manager', {
          body: { action: 'get_unread_count', user_id: user.id || user.user_id }
        });
        setUnreadMessages(data?.unread_count || 0);
      };
      loadUnread();
      const interval = setInterval(loadUnread, 30000);
      return () => clearInterval(interval);
    }
  }, [user]);

  // Load mining balance
  useEffect(() => {
    if (user) {
      const loadMiningBalance = async () => {
        try {
          const { data } = await supabase.functions.invoke('mining-manager', {
            body: { action: 'get_wallet', user_id: user.user_id || user.id }
          });
          if (data?.wallet) {
            setMiningBalance(parseFloat(data.wallet.balance) || 0);
          }
        } catch (error) {
          console.error('Failed to load mining balance:', error);
        }
      };
      loadMiningBalance();
      const interval = setInterval(loadMiningBalance, 60000);
      return () => clearInterval(interval);
    }
  }, [user]);

  const categories = ['All', 'Gaming', 'Music', 'Beauty', 'Talk', 'Talent'];
  const filteredStreams = streams.filter(stream => (activeCategory === 'All' || stream.category === activeCategory) && (stream.streamerName.toLowerCase().includes(searchQuery.toLowerCase()) || stream.title.toLowerCase().includes(searchQuery.toLowerCase())));
  const safeLiveStreams = Array.isArray(liveStreams) ? liveStreams : [];
  const filteredLiveStreams = safeLiveStreams.filter(stream => (activeCategory === 'All' || stream.category === activeCategory) && (stream.streamer_name?.toLowerCase().includes(searchQuery.toLowerCase()) || stream.title?.toLowerCase().includes(searchQuery.toLowerCase())));

  const handleSignOut = async () => { await signOut(); setShowUserMenu(false); };
  const handleGoLive = () => { if (!user) { navigate('/login'); return; } setShowGoLiveModal(true); };

  return (
    <div className="min-h-screen bg-[#1a1a2e]">
      <header className="bg-[#16213e] border-b border-gray-800 sticky top-0 z-40">
        <div className="max-w-7xl mx-auto px-4 py-4">
          <div className="flex items-center justify-between gap-4">
            <Link to="/" className="text-3xl font-bold bg-gradient-to-r from-purple-500 to-pink-500 bg-clip-text text-transparent">Assigned</Link>

            <div className="flex-1 max-w-md">
              <input type="text" placeholder="Search streams..." value={searchQuery} onChange={(e) => setSearchQuery(e.target.value)} className="w-full bg-[#1a1a2e] text-white px-4 py-2 rounded-full border border-gray-700 focus:border-purple-500 focus:outline-none" />
            </div>
            <div className="flex items-center gap-3">
              {/* Find User Button */}
              <button 
                onClick={() => setShowUserLookup(true)}
                className="p-2 text-cyan-400 hover:text-cyan-300 hover:bg-cyan-500/20 rounded-full transition-colors"
                title="Find User by ID or Phone"
              >
                <Search className="w-5 h-5" />
              </button>

              {/* QR Code Button */}
              <button 
                onClick={() => setShowQRModal(true)}
                className="p-2 text-purple-400 hover:text-purple-300 hover:bg-purple-500/20 rounded-full transition-colors"
                title="Signup QR Code"
              >
                <QrCode className="w-5 h-5" />
              </button>
              
              <button onClick={handleGoLive} className="bg-gradient-to-r from-purple-600 to-pink-600 text-white px-6 py-2 rounded-full font-semibold hover:shadow-lg hover:shadow-purple-500/50 transition-all flex items-center gap-2"><Radio className="w-4 h-4" /> Go Live</button>
              {user ? (
                <>
                  {/* Mining Balance Quick View */}
                  {miningBalance !== null && (
                    <Link 
                      to="/mining" 
                      className="flex items-center gap-2 bg-gradient-to-r from-amber-500/20 to-orange-500/20 px-3 py-2 rounded-full border border-amber-500/30 hover:border-amber-500/50 transition-colors"
                      title="StreamCoin Balance"
                    >
                      <Coins className="w-4 h-4 text-amber-400" />
                      <span className="text-amber-400 text-sm font-medium">{miningBalance.toFixed(4)} STC</span>
                    </Link>
                  )}
                  
                  {/* AI Assistant Quick Access */}
                  <Link 
                    to="/mining?tab=ai-chat" 
                    className="p-2 text-violet-400 hover:text-violet-300 hover:bg-violet-500/20 rounded-full transition-colors"
                    title="AI Assistant"
                  >
                    <Bot className="w-5 h-5" />
                  </Link>
                  
                  <Link to="/messages" className="relative p-2 text-gray-400 hover:text-white transition-colors">
                    <MessageCircle className="w-6 h-6" />
                    {unreadMessages > 0 && <span className="absolute -top-1 -right-1 bg-red-500 text-white text-xs rounded-full w-5 h-5 flex items-center justify-center">{unreadMessages > 9 ? '9+' : unreadMessages}</span>}
                  </Link>
                  <div className="relative">
                    <button onClick={() => setShowUserMenu(!showUserMenu)} className="flex items-center gap-2 bg-[#1a1a2e] px-3 py-2 rounded-full border border-gray-700 hover:border-purple-500 transition-colors">
                      <div className="w-8 h-8 rounded-full bg-gradient-to-br from-purple-500 to-pink-500 flex items-center justify-center overflow-hidden">{user.avatar_url ? <img src={user.avatar_url} alt="" className="w-full h-full object-cover" /> : <span className="text-white font-bold text-sm">{user.username[0].toUpperCase()}</span>}</div>
                      <span className="text-white text-sm hidden sm:block">{user.display_name || user.username}</span>
                      <ChevronDown className="w-4 h-4 text-gray-400" />
                    </button>
                    {showUserMenu && (
                      <div className="absolute right-0 mt-2 w-64 bg-[#16213e] border border-gray-700 rounded-xl shadow-xl overflow-hidden z-50 max-h-[80vh] overflow-y-auto">
                        {/* User Info Header */}
                        {user.unique_id && (
                          <div className="px-4 py-3 bg-gradient-to-r from-purple-500/10 to-pink-500/10 border-b border-gray-700">
                            <div className="flex items-center gap-2 text-xs text-gray-400">
                              <Hash className="w-3 h-3" />
                              <span>ID: <span className="text-purple-400 font-mono">{user.unique_id}</span></span>
                            </div>
                            {user.phone_number && (
                              <div className="flex items-center gap-2 text-xs text-gray-400 mt-1">
                                <Phone className="w-3 h-3" />
                                <span className="text-green-400 font-mono">{user.phone_number}</span>
                              </div>
                            )}
                          </div>
                        )}
                        
                        <Link to="/profile" onClick={() => setShowUserMenu(false)} className="flex items-center gap-3 px-4 py-3 text-gray-300 hover:bg-purple-600/20 hover:text-white transition-colors"><User className="w-4 h-4" /> My Profile</Link>
                        <Link to="/messages" onClick={() => setShowUserMenu(false)} className="flex items-center gap-3 px-4 py-3 text-gray-300 hover:bg-purple-600/20 hover:text-white transition-colors"><MessageCircle className="w-4 h-4" /> Messages {unreadMessages > 0 && <span className="ml-auto bg-red-500 text-white text-xs rounded-full px-2">{unreadMessages}</span>}</Link>
                        <Link to="/feed" onClick={() => setShowUserMenu(false)} className="flex items-center gap-3 px-4 py-3 text-gray-300 hover:bg-purple-600/20 hover:text-white transition-colors"><Users className="w-4 h-4" /> Following Feed</Link>
                        
                        {/* Find User */}
                        <button 
                          onClick={() => { setShowUserMenu(false); setShowUserLookup(true); }}
                          className="w-full flex items-center gap-3 px-4 py-3 text-gray-300 hover:bg-cyan-600/20 hover:text-cyan-400 transition-colors"
                        >
                          <Search className="w-4 h-4" /> 
                          <span>Find User</span>
                          <span className="ml-auto text-cyan-400 text-xs">ID/Phone</span>
                        </button>

                        {/* QR Code */}
                        <button 
                          onClick={() => { setShowUserMenu(false); setShowQRModal(true); }}
                          className="w-full flex items-center gap-3 px-4 py-3 text-gray-300 hover:bg-purple-600/20 hover:text-purple-400 transition-colors"
                        >
                          <QrCode className="w-4 h-4" /> 
                          <span>Signup QR Code</span>
                          <span className="ml-auto bg-purple-500/20 text-purple-400 text-xs px-2 py-0.5 rounded-full">Share</span>
                        </button>
                        
                        {/* Voice Rooms */}
                        <Link 
                          to="/voice" 
                          onClick={() => setShowUserMenu(false)}
                          className="flex items-center gap-3 px-4 py-3 text-gray-300 hover:bg-green-600/20 hover:text-green-400 transition-colors"
                        >
                          <Mic className="w-4 h-4" /> 
                          <span>Voice Rooms</span>
                          <span className="ml-auto bg-green-500/20 text-green-400 text-xs px-2 py-0.5 rounded-full">Live</span>
                        </Link>
                        
                        {/* Media Posts Section */}
                        <div className="border-t border-gray-700 my-1" />
                        <div className="px-4 py-2 text-xs text-gray-500 uppercase tracking-wider">Media</div>
                        <Link to="/feed" onClick={() => setShowUserMenu(false)} className="flex items-center gap-3 px-4 py-3 text-gray-300 hover:bg-pink-600/20 hover:text-pink-400 transition-colors">
                          <Image className="w-4 h-4" /> 
                          <span>Photos & Videos</span>
                          <Film className="w-3 h-3 ml-auto text-pink-400" />
                        </Link>
                        
                        <div className="border-t border-gray-700 my-1" />

                        <Link to="/subscriptions" onClick={() => setShowUserMenu(false)} className="flex items-center gap-3 px-4 py-3 text-gray-300 hover:bg-purple-600/20 hover:text-white transition-colors"><Star className="w-4 h-4" /> Subscriptions</Link>
                        <Link to="/analytics" onClick={() => setShowUserMenu(false)} className="flex items-center gap-3 px-4 py-3 text-gray-300 hover:bg-blue-600/20 hover:text-blue-400 transition-colors"><BarChart3 className="w-4 h-4" /> Analytics</Link>
                        <Link to="/wallet" onClick={() => setShowUserMenu(false)} className="flex items-center gap-3 px-4 py-3 text-gray-300 hover:bg-yellow-600/20 hover:text-yellow-400 transition-colors"><Coins className="w-4 h-4" /> Wallet</Link>

                        <div className="border-t border-gray-700 my-1" />
                        <div className="px-4 py-2 text-xs text-gray-500 uppercase tracking-wider">Blockchain & AI</div>
                        <Link to="/mining" onClick={() => setShowUserMenu(false)} className="flex items-center gap-3 px-4 py-3 text-gray-300 hover:bg-amber-600/20 hover:text-amber-400 transition-colors">
                          <Pickaxe className="w-4 h-4" /> 
                          <span>Mining Dashboard</span>
                          {miningBalance !== null && (
                            <span className="ml-auto text-amber-400 text-xs font-mono">{miningBalance.toFixed(4)} STC</span>
                          )}
                        </Link>
                        <Link to="/mining?tab=explorer" onClick={() => setShowUserMenu(false)} className="flex items-center gap-3 px-4 py-3 text-gray-300 hover:bg-blue-600/20 hover:text-blue-400 transition-colors">
                          <Blocks className="w-4 h-4" /> 
                          <span>Blockchain Explorer</span>
                        </Link>
                        <Link to="/trading" onClick={() => setShowUserMenu(false)} className="flex items-center gap-3 px-4 py-3 text-gray-300 hover:bg-green-600/20 hover:text-green-400 transition-colors">
                          <ArrowUpDown className="w-4 h-4" /> 
                          <span>STC Trading</span>
                        </Link>
                        <Link to="/trading?tab=bots" onClick={() => setShowUserMenu(false)} className="flex items-center gap-3 px-4 py-3 text-gray-300 hover:bg-purple-600/20 hover:text-purple-400 transition-colors">
                          <Bot className="w-4 h-4" /> 
                          <span>Trading Bots</span>
                          <span className="ml-auto text-purple-400 text-xs">API</span>
                        </Link>

                        <Link to="/mining?tab=ai-chat" onClick={() => setShowUserMenu(false)} className="flex items-center gap-3 px-4 py-3 text-gray-300 hover:bg-violet-600/20 hover:text-violet-400 transition-colors">
                          <Bot className="w-4 h-4" /> 
                          <span>AI Assistant</span>
                          <Sparkles className="w-3 h-3 ml-auto text-violet-400" />
                        </Link>
                        <Link to="/mining?tab=ai-tools" onClick={() => setShowUserMenu(false)} className="flex items-center gap-3 px-4 py-3 text-gray-300 hover:bg-pink-600/20 hover:text-pink-400 transition-colors">
                          <Sparkles className="w-4 h-4" /> 
                          <span>AI Content Tools</span>
                        </Link>
                        
                        <Link to="/earnings" onClick={() => setShowUserMenu(false)} className="flex items-center gap-3 px-4 py-3 text-gray-300 hover:bg-green-600/20 hover:text-green-400 transition-colors"><Wallet className="w-4 h-4" /> Earnings</Link>
                        
                        {/* SMS Sign-In Info */}
                        <button 
                          onClick={() => { setShowUserMenu(false); setShowSMSSignIn(true); }}
                          className="w-full flex items-center gap-3 px-4 py-3 text-gray-300 hover:bg-green-600/20 hover:text-green-400 transition-colors"
                        >
                          <Smartphone className="w-4 h-4" /> 
                          <span>Text Me Sign-In Info</span>
                          <span className="ml-auto bg-green-500/20 text-green-400 text-xs px-2 py-0.5 rounded-full">SMS</span>
                        </button>
                        
                        <button onClick={handleSignOut} className="w-full flex items-center gap-3 px-4 py-3 text-gray-300 hover:bg-red-600/20 hover:text-red-400 transition-colors"><LogOut className="w-4 h-4" /> Sign Out</button>
                      </div>



                    )}
                  </div>
                </>
              ) : (<Link to="/login" className="text-white bg-[#1a1a2e] px-4 py-2 rounded-full border border-gray-700 hover:border-purple-500 transition-colors">Sign In</Link>)}
            </div>
          </div>
        </div>
      </header>
      <div className="relative h-64 overflow-hidden">
        <img src="https://d64gsuwffb70l.cloudfront.net/6927ca8790687cc18bcac914_1764215524398_d014a803.webp" alt="Hero" className="w-full h-full object-cover" />
        <div className="absolute inset-0 bg-gradient-to-r from-purple-900/80 to-pink-900/80 flex items-center justify-center">
          <div className="text-center"><h2 className="text-5xl font-bold text-white mb-4">Welcome to Assigned</h2><p className="text-xl text-gray-200">Connect with creators and join dialogues around the world</p></div>
        </div>
      </div>

      {/* Stories Section */}
      {user && (
        <div className="max-w-7xl mx-auto px-4 pt-6">
          <StoriesBar />
        </div>
      )}

      <StatsBar />
      {filteredLiveStreams.length > 0 && (
        <div className="max-w-7xl mx-auto px-4 py-8">
          <h2 className="text-3xl font-bold text-white mb-6 flex items-center gap-3"><span className="w-3 h-3 bg-red-500 rounded-full animate-pulse" /> Live Now</h2>
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
            {filteredLiveStreams.map(stream => (
              <div key={stream.id} onClick={() => navigate(`/watch/${stream.id}`)} className="cursor-pointer bg-[#16213e] rounded-xl overflow-hidden hover:ring-2 hover:ring-purple-500 transition-all group">
                <div className="relative aspect-video bg-gray-800">{stream.thumbnail_url ? <img src={stream.thumbnail_url} alt="" className="w-full h-full object-cover group-hover:scale-105 transition-transform" /> : <div className="w-full h-full flex items-center justify-center text-gray-600"><Radio className="w-12 h-12" /></div>}<div className="absolute top-2 left-2 bg-red-600 text-white text-xs px-2 py-1 rounded font-semibold">LIVE</div><div className="absolute bottom-2 right-2 bg-black/70 text-white text-xs px-2 py-1 rounded flex items-center gap-1"><Users className="w-3 h-3" />{stream.viewer_count}</div></div>
                <div className="p-3"><h3 className="text-white font-semibold truncate">{stream.title}</h3><p className="text-gray-400 text-sm">{stream.streamer_name}</p><span className="text-purple-400 text-xs">{stream.category}</span></div>
              </div>
            ))}
          </div>
        </div>
      )}
      <div className="max-w-7xl mx-auto px-4 py-8 space-y-8">
        <UpcomingSchedules />
        <TopClips />
        <TrendingSection streams={streams} onStreamClick={(s) => navigate(`/watch/${s.id}`)} />
        <div className="mb-6"><h2 className="text-3xl font-bold text-white mb-6">All Streams</h2><CategoryFilter categories={categories} activeCategory={activeCategory} onCategoryChange={setActiveCategory} /></div>
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">{filteredStreams.map(stream => (<StreamCard key={stream.id} stream={stream} onClick={() => {}} />))}</div>
      </div>

      <Footer />
      <GoLiveModal isOpen={showGoLiveModal} onClose={() => setShowGoLiveModal(false)} onStreamStarted={() => navigate('/broadcast')} />
      <UserLookup isOpen={showUserLookup} onClose={() => setShowUserLookup(false)} />
      <SignupQRModal isOpen={showQRModal} onClose={() => setShowQRModal(false)} />
      <SendSignInSMS isOpen={showSMSSignIn} onClose={() => setShowSMSSignIn(false)} />
    </div>
  );
}

