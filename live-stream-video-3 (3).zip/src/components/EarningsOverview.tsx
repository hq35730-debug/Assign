
import React from 'react';
import { DollarSign, TrendingUp, Users, CreditCard, Percent, Wallet } from 'lucide-react';

interface EarningsData {
  donations: number;
  subscriptions: number;
  total: number;
  platformFee: number;
  paidOut: number;
  available: number;
  subCount: number;
}

interface Props {
  earnings: EarningsData;
  loading: boolean;
}

export function EarningsOverview({ earnings, loading }: Props) {
  const formatCurrency = (cents: number) => `$${(cents / 100).toFixed(2)}`;

  const cards = [
    { label: 'Total Earnings', value: earnings.total, icon: TrendingUp, color: 'from-green-500 to-emerald-500' },
    { label: 'From Donations', value: earnings.donations, icon: DollarSign, color: 'from-purple-500 to-pink-500' },
    { label: 'From Subscriptions', value: earnings.subscriptions, icon: Users, color: 'from-blue-500 to-cyan-500', sub: `${earnings.subCount} active` },
    { label: 'Platform Fee (10%)', value: earnings.platformFee, icon: Percent, color: 'from-orange-500 to-red-500' },
    { label: 'Paid Out', value: earnings.paidOut, icon: CreditCard, color: 'from-gray-500 to-gray-600' },
    { label: 'Available Balance', value: earnings.available, icon: Wallet, color: 'from-green-400 to-teal-500', highlight: true },
  ];

  if (loading) {
    return (
      <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
        {[...Array(6)].map((_, i) => (
          <div key={i} className="bg-[#16213e] rounded-xl p-4 border border-gray-800 animate-pulse">
            <div className="h-4 bg-gray-700 rounded w-24 mb-2" />
            <div className="h-8 bg-gray-700 rounded w-20" />
          </div>
        ))}
      </div>
    );
  }

  return (
    <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
      {cards.map((card) => (
        <div key={card.label} className={`bg-[#16213e] rounded-xl p-4 border ${card.highlight ? 'border-green-500/50 ring-1 ring-green-500/20' : 'border-gray-800'}`}>
          <div className="flex items-center gap-2 mb-2">
            <div className={`w-8 h-8 rounded-lg bg-gradient-to-br ${card.color} flex items-center justify-center`}>
              <card.icon className="w-4 h-4 text-white" />
            </div>
            <span className="text-gray-400 text-sm">{card.label}</span>
          </div>
          <p className={`text-2xl font-bold ${card.highlight ? 'text-green-400' : 'text-white'}`}>
            {formatCurrency(card.value)}
          </p>
          {card.sub && <p className="text-gray-500 text-xs mt-1">{card.sub}</p>}
        </div>
      ))}
    </div>
  );
}
