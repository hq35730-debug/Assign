import React from 'react';
import { Card } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Play, Eye, Heart, Share2, Clock } from 'lucide-react';

interface ClipCardProps {
  clip: {
    id: string;
    title: string;
    streamer_name: string;
    creator_name: string;
    thumbnail_url: string;
    duration: number;
    views: number;
    likes: number;
    created_at: string;
  };
  onClick: () => void;
  onShare?: () => void;
}

export const ClipCard: React.FC<ClipCardProps> = ({ clip, onClick, onShare }) => {
  const formatDuration = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  const formatViews = (views: number) => {
    if (views >= 1000000) return `${(views / 1000000).toFixed(1)}M`;
    if (views >= 1000) return `${(views / 1000).toFixed(1)}K`;
    return views.toString();
  };

  const timeAgo = (date: string) => {
    const seconds = Math.floor((Date.now() - new Date(date).getTime()) / 1000);
    if (seconds < 3600) return `${Math.floor(seconds / 60)}m ago`;
    if (seconds < 86400) return `${Math.floor(seconds / 3600)}h ago`;
    return `${Math.floor(seconds / 86400)}d ago`;
  };

  return (
    <Card className="group overflow-hidden bg-gray-800/50 border-gray-700 hover:border-purple-500/50 transition-all cursor-pointer" onClick={onClick}>
      <div className="relative aspect-video">
        <img src={clip.thumbnail_url} alt={clip.title} className="w-full h-full object-cover" />
        <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
          <div className="w-14 h-14 rounded-full bg-purple-600 flex items-center justify-center">
            <Play className="w-6 h-6 text-white fill-white ml-1" />
          </div>
        </div>
        <Badge className="absolute bottom-2 right-2 bg-black/80 text-white">
          <Clock className="w-3 h-3 mr-1" />
          {formatDuration(clip.duration)}
        </Badge>
      </div>
      <div className="p-3">
        <h3 className="font-semibold text-white truncate group-hover:text-purple-400 transition-colors">{clip.title}</h3>
        <p className="text-sm text-gray-400 mt-1">Clipped from {clip.streamer_name}</p>
        <p className="text-xs text-gray-500">by {clip.creator_name}</p>
        <div className="flex items-center gap-3 mt-2 text-xs text-gray-400">
          <span className="flex items-center gap-1"><Eye className="w-3 h-3" />{formatViews(clip.views)}</span>
          <span className="flex items-center gap-1"><Heart className="w-3 h-3" />{formatViews(clip.likes)}</span>
          <span className="ml-auto">{timeAgo(clip.created_at)}</span>
        </div>
      </div>
    </Card>
  );
};
