import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { useStream } from '@/contexts/StreamContext';
import { supabase } from '@/lib/supabase';
import { Mic } from 'lucide-react';

export const StatsBar: React.FC = () => {
  const { liveStreams } = useStream();
  const safeStreams = Array.isArray(liveStreams) ? liveStreams : [];
  const totalViewers = safeStreams.reduce((sum, s) => sum + (s.viewer_count || 0), 0);
  const [voiceRoomCount, setVoiceRoomCount] = useState(0);

  useEffect(() => {
    const loadVoiceRooms = async () => {
      try {
        const { data } = await supabase.functions.invoke('voice-room-manager', {
          body: { action: 'get_active_rooms' }
        });
        setVoiceRoomCount(data?.rooms?.length || 0);
      } catch (err) {
        console.error('Failed to load voice rooms:', err);
      }
    };
    loadVoiceRooms();
    const interval = setInterval(loadVoiceRooms, 30000);
    return () => clearInterval(interval);
  }, []);

  return (
    <div className="bg-gradient-to-r from-purple-900/50 to-pink-900/50 py-8 mb-12">
      <div className="max-w-7xl mx-auto px-4">
        <div className="grid grid-cols-2 md:grid-cols-5 gap-8">
          <div className="text-center">
            <div className="text-4xl font-bold text-white mb-2">{safeStreams.length}</div>
            <div className="text-gray-300 text-sm">Live Now</div>
          </div>
          <div className="text-center">
            <div className="text-4xl font-bold text-white mb-2">{totalViewers.toLocaleString()}</div>
            <div className="text-gray-300 text-sm">Current Viewers</div>
          </div>
          <Link to="/voice" className="text-center group">
            <div className="text-4xl font-bold text-green-400 mb-2 flex items-center justify-center gap-2 group-hover:text-green-300 transition-colors">
              <Mic className="w-8 h-8" />
              {voiceRoomCount}
            </div>
            <div className="text-gray-300 text-sm group-hover:text-green-300 transition-colors">Voice Rooms</div>
          </Link>
          <div className="text-center">
            <div className="text-4xl font-bold text-white mb-2">24/7</div>
            <div className="text-gray-300 text-sm">Live Content</div>
          </div>
          <div className="text-center">
            <div className="text-4xl font-bold text-white mb-2">100+</div>
            <div className="text-gray-300 text-sm">Countries</div>
          </div>
        </div>
      </div>
    </div>
  );
};
