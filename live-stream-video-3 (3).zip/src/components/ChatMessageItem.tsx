
import React, { useState } from 'react';
import { Shield, Trash2, Clock, Crown, Star, Sparkles, Diamond } from 'lucide-react';

interface ChatMsg {
  id: string;
  user_id: string;
  username: string;
  display_name: string;
  message: string;
  badge: string | null;
  is_highlighted?: boolean;
  vip_tier_level?: number;
  vip_badge_color?: string;
}

interface Props {
  msg: ChatMsg;
  canModerate: boolean;
  onDelete: (id: string) => void;
  onTimeout: () => void;
  currentUserId?: string;
  renderMessage: (m: string) => string;
}

export const ChatMessageItem: React.FC<Props> = ({ msg, canModerate, onDelete, onTimeout, currentUserId, renderMessage }) => {
  const [showActions, setShowActions] = useState(false);

  const getVIPBadge = () => {
    if (!msg.vip_tier_level || !msg.vip_badge_color) return null;
    const style = { color: msg.vip_badge_color };
    switch (msg.vip_tier_level) {
      case 1: return <Shield className="w-4 h-4" style={style} />;
      case 2: return <Star className="w-4 h-4" style={style} fill={msg.vip_badge_color} />;
      case 3: return <Crown className="w-4 h-4" style={style} fill={msg.vip_badge_color} />;
      case 4: return <Diamond className="w-4 h-4" style={style} fill={msg.vip_badge_color} />;
      default: return null;
    }
  };

  const getRoleBadge = () => {
    if (msg.badge === 'STREAMER') return <Crown className="w-4 h-4 text-yellow-400" />;
    if (msg.badge === 'MOD') return <Shield className="w-4 h-4 text-green-400" />;
    if (msg.badge === 'SUB') return <Star className="w-4 h-4 text-purple-400 fill-purple-400" />;
    return null;
  };

  const isOwnMessage = msg.user_id === currentUserId;
  const nameColor = msg.badge === 'STREAMER' ? 'text-yellow-400' : msg.badge === 'MOD' ? 'text-green-400' : msg.badge === 'SUB' ? 'text-purple-400' : msg.vip_badge_color ? '' : 'text-gray-400';
  const nameStyle = msg.vip_badge_color && !msg.badge ? { color: msg.vip_badge_color } : {};

  return (
    <div 
      className={`group flex items-start gap-2 rounded px-2 py-1 ${msg.is_highlighted ? 'bg-gradient-to-r from-purple-600/30 to-pink-600/30 border-l-2 border-purple-500' : 'hover:bg-white/5'}`}
      onMouseEnter={() => setShowActions(true)} 
      onMouseLeave={() => setShowActions(false)}
    >
      {msg.is_highlighted && <Sparkles className="w-4 h-4 text-yellow-400 flex-shrink-0 mt-0.5" />}
      <div className="flex-1 min-w-0">
        <span className="inline-flex items-center gap-1">
          {getVIPBadge()}
          {getRoleBadge()}
          <span className={`font-semibold text-sm ${nameColor}`} style={nameStyle}>
            {msg.display_name || msg.username}:
          </span>
        </span>
        <span className="text-gray-200 text-sm ml-1">{renderMessage(msg.message)}</span>
      </div>
      {showActions && canModerate && !isOwnMessage && (
        <div className="flex gap-1">
          <button onClick={() => onDelete(msg.id)} className="p-1 hover:bg-red-600/30 rounded" title="Delete">
            <Trash2 className="w-4 h-4 text-red-400" />
          </button>
          <button onClick={onTimeout} className="p-1 hover:bg-orange-600/30 rounded" title="Timeout">
            <Clock className="w-4 h-4 text-orange-400" />
          </button>
        </div>
      )}
    </div>
  );
};
