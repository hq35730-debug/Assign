import React, { useState } from 'react';
import { DollarSign, Gift, X } from 'lucide-react';
import { useAuth } from '@/contexts/AuthContext';
import { supabase } from '@/lib/supabase';

interface Props {
  streamerId: string;
  streamerName: string;
  streamId: string;
}

const presetAmounts = [1, 5, 10, 25];

export function DonationButton({ streamerId, streamerName, streamId }: Props) {
  const { user } = useAuth();
  const [showModal, setShowModal] = useState(false);
  const [amount, setAmount] = useState(5);
  const [customAmount, setCustomAmount] = useState('');
  const [message, setMessage] = useState('');
  const [loading, setLoading] = useState(false);

  const handleDonate = async () => {
    if (!user) return;
    const finalAmount = customAmount ? parseInt(customAmount) : amount;
    if (finalAmount < 1) return;

    setLoading(true);
    try {
      const { data, error } = await supabase.functions.invoke('donation-manager', {
        body: {
          action: 'create_checkout',
          amount: finalAmount,
          streamer_id: streamerId,
          streamer_name: streamerName,
          stream_id: streamId,
          donor_id: user.user_id,
          donor_username: user.username,
          donor_display_name: user.display_name,
          message
        }
      });

      if (data?.url) {
        window.location.href = data.url;
      }
    } catch (err) {
      console.error('Donation error:', err);
    }
    setLoading(false);
  };

  if (!user) return null;

  return (
    <>
      <button
        onClick={() => setShowModal(true)}
        className="bg-gradient-to-r from-yellow-500 to-orange-500 text-white px-4 py-2 rounded-full font-semibold hover:shadow-lg transition-all flex items-center gap-2"
      >
        <Gift className="w-4 h-4" /> Tip
      </button>

      {showModal && (
        <div className="fixed inset-0 bg-black/80 flex items-center justify-center z-50 p-4">
          <div className="bg-[#16213e] rounded-2xl p-6 w-full max-w-md border border-gray-700">
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-xl font-bold text-white flex items-center gap-2">
                <Gift className="w-6 h-6 text-yellow-500" /> Send a Tip
              </h2>
              <button onClick={() => setShowModal(false)} className="text-gray-400 hover:text-white">
                <X className="w-6 h-6" />
              </button>
            </div>

            <p className="text-gray-400 mb-4">Support {streamerName} with a tip!</p>

            <div className="grid grid-cols-4 gap-2 mb-4">
              {presetAmounts.map((preset) => (
                <button
                  key={preset}
                  onClick={() => { setAmount(preset); setCustomAmount(''); }}
                  className={`py-3 rounded-lg font-bold transition-all ${
                    amount === preset && !customAmount
                      ? 'bg-gradient-to-r from-yellow-500 to-orange-500 text-white'
                      : 'bg-[#1a1a2e] text-gray-300 hover:bg-gray-700'
                  }`}
                >
                  ${preset}
                </button>
              ))}
            </div>

            <div className="mb-4">
              <label className="text-gray-400 text-sm mb-2 block">Custom Amount</label>
              <div className="relative">
                <DollarSign className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-500" />
                <input
                  type="number"
                  min="1"
                  placeholder="Enter amount"
                  value={customAmount}
                  onChange={(e) => setCustomAmount(e.target.value)}
                  className="w-full bg-[#1a1a2e] text-white pl-10 pr-4 py-3 rounded-lg border border-gray-700 focus:border-yellow-500 outline-none"
                />
              </div>
            </div>

            <div className="mb-6">
              <label className="text-gray-400 text-sm mb-2 block">Message (optional)</label>
              <textarea
                placeholder="Say something nice..."
                value={message}
                onChange={(e) => setMessage(e.target.value)}
                maxLength={200}
                className="w-full bg-[#1a1a2e] text-white px-4 py-3 rounded-lg border border-gray-700 focus:border-yellow-500 outline-none resize-none h-20"
              />
            </div>

            <button
              onClick={handleDonate}
              disabled={loading}
              className="w-full bg-gradient-to-r from-yellow-500 to-orange-500 text-white py-3 rounded-lg font-bold hover:shadow-lg transition-all disabled:opacity-50"
            >
              {loading ? 'Processing...' : `Send $${customAmount || amount} Tip`}
            </button>
          </div>
        </div>
      )}
    </>
  );
}
