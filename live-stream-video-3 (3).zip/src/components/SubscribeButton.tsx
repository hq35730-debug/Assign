
import React, { useState, useEffect } from 'react';
import { Star, Loader2, Check } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/contexts/AuthContext';

interface SubscribeButtonProps {
  streamerId: string;
  streamerName: string;
  onSubscribed?: () => void;
}

export const SubscribeButton: React.FC<SubscribeButtonProps> = ({ streamerId, streamerName, onSubscribed }) => {
  const { user } = useAuth();
  const [isSubscribed, setIsSubscribed] = useState(false);
  const [loading, setLoading] = useState(false);
  const [checking, setChecking] = useState(true);

  useEffect(() => {
    if (user) checkSubscription();
    else setChecking(false);
  }, [user, streamerId]);

  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    if (params.get('success') === 'true' && params.get('streamer') === streamerId) {
      confirmSubscription();
      window.history.replaceState({}, '', window.location.pathname);
    }
  }, [streamerId]);

  const checkSubscription = async () => {
    setChecking(true);
    const { data } = await supabase.functions.invoke('subscription-manager', {
      body: { action: 'check_subscription', subscriber_id: user?.user_id, streamer_id: streamerId }
    });
    setIsSubscribed(data?.subscribed || false);
    setChecking(false);
  };

  const confirmSubscription = async () => {
    const sessionId = sessionStorage.getItem('checkout_session');
    if (sessionId && user) {
      await supabase.functions.invoke('subscription-manager', {
        body: { action: 'confirm_subscription', session_id: sessionId, subscriber_id: user.user_id, streamer_id: streamerId }
      });
      sessionStorage.removeItem('checkout_session');
      setIsSubscribed(true);
      onSubscribed?.();
    }
  };

  const handleSubscribe = async () => {
    if (!user) { window.location.href = '/login'; return; }
    setLoading(true);
    const { data, error } = await supabase.functions.invoke('subscription-manager', {
      body: { action: 'create_checkout', subscriber_id: user.user_id, streamer_id: streamerId, streamer_name: streamerName, return_url: window.location.href }
    });
    if (data?.url) {
      sessionStorage.setItem('checkout_session', data.session_id);
      window.location.href = data.url;
    }
    setLoading(false);
  };

  if (checking) return <div className="px-6 py-2 bg-gray-700 rounded-full"><Loader2 className="w-5 h-5 animate-spin text-gray-400" /></div>;
  if (user?.user_id === streamerId) return null;

  return isSubscribed ? (
    <div className="px-6 py-2 bg-gradient-to-r from-purple-600 to-pink-600 rounded-full flex items-center gap-2">
      <Star className="w-4 h-4 text-yellow-300 fill-yellow-300" />
      <span className="text-white font-semibold">Subscribed</span>
      <Check className="w-4 h-4 text-white" />
    </div>
  ) : (
    <button onClick={handleSubscribe} disabled={loading} className="px-6 py-2 bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 rounded-full flex items-center gap-2 disabled:opacity-50">
      {loading ? <Loader2 className="w-4 h-4 animate-spin text-white" /> : <Star className="w-4 h-4 text-yellow-300" />}
      <span className="text-white font-semibold">Subscribe</span>
      <span className="text-purple-200 text-sm">$4.99/mo</span>
    </button>
  );
};
