import { useState, useEffect } from 'react';
import { ArrowUpDown, TrendingUp, TrendingDown, Wallet, AlertCircle, Check, Loader2 } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Slider } from '@/components/ui/slider';
import { supabase } from '@/lib/supabase';
import { useToast } from '@/hooks/use-toast';

interface TradingInterfaceProps {
  userId: string;
  selectedPrice?: number;
  onOrderPlaced?: () => void;
}

interface Balances {
  stc_balance: number;
  stc_available: number;
  stc_locked: number;
  coins_balance: number;
  coins_available: number;
  coins_locked: number;
}

export function TradingInterface({ userId, selectedPrice, onOrderPlaced }: TradingInterfaceProps) {
  const [orderType, setOrderType] = useState<'buy' | 'sell'>('buy');
  const [orderMode, setOrderMode] = useState<'limit' | 'market'>('limit');
  const [price, setPrice] = useState('');
  const [amount, setAmount] = useState('');
  const [sliderValue, setSliderValue] = useState([0]);
  const [balances, setBalances] = useState<Balances | null>(null);
  const [loading, setLoading] = useState(false);
  const [fetchingBalances, setFetchingBalances] = useState(true);
  const { toast } = useToast();

  useEffect(() => {
    if (userId) {
      fetchBalances();
    }
  }, [userId]);

  useEffect(() => {
    if (selectedPrice) {
      setPrice(selectedPrice.toFixed(2));
    }
  }, [selectedPrice]);

  const fetchBalances = async () => {
    try {
      const { data, error } = await supabase.functions.invoke('trading-manager', {
        body: { action: 'get_user_balances', user_id: userId }
      });

      if (!error && data) {
        setBalances(data);
      }
    } catch (err) {
      console.error('Failed to fetch balances:', err);
    } finally {
      setFetchingBalances(false);
    }
  };

  const handleSliderChange = (value: number[]) => {
    setSliderValue(value);
    if (!balances) return;

    const percent = value[0] / 100;
    if (orderType === 'buy') {
      const priceNum = parseFloat(price) || 100;
      const maxAmount = balances.coins_available / priceNum;
      setAmount((maxAmount * percent).toFixed(4));
    } else {
      setAmount((balances.stc_available * percent).toFixed(4));
    }
  };

  const calculateTotal = () => {
    const priceNum = parseFloat(price) || 0;
    const amountNum = parseFloat(amount) || 0;
    return priceNum * amountNum;
  };

  const calculateFee = () => {
    return calculateTotal() * 0.005; // 0.5% fee
  };

  const handleSubmit = async () => {
    if (!userId) {
      toast({
        title: 'Error',
        description: 'Please sign in to trade',
        variant: 'destructive'
      });
      return;
    }

    const amountNum = parseFloat(amount);
    const priceNum = parseFloat(price);

    if (!amountNum || amountNum <= 0) {
      toast({
        title: 'Invalid Amount',
        description: 'Please enter a valid amount',
        variant: 'destructive'
      });
      return;
    }

    if (orderMode === 'limit' && (!priceNum || priceNum <= 0)) {
      toast({
        title: 'Invalid Price',
        description: 'Please enter a valid price for limit orders',
        variant: 'destructive'
      });
      return;
    }

    setLoading(true);
    try {
      const { data, error } = await supabase.functions.invoke('trading-manager', {
        body: {
          action: 'place_order',
          user_id: userId,
          order_type: orderType,
          order_mode: orderMode,
          price: orderMode === 'limit' ? priceNum : null,
          amount: amountNum
        }
      });

      if (error) throw error;

      if (data?.error) {
        toast({
          title: 'Order Failed',
          description: data.error,
          variant: 'destructive'
        });
        return;
      }

      const filledAmount = data?.filled || 0;
      toast({
        title: 'Order Placed',
        description: filledAmount > 0 
          ? `Order placed! ${filledAmount.toFixed(4)} STC filled immediately.`
          : `${orderMode === 'limit' ? 'Limit' : 'Market'} ${orderType} order placed successfully.`
      });

      setAmount('');
      setSliderValue([0]);
      fetchBalances();
      onOrderPlaced?.();
    } catch (err: any) {
      toast({
        title: 'Error',
        description: err.message || 'Failed to place order',
        variant: 'destructive'
      });
    } finally {
      setLoading(false);
    }
  };

  return (
    <Card className="bg-card/50 backdrop-blur border-border/50">
      <CardHeader className="pb-2">
        <CardTitle className="text-lg flex items-center gap-2">
          <ArrowUpDown className="w-5 h-5 text-primary" />
          Trade STC
        </CardTitle>
      </CardHeader>
      <CardContent>
        {/* Buy/Sell Toggle */}
        <div className="grid grid-cols-2 gap-2 mb-4">
          <Button
            variant={orderType === 'buy' ? 'default' : 'outline'}
            className={orderType === 'buy' ? 'bg-green-600 hover:bg-green-700' : ''}
            onClick={() => setOrderType('buy')}
          >
            <TrendingUp className="w-4 h-4 mr-2" />
            Buy
          </Button>
          <Button
            variant={orderType === 'sell' ? 'default' : 'outline'}
            className={orderType === 'sell' ? 'bg-red-600 hover:bg-red-700' : ''}
            onClick={() => setOrderType('sell')}
          >
            <TrendingDown className="w-4 h-4 mr-2" />
            Sell
          </Button>
        </div>

        {/* Order Mode */}
        <Tabs value={orderMode} onValueChange={(v) => setOrderMode(v as 'limit' | 'market')} className="mb-4">
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="limit">Limit</TabsTrigger>
            <TabsTrigger value="market">Market</TabsTrigger>
          </TabsList>
        </Tabs>

        {/* Balances */}
        <div className="grid grid-cols-2 gap-3 p-3 rounded-lg bg-muted/30 mb-4">
          <div className="flex items-center gap-2">
            <Wallet className="w-4 h-4 text-amber-500" />
            <div>
              <p className="text-xs text-muted-foreground">STC Available</p>
              <p className="font-mono font-medium">
                {fetchingBalances ? '...' : (balances?.stc_available || 0).toFixed(4)}
              </p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <Wallet className="w-4 h-4 text-primary" />
            <div>
              <p className="text-xs text-muted-foreground">Coins Available</p>
              <p className="font-mono font-medium">
                {fetchingBalances ? '...' : (balances?.coins_available || 0).toFixed(2)}
              </p>
            </div>
          </div>
        </div>

        {/* Price Input (Limit only) */}
        {orderMode === 'limit' && (
          <div className="mb-4">
            <Label htmlFor="price" className="text-sm">Price (Coins per STC)</Label>
            <div className="relative mt-1">
              <Input
                id="price"
                type="number"
                placeholder="0.00"
                value={price}
                onChange={(e) => setPrice(e.target.value)}
                className="pr-16 font-mono"
                step="0.01"
                min="0"
              />
              <span className="absolute right-3 top-1/2 -translate-y-1/2 text-sm text-muted-foreground">
                Coins
              </span>
            </div>
          </div>
        )}

        {/* Amount Input */}
        <div className="mb-4">
          <Label htmlFor="amount" className="text-sm">Amount (STC)</Label>
          <div className="relative mt-1">
            <Input
              id="amount"
              type="number"
              placeholder="0.0000"
              value={amount}
              onChange={(e) => setAmount(e.target.value)}
              className="pr-12 font-mono"
              step="0.0001"
              min="0"
            />
            <span className="absolute right-3 top-1/2 -translate-y-1/2 text-sm text-muted-foreground">
              STC
            </span>
          </div>
        </div>

        {/* Amount Slider */}
        <div className="mb-4">
          <Slider
            value={sliderValue}
            onValueChange={handleSliderChange}
            max={100}
            step={25}
            className="my-4"
          />
          <div className="flex justify-between text-xs text-muted-foreground">
            <span>0%</span>
            <span>25%</span>
            <span>50%</span>
            <span>75%</span>
            <span>100%</span>
          </div>
        </div>

        {/* Order Summary */}
        {(parseFloat(amount) > 0) && (
          <div className="p-3 rounded-lg bg-muted/30 mb-4 space-y-2">
            {orderMode === 'limit' && (
              <div className="flex justify-between text-sm">
                <span className="text-muted-foreground">Price</span>
                <span className="font-mono">{parseFloat(price || '0').toFixed(2)} Coins</span>
              </div>
            )}
            <div className="flex justify-between text-sm">
              <span className="text-muted-foreground">Amount</span>
              <span className="font-mono">{parseFloat(amount || '0').toFixed(4)} STC</span>
            </div>
            {orderMode === 'limit' && (
              <>
                <div className="flex justify-between text-sm">
                  <span className="text-muted-foreground">Subtotal</span>
                  <span className="font-mono">{calculateTotal().toFixed(2)} Coins</span>
                </div>
                <div className="flex justify-between text-sm">
                  <span className="text-muted-foreground">Fee (0.5%)</span>
                  <span className="font-mono">{calculateFee().toFixed(2)} Coins</span>
                </div>
                <div className="flex justify-between text-sm font-medium pt-2 border-t border-border/50">
                  <span>Total</span>
                  <span className="font-mono">
                    {orderType === 'buy' 
                      ? (calculateTotal() + calculateFee()).toFixed(2)
                      : (calculateTotal() - calculateFee()).toFixed(2)
                    } Coins
                  </span>
                </div>
              </>
            )}
            {orderMode === 'market' && (
              <div className="flex items-center gap-2 text-xs text-amber-500">
                <AlertCircle className="w-4 h-4" />
                <span>Market orders execute at best available price</span>
              </div>
            )}
          </div>
        )}

        {/* Submit Button */}
        <Button
          className={`w-full ${
            orderType === 'buy' 
              ? 'bg-green-600 hover:bg-green-700' 
              : 'bg-red-600 hover:bg-red-700'
          }`}
          onClick={handleSubmit}
          disabled={loading || !parseFloat(amount)}
        >
          {loading ? (
            <>
              <Loader2 className="w-4 h-4 mr-2 animate-spin" />
              Processing...
            </>
          ) : (
            <>
              {orderType === 'buy' ? (
                <TrendingUp className="w-4 h-4 mr-2" />
              ) : (
                <TrendingDown className="w-4 h-4 mr-2" />
              )}
              {orderType === 'buy' ? 'Buy' : 'Sell'} STC
            </>
          )}
        </Button>

        {/* Info */}
        <p className="text-xs text-muted-foreground text-center mt-3">
          Trading fee: 0.5% per trade
        </p>
      </CardContent>
    </Card>
  );
}
