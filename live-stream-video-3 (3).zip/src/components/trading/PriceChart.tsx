import { useState, useEffect, useMemo, useCallback } from 'react';
import { TrendingUp, TrendingDown, Clock, BarChart3, Activity, Maximize2, Minimize2, RefreshCw } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from '@/components/ui/tooltip';
import { supabase } from '@/lib/supabase';

interface PriceData {
  timestamp: string;
  open_price: string;
  high_price: string;
  low_price: string;
  close_price: string;
  volume: string;
  trades_count: number;
}

interface PriceChartProps {
  onPriceSelect?: (price: number) => void;
}

export function PriceChart({ onPriceSelect }: PriceChartProps) {
  const [priceHistory, setPriceHistory] = useState<PriceData[]>([]);
  const [interval, setInterval] = useState('1h');
  const [loading, setLoading] = useState(true);
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [showMA, setShowMA] = useState(true);
  const [lastUpdate, setLastUpdate] = useState<Date | null>(null);
  const [autoRefresh, setAutoRefresh] = useState(true);

  const intervals = [
    { value: '1m', label: '1m' },
    { value: '5m', label: '5m' },
    { value: '15m', label: '15m' },
    { value: '1h', label: '1H' },
    { value: '4h', label: '4H' },
    { value: '1d', label: '1D' },
  ];

  const fetchPriceHistory = useCallback(async () => {
    try {
      const { data, error } = await supabase.functions.invoke('trading-manager', {
        body: { action: 'get_price_history', interval, limit: 100 }
      });

      if (!error && data?.history) {
        setPriceHistory(data.history);
        setLastUpdate(new Date());
      }
    } catch (err) {
      console.error('Failed to fetch price history:', err);
    } finally {
      setLoading(false);
    }
  }, [interval]);

  useEffect(() => {
    fetchPriceHistory();
    
    if (autoRefresh) {
      const refreshInterval = interval === '1m' ? 10000 : interval === '5m' ? 30000 : 60000;
      const timer = window.setInterval(fetchPriceHistory, refreshInterval);
      return () => window.clearInterval(timer);
    }
  }, [interval, autoRefresh, fetchPriceHistory]);

  // Calculate moving averages
  const calculateMA = (data: number[], period: number) => {
    const result: (number | null)[] = [];
    for (let i = 0; i < data.length; i++) {
      if (i < period - 1) {
        result.push(null);
      } else {
        const sum = data.slice(i - period + 1, i + 1).reduce((a, b) => a + b, 0);
        result.push(sum / period);
      }
    }
    return result;
  };

  const chartData = useMemo(() => {
    if (priceHistory.length === 0) return { bars: [], min: 0, max: 100, ma7: [], ma25: [] };

    const prices = priceHistory.flatMap(p => [
      parseFloat(p.high_price),
      parseFloat(p.low_price)
    ]);
    const closePrices = priceHistory.map(p => parseFloat(p.close_price));
    
    const min = Math.min(...prices) * 0.98;
    const max = Math.max(...prices) * 1.02;

    const bars = priceHistory.map(p => ({
      timestamp: p.timestamp,
      open: parseFloat(p.open_price),
      high: parseFloat(p.high_price),
      low: parseFloat(p.low_price),
      close: parseFloat(p.close_price),
      volume: parseFloat(p.volume),
      isGreen: parseFloat(p.close_price) >= parseFloat(p.open_price)
    }));

    const ma7 = calculateMA(closePrices, 7);
    const ma25 = calculateMA(closePrices, 25);

    return { bars, min, max, ma7, ma25 };
  }, [priceHistory]);

  const currentPrice = priceHistory.length > 0 
    ? parseFloat(priceHistory[priceHistory.length - 1].close_price) 
    : 100;

  const firstPrice = priceHistory.length > 0 
    ? parseFloat(priceHistory[0].open_price) 
    : 100;

  const priceChange = currentPrice - firstPrice;
  const priceChangePercent = firstPrice > 0 ? (priceChange / firstPrice) * 100 : 0;
  const isPositive = priceChange >= 0;

  const totalVolume = priceHistory.reduce((sum, p) => sum + parseFloat(p.volume), 0);

  const getBarHeight = (price: number) => {
    const range = chartData.max - chartData.min;
    if (range === 0) return 50;
    return ((price - chartData.min) / range) * 100;
  };

  const chartHeight = isFullscreen ? 'h-[60vh]' : 'h-64';

  return (
    <Card className={`bg-card/50 backdrop-blur border-border/50 ${isFullscreen ? 'fixed inset-4 z-50' : ''}`}>
      <CardHeader className="pb-2">
        <div className="flex items-center justify-between flex-wrap gap-2">
          <div className="flex items-center gap-3">
            <CardTitle className="text-lg flex items-center gap-2">
              <BarChart3 className="w-5 h-5 text-primary" />
              STC/COINS
            </CardTitle>
            <div className="flex items-center gap-2">
              <span className="text-2xl font-bold">{currentPrice.toFixed(2)}</span>
              <div className={`flex items-center gap-1 text-sm ${isPositive ? 'text-green-500' : 'text-red-500'}`}>
                {isPositive ? <TrendingUp className="w-4 h-4" /> : <TrendingDown className="w-4 h-4" />}
                <span>{isPositive ? '+' : ''}{priceChange.toFixed(2)} ({priceChangePercent.toFixed(2)}%)</span>
              </div>
            </div>
            {autoRefresh && (
              <Badge variant="outline" className="text-xs bg-green-500/10 text-green-500 border-green-500/30">
                <span className="w-2 h-2 rounded-full bg-green-500 mr-1 animate-pulse" />
                Live
              </Badge>
            )}
          </div>
          <div className="flex items-center gap-2">
            <div className="flex items-center gap-1 text-xs text-muted-foreground mr-2">
              <Activity className="w-3 h-3" />
              Vol: {totalVolume.toFixed(2)} STC
            </div>
            <div className="flex items-center gap-1">
              {intervals.map(int => (
                <Button
                  key={int.value}
                  variant={interval === int.value ? 'default' : 'ghost'}
                  size="sm"
                  className="h-7 px-2 text-xs"
                  onClick={() => setInterval(int.value)}
                >
                  {int.label}
                </Button>
              ))}
            </div>
            <Button
              variant="ghost"
              size="sm"
              className="h-7 px-2"
              onClick={() => setShowMA(!showMA)}
            >
              MA
            </Button>
            <Button
              variant="ghost"
              size="sm"
              className="h-7 px-2"
              onClick={() => setAutoRefresh(!autoRefresh)}
            >
              <RefreshCw className={`w-4 h-4 ${autoRefresh ? 'text-green-500' : ''}`} />
            </Button>
            <Button
              variant="ghost"
              size="sm"
              className="h-7 px-2"
              onClick={() => setIsFullscreen(!isFullscreen)}
            >
              {isFullscreen ? <Minimize2 className="w-4 h-4" /> : <Maximize2 className="w-4 h-4" />}
            </Button>
          </div>
        </div>
        {lastUpdate && (
          <p className="text-xs text-muted-foreground">
            Last updated: {lastUpdate.toLocaleTimeString()}
          </p>
        )}
      </CardHeader>
      <CardContent>
        {loading ? (
          <div className={`${chartHeight} flex items-center justify-center`}>
            <div className="animate-spin w-8 h-8 border-2 border-primary border-t-transparent rounded-full" />
          </div>
        ) : (
          <div className={`relative ${chartHeight}`}>
            {/* Price labels */}
            <div className="absolute left-0 top-0 bottom-0 w-16 flex flex-col justify-between text-xs text-muted-foreground py-2">
              <span>{chartData.max.toFixed(2)}</span>
              <span>{((chartData.max + chartData.min) / 2).toFixed(2)}</span>
              <span>{chartData.min.toFixed(2)}</span>
            </div>

            {/* Chart area */}
            <div className="ml-16 h-full relative overflow-hidden rounded-lg bg-background/30">
              {/* Grid lines */}
              <div className="absolute inset-0 flex flex-col justify-between pointer-events-none">
                {[0, 1, 2, 3, 4].map(i => (
                  <div key={i} className="border-t border-border/30 w-full" />
                ))}
              </div>

              {/* Moving Averages */}
              {showMA && chartData.bars.length > 0 && (
                <svg className="absolute inset-0 w-full h-full pointer-events-none" preserveAspectRatio="none">
                  {/* MA7 Line */}
                  <polyline
                    fill="none"
                    stroke="#f59e0b"
                    strokeWidth="1.5"
                    strokeOpacity="0.8"
                    points={chartData.ma7.map((ma, idx) => {
                      if (ma === null) return '';
                      const x = (idx / (chartData.bars.length - 1)) * 100;
                      const y = 100 - getBarHeight(ma);
                      return `${x}%,${y}%`;
                    }).filter(Boolean).join(' ')}
                  />
                  {/* MA25 Line */}
                  <polyline
                    fill="none"
                    stroke="#8b5cf6"
                    strokeWidth="1.5"
                    strokeOpacity="0.8"
                    points={chartData.ma25.map((ma, idx) => {
                      if (ma === null) return '';
                      const x = (idx / (chartData.bars.length - 1)) * 100;
                      const y = 100 - getBarHeight(ma);
                      return `${x}%,${y}%`;
                    }).filter(Boolean).join(' ')}
                  />
                </svg>
              )}

              {/* Candlesticks */}
              <TooltipProvider>
                <div className="absolute inset-0 flex items-end gap-[2px] px-1 py-2">
                  {chartData.bars.map((bar, idx) => {
                    const bodyTop = getBarHeight(Math.max(bar.open, bar.close));
                    const bodyBottom = getBarHeight(Math.min(bar.open, bar.close));
                    const wickTop = getBarHeight(bar.high);
                    const wickBottom = getBarHeight(bar.low);
                    const bodyHeight = Math.max(1, bodyTop - bodyBottom);

                    return (
                      <Tooltip key={idx}>
                        <TooltipTrigger asChild>
                          <div
                            className="flex-1 relative cursor-pointer group"
                            style={{ minWidth: '3px', maxWidth: '16px' }}
                            onClick={() => onPriceSelect?.(bar.close)}
                          >
                            {/* Wick */}
                            <div
                              className={`absolute left-1/2 -translate-x-1/2 w-[1px] ${bar.isGreen ? 'bg-green-500' : 'bg-red-500'}`}
                              style={{
                                bottom: `${wickBottom}%`,
                                height: `${wickTop - wickBottom}%`
                              }}
                            />
                            {/* Body */}
                            <div
                              className={`absolute left-0 right-0 rounded-[1px] transition-opacity ${bar.isGreen ? 'bg-green-500' : 'bg-red-500'} group-hover:opacity-80`}
                              style={{
                                bottom: `${bodyBottom}%`,
                                height: `${bodyHeight}%`,
                                minHeight: '2px'
                              }}
                            />
                          </div>
                        </TooltipTrigger>
                        <TooltipContent side="top" className="z-50">
                          <div className="text-xs">
                            <div className="flex items-center gap-1 text-muted-foreground mb-1">
                              <Clock className="w-3 h-3" />
                              {new Date(bar.timestamp).toLocaleString()}
                            </div>
                            <div className="grid grid-cols-2 gap-x-3 gap-y-0.5">
                              <span className="text-muted-foreground">O:</span>
                              <span>{bar.open.toFixed(2)}</span>
                              <span className="text-muted-foreground">H:</span>
                              <span className="text-green-500">{bar.high.toFixed(2)}</span>
                              <span className="text-muted-foreground">L:</span>
                              <span className="text-red-500">{bar.low.toFixed(2)}</span>
                              <span className="text-muted-foreground">C:</span>
                              <span className={bar.isGreen ? 'text-green-500' : 'text-red-500'}>{bar.close.toFixed(2)}</span>
                              <span className="text-muted-foreground">Vol:</span>
                              <span>{bar.volume.toFixed(4)}</span>
                            </div>
                          </div>
                        </TooltipContent>
                      </Tooltip>
                    );
                  })}
                </div>
              </TooltipProvider>

              {/* Current price line */}
              <div
                className="absolute left-0 right-0 border-t border-dashed border-primary/50 pointer-events-none"
                style={{ bottom: `${getBarHeight(currentPrice)}%` }}
              >
                <span className="absolute right-0 -top-3 bg-primary text-primary-foreground text-xs px-1.5 py-0.5 rounded">
                  {currentPrice.toFixed(2)}
                </span>
              </div>
            </div>

            {/* Volume bars */}
            <div className="ml-16 h-12 mt-2 flex items-end gap-[2px] px-1">
              {chartData.bars.map((bar, idx) => {
                const maxVol = Math.max(...chartData.bars.map(b => b.volume), 1);
                const volHeight = (bar.volume / maxVol) * 100;
                return (
                  <div
                    key={idx}
                    className={`flex-1 rounded-t ${bar.isGreen ? 'bg-green-500/30' : 'bg-red-500/30'}`}
                    style={{
                      height: `${volHeight}%`,
                      minWidth: '3px',
                      maxWidth: '16px',
                      minHeight: '2px'
                    }}
                  />
                );
              })}
            </div>
            <div className="ml-16 flex items-center justify-between text-xs text-muted-foreground mt-1">
              <span>Volume</span>
              {showMA && (
                <div className="flex items-center gap-3">
                  <span className="flex items-center gap-1">
                    <span className="w-3 h-0.5 bg-amber-500 rounded" />
                    MA7
                  </span>
                  <span className="flex items-center gap-1">
                    <span className="w-3 h-0.5 bg-purple-500 rounded" />
                    MA25
                  </span>
                </div>
              )}
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
