import { useState, useEffect } from 'react';
import { 
  Bot, 
  Play, 
  Square, 
  Settings, 
  Trash2, 
  Plus,
  TrendingUp,
  TrendingDown,
  Activity,
  BarChart3,
  Clock,
  Zap,
  AlertTriangle,
  CheckCircle,
  XCircle,
  RefreshCw,
  ChevronDown,
  ChevronUp
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { supabase } from '@/lib/supabase';
import { useToast } from '@/hooks/use-toast';

interface TradingBot {
  id: string;
  name: string;
  strategy: string;
  status: string;
  config: any;
  total_trades: number;
  total_profit: number;
  total_volume: number;
  win_rate: number;
  last_trade_at: string;
  error_message: string;
  created_at: string;
}

interface BotTrade {
  id: string;
  side: string;
  order_type: string;
  price: number;
  amount: number;
  total: number;
  fee: number;
  executed_at: string;
}

interface TradingBotPanelProps {
  userId: string;
}

const STRATEGIES = [
  { value: 'dca', label: 'DCA (Dollar Cost Average)', description: 'Buy fixed amounts at regular intervals' },
  { value: 'grid', label: 'Grid Trading', description: 'Place buy/sell orders at price intervals' },
  { value: 'stop_loss', label: 'Stop Loss', description: 'Automatically sell when price drops' },
  { value: 'take_profit', label: 'Take Profit', description: 'Automatically sell when price rises' },
  { value: 'scalping', label: 'Scalping', description: 'Quick trades on small price movements' }
];

export function TradingBotPanel({ userId }: TradingBotPanelProps) {
  const [bots, setBots] = useState<TradingBot[]>([]);
  const [loading, setLoading] = useState(true);
  const [creating, setCreating] = useState(false);
  const [showCreateDialog, setShowCreateDialog] = useState(false);
  const [selectedBot, setSelectedBot] = useState<TradingBot | null>(null);
  const [botTrades, setBotTrades] = useState<BotTrade[]>([]);
  const [expandedBot, setExpandedBot] = useState<string | null>(null);
  const { toast } = useToast();

  // New bot form state
  const [newBot, setNewBot] = useState({
    name: '',
    strategy: 'dca',
    config: {
      dca_amount: 10,
      dca_interval: 'daily',
      grid_lower: 80,
      grid_upper: 120,
      grid_levels: 10,
      grid_amount: 5,
      stop_loss_percent: 10,
      take_profit_percent: 20,
      max_position: 1000
    }
  });

  useEffect(() => {
    loadBots();
  }, [userId]);

  const loadBots = async () => {
    try {
      const { data, error } = await supabase.functions.invoke('trading-bot-manager', {
        body: { action: 'list_bots', user_id: userId }
      });

      if (!error && data?.bots) {
        setBots(data.bots);
      }
    } catch (err) {
      console.error('Failed to load bots:', err);
    } finally {
      setLoading(false);
    }
  };

  const loadBotTrades = async (botId: string) => {
    try {
      const { data, error } = await supabase.functions.invoke('trading-bot-manager', {
        body: { action: 'get_bot_trades', bot_id: botId, limit: 20 }
      });

      if (!error && data?.trades) {
        setBotTrades(data.trades);
      }
    } catch (err) {
      console.error('Failed to load bot trades:', err);
    }
  };

  const createBot = async () => {
    if (!newBot.name.trim()) {
      toast({ title: 'Error', description: 'Please enter a bot name', variant: 'destructive' });
      return;
    }

    setCreating(true);
    try {
      const { data, error } = await supabase.functions.invoke('trading-bot-manager', {
        body: {
          action: 'create_bot',
          user_id: userId,
          name: newBot.name,
          strategy: newBot.strategy,
          config: newBot.config
        }
      });

      if (error) throw error;

      toast({ title: 'Bot Created', description: `${newBot.name} has been created successfully` });
      setShowCreateDialog(false);
      setNewBot({
        name: '',
        strategy: 'dca',
        config: {
          dca_amount: 10,
          dca_interval: 'daily',
          grid_lower: 80,
          grid_upper: 120,
          grid_levels: 10,
          grid_amount: 5,
          stop_loss_percent: 10,
          take_profit_percent: 20,
          max_position: 1000
        }
      });
      loadBots();
    } catch (err: any) {
      toast({ title: 'Error', description: err.message || 'Failed to create bot', variant: 'destructive' });
    } finally {
      setCreating(false);
    }
  };

  const startBot = async (botId: string) => {
    try {
      const { error } = await supabase.functions.invoke('trading-bot-manager', {
        body: { action: 'start_bot', bot_id: botId, user_id: userId }
      });

      if (error) throw error;

      toast({ title: 'Bot Started', description: 'Trading bot is now running' });
      loadBots();
    } catch (err: any) {
      toast({ title: 'Error', description: err.message || 'Failed to start bot', variant: 'destructive' });
    }
  };

  const stopBot = async (botId: string) => {
    try {
      const { error } = await supabase.functions.invoke('trading-bot-manager', {
        body: { action: 'stop_bot', bot_id: botId, user_id: userId }
      });

      if (error) throw error;

      toast({ title: 'Bot Stopped', description: 'Trading bot has been stopped' });
      loadBots();
    } catch (err: any) {
      toast({ title: 'Error', description: err.message || 'Failed to stop bot', variant: 'destructive' });
    }
  };

  const deleteBot = async (botId: string) => {
    if (!confirm('Are you sure you want to delete this bot?')) return;

    try {
      const { error } = await supabase.functions.invoke('trading-bot-manager', {
        body: { action: 'delete_bot', bot_id: botId, user_id: userId }
      });

      if (error) throw error;

      toast({ title: 'Bot Deleted', description: 'Trading bot has been removed' });
      loadBots();
    } catch (err: any) {
      toast({ title: 'Error', description: err.message || 'Failed to delete bot', variant: 'destructive' });
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'running': return 'bg-green-500/10 text-green-500 border-green-500/30';
      case 'stopped': return 'bg-gray-500/10 text-gray-500 border-gray-500/30';
      case 'paused': return 'bg-yellow-500/10 text-yellow-500 border-yellow-500/30';
      case 'error': return 'bg-red-500/10 text-red-500 border-red-500/30';
      default: return 'bg-gray-500/10 text-gray-500 border-gray-500/30';
    }
  };

  const getStrategyIcon = (strategy: string) => {
    switch (strategy) {
      case 'dca': return <Clock className="w-4 h-4" />;
      case 'grid': return <BarChart3 className="w-4 h-4" />;
      case 'stop_loss': return <TrendingDown className="w-4 h-4" />;
      case 'take_profit': return <TrendingUp className="w-4 h-4" />;
      case 'scalping': return <Zap className="w-4 h-4" />;
      default: return <Bot className="w-4 h-4" />;
    }
  };

  const toggleExpand = (botId: string) => {
    if (expandedBot === botId) {
      setExpandedBot(null);
    } else {
      setExpandedBot(botId);
      loadBotTrades(botId);
    }
  };

  if (loading) {
    return (
      <Card>
        <CardContent className="py-8 text-center">
          <RefreshCw className="w-8 h-8 animate-spin mx-auto text-muted-foreground" />
          <p className="mt-2 text-muted-foreground">Loading bots...</p>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-full bg-gradient-to-br from-purple-500 to-pink-500 flex items-center justify-center">
            <Bot className="w-5 h-5 text-white" />
          </div>
          <div>
            <h2 className="text-xl font-bold">Trading Bots</h2>
            <p className="text-sm text-muted-foreground">Automated trading strategies</p>
          </div>
        </div>
        <Dialog open={showCreateDialog} onOpenChange={setShowCreateDialog}>
          <DialogTrigger asChild>
            <Button className="gap-2">
              <Plus className="w-4 h-4" />
              Create Bot
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-lg">
            <DialogHeader>
              <DialogTitle>Create Trading Bot</DialogTitle>
            </DialogHeader>
            <div className="space-y-4 py-4">
              <div className="space-y-2">
                <Label>Bot Name</Label>
                <Input
                  placeholder="My Trading Bot"
                  value={newBot.name}
                  onChange={(e) => setNewBot({ ...newBot, name: e.target.value })}
                />
              </div>

              <div className="space-y-2">
                <Label>Strategy</Label>
                <Select
                  value={newBot.strategy}
                  onValueChange={(value) => setNewBot({ ...newBot, strategy: value })}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {STRATEGIES.map((s) => (
                      <SelectItem key={s.value} value={s.value}>
                        <div className="flex items-center gap-2">
                          {getStrategyIcon(s.value)}
                          <span>{s.label}</span>
                        </div>
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                <p className="text-xs text-muted-foreground">
                  {STRATEGIES.find(s => s.value === newBot.strategy)?.description}
                </p>
              </div>

              {/* Strategy-specific config */}
              {newBot.strategy === 'dca' && (
                <div className="space-y-4 p-4 bg-muted/50 rounded-lg">
                  <h4 className="font-medium">DCA Settings</h4>
                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label>Amount per Buy</Label>
                      <Input
                        type="number"
                        value={newBot.config.dca_amount}
                        onChange={(e) => setNewBot({
                          ...newBot,
                          config: { ...newBot.config, dca_amount: parseFloat(e.target.value) }
                        })}
                      />
                    </div>
                    <div className="space-y-2">
                      <Label>Interval</Label>
                      <Select
                        value={newBot.config.dca_interval}
                        onValueChange={(value) => setNewBot({
                          ...newBot,
                          config: { ...newBot.config, dca_interval: value }
                        })}
                      >
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="hourly">Hourly</SelectItem>
                          <SelectItem value="daily">Daily</SelectItem>
                          <SelectItem value="weekly">Weekly</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>
                </div>
              )}

              {newBot.strategy === 'grid' && (
                <div className="space-y-4 p-4 bg-muted/50 rounded-lg">
                  <h4 className="font-medium">Grid Settings</h4>
                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label>Lower Price</Label>
                      <Input
                        type="number"
                        value={newBot.config.grid_lower}
                        onChange={(e) => setNewBot({
                          ...newBot,
                          config: { ...newBot.config, grid_lower: parseFloat(e.target.value) }
                        })}
                      />
                    </div>
                    <div className="space-y-2">
                      <Label>Upper Price</Label>
                      <Input
                        type="number"
                        value={newBot.config.grid_upper}
                        onChange={(e) => setNewBot({
                          ...newBot,
                          config: { ...newBot.config, grid_upper: parseFloat(e.target.value) }
                        })}
                      />
                    </div>
                    <div className="space-y-2">
                      <Label>Grid Levels</Label>
                      <Input
                        type="number"
                        value={newBot.config.grid_levels}
                        onChange={(e) => setNewBot({
                          ...newBot,
                          config: { ...newBot.config, grid_levels: parseInt(e.target.value) }
                        })}
                      />
                    </div>
                    <div className="space-y-2">
                      <Label>Amount per Grid</Label>
                      <Input
                        type="number"
                        value={newBot.config.grid_amount}
                        onChange={(e) => setNewBot({
                          ...newBot,
                          config: { ...newBot.config, grid_amount: parseFloat(e.target.value) }
                        })}
                      />
                    </div>
                  </div>
                </div>
              )}

              {(newBot.strategy === 'stop_loss' || newBot.strategy === 'take_profit') && (
                <div className="space-y-4 p-4 bg-muted/50 rounded-lg">
                  <h4 className="font-medium">
                    {newBot.strategy === 'stop_loss' ? 'Stop Loss' : 'Take Profit'} Settings
                  </h4>
                  <div className="space-y-2">
                    <Label>
                      {newBot.strategy === 'stop_loss' ? 'Stop Loss' : 'Take Profit'} Percentage
                    </Label>
                    <Input
                      type="number"
                      value={newBot.strategy === 'stop_loss' 
                        ? newBot.config.stop_loss_percent 
                        : newBot.config.take_profit_percent}
                      onChange={(e) => setNewBot({
                        ...newBot,
                        config: {
                          ...newBot.config,
                          [newBot.strategy === 'stop_loss' ? 'stop_loss_percent' : 'take_profit_percent']: parseFloat(e.target.value)
                        }
                      })}
                    />
                  </div>
                </div>
              )}

              <div className="space-y-2">
                <Label>Max Position Size (STC)</Label>
                <Input
                  type="number"
                  value={newBot.config.max_position}
                  onChange={(e) => setNewBot({
                    ...newBot,
                    config: { ...newBot.config, max_position: parseFloat(e.target.value) }
                  })}
                />
              </div>

              <Button onClick={createBot} disabled={creating} className="w-full">
                {creating ? 'Creating...' : 'Create Bot'}
              </Button>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      {/* Stats Overview */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <Card className="bg-card/50">
          <CardContent className="pt-4">
            <div className="flex items-center gap-2 text-muted-foreground text-sm">
              <Bot className="w-4 h-4" />
              Total Bots
            </div>
            <p className="text-2xl font-bold mt-1">{bots.length}</p>
          </CardContent>
        </Card>
        <Card className="bg-card/50">
          <CardContent className="pt-4">
            <div className="flex items-center gap-2 text-muted-foreground text-sm">
              <Activity className="w-4 h-4 text-green-500" />
              Active
            </div>
            <p className="text-2xl font-bold mt-1 text-green-500">
              {bots.filter(b => b.status === 'running').length}
            </p>
          </CardContent>
        </Card>
        <Card className="bg-card/50">
          <CardContent className="pt-4">
            <div className="flex items-center gap-2 text-muted-foreground text-sm">
              <BarChart3 className="w-4 h-4" />
              Total Trades
            </div>
            <p className="text-2xl font-bold mt-1">
              {bots.reduce((sum, b) => sum + (b.total_trades || 0), 0)}
            </p>
          </CardContent>
        </Card>
        <Card className="bg-card/50">
          <CardContent className="pt-4">
            <div className="flex items-center gap-2 text-muted-foreground text-sm">
              <TrendingUp className="w-4 h-4" />
              Total Volume
            </div>
            <p className="text-2xl font-bold mt-1">
              {bots.reduce((sum, b) => sum + parseFloat(b.total_volume?.toString() || '0'), 0).toFixed(2)}
            </p>
          </CardContent>
        </Card>
      </div>

      {/* Bots List */}
      {bots.length === 0 ? (
        <Card className="bg-card/50">
          <CardContent className="py-12 text-center">
            <Bot className="w-12 h-12 mx-auto text-muted-foreground mb-4" />
            <h3 className="text-lg font-semibold mb-2">No Trading Bots</h3>
            <p className="text-muted-foreground mb-4">Create your first automated trading bot</p>
            <Button onClick={() => setShowCreateDialog(true)} className="gap-2">
              <Plus className="w-4 h-4" />
              Create Bot
            </Button>
          </CardContent>
        </Card>
      ) : (
        <div className="space-y-4">
          {bots.map((bot) => (
            <Card key={bot.id} className="bg-card/50 overflow-hidden">
              <CardContent className="p-0">
                {/* Bot Header */}
                <div 
                  className="p-4 cursor-pointer hover:bg-muted/50 transition-colors"
                  onClick={() => toggleExpand(bot.id)}
                >
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-4">
                      <div className={`w-10 h-10 rounded-full flex items-center justify-center ${
                        bot.status === 'running' ? 'bg-green-500/10' : 'bg-muted'
                      }`}>
                        {getStrategyIcon(bot.strategy)}
                      </div>
                      <div>
                        <div className="flex items-center gap-2">
                          <h3 className="font-semibold">{bot.name}</h3>
                          <Badge variant="outline" className={getStatusColor(bot.status)}>
                            {bot.status === 'running' && <Activity className="w-3 h-3 mr-1 animate-pulse" />}
                            {bot.status}
                          </Badge>
                        </div>
                        <p className="text-sm text-muted-foreground">
                          {STRATEGIES.find(s => s.value === bot.strategy)?.label}
                        </p>
                      </div>
                    </div>

                    <div className="flex items-center gap-6">
                      <div className="text-right hidden md:block">
                        <p className="text-sm text-muted-foreground">Trades</p>
                        <p className="font-mono font-semibold">{bot.total_trades || 0}</p>
                      </div>
                      <div className="text-right hidden md:block">
                        <p className="text-sm text-muted-foreground">Volume</p>
                        <p className="font-mono font-semibold">{parseFloat(bot.total_volume?.toString() || '0').toFixed(2)}</p>
                      </div>
                      <div className="flex items-center gap-2">
                        {bot.status === 'running' ? (
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={(e) => { e.stopPropagation(); stopBot(bot.id); }}
                            className="gap-1"
                          >
                            <Square className="w-3 h-3" />
                            Stop
                          </Button>
                        ) : (
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={(e) => { e.stopPropagation(); startBot(bot.id); }}
                            className="gap-1 text-green-500 border-green-500/30 hover:bg-green-500/10"
                          >
                            <Play className="w-3 h-3" />
                            Start
                          </Button>
                        )}
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={(e) => { e.stopPropagation(); deleteBot(bot.id); }}
                          className="text-red-500 hover:text-red-400 hover:bg-red-500/10"
                        >
                          <Trash2 className="w-4 h-4" />
                        </Button>
                        {expandedBot === bot.id ? (
                          <ChevronUp className="w-4 h-4 text-muted-foreground" />
                        ) : (
                          <ChevronDown className="w-4 h-4 text-muted-foreground" />
                        )}
                      </div>
                    </div>
                  </div>
                </div>

                {/* Expanded Details */}
                {expandedBot === bot.id && (
                  <div className="border-t p-4 bg-muted/30">
                    <Tabs defaultValue="config">
                      <TabsList className="mb-4">
                        <TabsTrigger value="config">Configuration</TabsTrigger>
                        <TabsTrigger value="trades">Recent Trades</TabsTrigger>
                      </TabsList>

                      <TabsContent value="config">
                        <div className="grid md:grid-cols-2 gap-4">
                          {bot.strategy === 'dca' && (
                            <>
                              <div className="p-3 bg-background rounded-lg">
                                <p className="text-sm text-muted-foreground">Amount per Buy</p>
                                <p className="font-mono font-semibold">{bot.config?.dca_amount || 10} COINS</p>
                              </div>
                              <div className="p-3 bg-background rounded-lg">
                                <p className="text-sm text-muted-foreground">Interval</p>
                                <p className="font-mono font-semibold capitalize">{bot.config?.dca_interval || 'daily'}</p>
                              </div>
                            </>
                          )}
                          {bot.strategy === 'grid' && (
                            <>
                              <div className="p-3 bg-background rounded-lg">
                                <p className="text-sm text-muted-foreground">Price Range</p>
                                <p className="font-mono font-semibold">
                                  {bot.config?.grid_lower || 80} - {bot.config?.grid_upper || 120}
                                </p>
                              </div>
                              <div className="p-3 bg-background rounded-lg">
                                <p className="text-sm text-muted-foreground">Grid Levels</p>
                                <p className="font-mono font-semibold">{bot.config?.grid_levels || 10}</p>
                              </div>
                            </>
                          )}
                          {bot.strategy === 'stop_loss' && (
                            <div className="p-3 bg-background rounded-lg">
                              <p className="text-sm text-muted-foreground">Stop Loss</p>
                              <p className="font-mono font-semibold text-red-500">
                                -{bot.config?.stop_loss_percent || 10}%
                              </p>
                            </div>
                          )}
                          {bot.strategy === 'take_profit' && (
                            <div className="p-3 bg-background rounded-lg">
                              <p className="text-sm text-muted-foreground">Take Profit</p>
                              <p className="font-mono font-semibold text-green-500">
                                +{bot.config?.take_profit_percent || 20}%
                              </p>
                            </div>
                          )}
                          <div className="p-3 bg-background rounded-lg">
                            <p className="text-sm text-muted-foreground">Max Position</p>
                            <p className="font-mono font-semibold">{bot.config?.max_position || 1000} STC</p>
                          </div>
                          <div className="p-3 bg-background rounded-lg">
                            <p className="text-sm text-muted-foreground">Created</p>
                            <p className="font-mono text-sm">
                              {new Date(bot.created_at).toLocaleDateString()}
                            </p>
                          </div>
                        </div>
                        {bot.error_message && (
                          <div className="mt-4 p-3 bg-red-500/10 border border-red-500/30 rounded-lg flex items-start gap-2">
                            <AlertTriangle className="w-4 h-4 text-red-500 mt-0.5" />
                            <div>
                              <p className="text-sm font-medium text-red-500">Error</p>
                              <p className="text-sm text-muted-foreground">{bot.error_message}</p>
                            </div>
                          </div>
                        )}
                      </TabsContent>

                      <TabsContent value="trades">
                        {botTrades.length === 0 ? (
                          <div className="text-center py-8 text-muted-foreground">
                            <Activity className="w-8 h-8 mx-auto mb-2 opacity-50" />
                            <p>No trades yet</p>
                          </div>
                        ) : (
                          <div className="space-y-2">
                            {botTrades.map((trade) => (
                              <div 
                                key={trade.id}
                                className="flex items-center justify-between p-3 bg-background rounded-lg"
                              >
                                <div className="flex items-center gap-3">
                                  <div className={`w-8 h-8 rounded-full flex items-center justify-center ${
                                    trade.side === 'buy' ? 'bg-green-500/10' : 'bg-red-500/10'
                                  }`}>
                                    {trade.side === 'buy' ? (
                                      <TrendingUp className="w-4 h-4 text-green-500" />
                                    ) : (
                                      <TrendingDown className="w-4 h-4 text-red-500" />
                                    )}
                                  </div>
                                  <div>
                                    <p className={`font-medium ${
                                      trade.side === 'buy' ? 'text-green-500' : 'text-red-500'
                                    }`}>
                                      {trade.side.toUpperCase()} {trade.amount} STC
                                    </p>
                                    <p className="text-xs text-muted-foreground">
                                      @ {trade.price} COINS
                                    </p>
                                  </div>
                                </div>
                                <div className="text-right">
                                  <p className="font-mono">{trade.total.toFixed(2)} COINS</p>
                                  <p className="text-xs text-muted-foreground">
                                    {new Date(trade.executed_at).toLocaleString()}
                                  </p>
                                </div>
                              </div>
                            ))}
                          </div>
                        )}
                      </TabsContent>
                    </Tabs>
                  </div>
                )}
              </CardContent>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
}
