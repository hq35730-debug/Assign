import { useState, useEffect } from 'react';
import { ListOrdered, X, Clock, TrendingUp, TrendingDown, Loader2 } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { supabase } from '@/lib/supabase';
import { useToast } from '@/hooks/use-toast';

interface Order {
  id: string;
  order_type: 'buy' | 'sell';
  order_mode: 'limit' | 'market';
  price: string | null;
  amount: string;
  filled_amount: string;
  status: 'open' | 'partial' | 'filled' | 'cancelled';
  created_at: string;
}

interface OpenOrdersProps {
  userId: string;
  refreshTrigger?: number;
}

export function OpenOrders({ userId, refreshTrigger }: OpenOrdersProps) {
  const [orders, setOrders] = useState<Order[]>([]);
  const [loading, setLoading] = useState(true);
  const [cancellingId, setCancellingId] = useState<string | null>(null);
  const { toast } = useToast();

  useEffect(() => {
    if (userId) {
      fetchOrders();
    }
  }, [userId, refreshTrigger]);

  const fetchOrders = async () => {
    try {
      const { data, error } = await supabase.functions.invoke('trading-manager', {
        body: { action: 'get_user_orders', user_id: userId }
      });

      if (!error && data?.orders) {
        setOrders(data.orders);
      }
    } catch (err) {
      console.error('Failed to fetch orders:', err);
    } finally {
      setLoading(false);
    }
  };

  const handleCancelOrder = async (orderId: string) => {
    setCancellingId(orderId);
    try {
      const { data, error } = await supabase.functions.invoke('trading-manager', {
        body: { action: 'cancel_order', user_id: userId, order_id: orderId }
      });

      if (error) throw error;

      if (data?.error) {
        toast({
          title: 'Cancel Failed',
          description: data.error,
          variant: 'destructive'
        });
        return;
      }

      toast({
        title: 'Order Cancelled',
        description: 'Your order has been cancelled successfully.'
      });

      fetchOrders();
    } catch (err: any) {
      toast({
        title: 'Error',
        description: err.message || 'Failed to cancel order',
        variant: 'destructive'
      });
    } finally {
      setCancellingId(null);
    }
  };

  const formatTime = (timestamp: string) => {
    const date = new Date(timestamp);
    return date.toLocaleString();
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'open':
        return <Badge variant="outline" className="bg-blue-500/10 text-blue-500 border-blue-500/30">Open</Badge>;
      case 'partial':
        return <Badge variant="outline" className="bg-amber-500/10 text-amber-500 border-amber-500/30">Partial</Badge>;
      case 'filled':
        return <Badge variant="outline" className="bg-green-500/10 text-green-500 border-green-500/30">Filled</Badge>;
      case 'cancelled':
        return <Badge variant="outline" className="bg-gray-500/10 text-gray-500 border-gray-500/30">Cancelled</Badge>;
      default:
        return <Badge variant="outline">{status}</Badge>;
    }
  };

  const openOrders = orders.filter(o => o.status === 'open' || o.status === 'partial');
  const orderHistory = orders.filter(o => o.status === 'filled' || o.status === 'cancelled');

  return (
    <Card className="bg-card/50 backdrop-blur border-border/50">
      <CardHeader className="pb-2">
        <CardTitle className="text-lg flex items-center gap-2">
          <ListOrdered className="w-5 h-5 text-primary" />
          My Orders
        </CardTitle>
      </CardHeader>
      <CardContent>
        {loading ? (
          <div className="h-48 flex items-center justify-center">
            <div className="animate-spin w-6 h-6 border-2 border-primary border-t-transparent rounded-full" />
          </div>
        ) : (
          <div className="space-y-4">
            {/* Open Orders */}
            <div>
              <h4 className="text-sm font-medium mb-2 flex items-center gap-2">
                <span className="w-2 h-2 rounded-full bg-blue-500 animate-pulse" />
                Open Orders ({openOrders.length})
              </h4>
              {openOrders.length === 0 ? (
                <div className="text-center py-6 text-muted-foreground text-sm">
                  No open orders
                </div>
              ) : (
                <div className="space-y-2">
                  {openOrders.map(order => {
                    const filled = parseFloat(order.filled_amount);
                    const total = parseFloat(order.amount);
                    const fillPercent = (filled / total) * 100;

                    return (
                      <div
                        key={order.id}
                        className="p-3 rounded-lg bg-muted/30 border border-border/50"
                      >
                        <div className="flex items-center justify-between mb-2">
                          <div className="flex items-center gap-2">
                            {order.order_type === 'buy' ? (
                              <TrendingUp className="w-4 h-4 text-green-500" />
                            ) : (
                              <TrendingDown className="w-4 h-4 text-red-500" />
                            )}
                            <span className={`font-medium ${order.order_type === 'buy' ? 'text-green-500' : 'text-red-500'}`}>
                              {order.order_type.toUpperCase()}
                            </span>
                            <Badge variant="outline" className="text-xs">
                              {order.order_mode}
                            </Badge>
                          </div>
                          <Button
                            variant="ghost"
                            size="sm"
                            className="h-7 w-7 p-0 text-muted-foreground hover:text-red-500"
                            onClick={() => handleCancelOrder(order.id)}
                            disabled={cancellingId === order.id}
                          >
                            {cancellingId === order.id ? (
                              <Loader2 className="w-4 h-4 animate-spin" />
                            ) : (
                              <X className="w-4 h-4" />
                            )}
                          </Button>
                        </div>

                        <div className="grid grid-cols-3 gap-2 text-sm mb-2">
                          <div>
                            <p className="text-xs text-muted-foreground">Price</p>
                            <p className="font-mono">{order.price ? parseFloat(order.price).toFixed(2) : 'Market'}</p>
                          </div>
                          <div>
                            <p className="text-xs text-muted-foreground">Amount</p>
                            <p className="font-mono">{parseFloat(order.amount).toFixed(4)}</p>
                          </div>
                          <div>
                            <p className="text-xs text-muted-foreground">Filled</p>
                            <p className="font-mono">{filled.toFixed(4)}</p>
                          </div>
                        </div>

                        {/* Fill progress */}
                        <div className="relative h-1.5 bg-muted rounded-full overflow-hidden">
                          <div
                            className={`absolute inset-y-0 left-0 ${order.order_type === 'buy' ? 'bg-green-500' : 'bg-red-500'}`}
                            style={{ width: `${fillPercent}%` }}
                          />
                        </div>
                        <div className="flex items-center justify-between mt-1 text-xs text-muted-foreground">
                          <span>{fillPercent.toFixed(1)}% filled</span>
                          <span className="flex items-center gap-1">
                            <Clock className="w-3 h-3" />
                            {formatTime(order.created_at)}
                          </span>
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}
            </div>

            {/* Order History */}
            <div>
              <h4 className="text-sm font-medium mb-2">Order History</h4>
              {orderHistory.length === 0 ? (
                <div className="text-center py-4 text-muted-foreground text-sm">
                  No order history
                </div>
              ) : (
                <div className="max-h-48 overflow-y-auto space-y-1">
                  {orderHistory.slice(0, 10).map(order => (
                    <div
                      key={order.id}
                      className="flex items-center justify-between p-2 rounded hover:bg-muted/30 text-sm"
                    >
                      <div className="flex items-center gap-2">
                        {order.order_type === 'buy' ? (
                          <TrendingUp className="w-3 h-3 text-green-500" />
                        ) : (
                          <TrendingDown className="w-3 h-3 text-red-500" />
                        )}
                        <span className="font-mono">
                          {parseFloat(order.amount).toFixed(4)} STC
                        </span>
                        <span className="text-muted-foreground">@</span>
                        <span className="font-mono">
                          {order.price ? parseFloat(order.price).toFixed(2) : 'Market'}
                        </span>
                      </div>
                      {getStatusBadge(order.status)}
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
