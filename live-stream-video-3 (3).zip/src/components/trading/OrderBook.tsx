import { useState, useEffect } from 'react';
import { BookOpen, ArrowUp, ArrowDown } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { supabase } from '@/lib/supabase';

interface OrderLevel {
  price: number;
  amount: number;
}

interface OrderBookProps {
  onPriceSelect?: (price: number) => void;
}

export function OrderBook({ onPriceSelect }: OrderBookProps) {
  const [bids, setBids] = useState<OrderLevel[]>([]);
  const [asks, setAsks] = useState<OrderLevel[]>([]);
  const [loading, setLoading] = useState(true);
  const [spread, setSpread] = useState({ value: 0, percent: 0 });

  useEffect(() => {
    fetchOrderBook();
    const timer = setInterval(fetchOrderBook, 5000);
    return () => clearInterval(timer);
  }, []);

  const fetchOrderBook = async () => {
    try {
      const { data, error } = await supabase.functions.invoke('trading-manager', {
        body: { action: 'get_order_book' }
      });

      if (!error && data) {
        setBids(data.bids || []);
        setAsks(data.asks || []);

        // Calculate spread
        if (data.asks?.length > 0 && data.bids?.length > 0) {
          const lowestAsk = data.asks[0].price;
          const highestBid = data.bids[0].price;
          const spreadValue = lowestAsk - highestBid;
          const spreadPercent = (spreadValue / lowestAsk) * 100;
          setSpread({ value: spreadValue, percent: spreadPercent });
        }
      }
    } catch (err) {
      console.error('Failed to fetch order book:', err);
    } finally {
      setLoading(false);
    }
  };

  const maxBidAmount = Math.max(...bids.map(b => b.amount), 1);
  const maxAskAmount = Math.max(...asks.map(a => a.amount), 1);

  const displayedAsks = asks.slice(0, 10).reverse();
  const displayedBids = bids.slice(0, 10);

  return (
    <Card className="bg-card/50 backdrop-blur border-border/50">
      <CardHeader className="pb-2">
        <CardTitle className="text-lg flex items-center gap-2">
          <BookOpen className="w-5 h-5 text-primary" />
          Order Book
        </CardTitle>
      </CardHeader>
      <CardContent>
        {loading ? (
          <div className="h-64 flex items-center justify-center">
            <div className="animate-spin w-6 h-6 border-2 border-primary border-t-transparent rounded-full" />
          </div>
        ) : (
          <div className="space-y-2">
            {/* Header */}
            <div className="grid grid-cols-3 text-xs text-muted-foreground px-2">
              <span>Price (Coins)</span>
              <span className="text-right">Amount (STC)</span>
              <span className="text-right">Total</span>
            </div>

            {/* Asks (Sell orders) */}
            <div className="space-y-0.5">
              {displayedAsks.length === 0 ? (
                <div className="text-center text-sm text-muted-foreground py-4">
                  No sell orders
                </div>
              ) : (
                displayedAsks.map((ask, idx) => (
                  <div
                    key={`ask-${idx}`}
                    className="relative grid grid-cols-3 text-sm py-1 px-2 cursor-pointer hover:bg-red-500/10 rounded transition-colors"
                    onClick={() => onPriceSelect?.(ask.price)}
                  >
                    <div
                      className="absolute inset-y-0 right-0 bg-red-500/10"
                      style={{ width: `${(ask.amount / maxAskAmount) * 100}%` }}
                    />
                    <span className="relative text-red-500 font-mono">{ask.price.toFixed(2)}</span>
                    <span className="relative text-right font-mono">{ask.amount.toFixed(4)}</span>
                    <span className="relative text-right font-mono text-muted-foreground">
                      {(ask.price * ask.amount).toFixed(2)}
                    </span>
                  </div>
                ))
              )}
            </div>

            {/* Spread */}
            <div className="flex items-center justify-center gap-3 py-2 border-y border-border/50">
              <div className="flex items-center gap-1 text-sm">
                <span className="text-muted-foreground">Spread:</span>
                <span className="font-mono">{spread.value.toFixed(2)}</span>
                <span className="text-muted-foreground">({spread.percent.toFixed(2)}%)</span>
              </div>
            </div>

            {/* Bids (Buy orders) */}
            <div className="space-y-0.5">
              {displayedBids.length === 0 ? (
                <div className="text-center text-sm text-muted-foreground py-4">
                  No buy orders
                </div>
              ) : (
                displayedBids.map((bid, idx) => (
                  <div
                    key={`bid-${idx}`}
                    className="relative grid grid-cols-3 text-sm py-1 px-2 cursor-pointer hover:bg-green-500/10 rounded transition-colors"
                    onClick={() => onPriceSelect?.(bid.price)}
                  >
                    <div
                      className="absolute inset-y-0 right-0 bg-green-500/10"
                      style={{ width: `${(bid.amount / maxBidAmount) * 100}%` }}
                    />
                    <span className="relative text-green-500 font-mono">{bid.price.toFixed(2)}</span>
                    <span className="relative text-right font-mono">{bid.amount.toFixed(4)}</span>
                    <span className="relative text-right font-mono text-muted-foreground">
                      {(bid.price * bid.amount).toFixed(2)}
                    </span>
                  </div>
                ))
              )}
            </div>

            {/* Summary */}
            <div className="grid grid-cols-2 gap-4 pt-3 border-t border-border/50">
              <div className="text-center">
                <div className="flex items-center justify-center gap-1 text-green-500">
                  <ArrowUp className="w-4 h-4" />
                  <span className="text-sm font-medium">Buy Orders</span>
                </div>
                <p className="text-lg font-bold">
                  {bids.reduce((sum, b) => sum + b.amount, 0).toFixed(4)} STC
                </p>
              </div>
              <div className="text-center">
                <div className="flex items-center justify-center gap-1 text-red-500">
                  <ArrowDown className="w-4 h-4" />
                  <span className="text-sm font-medium">Sell Orders</span>
                </div>
                <p className="text-lg font-bold">
                  {asks.reduce((sum, a) => sum + a.amount, 0).toFixed(4)} STC
                </p>
              </div>
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
