import { useState, useEffect } from 'react';
import { 
  Key, 
  Plus, 
  Copy, 
  Trash2, 
  Eye, 
  EyeOff,
  Shield,
  Clock,
  AlertTriangle,
  CheckCircle,
  RefreshCw
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Checkbox } from '@/components/ui/checkbox';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { supabase } from '@/lib/supabase';
import { useToast } from '@/hooks/use-toast';

interface APIKey {
  id: string;
  name: string;
  api_key: string;
  permissions: string[];
  is_active: boolean;
  last_used_at: string | null;
  expires_at: string | null;
  created_at: string;
}

interface NewKeyResponse {
  api_key: string;
  api_secret: string;
  key_id: string;
}

interface APIKeyManagerProps {
  userId: string;
}

export function APIKeyManager({ userId }: APIKeyManagerProps) {
  const [keys, setKeys] = useState<APIKey[]>([]);
  const [loading, setLoading] = useState(true);
  const [creating, setCreating] = useState(false);
  const [showCreateDialog, setShowCreateDialog] = useState(false);
  const [newKeyData, setNewKeyData] = useState<NewKeyResponse | null>(null);
  const [showSecrets, setShowSecrets] = useState<Record<string, boolean>>({});
  const { toast } = useToast();

  // New key form state
  const [newKey, setNewKey] = useState({
    name: '',
    permissions: ['read', 'trade'],
    expires_days: 0
  });

  useEffect(() => {
    loadKeys();
  }, [userId]);

  const loadKeys = async () => {
    try {
      const { data, error } = await supabase.functions.invoke('trading-bot-manager', {
        body: { action: 'list_api_keys', user_id: userId }
      });

      if (!error && data?.keys) {
        setKeys(data.keys);
      }
    } catch (err) {
      console.error('Failed to load API keys:', err);
    } finally {
      setLoading(false);
    }
  };

  const createKey = async () => {
    if (!newKey.name.trim()) {
      toast({ title: 'Error', description: 'Please enter a key name', variant: 'destructive' });
      return;
    }

    setCreating(true);
    try {
      const { data, error } = await supabase.functions.invoke('trading-bot-manager', {
        body: {
          action: 'create_api_key',
          user_id: userId,
          name: newKey.name,
          permissions: newKey.permissions,
          expires_days: newKey.expires_days || null
        }
      });

      if (error) throw error;

      setNewKeyData({
        api_key: data.api_key,
        api_secret: data.api_secret,
        key_id: data.key_id
      });

      toast({ title: 'API Key Created', description: 'Save your secret key - it will not be shown again!' });
      loadKeys();
    } catch (err: any) {
      toast({ title: 'Error', description: err.message || 'Failed to create API key', variant: 'destructive' });
    } finally {
      setCreating(false);
    }
  };

  const revokeKey = async (keyId: string) => {
    try {
      const { error } = await supabase.functions.invoke('trading-bot-manager', {
        body: { action: 'revoke_api_key', key_id: keyId, user_id: userId }
      });

      if (error) throw error;

      toast({ title: 'API Key Revoked', description: 'The key has been deactivated' });
      loadKeys();
    } catch (err: any) {
      toast({ title: 'Error', description: err.message || 'Failed to revoke key', variant: 'destructive' });
    }
  };

  const deleteKey = async (keyId: string) => {
    if (!confirm('Are you sure you want to permanently delete this API key?')) return;

    try {
      const { error } = await supabase.functions.invoke('trading-bot-manager', {
        body: { action: 'delete_api_key', key_id: keyId, user_id: userId }
      });

      if (error) throw error;

      toast({ title: 'API Key Deleted', description: 'The key has been permanently removed' });
      loadKeys();
    } catch (err: any) {
      toast({ title: 'Error', description: err.message || 'Failed to delete key', variant: 'destructive' });
    }
  };

  const copyToClipboard = (text: string, label: string) => {
    navigator.clipboard.writeText(text);
    toast({ title: 'Copied', description: `${label} copied to clipboard` });
  };

  const togglePermission = (permission: string) => {
    setNewKey(prev => ({
      ...prev,
      permissions: prev.permissions.includes(permission)
        ? prev.permissions.filter(p => p !== permission)
        : [...prev.permissions, permission]
    }));
  };

  const closeNewKeyDialog = () => {
    setShowCreateDialog(false);
    setNewKeyData(null);
    setNewKey({ name: '', permissions: ['read', 'trade'], expires_days: 0 });
  };

  if (loading) {
    return (
      <Card>
        <CardContent className="py-8 text-center">
          <RefreshCw className="w-8 h-8 animate-spin mx-auto text-muted-foreground" />
          <p className="mt-2 text-muted-foreground">Loading API keys...</p>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-full bg-gradient-to-br from-blue-500 to-cyan-500 flex items-center justify-center">
            <Key className="w-5 h-5 text-white" />
          </div>
          <div>
            <h2 className="text-xl font-bold">API Keys</h2>
            <p className="text-sm text-muted-foreground">Manage external bot access</p>
          </div>
        </div>
        <Dialog open={showCreateDialog} onOpenChange={setShowCreateDialog}>
          <DialogTrigger asChild>
            <Button className="gap-2">
              <Plus className="w-4 h-4" />
              Create API Key
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-lg">
            <DialogHeader>
              <DialogTitle>
                {newKeyData ? 'API Key Created' : 'Create API Key'}
              </DialogTitle>
            </DialogHeader>

            {newKeyData ? (
              <div className="space-y-4 py-4">
                <Alert className="bg-yellow-500/10 border-yellow-500/30">
                  <AlertTriangle className="w-4 h-4 text-yellow-500" />
                  <AlertDescription className="text-yellow-500">
                    Save your API secret now! It will not be shown again.
                  </AlertDescription>
                </Alert>

                <div className="space-y-4">
                  <div className="space-y-2">
                    <Label>API Key</Label>
                    <div className="flex gap-2">
                      <Input value={newKeyData.api_key} readOnly className="font-mono text-sm" />
                      <Button
                        variant="outline"
                        size="icon"
                        onClick={() => copyToClipboard(newKeyData.api_key, 'API Key')}
                      >
                        <Copy className="w-4 h-4" />
                      </Button>
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label>API Secret</Label>
                    <div className="flex gap-2">
                      <Input 
                        value={newKeyData.api_secret} 
                        readOnly 
                        className="font-mono text-sm"
                        type={showSecrets['new'] ? 'text' : 'password'}
                      />
                      <Button
                        variant="outline"
                        size="icon"
                        onClick={() => setShowSecrets(prev => ({ ...prev, new: !prev.new }))}
                      >
                        {showSecrets['new'] ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                      </Button>
                      <Button
                        variant="outline"
                        size="icon"
                        onClick={() => copyToClipboard(newKeyData.api_secret, 'API Secret')}
                      >
                        <Copy className="w-4 h-4" />
                      </Button>
                    </div>
                  </div>
                </div>

                <div className="p-4 bg-muted rounded-lg">
                  <h4 className="font-medium mb-2">Usage Example</h4>
                  <pre className="text-xs bg-background p-3 rounded overflow-x-auto">
{`curl -X POST \\
  https://api.databasepad.com/functions/v1/trading-bot-manager \\
  -H "Content-Type: application/json" \\
  -H "X-API-Key: ${newKeyData.api_key}" \\
  -H "X-API-Secret: YOUR_SECRET" \\
  -d '{"action": "get_market_data"}'`}
                  </pre>
                </div>

                <Button onClick={closeNewKeyDialog} className="w-full">
                  Done
                </Button>
              </div>
            ) : (
              <div className="space-y-4 py-4">
                <div className="space-y-2">
                  <Label>Key Name</Label>
                  <Input
                    placeholder="My Trading Bot"
                    value={newKey.name}
                    onChange={(e) => setNewKey({ ...newKey, name: e.target.value })}
                  />
                </div>

                <div className="space-y-2">
                  <Label>Permissions</Label>
                  <div className="space-y-2">
                    <div className="flex items-center gap-2">
                      <Checkbox
                        id="perm-read"
                        checked={newKey.permissions.includes('read')}
                        onCheckedChange={() => togglePermission('read')}
                      />
                      <label htmlFor="perm-read" className="text-sm">
                        Read - View market data, balances, orders
                      </label>
                    </div>
                    <div className="flex items-center gap-2">
                      <Checkbox
                        id="perm-trade"
                        checked={newKey.permissions.includes('trade')}
                        onCheckedChange={() => togglePermission('trade')}
                      />
                      <label htmlFor="perm-trade" className="text-sm">
                        Trade - Place and cancel orders
                      </label>
                    </div>
                    <div className="flex items-center gap-2">
                      <Checkbox
                        id="perm-withdraw"
                        checked={newKey.permissions.includes('withdraw')}
                        onCheckedChange={() => togglePermission('withdraw')}
                      />
                      <label htmlFor="perm-withdraw" className="text-sm">
                        Withdraw - Transfer funds (use with caution)
                      </label>
                    </div>
                  </div>
                </div>

                <div className="space-y-2">
                  <Label>Expiration</Label>
                  <Select
                    value={newKey.expires_days.toString()}
                    onValueChange={(value) => setNewKey({ ...newKey, expires_days: parseInt(value) })}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="0">Never expires</SelectItem>
                      <SelectItem value="7">7 days</SelectItem>
                      <SelectItem value="30">30 days</SelectItem>
                      <SelectItem value="90">90 days</SelectItem>
                      <SelectItem value="365">1 year</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <Button onClick={createKey} disabled={creating} className="w-full">
                  {creating ? 'Creating...' : 'Create API Key'}
                </Button>
              </div>
            )}
          </DialogContent>
        </Dialog>
      </div>

      {/* API Documentation */}
      <Card className="bg-gradient-to-r from-blue-500/10 to-cyan-500/10 border-blue-500/20">
        <CardContent className="py-4">
          <div className="flex items-start gap-3">
            <Shield className="w-5 h-5 text-blue-500 flex-shrink-0 mt-0.5" />
            <div>
              <h3 className="font-semibold text-blue-500">API Documentation</h3>
              <p className="text-sm text-muted-foreground mt-1">
                Use API keys to connect external trading bots. Include <code className="bg-muted px-1 rounded">X-API-Key</code> and <code className="bg-muted px-1 rounded">X-API-Secret</code> headers in your requests.
              </p>
              <div className="mt-3 flex gap-2">
                <Badge variant="outline">Endpoint: /functions/v1/trading-bot-manager</Badge>
                <Badge variant="outline">Method: POST</Badge>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Keys List */}
      {keys.length === 0 ? (
        <Card className="bg-card/50">
          <CardContent className="py-12 text-center">
            <Key className="w-12 h-12 mx-auto text-muted-foreground mb-4" />
            <h3 className="text-lg font-semibold mb-2">No API Keys</h3>
            <p className="text-muted-foreground mb-4">Create an API key to connect external trading bots</p>
            <Button onClick={() => setShowCreateDialog(true)} className="gap-2">
              <Plus className="w-4 h-4" />
              Create API Key
            </Button>
          </CardContent>
        </Card>
      ) : (
        <div className="space-y-4">
          {keys.map((key) => (
            <Card key={key.id} className="bg-card/50">
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-4">
                    <div className={`w-10 h-10 rounded-full flex items-center justify-center ${
                      key.is_active ? 'bg-green-500/10' : 'bg-red-500/10'
                    }`}>
                      <Key className={`w-5 h-5 ${key.is_active ? 'text-green-500' : 'text-red-500'}`} />
                    </div>
                    <div>
                      <div className="flex items-center gap-2">
                        <h3 className="font-semibold">{key.name}</h3>
                        {key.is_active ? (
                          <Badge variant="outline" className="bg-green-500/10 text-green-500 border-green-500/30">
                            <CheckCircle className="w-3 h-3 mr-1" />
                            Active
                          </Badge>
                        ) : (
                          <Badge variant="outline" className="bg-red-500/10 text-red-500 border-red-500/30">
                            Revoked
                          </Badge>
                        )}
                      </div>
                      <div className="flex items-center gap-2 mt-1">
                        <code className="text-xs bg-muted px-2 py-0.5 rounded font-mono">
                          {key.api_key.substring(0, 12)}...
                        </code>
                        <Button
                          variant="ghost"
                          size="sm"
                          className="h-6 px-2"
                          onClick={() => copyToClipboard(key.api_key, 'API Key')}
                        >
                          <Copy className="w-3 h-3" />
                        </Button>
                      </div>
                    </div>
                  </div>

                  <div className="flex items-center gap-4">
                    <div className="text-right hidden md:block">
                      <p className="text-xs text-muted-foreground">Permissions</p>
                      <div className="flex gap-1 mt-1">
                        {key.permissions?.map((p) => (
                          <Badge key={p} variant="secondary" className="text-xs">
                            {p}
                          </Badge>
                        ))}
                      </div>
                    </div>
                    <div className="text-right hidden md:block">
                      <p className="text-xs text-muted-foreground">Last Used</p>
                      <p className="text-sm">
                        {key.last_used_at 
                          ? new Date(key.last_used_at).toLocaleDateString()
                          : 'Never'}
                      </p>
                    </div>
                    <div className="text-right hidden md:block">
                      <p className="text-xs text-muted-foreground">Expires</p>
                      <p className="text-sm">
                        {key.expires_at 
                          ? new Date(key.expires_at).toLocaleDateString()
                          : 'Never'}
                      </p>
                    </div>
                    <div className="flex items-center gap-2">
                      {key.is_active && (
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => revokeKey(key.id)}
                          className="text-yellow-500 border-yellow-500/30 hover:bg-yellow-500/10"
                        >
                          Revoke
                        </Button>
                      )}
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => deleteKey(key.id)}
                        className="text-red-500 hover:text-red-400 hover:bg-red-500/10"
                      >
                        <Trash2 className="w-4 h-4" />
                      </Button>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}

      {/* API Endpoints Reference */}
      <Card className="bg-card/50">
        <CardHeader>
          <CardTitle className="text-lg">Available API Endpoints</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-3 text-sm">
            <div className="grid grid-cols-3 gap-4 p-3 bg-muted rounded-lg">
              <div className="font-mono text-blue-500">get_market_data</div>
              <div className="text-muted-foreground">Read</div>
              <div>Get current prices, order book, recent trades</div>
            </div>
            <div className="grid grid-cols-3 gap-4 p-3 bg-muted rounded-lg">
              <div className="font-mono text-blue-500">list_bots</div>
              <div className="text-muted-foreground">Read</div>
              <div>List all your trading bots</div>
            </div>
            <div className="grid grid-cols-3 gap-4 p-3 bg-muted rounded-lg">
              <div className="font-mono text-green-500">start_bot</div>
              <div className="text-muted-foreground">Trade</div>
              <div>Start a trading bot</div>
            </div>
            <div className="grid grid-cols-3 gap-4 p-3 bg-muted rounded-lg">
              <div className="font-mono text-green-500">stop_bot</div>
              <div className="text-muted-foreground">Trade</div>
              <div>Stop a trading bot</div>
            </div>
            <div className="grid grid-cols-3 gap-4 p-3 bg-muted rounded-lg">
              <div className="font-mono text-green-500">execute_bot_trade</div>
              <div className="text-muted-foreground">Trade</div>
              <div>Execute a trade through a bot</div>
            </div>
            <div className="grid grid-cols-3 gap-4 p-3 bg-muted rounded-lg">
              <div className="font-mono text-blue-500">get_bot_trades</div>
              <div className="text-muted-foreground">Read</div>
              <div>Get trade history for a bot</div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
