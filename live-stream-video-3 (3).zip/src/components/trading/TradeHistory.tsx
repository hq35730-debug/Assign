import { useState, useEffect } from 'react';
import { History, ArrowUpRight, ArrowDownRight, Clock } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { supabase } from '@/lib/supabase';

interface Trade {
  id: string;
  buyer_id: string;
  seller_id: string;
  price: string;
  amount: string;
  total_coins: string;
  fee: string;
  executed_at: string;
}

interface TradeHistoryProps {
  userId?: string;
}

export function TradeHistory({ userId }: TradeHistoryProps) {
  const [marketTrades, setMarketTrades] = useState<Trade[]>([]);
  const [userTrades, setUserTrades] = useState<Trade[]>([]);
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState('market');

  useEffect(() => {
    fetchTrades();
    const timer = setInterval(fetchTrades, 10000);
    return () => clearInterval(timer);
  }, [userId]);

  const fetchTrades = async () => {
    try {
      // Fetch market trades
      const { data: marketData } = await supabase.functions.invoke('trading-manager', {
        body: { action: 'get_trade_history', limit: 50 }
      });

      if (marketData?.trades) {
        setMarketTrades(marketData.trades);
      }

      // Fetch user trades if userId provided
      if (userId) {
        const { data: userData } = await supabase.functions.invoke('trading-manager', {
          body: { action: 'get_user_trades', user_id: userId, limit: 50 }
        });

        if (userData?.trades) {
          setUserTrades(userData.trades);
        }
      }
    } catch (err) {
      console.error('Failed to fetch trades:', err);
    } finally {
      setLoading(false);
    }
  };

  const formatTime = (timestamp: string) => {
    const date = new Date(timestamp);
    const now = new Date();
    const diff = now.getTime() - date.getTime();
    
    if (diff < 60000) return 'Just now';
    if (diff < 3600000) return `${Math.floor(diff / 60000)}m ago`;
    if (diff < 86400000) return `${Math.floor(diff / 3600000)}h ago`;
    return date.toLocaleDateString();
  };

  const TradeRow = ({ trade, showSide = false }: { trade: Trade; showSide?: boolean }) => {
    const isBuyer = userId === trade.buyer_id;
    const isSeller = userId === trade.seller_id;
    const side = isBuyer ? 'buy' : isSeller ? 'sell' : null;

    return (
      <div className="grid grid-cols-4 text-sm py-2 px-2 hover:bg-muted/30 rounded transition-colors">
        <div className="flex items-center gap-2">
          {showSide && side ? (
            side === 'buy' ? (
              <ArrowUpRight className="w-4 h-4 text-green-500" />
            ) : (
              <ArrowDownRight className="w-4 h-4 text-red-500" />
            )
          ) : (
            <div className={`w-2 h-2 rounded-full ${parseFloat(trade.price) >= 100 ? 'bg-green-500' : 'bg-red-500'}`} />
          )}
          <span className={`font-mono ${showSide && side === 'buy' ? 'text-green-500' : showSide && side === 'sell' ? 'text-red-500' : ''}`}>
            {parseFloat(trade.price).toFixed(2)}
          </span>
        </div>
        <span className="font-mono text-right">{parseFloat(trade.amount).toFixed(4)}</span>
        <span className="font-mono text-right text-muted-foreground">
          {parseFloat(trade.total_coins).toFixed(2)}
        </span>
        <span className="text-right text-muted-foreground flex items-center justify-end gap-1">
          <Clock className="w-3 h-3" />
          {formatTime(trade.executed_at)}
        </span>
      </div>
    );
  };

  return (
    <Card className="bg-card/50 backdrop-blur border-border/50">
      <CardHeader className="pb-2">
        <CardTitle className="text-lg flex items-center gap-2">
          <History className="w-5 h-5 text-primary" />
          Trade History
        </CardTitle>
      </CardHeader>
      <CardContent>
        <Tabs value={activeTab} onValueChange={setActiveTab}>
          <TabsList className="grid w-full grid-cols-2 mb-4">
            <TabsTrigger value="market">Market Trades</TabsTrigger>
            <TabsTrigger value="my-trades" disabled={!userId}>
              My Trades
            </TabsTrigger>
          </TabsList>

          <TabsContent value="market" className="mt-0">
            {loading ? (
              <div className="h-48 flex items-center justify-center">
                <div className="animate-spin w-6 h-6 border-2 border-primary border-t-transparent rounded-full" />
              </div>
            ) : marketTrades.length === 0 ? (
              <div className="h-48 flex flex-col items-center justify-center text-muted-foreground">
                <History className="w-10 h-10 mb-2 opacity-50" />
                <p>No trades yet</p>
                <p className="text-sm">Be the first to trade!</p>
              </div>
            ) : (
              <div>
                <div className="grid grid-cols-4 text-xs text-muted-foreground px-2 pb-2 border-b border-border/50">
                  <span>Price</span>
                  <span className="text-right">Amount</span>
                  <span className="text-right">Total</span>
                  <span className="text-right">Time</span>
                </div>
                <div className="max-h-64 overflow-y-auto">
                  {marketTrades.map(trade => (
                    <TradeRow key={trade.id} trade={trade} />
                  ))}
                </div>
              </div>
            )}
          </TabsContent>

          <TabsContent value="my-trades" className="mt-0">
            {loading ? (
              <div className="h-48 flex items-center justify-center">
                <div className="animate-spin w-6 h-6 border-2 border-primary border-t-transparent rounded-full" />
              </div>
            ) : userTrades.length === 0 ? (
              <div className="h-48 flex flex-col items-center justify-center text-muted-foreground">
                <History className="w-10 h-10 mb-2 opacity-50" />
                <p>No trades yet</p>
                <p className="text-sm">Place an order to start trading!</p>
              </div>
            ) : (
              <div>
                <div className="grid grid-cols-4 text-xs text-muted-foreground px-2 pb-2 border-b border-border/50">
                  <span>Side/Price</span>
                  <span className="text-right">Amount</span>
                  <span className="text-right">Total</span>
                  <span className="text-right">Time</span>
                </div>
                <div className="max-h-64 overflow-y-auto">
                  {userTrades.map(trade => (
                    <TradeRow key={trade.id} trade={trade} showSide />
                  ))}
                </div>
              </div>
            )}
          </TabsContent>
        </Tabs>

        {/* Stats */}
        {marketTrades.length > 0 && (
          <div className="grid grid-cols-3 gap-4 mt-4 pt-4 border-t border-border/50">
            <div className="text-center">
              <p className="text-xs text-muted-foreground">24h Trades</p>
              <p className="font-bold">{marketTrades.length}</p>
            </div>
            <div className="text-center">
              <p className="text-xs text-muted-foreground">24h Volume</p>
              <p className="font-bold">
                {marketTrades.reduce((sum, t) => sum + parseFloat(t.amount), 0).toFixed(2)} STC
              </p>
            </div>
            <div className="text-center">
              <p className="text-xs text-muted-foreground">Avg Price</p>
              <p className="font-bold">
                {(marketTrades.reduce((sum, t) => sum + parseFloat(t.price), 0) / marketTrades.length).toFixed(2)}
              </p>
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
