import { useState, useEffect } from 'react';
import {
  Play,
  BarChart3,
  TrendingUp,
  TrendingDown,
  Activity,
  Clock,
  Zap,
  Bot,
  Calendar,
  DollarSign,
  Target,
  AlertTriangle,
  CheckCircle,
  XCircle,
  RefreshCw,
  ChevronDown,
  ChevronUp,
  LineChart,
  PieChart,
  ArrowUpRight,
  ArrowDownRight,
  Percent,
  History
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Progress } from '@/components/ui/progress';
import { supabase } from '@/lib/supabase';
import { useToast } from '@/hooks/use-toast';

interface Trade {
  id: string;
  timestamp: string;
  side: 'buy' | 'sell';
  price: number;
  amount: number;
  total: number;
  fee: number;
  balance_after: number;
  position_after: number;
  pnl: number;
  reason: string;
}

interface BacktestMetrics {
  total_return: number;
  total_return_percent: number;
  win_rate: number;
  total_trades: number;
  winning_trades: number;
  losing_trades: number;
  max_drawdown: number;
  max_drawdown_percent: number;
  sharpe_ratio: number;
  profit_factor: number;
  avg_trade_pnl: number;
  best_trade: number;
  worst_trade: number;
  avg_holding_time: string;
  final_balance: number;
  final_position: number;
}

interface BacktestResult {
  trades: Trade[];
  metrics: BacktestMetrics;
  equity_curve: { timestamp: string; equity: number; drawdown: number }[];
  price_data: { timestamp: string; price: number }[];
}

interface BacktestingPanelProps {
  userId: string;
}

const STRATEGIES = [
  { value: 'dca', label: 'DCA (Dollar Cost Average)', description: 'Buy fixed amounts at regular intervals', icon: Clock },
  { value: 'grid', label: 'Grid Trading', description: 'Place buy/sell orders at price intervals', icon: BarChart3 },
  { value: 'stop_loss', label: 'Stop Loss', description: 'Automatically sell when price drops', icon: TrendingDown },
  { value: 'take_profit', label: 'Take Profit', description: 'Automatically sell when price rises', icon: TrendingUp },
  { value: 'scalping', label: 'Scalping', description: 'Quick trades on small price movements', icon: Zap }
];

export function BacktestingPanel({ userId }: BacktestingPanelProps) {
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<BacktestResult | null>(null);
  const [activeTab, setActiveTab] = useState('config');
  const { toast } = useToast();

  // Backtest configuration
  const [config, setConfig] = useState({
    strategy: 'dca',
    initial_capital: 1000,
    start_date: new Date(Date.now() - 30 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
    end_date: new Date().toISOString().split('T')[0],
    // Strategy-specific configs
    dca_amount: 50,
    dca_interval: 'daily',
    grid_lower: 80,
    grid_upper: 120,
    grid_levels: 10,
    grid_amount: 25,
    stop_loss_percent: 10,
    take_profit_percent: 20,
    max_position: 1000
  });

  const runBacktest = async () => {
    setLoading(true);
    setResult(null);

    try {
      const strategyConfig: any = {};
      
      switch (config.strategy) {
        case 'dca':
          strategyConfig.dca_amount = config.dca_amount;
          strategyConfig.dca_interval = config.dca_interval;
          break;
        case 'grid':
          strategyConfig.grid_lower = config.grid_lower;
          strategyConfig.grid_upper = config.grid_upper;
          strategyConfig.grid_levels = config.grid_levels;
          strategyConfig.grid_amount = config.grid_amount;
          break;
        case 'stop_loss':
          strategyConfig.stop_loss_percent = config.stop_loss_percent;
          break;
        case 'take_profit':
          strategyConfig.take_profit_percent = config.take_profit_percent;
          break;
        case 'scalping':
          // Uses default scalping params
          break;
      }

      const { data, error } = await supabase.functions.invoke('backtest-manager', {
        body: {
          action: 'run_backtest',
          strategy: config.strategy,
          config: strategyConfig,
          start_date: config.start_date,
          end_date: config.end_date,
          initial_capital: config.initial_capital
        }
      });

      if (error) throw error;

      if (data?.result) {
        setResult(data.result);
        setActiveTab('results');
        toast({
          title: 'Backtest Complete',
          description: `Strategy tested with ${data.result.metrics.total_trades} trades`
        });
      }
    } catch (err: any) {
      toast({
        title: 'Backtest Failed',
        description: err.message || 'Failed to run backtest',
        variant: 'destructive'
      });
    } finally {
      setLoading(false);
    }
  };

  const getStrategyIcon = (strategy: string) => {
    const strat = STRATEGIES.find(s => s.value === strategy);
    if (strat) {
      const Icon = strat.icon;
      return <Icon className="w-4 h-4" />;
    }
    return <Bot className="w-4 h-4" />;
  };

  const formatDate = (dateStr: string) => {
    return new Date(dateStr).toLocaleDateString('en-US', {
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  // Simple chart component using CSS
  const EquityChart = ({ data, priceData }: { data: { timestamp: string; equity: number; drawdown: number }[]; priceData: { timestamp: string; price: number }[] }) => {
    if (!data || data.length === 0) return null;

    const maxEquity = Math.max(...data.map(d => d.equity));
    const minEquity = Math.min(...data.map(d => d.equity));
    const equityRange = maxEquity - minEquity || 1;

    const maxPrice = Math.max(...priceData.map(d => d.price));
    const minPrice = Math.min(...priceData.map(d => d.price));
    const priceRange = maxPrice - minPrice || 1;

    return (
      <div className="space-y-4">
        {/* Equity Curve */}
        <div>
          <div className="flex items-center justify-between mb-2">
            <span className="text-sm font-medium">Portfolio Value</span>
            <div className="flex items-center gap-4 text-xs">
              <span className="flex items-center gap-1">
                <div className="w-3 h-0.5 bg-green-500"></div>
                Equity
              </span>
              <span className="flex items-center gap-1">
                <div className="w-3 h-0.5 bg-blue-500"></div>
                Price
              </span>
            </div>
          </div>
          <div className="relative h-48 bg-muted/30 rounded-lg overflow-hidden">
            {/* Grid lines */}
            <div className="absolute inset-0 flex flex-col justify-between py-2">
              {[0, 1, 2, 3, 4].map(i => (
                <div key={i} className="border-t border-border/30 w-full"></div>
              ))}
            </div>
            
            {/* Equity line */}
            <svg className="absolute inset-0 w-full h-full" preserveAspectRatio="none">
              <defs>
                <linearGradient id="equityGradient" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stopColor="rgb(34, 197, 94)" stopOpacity="0.3" />
                  <stop offset="100%" stopColor="rgb(34, 197, 94)" stopOpacity="0" />
                </linearGradient>
              </defs>
              
              {/* Area fill */}
              <path
                d={`M 0 ${192} ${data.map((d, i) => {
                  const x = (i / (data.length - 1)) * 100;
                  const y = 192 - ((d.equity - minEquity) / equityRange) * 180;
                  return `L ${x}% ${y}`;
                }).join(' ')} L 100% 192 Z`}
                fill="url(#equityGradient)"
              />
              
              {/* Equity line */}
              <path
                d={`M ${data.map((d, i) => {
                  const x = (i / (data.length - 1)) * 100;
                  const y = 192 - ((d.equity - minEquity) / equityRange) * 180;
                  return `${i === 0 ? '' : 'L '}${x}% ${y}`;
                }).join(' ')}`}
                fill="none"
                stroke="rgb(34, 197, 94)"
                strokeWidth="2"
              />
              
              {/* Price line */}
              <path
                d={`M ${priceData.map((d, i) => {
                  const x = (i / (priceData.length - 1)) * 100;
                  const y = 192 - ((d.price - minPrice) / priceRange) * 180;
                  return `${i === 0 ? '' : 'L '}${x}% ${y}`;
                }).join(' ')}`}
                fill="none"
                stroke="rgb(59, 130, 246)"
                strokeWidth="1.5"
                strokeDasharray="4 2"
                opacity="0.7"
              />
            </svg>

            {/* Y-axis labels */}
            <div className="absolute left-2 top-2 text-xs text-muted-foreground">
              ${maxEquity.toFixed(0)}
            </div>
            <div className="absolute left-2 bottom-2 text-xs text-muted-foreground">
              ${minEquity.toFixed(0)}
            </div>
          </div>
        </div>

        {/* Drawdown Chart */}
        <div>
          <div className="flex items-center justify-between mb-2">
            <span className="text-sm font-medium">Drawdown</span>
            <span className="text-xs text-muted-foreground">
              Max: {Math.max(...data.map(d => d.drawdown)).toFixed(2)}%
            </span>
          </div>
          <div className="relative h-24 bg-muted/30 rounded-lg overflow-hidden">
            <svg className="absolute inset-0 w-full h-full" preserveAspectRatio="none">
              <defs>
                <linearGradient id="drawdownGradient" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stopColor="rgb(239, 68, 68)" stopOpacity="0.5" />
                  <stop offset="100%" stopColor="rgb(239, 68, 68)" stopOpacity="0" />
                </linearGradient>
              </defs>
              
              {/* Area fill */}
              <path
                d={`M 0 0 ${data.map((d, i) => {
                  const x = (i / (data.length - 1)) * 100;
                  const maxDD = Math.max(...data.map(d => d.drawdown)) || 1;
                  const y = (d.drawdown / maxDD) * 90;
                  return `L ${x}% ${y}`;
                }).join(' ')} L 100% 0 Z`}
                fill="url(#drawdownGradient)"
              />
              
              {/* Line */}
              <path
                d={`M ${data.map((d, i) => {
                  const x = (i / (data.length - 1)) * 100;
                  const maxDD = Math.max(...data.map(d => d.drawdown)) || 1;
                  const y = (d.drawdown / maxDD) * 90;
                  return `${i === 0 ? '' : 'L '}${x}% ${y}`;
                }).join(' ')}`}
                fill="none"
                stroke="rgb(239, 68, 68)"
                strokeWidth="1.5"
              />
            </svg>
          </div>
        </div>
      </div>
    );
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-full bg-gradient-to-br from-blue-500 to-cyan-500 flex items-center justify-center">
            <History className="w-5 h-5 text-white" />
          </div>
          <div>
            <h2 className="text-xl font-bold">Strategy Backtesting</h2>
            <p className="text-sm text-muted-foreground">Test strategies against historical data</p>
          </div>
        </div>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="grid w-full max-w-md grid-cols-3">
          <TabsTrigger value="config" className="gap-2">
            <Bot className="w-4 h-4" />
            Configure
          </TabsTrigger>
          <TabsTrigger value="results" className="gap-2" disabled={!result}>
            <BarChart3 className="w-4 h-4" />
            Results
          </TabsTrigger>
          <TabsTrigger value="trades" className="gap-2" disabled={!result}>
            <Activity className="w-4 h-4" />
            Trades
          </TabsTrigger>
        </TabsList>

        {/* Configuration Tab */}
        <TabsContent value="config" className="space-y-6">
          <div className="grid md:grid-cols-2 gap-6">
            {/* Strategy Selection */}
            <Card className="bg-card/50">
              <CardHeader>
                <CardTitle className="text-lg flex items-center gap-2">
                  <Bot className="w-5 h-5" />
                  Strategy Selection
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <Label>Trading Strategy</Label>
                  <Select
                    value={config.strategy}
                    onValueChange={(value) => setConfig({ ...config, strategy: value })}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {STRATEGIES.map((s) => (
                        <SelectItem key={s.value} value={s.value}>
                          <div className="flex items-center gap-2">
                            <s.icon className="w-4 h-4" />
                            <span>{s.label}</span>
                          </div>
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  <p className="text-xs text-muted-foreground">
                    {STRATEGIES.find(s => s.value === config.strategy)?.description}
                  </p>
                </div>

                {/* Strategy-specific settings */}
                {config.strategy === 'dca' && (
                  <div className="space-y-4 p-4 bg-muted/50 rounded-lg">
                    <h4 className="font-medium text-sm">DCA Settings</h4>
                    <div className="grid grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <Label className="text-xs">Amount per Buy</Label>
                        <Input
                          type="number"
                          value={config.dca_amount}
                          onChange={(e) => setConfig({ ...config, dca_amount: parseFloat(e.target.value) || 0 })}
                        />
                      </div>
                      <div className="space-y-2">
                        <Label className="text-xs">Interval</Label>
                        <Select
                          value={config.dca_interval}
                          onValueChange={(value) => setConfig({ ...config, dca_interval: value })}
                        >
                          <SelectTrigger>
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="hourly">Hourly</SelectItem>
                            <SelectItem value="daily">Daily</SelectItem>
                            <SelectItem value="weekly">Weekly</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                    </div>
                  </div>
                )}

                {config.strategy === 'grid' && (
                  <div className="space-y-4 p-4 bg-muted/50 rounded-lg">
                    <h4 className="font-medium text-sm">Grid Settings</h4>
                    <div className="grid grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <Label className="text-xs">Lower Price</Label>
                        <Input
                          type="number"
                          value={config.grid_lower}
                          onChange={(e) => setConfig({ ...config, grid_lower: parseFloat(e.target.value) || 0 })}
                        />
                      </div>
                      <div className="space-y-2">
                        <Label className="text-xs">Upper Price</Label>
                        <Input
                          type="number"
                          value={config.grid_upper}
                          onChange={(e) => setConfig({ ...config, grid_upper: parseFloat(e.target.value) || 0 })}
                        />
                      </div>
                      <div className="space-y-2">
                        <Label className="text-xs">Grid Levels</Label>
                        <Input
                          type="number"
                          value={config.grid_levels}
                          onChange={(e) => setConfig({ ...config, grid_levels: parseInt(e.target.value) || 0 })}
                        />
                      </div>
                      <div className="space-y-2">
                        <Label className="text-xs">Amount per Grid</Label>
                        <Input
                          type="number"
                          value={config.grid_amount}
                          onChange={(e) => setConfig({ ...config, grid_amount: parseFloat(e.target.value) || 0 })}
                        />
                      </div>
                    </div>
                  </div>
                )}

                {config.strategy === 'stop_loss' && (
                  <div className="space-y-4 p-4 bg-muted/50 rounded-lg">
                    <h4 className="font-medium text-sm">Stop Loss Settings</h4>
                    <div className="space-y-2">
                      <Label className="text-xs">Stop Loss Percentage</Label>
                      <div className="flex items-center gap-2">
                        <Input
                          type="number"
                          value={config.stop_loss_percent}
                          onChange={(e) => setConfig({ ...config, stop_loss_percent: parseFloat(e.target.value) || 0 })}
                        />
                        <span className="text-muted-foreground">%</span>
                      </div>
                    </div>
                  </div>
                )}

                {config.strategy === 'take_profit' && (
                  <div className="space-y-4 p-4 bg-muted/50 rounded-lg">
                    <h4 className="font-medium text-sm">Take Profit Settings</h4>
                    <div className="space-y-2">
                      <Label className="text-xs">Take Profit Percentage</Label>
                      <div className="flex items-center gap-2">
                        <Input
                          type="number"
                          value={config.take_profit_percent}
                          onChange={(e) => setConfig({ ...config, take_profit_percent: parseFloat(e.target.value) || 0 })}
                        />
                        <span className="text-muted-foreground">%</span>
                      </div>
                    </div>
                  </div>
                )}

                {config.strategy === 'scalping' && (
                  <div className="p-4 bg-muted/50 rounded-lg">
                    <h4 className="font-medium text-sm mb-2">Scalping Settings</h4>
                    <p className="text-xs text-muted-foreground">
                      Uses default parameters: 0.5% profit target, 0.3% stop loss, 20% position size per trade.
                    </p>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Backtest Parameters */}
            <Card className="bg-card/50">
              <CardHeader>
                <CardTitle className="text-lg flex items-center gap-2">
                  <Calendar className="w-5 h-5" />
                  Backtest Parameters
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <Label>Initial Capital</Label>
                  <div className="flex items-center gap-2">
                    <DollarSign className="w-4 h-4 text-muted-foreground" />
                    <Input
                      type="number"
                      value={config.initial_capital}
                      onChange={(e) => setConfig({ ...config, initial_capital: parseFloat(e.target.value) || 0 })}
                    />
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label>Start Date</Label>
                    <Input
                      type="date"
                      value={config.start_date}
                      onChange={(e) => setConfig({ ...config, start_date: e.target.value })}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label>End Date</Label>
                    <Input
                      type="date"
                      value={config.end_date}
                      onChange={(e) => setConfig({ ...config, end_date: e.target.value })}
                    />
                  </div>
                </div>

                <div className="p-4 bg-blue-500/10 border border-blue-500/30 rounded-lg">
                  <div className="flex items-start gap-2">
                    <Activity className="w-4 h-4 text-blue-500 mt-0.5" />
                    <div>
                      <p className="text-sm font-medium text-blue-500">Simulated Data</p>
                      <p className="text-xs text-muted-foreground">
                        Backtest uses simulated historical price data with realistic market patterns including trends and volatility.
                      </p>
                    </div>
                  </div>
                </div>

                <Button 
                  onClick={runBacktest} 
                  disabled={loading}
                  className="w-full gap-2"
                  size="lg"
                >
                  {loading ? (
                    <>
                      <RefreshCw className="w-4 h-4 animate-spin" />
                      Running Backtest...
                    </>
                  ) : (
                    <>
                      <Play className="w-4 h-4" />
                      Run Backtest
                    </>
                  )}
                </Button>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        {/* Results Tab */}
        <TabsContent value="results" className="space-y-6">
          {result && (
            <>
              {/* Key Metrics */}
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                <Card className={`bg-card/50 ${result.metrics.total_return >= 0 ? 'border-green-500/30' : 'border-red-500/30'}`}>
                  <CardContent className="pt-4">
                    <div className="flex items-center gap-2 text-muted-foreground text-sm">
                      <DollarSign className="w-4 h-4" />
                      Total Return
                    </div>
                    <div className="flex items-center gap-2 mt-1">
                      <p className={`text-2xl font-bold ${result.metrics.total_return >= 0 ? 'text-green-500' : 'text-red-500'}`}>
                        ${result.metrics.total_return.toFixed(2)}
                      </p>
                      {result.metrics.total_return >= 0 ? (
                        <ArrowUpRight className="w-5 h-5 text-green-500" />
                      ) : (
                        <ArrowDownRight className="w-5 h-5 text-red-500" />
                      )}
                    </div>
                    <p className={`text-sm ${result.metrics.total_return_percent >= 0 ? 'text-green-500' : 'text-red-500'}`}>
                      {result.metrics.total_return_percent >= 0 ? '+' : ''}{result.metrics.total_return_percent.toFixed(2)}%
                    </p>
                  </CardContent>
                </Card>

                <Card className="bg-card/50">
                  <CardContent className="pt-4">
                    <div className="flex items-center gap-2 text-muted-foreground text-sm">
                      <Target className="w-4 h-4" />
                      Win Rate
                    </div>
                    <p className="text-2xl font-bold mt-1">{result.metrics.win_rate.toFixed(1)}%</p>
                    <p className="text-sm text-muted-foreground">
                      {result.metrics.winning_trades}W / {result.metrics.losing_trades}L
                    </p>
                  </CardContent>
                </Card>

                <Card className="bg-card/50 border-red-500/30">
                  <CardContent className="pt-4">
                    <div className="flex items-center gap-2 text-muted-foreground text-sm">
                      <TrendingDown className="w-4 h-4" />
                      Max Drawdown
                    </div>
                    <p className="text-2xl font-bold mt-1 text-red-500">
                      -{result.metrics.max_drawdown_percent.toFixed(2)}%
                    </p>
                    <p className="text-sm text-muted-foreground">
                      ${result.metrics.max_drawdown.toFixed(2)}
                    </p>
                  </CardContent>
                </Card>

                <Card className="bg-card/50">
                  <CardContent className="pt-4">
                    <div className="flex items-center gap-2 text-muted-foreground text-sm">
                      <Activity className="w-4 h-4" />
                      Total Trades
                    </div>
                    <p className="text-2xl font-bold mt-1">{result.metrics.total_trades}</p>
                    <p className="text-sm text-muted-foreground">
                      Avg PnL: ${result.metrics.avg_trade_pnl.toFixed(2)}
                    </p>
                  </CardContent>
                </Card>
              </div>

              {/* Performance Chart */}
              <Card className="bg-card/50">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <LineChart className="w-5 h-5" />
                    Performance Chart
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <EquityChart data={result.equity_curve} priceData={result.price_data} />
                </CardContent>
              </Card>

              {/* Detailed Metrics */}
              <div className="grid md:grid-cols-2 gap-6">
                <Card className="bg-card/50">
                  <CardHeader>
                    <CardTitle className="text-lg">Risk Metrics</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="flex items-center justify-between">
                      <span className="text-muted-foreground">Sharpe Ratio</span>
                      <span className={`font-mono font-semibold ${result.metrics.sharpe_ratio >= 1 ? 'text-green-500' : result.metrics.sharpe_ratio >= 0 ? 'text-yellow-500' : 'text-red-500'}`}>
                        {result.metrics.sharpe_ratio.toFixed(2)}
                      </span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-muted-foreground">Profit Factor</span>
                      <span className={`font-mono font-semibold ${result.metrics.profit_factor >= 1.5 ? 'text-green-500' : result.metrics.profit_factor >= 1 ? 'text-yellow-500' : 'text-red-500'}`}>
                        {result.metrics.profit_factor === Infinity ? '∞' : result.metrics.profit_factor.toFixed(2)}
                      </span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-muted-foreground">Best Trade</span>
                      <span className="font-mono font-semibold text-green-500">
                        +${result.metrics.best_trade.toFixed(2)}
                      </span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-muted-foreground">Worst Trade</span>
                      <span className="font-mono font-semibold text-red-500">
                        ${result.metrics.worst_trade.toFixed(2)}
                      </span>
                    </div>
                  </CardContent>
                </Card>

                <Card className="bg-card/50">
                  <CardHeader>
                    <CardTitle className="text-lg">Final Position</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="flex items-center justify-between">
                      <span className="text-muted-foreground">Cash Balance</span>
                      <span className="font-mono font-semibold">
                        ${result.metrics.final_balance.toFixed(2)}
                      </span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-muted-foreground">STC Position</span>
                      <span className="font-mono font-semibold">
                        {result.metrics.final_position.toFixed(4)} STC
                      </span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-muted-foreground">Initial Capital</span>
                      <span className="font-mono">
                        ${config.initial_capital.toFixed(2)}
                      </span>
                    </div>
                    <div className="pt-2 border-t">
                      <div className="flex items-center justify-between">
                        <span className="font-medium">Total Equity</span>
                        <span className={`font-mono font-bold ${result.metrics.total_return >= 0 ? 'text-green-500' : 'text-red-500'}`}>
                          ${(config.initial_capital + result.metrics.total_return).toFixed(2)}
                        </span>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>

              {/* Strategy Summary */}
              <Card className={`${result.metrics.total_return >= 0 ? 'bg-green-500/5 border-green-500/30' : 'bg-red-500/5 border-red-500/30'}`}>
                <CardContent className="py-4">
                  <div className="flex items-start gap-3">
                    {result.metrics.total_return >= 0 ? (
                      <CheckCircle className="w-5 h-5 text-green-500 flex-shrink-0 mt-0.5" />
                    ) : (
                      <XCircle className="w-5 h-5 text-red-500 flex-shrink-0 mt-0.5" />
                    )}
                    <div>
                      <h3 className={`font-semibold ${result.metrics.total_return >= 0 ? 'text-green-500' : 'text-red-500'}`}>
                        {result.metrics.total_return >= 0 ? 'Profitable Strategy' : 'Unprofitable Strategy'}
                      </h3>
                      <p className="text-sm text-muted-foreground">
                        The {STRATEGIES.find(s => s.value === config.strategy)?.label} strategy 
                        {result.metrics.total_return >= 0 
                          ? ` generated a ${result.metrics.total_return_percent.toFixed(2)}% return with a ${result.metrics.win_rate.toFixed(1)}% win rate.`
                          : ` resulted in a ${Math.abs(result.metrics.total_return_percent).toFixed(2)}% loss. Consider adjusting parameters or trying a different strategy.`
                        }
                        {result.metrics.max_drawdown_percent > 20 && ' Warning: High drawdown detected.'}
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </>
          )}
        </TabsContent>

        {/* Trades Tab */}
        <TabsContent value="trades" className="space-y-6">
          {result && (
            <Card className="bg-card/50">
              <CardHeader>
                <CardTitle className="flex items-center justify-between">
                  <span className="flex items-center gap-2">
                    <Activity className="w-5 h-5" />
                    Trade History
                  </span>
                  <Badge variant="outline">{result.trades.length} trades</Badge>
                </CardTitle>
              </CardHeader>
              <CardContent>
                {result.trades.length === 0 ? (
                  <div className="text-center py-8 text-muted-foreground">
                    <Activity className="w-8 h-8 mx-auto mb-2 opacity-50" />
                    <p>No trades executed during backtest period</p>
                  </div>
                ) : (
                  <div className="space-y-2 max-h-[500px] overflow-y-auto">
                    {result.trades.map((trade, index) => (
                      <div
                        key={trade.id}
                        className="flex items-center justify-between p-3 bg-background rounded-lg hover:bg-muted/50 transition-colors"
                      >
                        <div className="flex items-center gap-3">
                          <div className={`w-8 h-8 rounded-full flex items-center justify-center ${
                            trade.side === 'buy' ? 'bg-green-500/10' : 'bg-red-500/10'
                          }`}>
                            {trade.side === 'buy' ? (
                              <TrendingUp className="w-4 h-4 text-green-500" />
                            ) : (
                              <TrendingDown className="w-4 h-4 text-red-500" />
                            )}
                          </div>
                          <div>
                            <div className="flex items-center gap-2">
                              <span className={`font-medium ${
                                trade.side === 'buy' ? 'text-green-500' : 'text-red-500'
                              }`}>
                                {trade.side.toUpperCase()}
                              </span>
                              <span className="font-mono">{trade.amount.toFixed(4)} STC</span>
                            </div>
                            <p className="text-xs text-muted-foreground">
                              @ {trade.price.toFixed(2)} • {trade.reason}
                            </p>
                          </div>
                        </div>
                        <div className="text-right">
                          <p className="font-mono">${trade.total.toFixed(2)}</p>
                          <p className="text-xs text-muted-foreground">
                            {formatDate(trade.timestamp)}
                          </p>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>
          )}
        </TabsContent>
      </Tabs>
    </div>
  );
}
