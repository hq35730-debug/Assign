
import React, { useState, useEffect } from 'react';
import { X, Save, Loader2, Eye, EyeOff } from 'lucide-react';
import { VOD } from './VODCard';
import { supabase } from '@/lib/supabase';

interface VODEditModalProps {
  vod: VOD | null;
  isOpen: boolean;
  onClose: () => void;
  onSave: (updatedVod: VOD) => void;
}

export const VODEditModal: React.FC<VODEditModalProps> = ({ vod, isOpen, onClose, onSave }) => {
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [isPublic, setIsPublic] = useState(true);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    if (vod) {
      setTitle(vod.title);
      setDescription(vod.description || '');
      setIsPublic(vod.is_public);
    }
  }, [vod]);

  const handleSave = async () => {
    if (!vod) return;
    setSaving(true);
    try {
      const { data } = await supabase.functions.invoke('vod-manager', {
        body: { action: 'update_vod', vod_id: vod.id, user_id: vod.user_id, title, description, is_public: isPublic }
      });
      if (data?.vod) {
        onSave(data.vod);
        onClose();
      }
    } catch (error) {
      console.error('Failed to update VOD:', error);
    }
    setSaving(false);
  };

  if (!isOpen || !vod) return null;

  return (
    <div className="fixed inset-0 bg-black/80 z-50 flex items-center justify-center p-4">
      <div className="bg-[#16213e] rounded-2xl w-full max-w-lg border border-gray-700">
        <div className="flex items-center justify-between p-4 border-b border-gray-700">
          <h2 className="text-xl font-bold text-white">Edit VOD</h2>
          <button onClick={onClose} className="text-gray-400 hover:text-white"><X className="w-6 h-6" /></button>
        </div>

        <div className="p-6 space-y-4">
          <div className="aspect-video rounded-lg overflow-hidden bg-gray-800">
            <img src={vod.thumbnail_url || 'https://d64gsuwffb70l.cloudfront.net/6927ca8790687cc18bcac914_1764565042610_75ffd34f.webp'} alt={vod.title} className="w-full h-full object-cover" />
          </div>

          <div>
            <label className="text-gray-300 text-sm mb-2 block">Title</label>
            <input type="text" value={title} onChange={e => setTitle(e.target.value)} className="w-full bg-[#1a1a2e] text-white px-4 py-3 rounded-lg border border-gray-700 focus:border-purple-500 focus:outline-none" placeholder="Enter VOD title" />
          </div>

          <div>
            <label className="text-gray-300 text-sm mb-2 block">Description</label>
            <textarea value={description} onChange={e => setDescription(e.target.value)} rows={3} className="w-full bg-[#1a1a2e] text-white px-4 py-3 rounded-lg border border-gray-700 focus:border-purple-500 focus:outline-none resize-none" placeholder="Enter VOD description" />
          </div>

          <div className="flex items-center justify-between p-3 bg-[#1a1a2e] rounded-lg">
            <div className="flex items-center gap-3">
              {isPublic ? <Eye className="w-5 h-5 text-green-400" /> : <EyeOff className="w-5 h-5 text-gray-400" />}
              <div>
                <p className="text-white font-medium">{isPublic ? 'Public' : 'Private'}</p>
                <p className="text-gray-400 text-xs">{isPublic ? 'Anyone can view this VOD' : 'Only you can view this VOD'}</p>
              </div>
            </div>
            <button onClick={() => setIsPublic(!isPublic)} className={`w-12 h-6 rounded-full transition-colors ${isPublic ? 'bg-purple-600' : 'bg-gray-600'}`}>
              <div className={`w-5 h-5 bg-white rounded-full transition-transform ${isPublic ? 'translate-x-6' : 'translate-x-0.5'}`} />
            </button>
          </div>
        </div>

        <div className="flex gap-3 p-4 border-t border-gray-700">
          <button onClick={onClose} className="flex-1 bg-gray-700 hover:bg-gray-600 text-white py-3 rounded-lg font-semibold transition-colors">Cancel</button>
          <button onClick={handleSave} disabled={saving || !title.trim()} className="flex-1 bg-purple-600 hover:bg-purple-500 disabled:opacity-50 text-white py-3 rounded-lg font-semibold transition-colors flex items-center justify-center gap-2">
            {saving ? <Loader2 className="w-5 h-5 animate-spin" /> : <Save className="w-5 h-5" />}
            {saving ? 'Saving...' : 'Save Changes'}
          </button>
        </div>
      </div>
    </div>
  );
};
