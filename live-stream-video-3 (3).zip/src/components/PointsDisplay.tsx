
import { useState, useEffect } from 'react';
import { Sparkles } from 'lucide-react';
import { supabase } from '@/lib/supabase';

interface PointsDisplayProps {
  channelId: string;
  userId: string;
  isSubscriber?: boolean;
  onPointsUpdate?: (points: number) => void;
}

export function PointsDisplay({ channelId, userId, isSubscriber = false, onPointsUpdate }: PointsDisplayProps) {
  const [points, setPoints] = useState(0);
  const [earnedPoints, setEarnedPoints] = useState<number | null>(null);
  const [showAnimation, setShowAnimation] = useState(false);

  useEffect(() => {
    fetchPoints();
    const interval = setInterval(() => {
      earnPoints();
    }, 60000); // Earn points every minute
    return () => clearInterval(interval);
  }, [channelId, userId]);

  const fetchPoints = async () => {
    const { data } = await supabase.functions.invoke('points-manager', {
      body: { action: 'get_points', user_id: userId, channel_id: channelId }
    });
    if (data?.data) {
      setPoints(data.data.points);
      onPointsUpdate?.(data.data.points);
    }
  };

  const earnPoints = async () => {
    const { data } = await supabase.functions.invoke('points-manager', {
      body: {
        action: 'earn_points',
        user_id: userId,
        username: 'Viewer',
        channel_id: channelId,
        minutes: 1,
        is_subscriber: isSubscriber
      }
    });
    if (data?.earned) {
      setEarnedPoints(data.earned);
      setShowAnimation(true);
      setPoints(data.data.points);
      onPointsUpdate?.(data.data.points);
      setTimeout(() => setShowAnimation(false), 2000);
    }
  };

  return (
    <div className="relative flex items-center gap-2 bg-gradient-to-r from-purple-600/20 to-pink-600/20 px-3 py-1.5 rounded-full border border-purple-500/30">
      <Sparkles className="w-4 h-4 text-yellow-400" />
      <span className="text-sm font-semibold text-white">{points.toLocaleString()}</span>
      {isSubscriber && (
        <span className="text-[10px] bg-purple-500 text-white px-1.5 py-0.5 rounded-full">2x</span>
      )}
      {showAnimation && earnedPoints && (
        <span className="absolute -top-6 left-1/2 -translate-x-1/2 text-green-400 text-sm font-bold animate-bounce">
          +{earnedPoints}
        </span>
      )}
    </div>
  );
}
