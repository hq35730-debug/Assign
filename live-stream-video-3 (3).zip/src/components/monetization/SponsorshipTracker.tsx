import React, { useState, useEffect } from 'react';
import { Handshake, Plus, X, Loader2, Calendar, DollarSign, Building2, CheckCircle, Clock, AlertCircle } from 'lucide-react';
import { supabase } from '@/lib/supabase';

interface Sponsorship {
  id: string;
  brand_name: string;
  deal_value: number;
  start_date: string;
  end_date: string;
  deliverables: string;
  status: 'active' | 'pending' | 'completed' | 'expired';
  paid: boolean;
}

interface Props {
  userId: string;
}

export function SponsorshipTracker({ userId }: Props) {
  const [sponsorships, setSponsorships] = useState<Sponsorship[]>([]);
  const [showCreate, setShowCreate] = useState(false);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [form, setForm] = useState({ brand_name: '', deal_value: 500, start_date: '', end_date: '', deliverables: '' });

  useEffect(() => {
    loadSponsorships();
  }, [userId]);

  const loadSponsorships = async () => {
    setLoading(true);
    const { data } = await supabase.functions.invoke('monetization-manager', {
      body: { action: 'get_sponsorships', streamer_id: userId }
    });
    if (data?.sponsorships && Array.isArray(data.sponsorships)) setSponsorships(data.sponsorships);
    setLoading(false);
  };

  const createSponsorship = async () => {
    setSaving(true);
    await supabase.functions.invoke('monetization-manager', {
      body: { action: 'create_sponsorship', streamer_id: userId, ...form, deal_value: form.deal_value * 100 }
    });
    setShowCreate(false);
    setForm({ brand_name: '', deal_value: 500, start_date: '', end_date: '', deliverables: '' });
    loadSponsorships();
    setSaving(false);
  };

  const updateStatus = async (id: string, status: string) => {
    await supabase.functions.invoke('monetization-manager', {
      body: { action: 'update_sponsorship', sponsorship_id: id, status }
    });
    setSponsorships(prev => prev.map(s => s.id === id ? { ...s, status: status as any } : s));
  };

  const totalValue = sponsorships.filter(s => s.status === 'active' || s.status === 'completed').reduce((sum, s) => sum + s.deal_value, 0);
  const pendingValue = sponsorships.filter(s => s.status === 'pending').reduce((sum, s) => sum + s.deal_value, 0);

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'active': return <CheckCircle className="w-4 h-4 text-green-400" />;
      case 'pending': return <Clock className="w-4 h-4 text-yellow-400" />;
      case 'completed': return <CheckCircle className="w-4 h-4 text-blue-400" />;
      default: return <AlertCircle className="w-4 h-4 text-gray-400" />;
    }
  };

  return (
    <div className="bg-[#16213e] rounded-2xl p-6 border border-gray-800">
      <div className="flex items-center justify-between mb-6">
        <h3 className="text-xl font-bold text-white flex items-center gap-2">
          <Handshake className="w-5 h-5 text-cyan-400" /> Sponsorships
        </h3>
        <button onClick={() => setShowCreate(true)} className="bg-cyan-600 hover:bg-cyan-700 text-white px-4 py-2 rounded-lg flex items-center gap-2">
          <Plus className="w-4 h-4" /> Add Deal
        </button>
      </div>

      <div className="grid grid-cols-2 gap-4 mb-6">
        <div className="bg-[#1a1a2e] rounded-xl p-4">
          <p className="text-gray-400 text-sm">Total Value</p>
          <p className="text-2xl font-bold text-green-400">${(totalValue / 100).toFixed(2)}</p>
        </div>
        <div className="bg-[#1a1a2e] rounded-xl p-4">
          <p className="text-gray-400 text-sm">Pending Deals</p>
          <p className="text-2xl font-bold text-yellow-400">${(pendingValue / 100).toFixed(2)}</p>
        </div>
      </div>

      {loading ? (
        <div className="flex justify-center py-8"><Loader2 className="w-8 h-8 animate-spin text-purple-400" /></div>
      ) : sponsorships.length === 0 ? (
        <p className="text-gray-400 text-center py-8">No sponsorships yet. Track your brand deals here!</p>
      ) : (
        <div className="space-y-3">
          {sponsorships.map(sponsor => (
            <div key={sponsor.id} className="bg-[#1a1a2e] rounded-xl p-4 border border-gray-700">
              <div className="flex items-start justify-between mb-2">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-lg bg-cyan-500/20 flex items-center justify-center">
                    <Building2 className="w-5 h-5 text-cyan-400" />
                  </div>
                  <div>
                    <h4 className="text-white font-bold">{sponsor.brand_name}</h4>
                    <p className="text-green-400 font-semibold">${(sponsor.deal_value / 100).toFixed(2)}</p>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  {getStatusIcon(sponsor.status)}
                  <span className={`text-xs px-2 py-1 rounded capitalize ${
                    sponsor.status === 'active' ? 'bg-green-500/20 text-green-400' :
                    sponsor.status === 'pending' ? 'bg-yellow-500/20 text-yellow-400' :
                    sponsor.status === 'completed' ? 'bg-blue-500/20 text-blue-400' :
                    'bg-gray-500/20 text-gray-400'
                  }`}>{sponsor.status}</span>
                </div>
              </div>
              <p className="text-gray-400 text-sm mb-2">{sponsor.deliverables}</p>
              <div className="flex items-center gap-4 text-xs text-gray-500">
                <span className="flex items-center gap-1"><Calendar className="w-3 h-3" /> {new Date(sponsor.start_date).toLocaleDateString()} - {new Date(sponsor.end_date).toLocaleDateString()}</span>
              </div>
            </div>
          ))}
        </div>
      )}

      {showCreate && (
        <div className="fixed inset-0 bg-black/80 flex items-center justify-center z-50 p-4">
          <div className="bg-[#16213e] rounded-2xl p-6 w-full max-w-md border border-gray-700">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-xl font-bold text-white">Add Sponsorship</h3>
              <button onClick={() => setShowCreate(false)} className="text-gray-400 hover:text-white"><X className="w-6 h-6" /></button>
            </div>
            <div className="space-y-4">
              <input type="text" placeholder="Brand Name" value={form.brand_name} onChange={e => setForm({...form, brand_name: e.target.value})} className="w-full bg-[#1a1a2e] text-white px-4 py-3 rounded-lg border border-gray-700" />
              <input type="number" placeholder="Deal Value ($)" value={form.deal_value} onChange={e => setForm({...form, deal_value: parseInt(e.target.value) || 0})} className="w-full bg-[#1a1a2e] text-white px-4 py-3 rounded-lg border border-gray-700" />
              <div className="grid grid-cols-2 gap-4">
                <input type="date" value={form.start_date} onChange={e => setForm({...form, start_date: e.target.value})} className="w-full bg-[#1a1a2e] text-white px-4 py-3 rounded-lg border border-gray-700" />
                <input type="date" value={form.end_date} onChange={e => setForm({...form, end_date: e.target.value})} className="w-full bg-[#1a1a2e] text-white px-4 py-3 rounded-lg border border-gray-700" />
              </div>
              <textarea placeholder="Deliverables (e.g., 2 sponsored streams, logo placement)" value={form.deliverables} onChange={e => setForm({...form, deliverables: e.target.value})} className="w-full bg-[#1a1a2e] text-white px-4 py-3 rounded-lg border border-gray-700 h-20" />
              <button onClick={createSponsorship} disabled={saving || !form.brand_name} className="w-full bg-cyan-600 hover:bg-cyan-700 text-white py-3 rounded-lg font-semibold disabled:opacity-50">
                {saving ? 'Adding...' : 'Add Sponsorship'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
