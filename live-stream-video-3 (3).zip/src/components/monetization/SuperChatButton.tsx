import React, { useState } from 'react';
import { MessageSquare, DollarSign, X, Loader2, Sparkles } from 'lucide-react';
import { useAuth } from '@/contexts/AuthContext';
import { supabase } from '@/lib/supabase';

interface Props {
  streamerId: string;
  streamerName: string;
  streamId: string;
  onSuperChat?: (message: string, amount: number) => void;
}

const presetAmounts = [
  { amount: 2, color: '#3b82f6', label: '$2' },
  { amount: 5, color: '#22c55e', label: '$5' },
  { amount: 10, color: '#eab308', label: '$10' },
  { amount: 25, color: '#f97316', label: '$25' },
  { amount: 50, color: '#ef4444', label: '$50' },
];

export function SuperChatButton({ streamerId, streamerName, streamId, onSuperChat }: Props) {
  const { user } = useAuth();
  const [showModal, setShowModal] = useState(false);
  const [amount, setAmount] = useState(5);
  const [message, setMessage] = useState('');
  const [loading, setLoading] = useState(false);

  const handleSend = async () => {
    if (!user || !message.trim()) return;
    setLoading(true);
    try {
      const { data, error } = await supabase.functions.invoke('monetization-manager', {
        body: {
          action: 'create_superchat',
          amount: amount * 100,
          streamer_id: streamerId,
          stream_id: streamId,
          sender_id: user.user_id,
          sender_name: user.display_name || user.username,
          message: message.trim()
        }
      });
      if (data?.url) {
        window.location.href = data.url;
      } else if (data?.success) {
        onSuperChat?.(message, amount);
        setShowModal(false);
        setMessage('');
      }
    } catch (err) {
      console.error('Super chat error:', err);
    }
    setLoading(false);
  };

  if (!user) return null;

  const selectedPreset = presetAmounts.find(p => p.amount === amount) || presetAmounts[1];

  return (
    <>
      <button
        onClick={() => setShowModal(true)}
        className="bg-gradient-to-r from-yellow-500 to-orange-500 text-white px-3 py-1.5 rounded-full font-semibold hover:shadow-lg transition-all flex items-center gap-1.5 text-sm"
      >
        <Sparkles className="w-4 h-4" /> Super Chat
      </button>

      {showModal && (
        <div className="fixed inset-0 bg-black/80 flex items-center justify-center z-50 p-4">
          <div className="bg-[#16213e] rounded-2xl p-6 w-full max-w-md border border-gray-700">
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-xl font-bold text-white flex items-center gap-2">
                <Sparkles className="w-6 h-6 text-yellow-500" /> Send Super Chat
              </h2>
              <button onClick={() => setShowModal(false)} className="text-gray-400 hover:text-white">
                <X className="w-6 h-6" />
              </button>
            </div>

            <p className="text-gray-400 mb-4">Your message will be highlighted in {streamerName}'s chat!</p>

            <div className="flex gap-2 mb-4 flex-wrap">
              {presetAmounts.map((preset) => (
                <button
                  key={preset.amount}
                  onClick={() => setAmount(preset.amount)}
                  className={`px-4 py-2 rounded-lg font-bold transition-all ${
                    amount === preset.amount
                      ? 'text-white scale-105'
                      : 'bg-[#1a1a2e] text-gray-300 hover:bg-gray-700'
                  }`}
                  style={amount === preset.amount ? { backgroundColor: preset.color } : {}}
                >
                  {preset.label}
                </button>
              ))}
            </div>

            <div className="mb-4 p-4 rounded-xl" style={{ backgroundColor: selectedPreset.color + '20', borderLeft: `4px solid ${selectedPreset.color}` }}>
              <textarea
                placeholder="Type your message..."
                value={message}
                onChange={(e) => setMessage(e.target.value)}
                maxLength={200}
                className="w-full bg-transparent text-white placeholder-gray-400 outline-none resize-none h-20"
              />
              <p className="text-gray-400 text-xs text-right">{message.length}/200</p>
            </div>

            <button
              onClick={handleSend}
              disabled={loading || !message.trim()}
              className="w-full bg-gradient-to-r from-yellow-500 to-orange-500 text-white py-3 rounded-lg font-bold hover:shadow-lg transition-all disabled:opacity-50 flex items-center justify-center gap-2"
            >
              {loading ? <Loader2 className="w-5 h-5 animate-spin" /> : <DollarSign className="w-5 h-5" />}
              Send ${amount} Super Chat
            </button>
          </div>
        </div>
      )}
    </>
  );
}
