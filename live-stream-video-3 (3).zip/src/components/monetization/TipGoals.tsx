import React, { useState, useEffect } from 'react';
import { Target, Plus, Trash2, X, Loader2, Trophy, DollarSign } from 'lucide-react';
import { supabase } from '@/lib/supabase';

interface TipGoal {
  id: string;
  title: string;
  target_amount: number;
  current_amount: number;
  reward_description: string;
  is_active: boolean;
  completed: boolean;
}

interface Props {
  userId: string;
}

export function TipGoals({ userId }: Props) {
  const [goals, setGoals] = useState<TipGoal[]>([]);
  const [showCreate, setShowCreate] = useState(false);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [form, setForm] = useState({ title: '', target_amount: 100, reward_description: '' });

  useEffect(() => {
    loadGoals();
  }, [userId]);

  const loadGoals = async () => {
    setLoading(true);
    const { data } = await supabase.functions.invoke('monetization-manager', {
      body: { action: 'get_tip_goals', streamer_id: userId }
    });
    if (data?.goals && Array.isArray(data.goals)) setGoals(data.goals);
    setLoading(false);
  };

  const createGoal = async () => {
    setSaving(true);
    await supabase.functions.invoke('monetization-manager', {
      body: { action: 'create_tip_goal', streamer_id: userId, ...form, target_amount: form.target_amount * 100 }
    });
    setShowCreate(false);
    setForm({ title: '', target_amount: 100, reward_description: '' });
    loadGoals();
    setSaving(false);
  };

  const toggleGoal = async (id: string, active: boolean) => {
    await supabase.functions.invoke('monetization-manager', {
      body: { action: 'toggle_tip_goal', goal_id: id, is_active: active }
    });
    setGoals(prev => prev.map(g => g.id === id ? { ...g, is_active: active } : g));
  };

  const deleteGoal = async (id: string) => {
    if (!confirm('Delete this goal?')) return;
    await supabase.functions.invoke('monetization-manager', { body: { action: 'delete_tip_goal', goal_id: id } });
    setGoals(prev => prev.filter(g => g.id !== id));
  };

  return (
    <div className="bg-[#16213e] rounded-2xl p-6 border border-gray-800">
      <div className="flex items-center justify-between mb-6">
        <h3 className="text-xl font-bold text-white flex items-center gap-2">
          <Target className="w-5 h-5 text-orange-400" /> Tip Goals
        </h3>
        <button onClick={() => setShowCreate(true)} className="bg-orange-600 hover:bg-orange-700 text-white px-4 py-2 rounded-lg flex items-center gap-2">
          <Plus className="w-4 h-4" /> New Goal
        </button>
      </div>

      {loading ? (
        <div className="flex justify-center py-8"><Loader2 className="w-8 h-8 animate-spin text-purple-400" /></div>
      ) : goals.length === 0 ? (
        <p className="text-gray-400 text-center py-8">No tip goals yet. Create goals to motivate your viewers!</p>
      ) : (
        <div className="space-y-4">
          {goals.map(goal => {
            const progress = Math.min((goal.current_amount / goal.target_amount) * 100, 100);
            return (
              <div key={goal.id} className={`bg-[#1a1a2e] rounded-xl p-4 border ${goal.completed ? 'border-green-500/50' : goal.is_active ? 'border-orange-500/50' : 'border-gray-700'}`}>
                <div className="flex items-start justify-between mb-3">
                  <div className="flex items-center gap-2">
                    {goal.completed ? <Trophy className="w-5 h-5 text-yellow-400" /> : <Target className="w-5 h-5 text-orange-400" />}
                    <h4 className="text-white font-bold">{goal.title}</h4>
                    {goal.is_active && !goal.completed && <span className="bg-orange-500/20 text-orange-400 text-xs px-2 py-0.5 rounded">ACTIVE</span>}
                    {goal.completed && <span className="bg-green-500/20 text-green-400 text-xs px-2 py-0.5 rounded">COMPLETED</span>}
                  </div>
                  <div className="flex items-center gap-2">
                    {!goal.completed && (
                      <button onClick={() => toggleGoal(goal.id, !goal.is_active)} className={`text-sm px-3 py-1 rounded ${goal.is_active ? 'bg-gray-600 text-gray-300' : 'bg-orange-600 text-white'}`}>
                        {goal.is_active ? 'Deactivate' : 'Activate'}
                      </button>
                    )}
                    <button onClick={() => deleteGoal(goal.id)} className="text-red-400 hover:text-red-300 p-1"><Trash2 className="w-4 h-4" /></button>
                  </div>
                </div>
                <p className="text-gray-400 text-sm mb-3">{goal.reward_description}</p>
                <div className="relative h-4 bg-gray-700 rounded-full overflow-hidden mb-2">
                  <div className="absolute inset-y-0 left-0 bg-gradient-to-r from-orange-500 to-yellow-500 rounded-full transition-all" style={{ width: `${progress}%` }} />
                </div>
                <div className="flex justify-between text-sm">
                  <span className="text-green-400">${(goal.current_amount / 100).toFixed(2)}</span>
                  <span className="text-gray-400">${(goal.target_amount / 100).toFixed(2)}</span>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {showCreate && (
        <div className="fixed inset-0 bg-black/80 flex items-center justify-center z-50 p-4">
          <div className="bg-[#16213e] rounded-2xl p-6 w-full max-w-md border border-gray-700">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-xl font-bold text-white">Create Tip Goal</h3>
              <button onClick={() => setShowCreate(false)} className="text-gray-400 hover:text-white"><X className="w-6 h-6" /></button>
            </div>
            <div className="space-y-4">
              <input type="text" placeholder="Goal Title (e.g., New Microphone)" value={form.title} onChange={e => setForm({...form, title: e.target.value})} className="w-full bg-[#1a1a2e] text-white px-4 py-3 rounded-lg border border-gray-700" />
              <div>
                <label className="text-gray-400 text-sm block mb-1">Target Amount ($)</label>
                <input type="number" value={form.target_amount} onChange={e => setForm({...form, target_amount: parseInt(e.target.value) || 0})} className="w-full bg-[#1a1a2e] text-white px-4 py-3 rounded-lg border border-gray-700" />
              </div>
              <textarea placeholder="What will you do when goal is reached?" value={form.reward_description} onChange={e => setForm({...form, reward_description: e.target.value})} className="w-full bg-[#1a1a2e] text-white px-4 py-3 rounded-lg border border-gray-700 h-20" />
              <button onClick={createGoal} disabled={saving || !form.title || form.target_amount <= 0} className="w-full bg-orange-600 hover:bg-orange-700 text-white py-3 rounded-lg font-semibold disabled:opacity-50">
                {saving ? 'Creating...' : 'Create Goal'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
