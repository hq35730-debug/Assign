import React, { useState, useEffect } from 'react';
import { MessageSquare, DollarSign, Palette, Clock, Save, Loader2 } from 'lucide-react';
import { supabase } from '@/lib/supabase';

interface SuperChatTier {
  minAmount: number;
  maxAmount: number;
  color: string;
  duration: number;
  highlight: boolean;
}

interface Props {
  userId: string;
}

export function SuperChatSettings({ userId }: Props) {
  const [enabled, setEnabled] = useState(true);
  const [minAmount, setMinAmount] = useState(1);
  const [saving, setSaving] = useState(false);
  const [tiers] = useState<SuperChatTier[]>([
    { minAmount: 1, maxAmount: 4, color: '#3b82f6', duration: 30, highlight: false },
    { minAmount: 5, maxAmount: 9, color: '#22c55e', duration: 60, highlight: true },
    { minAmount: 10, maxAmount: 24, color: '#eab308', duration: 120, highlight: true },
    { minAmount: 25, maxAmount: 49, color: '#f97316', duration: 300, highlight: true },
    { minAmount: 50, maxAmount: 100, color: '#ef4444', duration: 600, highlight: true },
  ]);
  const [stats, setStats] = useState({ total: 0, count: 0, topAmount: 0 });

  useEffect(() => {
    loadStats();
  }, [userId]);

  const loadStats = async () => {
    const { data } = await supabase.functions.invoke('monetization-manager', {
      body: { action: 'get_superchat_stats', streamer_id: userId }
    });
    if (data) setStats(data);
  };

  const saveSettings = async () => {
    setSaving(true);
    await supabase.functions.invoke('monetization-manager', {
      body: { action: 'update_superchat_settings', streamer_id: userId, enabled, minAmount }
    });
    setSaving(false);
  };

  return (
    <div className="bg-[#16213e] rounded-2xl p-6 border border-gray-800">
      <div className="flex items-center justify-between mb-6">
        <h3 className="text-xl font-bold text-white flex items-center gap-2">
          <MessageSquare className="w-5 h-5 text-yellow-400" /> Super Chats
        </h3>
        <label className="flex items-center gap-2 cursor-pointer">
          <span className="text-gray-400 text-sm">Enabled</span>
          <div className={`w-12 h-6 rounded-full transition-colors ${enabled ? 'bg-green-500' : 'bg-gray-600'}`} onClick={() => setEnabled(!enabled)}>
            <div className={`w-5 h-5 bg-white rounded-full mt-0.5 transition-transform ${enabled ? 'translate-x-6' : 'translate-x-0.5'}`} />
          </div>
        </label>
      </div>

      <div className="grid grid-cols-3 gap-4 mb-6">
        <div className="bg-[#1a1a2e] rounded-xl p-4 text-center">
          <DollarSign className="w-6 h-6 text-green-400 mx-auto mb-2" />
          <p className="text-2xl font-bold text-white">${(stats.total / 100).toFixed(2)}</p>
          <p className="text-gray-400 text-sm">Total Earned</p>
        </div>
        <div className="bg-[#1a1a2e] rounded-xl p-4 text-center">
          <MessageSquare className="w-6 h-6 text-yellow-400 mx-auto mb-2" />
          <p className="text-2xl font-bold text-white">{stats.count}</p>
          <p className="text-gray-400 text-sm">Super Chats</p>
        </div>
        <div className="bg-[#1a1a2e] rounded-xl p-4 text-center">
          <DollarSign className="w-6 h-6 text-purple-400 mx-auto mb-2" />
          <p className="text-2xl font-bold text-white">${(stats.topAmount / 100).toFixed(2)}</p>
          <p className="text-gray-400 text-sm">Highest</p>
        </div>
      </div>

      <div className="space-y-3">
        <p className="text-gray-400 text-sm font-medium">Super Chat Tiers</p>
        {tiers.map((tier, i) => (
          <div key={i} className="flex items-center gap-3 p-3 rounded-lg" style={{ backgroundColor: tier.color + '20', borderLeft: `4px solid ${tier.color}` }}>
            <div className="flex-1">
              <p className="text-white font-medium">${tier.minAmount} - ${tier.maxAmount}</p>
              <p className="text-gray-400 text-xs flex items-center gap-2">
                <Clock className="w-3 h-3" /> Pinned for {tier.duration}s
              </p>
            </div>
            <div className="w-4 h-4 rounded" style={{ backgroundColor: tier.color }} />
          </div>
        ))}
      </div>

      <button onClick={saveSettings} disabled={saving} className="mt-4 w-full bg-purple-600 hover:bg-purple-700 text-white py-3 rounded-lg font-semibold flex items-center justify-center gap-2 disabled:opacity-50">
        {saving ? <Loader2 className="w-4 h-4 animate-spin" /> : <Save className="w-4 h-4" />}
        Save Settings
      </button>
    </div>
  );
}
