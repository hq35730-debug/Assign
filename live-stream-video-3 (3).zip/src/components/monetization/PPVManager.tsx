import React, { useState, useEffect } from 'react';
import { Ticket, Plus, Calendar, DollarSign, Users, Clock, Edit2, Trash2, X, Loader2 } from 'lucide-react';
import { supabase } from '@/lib/supabase';

interface PPVEvent {
  id: string;
  title: string;
  description: string;
  price: number;
  scheduled_at: string;
  duration_minutes: number;
  ticket_count: number;
  max_tickets: number;
  status: 'upcoming' | 'live' | 'ended';
}

interface Props {
  userId: string;
}

export function PPVManager({ userId }: Props) {
  const [events, setEvents] = useState<PPVEvent[]>([]);
  const [showCreate, setShowCreate] = useState(false);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [form, setForm] = useState({ title: '', description: '', price: 999, scheduled_at: '', duration_minutes: 60, max_tickets: 100 });

  useEffect(() => {
    loadEvents();
  }, [userId]);

  const loadEvents = async () => {
    setLoading(true);
    const { data } = await supabase.functions.invoke('monetization-manager', {
      body: { action: 'get_ppv_events', streamer_id: userId }
    });
    if (data?.events && Array.isArray(data.events)) setEvents(data.events);
    setLoading(false);
  };

  const createEvent = async () => {
    setSaving(true);
    await supabase.functions.invoke('monetization-manager', {
      body: { action: 'create_ppv_event', streamer_id: userId, ...form }
    });
    setShowCreate(false);
    setForm({ title: '', description: '', price: 999, scheduled_at: '', duration_minutes: 60, max_tickets: 100 });
    loadEvents();
    setSaving(false);
  };

  const deleteEvent = async (id: string) => {
    if (!confirm('Delete this PPV event?')) return;
    await supabase.functions.invoke('monetization-manager', {
      body: { action: 'delete_ppv_event', event_id: id }
    });
    setEvents(prev => prev.filter(e => e.id !== id));
  };

  const totalRevenue = events.reduce((sum, e) => sum + (e.price * e.ticket_count), 0);

  return (
    <div className="bg-[#16213e] rounded-2xl p-6 border border-gray-800">
      <div className="flex items-center justify-between mb-6">
        <h3 className="text-xl font-bold text-white flex items-center gap-2">
          <Ticket className="w-5 h-5 text-pink-400" /> Pay-Per-View Events
        </h3>
        <button onClick={() => setShowCreate(true)} className="bg-pink-600 hover:bg-pink-700 text-white px-4 py-2 rounded-lg flex items-center gap-2">
          <Plus className="w-4 h-4" /> Create Event
        </button>
      </div>

      <div className="grid grid-cols-2 gap-4 mb-6">
        <div className="bg-[#1a1a2e] rounded-xl p-4">
          <p className="text-gray-400 text-sm">Total Revenue</p>
          <p className="text-2xl font-bold text-green-400">${(totalRevenue / 100).toFixed(2)}</p>
        </div>
        <div className="bg-[#1a1a2e] rounded-xl p-4">
          <p className="text-gray-400 text-sm">Total Tickets Sold</p>
          <p className="text-2xl font-bold text-white">{events.reduce((sum, e) => sum + e.ticket_count, 0)}</p>
        </div>
      </div>

      {loading ? (
        <div className="flex justify-center py-8"><Loader2 className="w-8 h-8 animate-spin text-purple-400" /></div>
      ) : events.length === 0 ? (
        <p className="text-gray-400 text-center py-8">No PPV events yet. Create your first exclusive stream!</p>
      ) : (
        <div className="space-y-3">
          {events.map(event => (
            <div key={event.id} className="bg-[#1a1a2e] rounded-xl p-4 border border-gray-700">
              <div className="flex items-start justify-between">
                <div className="flex-1">
                  <div className="flex items-center gap-2 mb-1">
                    <h4 className="text-white font-bold">{event.title}</h4>
                    <span className={`text-xs px-2 py-0.5 rounded ${event.status === 'live' ? 'bg-red-500 text-white' : event.status === 'upcoming' ? 'bg-blue-500/20 text-blue-400' : 'bg-gray-500/20 text-gray-400'}`}>
                      {event.status.toUpperCase()}
                    </span>
                  </div>
                  <p className="text-gray-400 text-sm mb-2">{event.description}</p>
                  <div className="flex items-center gap-4 text-sm">
                    <span className="text-green-400 flex items-center gap-1"><DollarSign className="w-4 h-4" />${(event.price / 100).toFixed(2)}</span>
                    <span className="text-gray-400 flex items-center gap-1"><Users className="w-4 h-4" />{event.ticket_count}/{event.max_tickets}</span>
                    <span className="text-gray-400 flex items-center gap-1"><Clock className="w-4 h-4" />{event.duration_minutes}min</span>
                  </div>
                </div>
                <button onClick={() => deleteEvent(event.id)} className="text-red-400 hover:text-red-300 p-2"><Trash2 className="w-4 h-4" /></button>
              </div>
            </div>
          ))}
        </div>
      )}

      {showCreate && (
        <div className="fixed inset-0 bg-black/80 flex items-center justify-center z-50 p-4">
          <div className="bg-[#16213e] rounded-2xl p-6 w-full max-w-md border border-gray-700">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-xl font-bold text-white">Create PPV Event</h3>
              <button onClick={() => setShowCreate(false)} className="text-gray-400 hover:text-white"><X className="w-6 h-6" /></button>
            </div>
            <div className="space-y-4">
              <input type="text" placeholder="Event Title" value={form.title} onChange={e => setForm({...form, title: e.target.value})} className="w-full bg-[#1a1a2e] text-white px-4 py-3 rounded-lg border border-gray-700" />
              <textarea placeholder="Description" value={form.description} onChange={e => setForm({...form, description: e.target.value})} className="w-full bg-[#1a1a2e] text-white px-4 py-3 rounded-lg border border-gray-700 h-20" />
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="text-gray-400 text-sm block mb-1">Price ($)</label>
                  <input type="number" value={form.price / 100} onChange={e => setForm({...form, price: Math.round(parseFloat(e.target.value) * 100)})} className="w-full bg-[#1a1a2e] text-white px-4 py-3 rounded-lg border border-gray-700" />
                </div>
                <div>
                  <label className="text-gray-400 text-sm block mb-1">Max Tickets</label>
                  <input type="number" value={form.max_tickets} onChange={e => setForm({...form, max_tickets: parseInt(e.target.value)})} className="w-full bg-[#1a1a2e] text-white px-4 py-3 rounded-lg border border-gray-700" />
                </div>
              </div>
              <input type="datetime-local" value={form.scheduled_at} onChange={e => setForm({...form, scheduled_at: e.target.value})} className="w-full bg-[#1a1a2e] text-white px-4 py-3 rounded-lg border border-gray-700" />
              <button onClick={createEvent} disabled={saving || !form.title} className="w-full bg-pink-600 hover:bg-pink-700 text-white py-3 rounded-lg font-semibold disabled:opacity-50">
                {saving ? 'Creating...' : 'Create Event'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
