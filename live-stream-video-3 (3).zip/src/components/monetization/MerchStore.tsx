import React, { useState, useEffect } from 'react';
import { ShoppingBag, Plus, Edit2, Trash2, X, Loader2, Package, DollarSign, ExternalLink } from 'lucide-react';
import { supabase } from '@/lib/supabase';

interface MerchItem {
  id: string;
  name: string;
  description: string;
  price: number;
  image_url: string;
  external_url: string;
  sold_count: number;
  is_active: boolean;
}

interface Props {
  userId: string;
}

export function MerchStore({ userId }: Props) {
  const [items, setItems] = useState<MerchItem[]>([]);
  const [showCreate, setShowCreate] = useState(false);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [form, setForm] = useState({ name: '', description: '', price: 2499, image_url: '', external_url: '' });

  useEffect(() => {
    loadItems();
  }, [userId]);

  const loadItems = async () => {
    setLoading(true);
    const { data } = await supabase.functions.invoke('monetization-manager', {
      body: { action: 'get_merch_items', streamer_id: userId }
    });
    if (data?.items && Array.isArray(data.items)) setItems(data.items);
    setLoading(false);
  };

  const createItem = async () => {
    setSaving(true);
    await supabase.functions.invoke('monetization-manager', {
      body: { action: 'create_merch_item', streamer_id: userId, ...form }
    });
    setShowCreate(false);
    setForm({ name: '', description: '', price: 2499, image_url: '', external_url: '' });
    loadItems();
    setSaving(false);
  };

  const toggleItem = async (id: string, active: boolean) => {
    await supabase.functions.invoke('monetization-manager', {
      body: { action: 'toggle_merch_item', item_id: id, is_active: active }
    });
    setItems(prev => prev.map(i => i.id === id ? { ...i, is_active: active } : i));
  };

  const deleteItem = async (id: string) => {
    if (!confirm('Delete this item?')) return;
    await supabase.functions.invoke('monetization-manager', { body: { action: 'delete_merch_item', item_id: id } });
    setItems(prev => prev.filter(i => i.id !== id));
  };

  const totalRevenue = items.reduce((sum, i) => sum + (i.price * i.sold_count), 0);

  return (
    <div className="bg-[#16213e] rounded-2xl p-6 border border-gray-800">
      <div className="flex items-center justify-between mb-6">
        <h3 className="text-xl font-bold text-white flex items-center gap-2">
          <ShoppingBag className="w-5 h-5 text-blue-400" /> Merchandise Store
        </h3>
        <button onClick={() => setShowCreate(true)} className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg flex items-center gap-2">
          <Plus className="w-4 h-4" /> Add Item
        </button>
      </div>

      <div className="grid grid-cols-2 gap-4 mb-6">
        <div className="bg-[#1a1a2e] rounded-xl p-4">
          <p className="text-gray-400 text-sm">Est. Revenue</p>
          <p className="text-2xl font-bold text-green-400">${(totalRevenue / 100).toFixed(2)}</p>
        </div>
        <div className="bg-[#1a1a2e] rounded-xl p-4">
          <p className="text-gray-400 text-sm">Items Sold</p>
          <p className="text-2xl font-bold text-white">{items.reduce((sum, i) => sum + i.sold_count, 0)}</p>
        </div>
      </div>

      {loading ? (
        <div className="flex justify-center py-8"><Loader2 className="w-8 h-8 animate-spin text-purple-400" /></div>
      ) : items.length === 0 ? (
        <p className="text-gray-400 text-center py-8">No merchandise yet. Add items to start selling!</p>
      ) : (
        <div className="grid grid-cols-2 gap-4">
          {items.map(item => (
            <div key={item.id} className={`bg-[#1a1a2e] rounded-xl overflow-hidden border ${item.is_active ? 'border-blue-500/30' : 'border-gray-700 opacity-60'}`}>
              <div className="aspect-square bg-gray-800 relative">
                {item.image_url ? (
                  <img src={item.image_url} alt={item.name} className="w-full h-full object-cover" />
                ) : (
                  <div className="w-full h-full flex items-center justify-center"><Package className="w-12 h-12 text-gray-600" /></div>
                )}
                <div className="absolute top-2 right-2 flex gap-1">
                  <button onClick={() => toggleItem(item.id, !item.is_active)} className={`p-1.5 rounded ${item.is_active ? 'bg-green-500' : 'bg-gray-600'}`}>
                    <Package className="w-3 h-3 text-white" />
                  </button>
                  <button onClick={() => deleteItem(item.id)} className="p-1.5 rounded bg-red-500"><Trash2 className="w-3 h-3 text-white" /></button>
                </div>
              </div>
              <div className="p-3">
                <h4 className="text-white font-semibold truncate">{item.name}</h4>
                <div className="flex items-center justify-between mt-1">
                  <span className="text-green-400 font-bold">${(item.price / 100).toFixed(2)}</span>
                  <span className="text-gray-400 text-sm">{item.sold_count} sold</span>
                </div>
                {item.external_url && (
                  <a href={item.external_url} target="_blank" rel="noopener noreferrer" className="text-blue-400 text-xs flex items-center gap-1 mt-2 hover:underline">
                    <ExternalLink className="w-3 h-3" /> View Store
                  </a>
                )}
              </div>
            </div>
          ))}
        </div>
      )}

      {showCreate && (
        <div className="fixed inset-0 bg-black/80 flex items-center justify-center z-50 p-4">
          <div className="bg-[#16213e] rounded-2xl p-6 w-full max-w-md border border-gray-700">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-xl font-bold text-white">Add Merchandise</h3>
              <button onClick={() => setShowCreate(false)} className="text-gray-400 hover:text-white"><X className="w-6 h-6" /></button>
            </div>
            <div className="space-y-4">
              <input type="text" placeholder="Item Name" value={form.name} onChange={e => setForm({...form, name: e.target.value})} className="w-full bg-[#1a1a2e] text-white px-4 py-3 rounded-lg border border-gray-700" />
              <textarea placeholder="Description" value={form.description} onChange={e => setForm({...form, description: e.target.value})} className="w-full bg-[#1a1a2e] text-white px-4 py-3 rounded-lg border border-gray-700 h-20" />
              <input type="number" placeholder="Price ($)" value={form.price / 100} onChange={e => setForm({...form, price: Math.round(parseFloat(e.target.value) * 100)})} className="w-full bg-[#1a1a2e] text-white px-4 py-3 rounded-lg border border-gray-700" />
              <input type="url" placeholder="Image URL" value={form.image_url} onChange={e => setForm({...form, image_url: e.target.value})} className="w-full bg-[#1a1a2e] text-white px-4 py-3 rounded-lg border border-gray-700" />
              <input type="url" placeholder="External Store URL" value={form.external_url} onChange={e => setForm({...form, external_url: e.target.value})} className="w-full bg-[#1a1a2e] text-white px-4 py-3 rounded-lg border border-gray-700" />
              <button onClick={createItem} disabled={saving || !form.name} className="w-full bg-blue-600 hover:bg-blue-700 text-white py-3 rounded-lg font-semibold disabled:opacity-50">
                {saving ? 'Adding...' : 'Add Item'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
