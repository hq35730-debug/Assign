import React, { useState, useEffect } from 'react';
import { Play, DollarSign, Eye, Clock, TrendingUp, BarChart3, Settings } from 'lucide-react';
import { supabase } from '@/lib/supabase';

interface AdStats {
  total_revenue: number;
  impressions: number;
  cpm: number;
  watch_hours: number;
  ad_breaks_run: number;
}

interface Props {
  userId: string;
}

export function AdRevenuePanel({ userId }: Props) {
  const [stats, setStats] = useState<AdStats>({ total_revenue: 0, impressions: 0, cpm: 250, watch_hours: 0, ad_breaks_run: 0 });
  const [adSettings, setAdSettings] = useState({ preroll: true, midroll: true, midroll_interval: 30, postroll: false });
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadStats();
  }, [userId]);

  const loadStats = async () => {
    setLoading(true);
    const { data } = await supabase.functions.invoke('monetization-manager', {
      body: { action: 'get_ad_stats', streamer_id: userId }
    });
    if (data?.stats) setStats(data.stats);
    if (data?.settings) setAdSettings(data.settings);
    setLoading(false);
  };

  const saveSettings = async () => {
    await supabase.functions.invoke('monetization-manager', {
      body: { action: 'update_ad_settings', streamer_id: userId, settings: adSettings }
    });
  };

  const estimatedMonthly = (stats.watch_hours * stats.cpm) / 1000;

  return (
    <div className="bg-[#16213e] rounded-2xl p-6 border border-gray-800">
      <h3 className="text-xl font-bold text-white mb-6 flex items-center gap-2">
        <Play className="w-5 h-5 text-green-400" /> Ad Revenue
      </h3>

      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
        <div className="bg-[#1a1a2e] rounded-xl p-4">
          <DollarSign className="w-6 h-6 text-green-400 mb-2" />
          <p className="text-2xl font-bold text-white">${(stats.total_revenue / 100).toFixed(2)}</p>
          <p className="text-gray-400 text-sm">Total Revenue</p>
        </div>
        <div className="bg-[#1a1a2e] rounded-xl p-4">
          <Eye className="w-6 h-6 text-blue-400 mb-2" />
          <p className="text-2xl font-bold text-white">{(stats.impressions / 1000).toFixed(1)}K</p>
          <p className="text-gray-400 text-sm">Impressions</p>
        </div>
        <div className="bg-[#1a1a2e] rounded-xl p-4">
          <Clock className="w-6 h-6 text-purple-400 mb-2" />
          <p className="text-2xl font-bold text-white">{stats.watch_hours.toFixed(0)}</p>
          <p className="text-gray-400 text-sm">Watch Hours</p>
        </div>
        <div className="bg-[#1a1a2e] rounded-xl p-4">
          <TrendingUp className="w-6 h-6 text-yellow-400 mb-2" />
          <p className="text-2xl font-bold text-white">${(stats.cpm / 100).toFixed(2)}</p>
          <p className="text-gray-400 text-sm">CPM Rate</p>
        </div>
      </div>

      <div className="bg-gradient-to-r from-green-900/30 to-emerald-900/30 rounded-xl p-4 mb-6 border border-green-500/30">
        <div className="flex items-center justify-between">
          <div>
            <p className="text-gray-300 text-sm">Estimated Monthly Revenue</p>
            <p className="text-3xl font-bold text-green-400">${estimatedMonthly.toFixed(2)}</p>
          </div>
          <BarChart3 className="w-12 h-12 text-green-400/50" />
        </div>
      </div>

      <div className="space-y-4">
        <h4 className="text-white font-semibold flex items-center gap-2"><Settings className="w-4 h-4" /> Ad Settings</h4>
        
        <div className="flex items-center justify-between p-3 bg-[#1a1a2e] rounded-lg">
          <div>
            <p className="text-white font-medium">Pre-roll Ads</p>
            <p className="text-gray-400 text-sm">Show ad before stream starts</p>
          </div>
          <button onClick={() => { setAdSettings(s => ({...s, preroll: !s.preroll})); saveSettings(); }} className={`w-12 h-6 rounded-full transition-colors ${adSettings.preroll ? 'bg-green-500' : 'bg-gray-600'}`}>
            <div className={`w-5 h-5 bg-white rounded-full mt-0.5 transition-transform ${adSettings.preroll ? 'translate-x-6' : 'translate-x-0.5'}`} />
          </button>
        </div>

        <div className="flex items-center justify-between p-3 bg-[#1a1a2e] rounded-lg">
          <div>
            <p className="text-white font-medium">Mid-roll Ads</p>
            <p className="text-gray-400 text-sm">Every {adSettings.midroll_interval} minutes</p>
          </div>
          <button onClick={() => { setAdSettings(s => ({...s, midroll: !s.midroll})); saveSettings(); }} className={`w-12 h-6 rounded-full transition-colors ${adSettings.midroll ? 'bg-green-500' : 'bg-gray-600'}`}>
            <div className={`w-5 h-5 bg-white rounded-full mt-0.5 transition-transform ${adSettings.midroll ? 'translate-x-6' : 'translate-x-0.5'}`} />
          </button>
        </div>

        <div className="flex items-center justify-between p-3 bg-[#1a1a2e] rounded-lg">
          <div>
            <p className="text-white font-medium">Post-roll Ads</p>
            <p className="text-gray-400 text-sm">Show ad after stream ends</p>
          </div>
          <button onClick={() => { setAdSettings(s => ({...s, postroll: !s.postroll})); saveSettings(); }} className={`w-12 h-6 rounded-full transition-colors ${adSettings.postroll ? 'bg-green-500' : 'bg-gray-600'}`}>
            <div className={`w-5 h-5 bg-white rounded-full mt-0.5 transition-transform ${adSettings.postroll ? 'translate-x-6' : 'translate-x-0.5'}`} />
          </button>
        </div>
      </div>
    </div>
  );
}
