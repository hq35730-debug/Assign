import React, { useState, useEffect } from 'react';
import { Star, Edit2, Plus, Check, X, Loader2 } from 'lucide-react';
import { supabase } from '@/lib/supabase';

interface Tier {
  id: string;
  name: string;
  price: number;
  benefits: string[];
  badge_color: string;
  subscriber_count: number;
}

interface Props {
  userId: string;
}

export function SubscriptionTiers({ userId }: Props) {
  const [tiers, setTiers] = useState<Tier[]>([
    { id: '1', name: 'Tier 1', price: 499, benefits: ['Ad-free viewing', 'Subscriber badge', 'Custom emotes'], badge_color: '#9333ea', subscriber_count: 0 },
    { id: '2', name: 'Tier 2', price: 999, benefits: ['All Tier 1 benefits', 'Priority chat', 'Exclusive VODs'], badge_color: '#ec4899', subscriber_count: 0 },
    { id: '3', name: 'Tier 3', price: 2499, benefits: ['All Tier 2 benefits', 'Monthly shoutout', 'Discord access', 'Private streams'], badge_color: '#f59e0b', subscriber_count: 0 },
  ]);
  const [editing, setEditing] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    loadTiers();
  }, [userId]);

  const loadTiers = async () => {
    const { data } = await supabase.functions.invoke('monetization-manager', {
      body: { action: 'get_tiers', streamer_id: userId }
    });
    if (data?.tiers && Array.isArray(data.tiers)) setTiers(data.tiers);
  };

  const saveTier = async (tier: Tier) => {
    setLoading(true);
    await supabase.functions.invoke('monetization-manager', {
      body: { action: 'update_tier', streamer_id: userId, tier }
    });
    setEditing(null);
    setLoading(false);
  };

  return (
    <div className="bg-[#16213e] rounded-2xl p-6 border border-gray-800">
      <h3 className="text-xl font-bold text-white mb-4 flex items-center gap-2">
        <Star className="w-5 h-5 text-purple-400" /> Subscription Tiers
      </h3>
      <div className="grid gap-4">
        {tiers.map((tier) => (
          <div key={tier.id} className="bg-[#1a1a2e] rounded-xl p-4 border border-gray-700">
            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-full flex items-center justify-center" style={{ backgroundColor: tier.badge_color }}>
                  <Star className="w-5 h-5 text-white fill-white" />
                </div>
                <div>
                  <h4 className="text-white font-bold">{tier.name}</h4>
                  <p className="text-green-400 font-semibold">${(tier.price / 100).toFixed(2)}/mo</p>
                </div>
              </div>
              <div className="text-right">
                <p className="text-gray-400 text-sm">{tier.subscriber_count} subscribers</p>
                <p className="text-green-400 text-sm">${((tier.price * tier.subscriber_count) / 100).toFixed(2)}/mo</p>
              </div>
            </div>
            <div className="space-y-1">
              {tier.benefits.map((b, i) => (
                <div key={i} className="flex items-center gap-2 text-gray-300 text-sm">
                  <Check className="w-4 h-4 text-green-400" /> {b}
                </div>
              ))}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
