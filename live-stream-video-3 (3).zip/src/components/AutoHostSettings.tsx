import React, { useState, useEffect } from 'react';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/contexts/AuthContext';
import { Monitor, Plus, Trash2, GripVertical, Search, X, ChevronUp, ChevronDown } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Switch } from '@/components/ui/switch';

interface AutoHostItem {
  id: string;
  target_channel_id: string;
  target_channel_name: string;
  target_avatar_url?: string;
  priority: number;
}

interface AutoHostSettingsData {
  enabled: boolean;
  host_only_when_offline: boolean;
}

export function AutoHostSettings() {
  const { user } = useAuth();
  const [list, setList] = useState<AutoHostItem[]>([]);
  const [settings, setSettings] = useState<AutoHostSettingsData>({ enabled: true, host_only_when_offline: true });
  const [showSearch, setShowSearch] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [searchResults, setSearchResults] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (user) loadAutoHostList();
  }, [user]);

  const loadAutoHostList = async () => {
    const { data } = await supabase.functions.invoke('raid-manager', {
      body: { action: 'get_auto_host_list', channel_id: user?.user_id }
    });
    setList(data?.list || []);
    setSettings(data?.settings || { enabled: true, host_only_when_offline: true });
    setLoading(false);
  };

  const searchChannels = async (query: string) => {
    if (!query.trim()) { setSearchResults([]); return; }
    const { data } = await supabase.from('profiles').select('user_id, username, display_name, avatar_url')
      .or(`username.ilike.%${query}%,display_name.ilike.%${query}%`).neq('user_id', user?.user_id).limit(10);
    const existingIds = new Set(list.map(i => i.target_channel_id));
    setSearchResults((data || []).filter(p => !existingIds.has(p.user_id)));
  };

  useEffect(() => {
    const timer = setTimeout(() => searchChannels(searchQuery), 300);
    return () => clearTimeout(timer);
  }, [searchQuery]);

  const addChannel = async (channel: any) => {
    await supabase.functions.invoke('raid-manager', {
      body: {
        action: 'add_to_auto_host', channel_id: user?.user_id, channel_name: user?.display_name || user?.username,
        target_channel_id: channel.user_id, target_channel_name: channel.display_name || channel.username, target_avatar_url: channel.avatar_url
      }
    });
    loadAutoHostList();
    setShowSearch(false);
    setSearchQuery('');
  };

  const removeChannel = async (targetId: string) => {
    await supabase.functions.invoke('raid-manager', {
      body: { action: 'remove_from_auto_host', channel_id: user?.user_id, target_channel_id: targetId }
    });
    setList(prev => prev.filter(i => i.target_channel_id !== targetId));
  };

  const moveItem = async (index: number, direction: 'up' | 'down') => {
    const newIndex = direction === 'up' ? index - 1 : index + 1;
    if (newIndex < 0 || newIndex >= list.length) return;
    const newList = [...list];
    [newList[index], newList[newIndex]] = [newList[newIndex], newList[index]];
    setList(newList);
    await supabase.functions.invoke('raid-manager', {
      body: { action: 'reorder_auto_host', channel_id: user?.user_id, ordered_ids: newList.map(i => i.id) }
    });
  };

  const updateSettings = async (key: keyof AutoHostSettingsData, value: boolean) => {
    const newSettings = { ...settings, [key]: value };
    setSettings(newSettings);
    await supabase.functions.invoke('raid-manager', {
      body: { action: 'update_auto_host_settings', channel_id: user?.user_id, ...newSettings }
    });
  };

  if (loading) return <div className="text-gray-400 text-center py-4">Loading...</div>;

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <Monitor className="w-5 h-5 text-purple-400" />
          <span className="text-white font-semibold">Auto-Host</span>
        </div>
        <Switch checked={settings.enabled} onCheckedChange={(v) => updateSettings('enabled', v)} />
      </div>
      
      <p className="text-gray-400 text-sm">Automatically host channels from your list when you go offline.</p>

      <div className="flex items-center justify-between py-2">
        <span className="text-gray-300 text-sm">Only host when offline</span>
        <Switch checked={settings.host_only_when_offline} onCheckedChange={(v) => updateSettings('host_only_when_offline', v)} />
      </div>

      <div className="border-t border-gray-700 pt-4">
        <div className="flex items-center justify-between mb-3">
          <h3 className="text-white font-medium">Priority List ({list.length})</h3>
          <Button size="sm" onClick={() => setShowSearch(true)} className="bg-purple-600 hover:bg-purple-700">
            <Plus className="w-4 h-4 mr-1" /> Add Channel
          </Button>
        </div>

        {showSearch && (
          <div className="bg-[#1a1a2e] rounded-lg p-3 mb-3 border border-purple-500/50">
            <div className="flex items-center gap-2 mb-2">
              <Search className="w-4 h-4 text-gray-400" />
              <input type="text" value={searchQuery} onChange={(e) => setSearchQuery(e.target.value)} placeholder="Search channels..."
                className="flex-1 bg-transparent text-white outline-none text-sm" autoFocus />
              <button onClick={() => { setShowSearch(false); setSearchQuery(''); }}><X className="w-4 h-4 text-gray-400 hover:text-white" /></button>
            </div>
            {searchResults.length > 0 && (
              <div className="space-y-1 max-h-40 overflow-y-auto">
                {searchResults.map(ch => (
                  <button key={ch.user_id} onClick={() => addChannel(ch)}
                    className="w-full flex items-center gap-2 p-2 rounded hover:bg-purple-600/20 transition-colors">
                    <div className="w-8 h-8 rounded-full bg-gradient-to-br from-purple-500 to-pink-500 flex items-center justify-center overflow-hidden">
                      {ch.avatar_url ? <img src={ch.avatar_url} className="w-full h-full object-cover" /> : <span className="text-white text-xs">{(ch.display_name || ch.username)[0]}</span>}
                    </div>
                    <span className="text-white text-sm">{ch.display_name || ch.username}</span>
                  </button>
                ))}
              </div>
            )}
          </div>
        )}

        {list.length === 0 ? (
          <p className="text-gray-500 text-sm text-center py-4">No channels in your auto-host list</p>
        ) : (
          <div className="space-y-2">
            {list.map((item, idx) => (
              <div key={item.id} className="flex items-center gap-3 bg-[#1a1a2e] rounded-lg p-3 border border-gray-700">
                <div className="flex flex-col gap-0.5">
                  <button onClick={() => moveItem(idx, 'up')} disabled={idx === 0} className="text-gray-500 hover:text-white disabled:opacity-30"><ChevronUp className="w-4 h-4" /></button>
                  <button onClick={() => moveItem(idx, 'down')} disabled={idx === list.length - 1} className="text-gray-500 hover:text-white disabled:opacity-30"><ChevronDown className="w-4 h-4" /></button>
                </div>
                <span className="text-purple-400 font-bold text-sm w-6">#{idx + 1}</span>
                <div className="w-10 h-10 rounded-full bg-gradient-to-br from-purple-500 to-pink-500 flex items-center justify-center overflow-hidden">
                  {item.target_avatar_url ? <img src={item.target_avatar_url} className="w-full h-full object-cover" /> : <span className="text-white">{item.target_channel_name[0]}</span>}
                </div>
                <span className="flex-1 text-white font-medium">{item.target_channel_name}</span>
                <button onClick={() => removeChannel(item.target_channel_id)} className="text-gray-500 hover:text-red-400 transition-colors"><Trash2 className="w-4 h-4" /></button>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
