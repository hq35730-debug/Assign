import React, { useState } from 'react';
import { Rocket, Target, Users, Clock, DollarSign, Globe, Zap, ChevronDown, ChevronUp, MapPin } from 'lucide-react';
import { Dialog, DialogContent, DialogTitle } from '@/components/ui/dialog';
import { allCountries, getRegions, getCountriesByRegion } from '@/data/countries';

interface SponsorPromotionModalProps {
  isOpen: boolean;
  onClose: () => void;
  contentType: 'stream' | 'clip' | 'vod' | 'profile';
  contentId: string;
  contentTitle: string;
  onSubmit: (promotion: PromotionConfig) => void;
}

export interface PromotionConfig {
  budget: number;
  duration: number;
  targetAudience: string[];
  targetCountries: string[];
  placement: string[];
  objective: string;
}

const budgetOptions = [
  { amount: 10, reach: '500-1K', label: 'Starter' },
  { amount: 25, reach: '2K-5K', label: 'Basic' },
  { amount: 50, reach: '5K-10K', label: 'Standard' },
  { amount: 100, reach: '15K-25K', label: 'Pro' },
  { amount: 250, reach: '40K-60K', label: 'Premium' },
  { amount: 500, reach: '100K+', label: 'Elite' },
];

const audiences = ['Gaming', 'Music', 'Art', 'IRL', 'Sports', 'Tech', 'Education', 'Cooking'];
const placements = ['Homepage Featured', 'Category Top', 'Search Results', 'Recommended', 'Push Notifications'];

export const SponsorPromotionModal: React.FC<SponsorPromotionModalProps> = ({ isOpen, onClose, contentTitle, onSubmit }) => {
  const [config, setConfig] = useState<PromotionConfig>({
    budget: 25, duration: 24, targetAudience: [], targetCountries: [], placement: ['Homepage Featured'], objective: 'views',
  });
  const [showCountries, setShowCountries] = useState(false);
  const [expandedRegion, setExpandedRegion] = useState<string | null>(null);

  const toggleAudience = (a: string) => setConfig(prev => ({ ...prev, targetAudience: prev.targetAudience.includes(a) ? prev.targetAudience.filter(x => x !== a) : [...prev.targetAudience, a] }));
  const togglePlacement = (p: string) => setConfig(prev => ({ ...prev, placement: prev.placement.includes(p) ? prev.placement.filter(x => x !== p) : [...prev.placement, p] }));
  const toggleCountry = (code: string) => setConfig(prev => ({ ...prev, targetCountries: prev.targetCountries.includes(code) ? prev.targetCountries.filter(x => x !== code) : [...prev.targetCountries, code] }));
  const selectAllRegion = (region: string) => {
    const regionCodes = getCountriesByRegion(region).map(c => c.code);
    const allSelected = regionCodes.every(c => config.targetCountries.includes(c));
    setConfig(prev => ({ ...prev, targetCountries: allSelected ? prev.targetCountries.filter(c => !regionCodes.includes(c)) : [...new Set([...prev.targetCountries, ...regionCodes])] }));
  };

  const selectedBudget = budgetOptions.find(b => b.amount === config.budget);
  const regions = getRegions();

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="bg-gradient-to-br from-[#16213e] to-[#1a1a2e] border-purple-500/30 max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogTitle className="flex items-center gap-3 text-white text-xl font-bold">
          <div className="p-2 bg-gradient-to-r from-yellow-500 to-orange-500 rounded-lg"><Rocket className="w-6 h-6" /></div>
          Sponsor Promotion
        </DialogTitle>
        <p className="text-gray-400 text-sm mb-4">Boost "{contentTitle}" to reach viewers in 107 countries</p>
        <div className="space-y-5">
          <div>
            <label className="text-gray-300 text-sm mb-2 flex items-center gap-2"><DollarSign className="w-4 h-4 text-green-400" /> Budget</label>
            <div className="grid grid-cols-3 gap-2">
              {budgetOptions.map(b => (
                <button key={b.amount} onClick={() => setConfig(prev => ({ ...prev, budget: b.amount }))} className={`p-3 rounded-xl border-2 transition-all ${config.budget === b.amount ? 'border-yellow-500 bg-yellow-500/10' : 'border-gray-700 hover:border-gray-600'}`}>
                  <div className="text-white font-bold">${b.amount}</div>
                  <div className="text-xs text-gray-400">{b.reach}</div>
                  <div className="text-xs text-yellow-400">{b.label}</div>
                </button>
              ))}
            </div>
          </div>
          <div>
            <label className="text-gray-300 text-sm mb-2 flex items-center gap-2"><Clock className="w-4 h-4 text-blue-400" /> Duration</label>
            <div className="flex gap-2">
              {[12, 24, 48, 72, 168].map(h => (
                <button key={h} onClick={() => setConfig(prev => ({ ...prev, duration: h }))} className={`flex-1 py-2 rounded-lg text-sm ${config.duration === h ? 'bg-blue-600 text-white' : 'bg-gray-700 text-gray-300'}`}>
                  {h < 24 ? `${h}h` : `${h / 24}d`}
                </button>
              ))}
            </div>
          </div>
          <div>
            <label className="text-gray-300 text-sm mb-2 flex items-center gap-2"><Target className="w-4 h-4 text-pink-400" /> Target Audience</label>
            <div className="flex flex-wrap gap-2">
              {audiences.map(a => (
                <button key={a} onClick={() => toggleAudience(a)} className={`px-3 py-1 rounded-full text-sm ${config.targetAudience.includes(a) ? 'bg-pink-600 text-white' : 'bg-gray-700 text-gray-300'}`}>{a}</button>
              ))}
            </div>
          </div>
          <div>
            <button onClick={() => setShowCountries(!showCountries)} className="w-full flex items-center justify-between text-gray-300 text-sm mb-2">
              <span className="flex items-center gap-2"><MapPin className="w-4 h-4 text-green-400" /> Target Countries ({config.targetCountries.length || 'All'} selected)</span>
              {showCountries ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
            </button>
            {showCountries && (
              <div className="bg-gray-800/50 rounded-lg p-3 max-h-48 overflow-y-auto space-y-2">
                {regions.map(region => (
                  <div key={region}>
                    <button onClick={() => setExpandedRegion(expandedRegion === region ? null : region)} className="w-full flex items-center justify-between py-1 text-sm text-white hover:text-purple-400">
                      <span>{region} ({getCountriesByRegion(region).length})</span>
                      <div className="flex items-center gap-2">
                        <button onClick={(e) => { e.stopPropagation(); selectAllRegion(region); }} className="text-xs text-purple-400 hover:text-purple-300">Select All</button>
                        {expandedRegion === region ? <ChevronUp className="w-3 h-3" /> : <ChevronDown className="w-3 h-3" />}
                      </div>
                    </button>
                    {expandedRegion === region && (
                      <div className="grid grid-cols-2 gap-1 mt-1 pl-2">
                        {getCountriesByRegion(region).map(c => (
                          <button key={c.code} onClick={() => toggleCountry(c.code)} className={`flex items-center gap-1 px-2 py-1 rounded text-xs ${config.targetCountries.includes(c.code) ? 'bg-green-600/30 text-green-400' : 'text-gray-400 hover:text-white'}`}>
                            <span>{c.flag}</span><span className="truncate">{c.name}</span>
                          </button>
                        ))}
                      </div>
                    )}
                  </div>
                ))}
              </div>
            )}
          </div>
          <div>
            <label className="text-gray-300 text-sm mb-2 flex items-center gap-2"><Globe className="w-4 h-4 text-purple-400" /> Placements</label>
            <div className="space-y-1">
              {placements.map(p => (
                <button key={p} onClick={() => togglePlacement(p)} className={`w-full p-2 rounded-lg text-left flex items-center justify-between text-sm ${config.placement.includes(p) ? 'bg-purple-600/20 border border-purple-500' : 'bg-gray-700/50 border border-transparent'}`}>
                  <span className="text-white">{p}</span>
                  {config.placement.includes(p) && <Zap className="w-4 h-4 text-yellow-400" />}
                </button>
              ))}
            </div>
          </div>
          <div className="p-4 bg-gradient-to-r from-purple-900/50 to-pink-900/50 rounded-xl">
            <div className="flex items-center justify-between mb-2">
              <span className="text-gray-300">Estimated Reach</span>
              <span className="text-white font-bold flex items-center gap-1"><Users className="w-4 h-4" /> {selectedBudget?.reach}</span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-gray-300">Total Cost</span>
              <span className="text-2xl font-bold text-green-400">${config.budget}</span>
            </div>
          </div>
        </div>
        <div className="flex gap-3 mt-4">
          <button onClick={onClose} className="flex-1 py-3 bg-gray-700 hover:bg-gray-600 text-white rounded-lg font-semibold">Cancel</button>
          <button onClick={() => { onSubmit(config); onClose(); }} className="flex-1 py-3 bg-gradient-to-r from-yellow-500 to-orange-500 hover:from-yellow-600 hover:to-orange-600 text-white rounded-lg font-semibold flex items-center justify-center gap-2">
            <Rocket className="w-5 h-5" /> Launch
          </button>
        </div>
      </DialogContent>
    </Dialog>
  );
};
