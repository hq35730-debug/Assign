import React, { useState, useEffect } from 'react';
import { Rocket, TrendingUp, Eye, Users, DollarSign, Clock, BarChart3, Play, Pause, Trash2 } from 'lucide-react';
import { useAuth } from '@/contexts/AuthContext';

interface Promotion {
  id: string;
  contentTitle: string;
  contentType: string;
  budget: number;
  spent: number;
  reach: number;
  views: number;
  clicks: number;
  duration: number;
  startedAt: string;
  status: 'active' | 'paused' | 'completed' | 'pending';
}

export const PromotionDashboard: React.FC = () => {
  const { user } = useAuth();
  const [promotions, setPromotions] = useState<Promotion[]>([
    { id: '1', contentTitle: 'Epic Gaming Stream', contentType: 'stream', budget: 50, spent: 32, reach: 8500, views: 4200, clicks: 380, duration: 48, startedAt: '2024-12-04T10:00:00Z', status: 'active' },
    { id: '2', contentTitle: 'Best Moments Clip', contentType: 'clip', budget: 25, spent: 25, reach: 5200, views: 2800, clicks: 210, duration: 24, startedAt: '2024-12-03T14:00:00Z', status: 'completed' },
    { id: '3', contentTitle: 'Tutorial VOD', contentType: 'vod', budget: 100, spent: 45, reach: 12000, views: 6500, clicks: 520, duration: 72, startedAt: '2024-12-05T08:00:00Z', status: 'paused' },
  ]);

  const totalSpent = promotions.reduce((sum, p) => sum + p.spent, 0);
  const totalReach = promotions.reduce((sum, p) => sum + p.reach, 0);
  const totalViews = promotions.reduce((sum, p) => sum + p.views, 0);

  const toggleStatus = (id: string) => {
    setPromotions(prev => prev.map(p => {
      if (p.id === id && p.status !== 'completed') {
        return { ...p, status: p.status === 'active' ? 'paused' : 'active' };
      }
      return p;
    }));
  };

  const deletePromotion = (id: string) => {
    setPromotions(prev => prev.filter(p => p.id !== id));
  };

  const statusColors = {
    active: 'bg-green-500',
    paused: 'bg-yellow-500',
    completed: 'bg-gray-500',
    pending: 'bg-blue-500',
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-3 mb-6">
        <div className="p-3 bg-gradient-to-r from-yellow-500 to-orange-500 rounded-xl">
          <Rocket className="w-8 h-8 text-white" />
        </div>
        <div>
          <h2 className="text-2xl font-bold text-white">Promotion Dashboard</h2>
          <p className="text-gray-400">Track and manage your sponsored content</p>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <div className="bg-gradient-to-br from-green-600/20 to-green-800/20 p-4 rounded-xl border border-green-500/30">
          <DollarSign className="w-6 h-6 text-green-400 mb-2" />
          <p className="text-gray-400 text-sm">Total Spent</p>
          <p className="text-2xl font-bold text-white">${totalSpent}</p>
        </div>
        <div className="bg-gradient-to-br from-blue-600/20 to-blue-800/20 p-4 rounded-xl border border-blue-500/30">
          <Users className="w-6 h-6 text-blue-400 mb-2" />
          <p className="text-gray-400 text-sm">Total Reach</p>
          <p className="text-2xl font-bold text-white">{totalReach.toLocaleString()}</p>
        </div>
        <div className="bg-gradient-to-br from-purple-600/20 to-purple-800/20 p-4 rounded-xl border border-purple-500/30">
          <Eye className="w-6 h-6 text-purple-400 mb-2" />
          <p className="text-gray-400 text-sm">Total Views</p>
          <p className="text-2xl font-bold text-white">{totalViews.toLocaleString()}</p>
        </div>
        <div className="bg-gradient-to-br from-pink-600/20 to-pink-800/20 p-4 rounded-xl border border-pink-500/30">
          <TrendingUp className="w-6 h-6 text-pink-400 mb-2" />
          <p className="text-gray-400 text-sm">Avg CTR</p>
          <p className="text-2xl font-bold text-white">{((promotions.reduce((s, p) => s + p.clicks, 0) / totalViews) * 100).toFixed(1)}%</p>
        </div>
      </div>

      <div className="bg-[#16213e] rounded-xl border border-gray-800">
        <div className="p-4 border-b border-gray-800">
          <h3 className="text-white font-semibold flex items-center gap-2"><BarChart3 className="w-5 h-5" /> Active Promotions</h3>
        </div>
        <div className="divide-y divide-gray-800">
          {promotions.map(promo => (
            <div key={promo.id} className="p-4 flex items-center justify-between">
              <div className="flex items-center gap-4">
                <div className={`w-3 h-3 rounded-full ${statusColors[promo.status]}`} />
                <div>
                  <p className="text-white font-medium">{promo.contentTitle}</p>
                  <p className="text-gray-400 text-sm capitalize">{promo.contentType} • ${promo.spent}/${promo.budget} spent</p>
                </div>
              </div>
              <div className="flex items-center gap-6">
                <div className="text-right">
                  <p className="text-white">{promo.reach.toLocaleString()} reach</p>
                  <p className="text-gray-400 text-sm">{promo.views.toLocaleString()} views</p>
                </div>
                <div className="flex gap-2">
                  {promo.status !== 'completed' && (
                    <button onClick={() => toggleStatus(promo.id)} className={`p-2 rounded-lg ${promo.status === 'active' ? 'bg-yellow-600 hover:bg-yellow-700' : 'bg-green-600 hover:bg-green-700'}`}>
                      {promo.status === 'active' ? <Pause className="w-4 h-4 text-white" /> : <Play className="w-4 h-4 text-white" />}
                    </button>
                  )}
                  <button onClick={() => deletePromotion(promo.id)} className="p-2 bg-red-600 hover:bg-red-700 rounded-lg"><Trash2 className="w-4 h-4 text-white" /></button>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
