import React, { useEffect, useState } from 'react';
import { Gift, DollarSign, Sparkles } from 'lucide-react';

interface Donation {
  id: string;
  donor_username: string;
  donor_display_name?: string;
  amount: number;
  message?: string;
}

interface Props {
  donation: Donation | null;
  onComplete: () => void;
}

export function DonationAlert({ donation, onComplete }: Props) {
  const [visible, setVisible] = useState(false);
  const [animating, setAnimating] = useState(false);

  useEffect(() => {
    if (donation) {
      setVisible(true);
      setAnimating(true);
      
      const hideTimer = setTimeout(() => {
        setAnimating(false);
        setTimeout(() => {
          setVisible(false);
          onComplete();
        }, 500);
      }, 5000);

      return () => clearTimeout(hideTimer);
    }
  }, [donation, onComplete]);

  if (!visible || !donation) return null;

  const displayName = donation.donor_display_name || donation.donor_username;
  const amountColor = donation.amount >= 25 ? 'from-yellow-400 to-amber-500' : 
                      donation.amount >= 10 ? 'from-purple-400 to-pink-500' : 
                      donation.amount >= 5 ? 'from-blue-400 to-cyan-500' : 'from-green-400 to-emerald-500';

  return (
    <div className={`fixed top-24 left-1/2 -translate-x-1/2 z-50 transition-all duration-500 ${
      animating ? 'opacity-100 scale-100 translate-y-0' : 'opacity-0 scale-75 -translate-y-8'
    }`}>
      <div className={`bg-gradient-to-r ${amountColor} p-1 rounded-2xl shadow-2xl`}>
        <div className="bg-[#1a1a2e] rounded-xl p-6 min-w-[300px] max-w-[400px]">
          <div className="flex items-center justify-center gap-2 mb-3">
            <Sparkles className="w-6 h-6 text-yellow-400 animate-pulse" />
            <Gift className="w-8 h-8 text-yellow-400" />
            <Sparkles className="w-6 h-6 text-yellow-400 animate-pulse" />
          </div>
          
          <div className="text-center">
            <p className="text-white font-bold text-lg mb-1">{displayName}</p>
            <p className="text-gray-400 text-sm mb-3">sent a tip!</p>
            
            <div className={`inline-flex items-center gap-1 bg-gradient-to-r ${amountColor} text-white text-3xl font-bold px-6 py-2 rounded-full mb-3`}>
              <DollarSign className="w-7 h-7" />
              {donation.amount}
            </div>
            
            {donation.message && (
              <p className="text-gray-300 text-sm italic mt-2 px-4">"{donation.message}"</p>
            )}
          </div>
        </div>
      </div>
      
      <div className="absolute -top-2 -left-2 w-4 h-4 bg-yellow-400 rounded-full animate-ping" />
      <div className="absolute -top-2 -right-2 w-4 h-4 bg-pink-400 rounded-full animate-ping" style={{ animationDelay: '0.2s' }} />
      <div className="absolute -bottom-2 left-1/2 w-4 h-4 bg-purple-400 rounded-full animate-ping" style={{ animationDelay: '0.4s' }} />
    </div>
  );
}
