import { useState, useEffect } from 'react';
import { Gift, Heart, Star, Diamond, Crown, Rocket, Flame, Trophy, Sparkles, Flower, Coins, Loader2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/contexts/AuthContext';
import { triggerGift } from '@/components/gifts/GiftOverlay';
import { useToast } from '@/hooks/use-toast';

interface GiftType {
  id: string;
  name: string;
  icon: string;
  coin_cost: number;
  color: string;
  animation_type: string;
  animation_duration: number;
  particle_count: number;
  is_premium: boolean;
}

interface GiftButtonProps {
  streamerId: string;
  streamId?: string;
  streamerName?: string;
  onGiftSent?: (gift: GiftType, quantity: number) => void;
}

const iconMap: Record<string, any> = {
  heart: Heart, star: Star, diamond: Diamond, crown: Crown,
  rocket: Rocket, flame: Flame, trophy: Trophy, sparkles: Sparkles,
  flower: Flower, rainbow: Sparkles
};

export function GiftButton({ streamerId, streamId, streamerName, onGiftSent }: GiftButtonProps) {
  const { user } = useAuth();
  const { toast } = useToast();
  const [open, setOpen] = useState(false);
  const [gifts, setGifts] = useState<GiftType[]>([]);
  const [selected, setSelected] = useState<GiftType | null>(null);
  const [quantity, setQuantity] = useState(1);
  const [balance, setBalance] = useState(0);
  const [sending, setSending] = useState(false);
  const [message, setMessage] = useState('');
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (open) { loadGifts(); loadBalance(); }
  }, [open]);

  const loadGifts = async () => {
    setLoading(true);
    try {
      const { data } = await supabase.functions.invoke('gifts-manager', { body: { action: 'get_gift_types' } });
      const giftsData = Array.isArray(data?.gifts) ? data.gifts : [];
      setGifts(giftsData);
    } catch (err) {
      console.error('Error loading gifts:', err);
      setGifts([]);
    }
    setLoading(false);
  };

  const loadBalance = async () => {
    if (!user) return;
    try {
      const { data } = await supabase.functions.invoke('coins-manager', { body: { action: 'get_wallet', user_id: user.id } });
      if (data?.wallet) setBalance(data.wallet.coins_balance || 0);
    } catch (err) {
      console.error('Error loading balance:', err);
    }
  };

  const sendGift = async () => {
    if (!user || !selected) return;
    setSending(true);
    try {
      const { data, error } = await supabase.functions.invoke('gifts-manager', {
        body: { action: 'send_gift', sender_id: user.id, receiver_id: streamerId, stream_id: streamId, gift_type_id: selected.id, quantity, message }
      });
      if (!error && data?.success) {
        triggerGift(selected, quantity, user.email?.split('@')[0] || 'Anonymous');
        onGiftSent?.(selected, quantity);
        toast({ title: 'Gift Sent!', description: `You sent ${quantity}x ${selected.name} to ${streamerName || 'the streamer'}` });
        setBalance(prev => prev - (selected.coin_cost * quantity));
        setOpen(false);
        setSelected(null);
        setQuantity(1);
        setMessage('');
      } else {
        toast({ title: 'Error', description: error?.message || data?.error || 'Failed to send gift', variant: 'destructive' });
      }
    } catch (err) {
      toast({ title: 'Error', description: 'Failed to send gift', variant: 'destructive' });
    }
    setSending(false);
  };

  const totalCost = selected ? selected.coin_cost * quantity : 0;
  const canAfford = balance >= totalCost;
  const safeGifts = Array.isArray(gifts) ? gifts : [];

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button variant="outline" className="gap-2 bg-gradient-to-r from-pink-500/20 to-purple-500/20 border-pink-500/50 hover:border-pink-400">
          <Gift className="w-4 h-4 text-pink-400" /> Send Gift
        </Button>
      </DialogTrigger>
      <DialogContent className="max-w-lg">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Gift className="w-5 h-5 text-pink-400" /> Send a Gift
          </DialogTitle>
        </DialogHeader>
        <div className="flex items-center justify-between p-2 bg-yellow-500/10 rounded-lg border border-yellow-500/30">
          <span className="text-sm">Your Balance:</span>
          <div className="flex items-center gap-1 text-yellow-500 font-bold">
            <Coins className="w-4 h-4" />
            {balance.toLocaleString()}
          </div>
        </div>
        {loading ? (
          <div className="flex justify-center py-8"><Loader2 className="w-8 h-8 animate-spin text-purple-400" /></div>
        ) : safeGifts.length === 0 ? (
          <p className="text-center text-gray-500 py-8">No gifts available</p>
        ) : (
          <div className="grid grid-cols-5 gap-2 max-h-64 overflow-y-auto p-1">
            {safeGifts.map((gift) => {
              const Icon = iconMap[gift.icon] || Gift;
              const affordable = balance >= gift.coin_cost;
              return (
                <button key={gift.id} onClick={() => affordable && setSelected(gift)} disabled={!affordable}
                  className={`relative p-2 rounded-lg border-2 transition-all ${selected?.id === gift.id ? 'border-purple-500 bg-purple-500/20 scale-105' : affordable ? 'border-gray-700 hover:border-gray-500' : 'border-gray-800 opacity-40'}`}>
                  {gift.is_premium && <span className="absolute -top-1 -right-1 text-[8px] px-1 bg-yellow-500 text-black rounded font-bold">VIP</span>}
                  <Icon className="w-5 h-5 mx-auto mb-0.5" style={{ color: gift.color }} />
                  <p className="text-[9px] font-medium truncate">{gift.name}</p>
                  <p className="text-[9px] text-yellow-500 font-bold">{gift.coin_cost}</p>
                </button>
              );
            })}
          </div>
        )}
        {selected && (
          <div className="space-y-3 border-t pt-3">
            <div className="flex items-center gap-2 flex-wrap">
              <span className="text-sm">Qty:</span>
              {[1, 5, 10, 25, 50, 100].map(q => (
                <Button key={q} size="sm" variant={quantity === q ? 'default' : 'outline'} onClick={() => setQuantity(q)} disabled={balance < selected.coin_cost * q} className="h-7 px-2">{q}</Button>
              ))}
            </div>
            <Input placeholder="Add a message (optional)" value={message} onChange={e => setMessage(e.target.value)} maxLength={100} />
            <Button className="w-full bg-gradient-to-r from-pink-500 to-purple-500 hover:from-pink-600 hover:to-purple-600" onClick={sendGift} disabled={sending || !canAfford}>
              {sending ? <><Loader2 className="w-4 h-4 mr-2 animate-spin" /> Sending...</> : `Send ${quantity}x ${selected.name} (${totalCost.toLocaleString()} coins)`}
            </Button>
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
}
