import React, { useState, useEffect } from 'react';
import { 
  Sparkles, 
  Wifi, 
  Monitor, 
  Zap, 
  Settings, 
  CheckCircle, 
  AlertTriangle,
  Gauge,
  Film,
  Cpu,
  Signal,
  RefreshCw,
  Eye
} from 'lucide-react';

interface CrystalClearSettingsProps {
  isOpen: boolean;
  onClose: () => void;
  onApply: (settings: StreamQualitySettings) => void;
  currentSettings?: StreamQualitySettings;
}

export interface StreamQualitySettings {
  mode: 'auto' | 'crystal_clear' | 'balanced' | 'performance' | 'custom';
  resolution: string;
  bitrate: number;
  frameRate: number;
  encoder: 'x264' | 'nvenc' | 'quicksync' | 'auto';
  keyframeInterval: number;
  bFrames: number;
  preset: string;
  profile: string;
  adaptiveBitrate: boolean;
  lowLatency: boolean;
  hdr: boolean;
  noiseReduction: boolean;
  sharpening: boolean;
  colorEnhancement: boolean;
}

const qualityPresets = {
  crystal_clear: {
    label: 'Crystal Clear 4K',
    description: 'Maximum quality for high-end setups',
    resolution: '2160p',
    bitrate: 45000,
    frameRate: 60,
    encoder: 'auto' as const,
    keyframeInterval: 2,
    bFrames: 2,
    preset: 'quality',
    profile: 'high',
    icon: Sparkles,
    color: 'from-purple-500 to-pink-500'
  },
  ultra_hd: {
    label: 'Ultra HD 1440p',
    description: 'Perfect balance of quality and performance',
    resolution: '1440p',
    bitrate: 20000,
    frameRate: 60,
    encoder: 'auto' as const,
    keyframeInterval: 2,
    bFrames: 2,
    preset: 'quality',
    profile: 'high',
    icon: Monitor,
    color: 'from-blue-500 to-cyan-500'
  },
  full_hd: {
    label: 'Full HD 1080p',
    description: 'Recommended for most streamers',
    resolution: '1080p',
    bitrate: 8000,
    frameRate: 60,
    encoder: 'auto' as const,
    keyframeInterval: 2,
    bFrames: 2,
    preset: 'balanced',
    profile: 'high',
    icon: Film,
    color: 'from-green-500 to-emerald-500'
  },
  performance: {
    label: 'Performance Mode',
    description: 'Optimized for slower connections',
    resolution: '720p',
    bitrate: 4500,
    frameRate: 30,
    encoder: 'auto' as const,
    keyframeInterval: 2,
    bFrames: 0,
    preset: 'fast',
    profile: 'main',
    icon: Zap,
    color: 'from-yellow-500 to-orange-500'
  }
};

export const CrystalClearSettings: React.FC<CrystalClearSettingsProps> = ({
  isOpen,
  onClose,
  onApply,
  currentSettings
}) => {
  const [settings, setSettings] = useState<StreamQualitySettings>({
    mode: 'auto',
    resolution: '1080p',
    bitrate: 8000,
    frameRate: 60,
    encoder: 'auto',
    keyframeInterval: 2,
    bFrames: 2,
    preset: 'balanced',
    profile: 'high',
    adaptiveBitrate: true,
    lowLatency: true,
    hdr: false,
    noiseReduction: true,
    sharpening: true,
    colorEnhancement: false
  });

  const [networkSpeed, setNetworkSpeed] = useState<number | null>(null);
  const [testingNetwork, setTestingNetwork] = useState(false);
  const [recommendedPreset, setRecommendedPreset] = useState<string>('full_hd');
  const [showAdvanced, setShowAdvanced] = useState(false);

  useEffect(() => {
    if (currentSettings) {
      setSettings(currentSettings);
    }
  }, [currentSettings]);

  useEffect(() => {
    if (isOpen) {
      testNetworkSpeed();
    }
  }, [isOpen]);

  const testNetworkSpeed = async () => {
    setTestingNetwork(true);
    // Simulate network speed test
    await new Promise(resolve => setTimeout(resolve, 2000));
    const speed = Math.floor(Math.random() * 80 + 20); // 20-100 Mbps simulation
    setNetworkSpeed(speed);
    
    // Recommend preset based on speed
    if (speed >= 50) {
      setRecommendedPreset('crystal_clear');
    } else if (speed >= 25) {
      setRecommendedPreset('ultra_hd');
    } else if (speed >= 10) {
      setRecommendedPreset('full_hd');
    } else {
      setRecommendedPreset('performance');
    }
    
    setTestingNetwork(false);
  };

  const applyPreset = (presetKey: string) => {
    const preset = qualityPresets[presetKey as keyof typeof qualityPresets];
    if (preset) {
      setSettings(prev => ({
        ...prev,
        mode: presetKey === 'crystal_clear' ? 'crystal_clear' : 
              presetKey === 'performance' ? 'performance' : 'balanced',
        resolution: preset.resolution,
        bitrate: preset.bitrate,
        frameRate: preset.frameRate,
        encoder: preset.encoder,
        keyframeInterval: preset.keyframeInterval,
        bFrames: preset.bFrames,
        preset: preset.preset,
        profile: preset.profile
      }));
    }
  };

  const enableCrystalClear = () => {
    setSettings(prev => ({
      ...prev,
      mode: 'crystal_clear',
      resolution: '2160p',
      bitrate: 45000,
      frameRate: 60,
      encoder: 'auto',
      keyframeInterval: 2,
      bFrames: 2,
      preset: 'quality',
      profile: 'high',
      adaptiveBitrate: true,
      noiseReduction: true,
      sharpening: true,
      colorEnhancement: true,
      hdr: true
    }));
  };

  const getNetworkQualityLabel = () => {
    if (!networkSpeed) return { label: 'Unknown', color: 'text-gray-400' };
    if (networkSpeed >= 50) return { label: 'Excellent', color: 'text-green-400' };
    if (networkSpeed >= 25) return { label: 'Good', color: 'text-blue-400' };
    if (networkSpeed >= 10) return { label: 'Fair', color: 'text-yellow-400' };
    return { label: 'Poor', color: 'text-red-400' };
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black/80 flex items-center justify-center z-50 p-4">
      <div className="bg-gradient-to-br from-[#16213e] to-[#1a1a2e] rounded-2xl w-full max-w-3xl max-h-[90vh] overflow-y-auto border border-purple-500/30 shadow-2xl">
        {/* Header */}
        <div className="sticky top-0 bg-gradient-to-r from-purple-600/20 to-pink-600/20 p-6 border-b border-purple-500/30 backdrop-blur-sm">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="p-3 bg-gradient-to-r from-purple-600 to-pink-600 rounded-xl">
                <Sparkles className="w-6 h-6 text-white" />
              </div>
              <div>
                <h2 className="text-xl font-bold text-white">Crystal Clear Streaming</h2>
                <p className="text-gray-400 text-sm">Automatic quality optimization for the best viewing experience</p>
              </div>
            </div>
            <button onClick={onClose} className="text-gray-400 hover:text-white text-2xl">&times;</button>
          </div>
        </div>

        <div className="p-6 space-y-6">
          {/* Network Speed Test */}
          <div className="bg-[#1a1a2e] rounded-xl p-4 border border-gray-700">
            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center gap-2">
                <Signal className="w-5 h-5 text-blue-400" />
                <span className="text-white font-medium">Network Analysis</span>
              </div>
              <button 
                onClick={testNetworkSpeed}
                disabled={testingNetwork}
                className="flex items-center gap-2 text-sm text-purple-400 hover:text-purple-300 disabled:opacity-50"
              >
                <RefreshCw className={`w-4 h-4 ${testingNetwork ? 'animate-spin' : ''}`} />
                {testingNetwork ? 'Testing...' : 'Retest'}
              </button>
            </div>
            
            {testingNetwork ? (
              <div className="flex items-center gap-3 py-4">
                <div className="w-6 h-6 border-2 border-purple-500 border-t-transparent rounded-full animate-spin" />
                <span className="text-gray-400">Analyzing your connection...</span>
              </div>
            ) : networkSpeed ? (
              <div className="grid grid-cols-3 gap-4">
                <div className="text-center">
                  <p className="text-2xl font-bold text-white">{networkSpeed}</p>
                  <p className="text-gray-500 text-sm">Mbps Upload</p>
                </div>
                <div className="text-center">
                  <p className={`text-lg font-semibold ${getNetworkQualityLabel().color}`}>
                    {getNetworkQualityLabel().label}
                  </p>
                  <p className="text-gray-500 text-sm">Connection Quality</p>
                </div>
                <div className="text-center">
                  <p className="text-lg font-semibold text-purple-400">
                    {qualityPresets[recommendedPreset as keyof typeof qualityPresets]?.label.split(' ')[0]}
                  </p>
                  <p className="text-gray-500 text-sm">Recommended</p>
                </div>
              </div>
            ) : null}
          </div>

          {/* One-Click Crystal Clear */}
          <button
            onClick={enableCrystalClear}
            className={`w-full p-6 rounded-xl border-2 transition-all ${
              settings.mode === 'crystal_clear' 
                ? 'border-purple-500 bg-gradient-to-r from-purple-600/20 to-pink-600/20' 
                : 'border-gray-700 hover:border-purple-500/50 bg-[#1a1a2e]'
            }`}
          >
            <div className="flex items-center gap-4">
              <div className="p-4 bg-gradient-to-r from-purple-600 to-pink-600 rounded-xl">
                <Sparkles className="w-8 h-8 text-white" />
              </div>
              <div className="flex-1 text-left">
                <div className="flex items-center gap-2">
                  <h3 className="text-xl font-bold text-white">Enable Crystal Clear Mode</h3>
                  {settings.mode === 'crystal_clear' && (
                    <CheckCircle className="w-5 h-5 text-green-400" />
                  )}
                </div>
                <p className="text-gray-400 mt-1">
                  4K @ 60fps • 45,000 kbps • HDR • Noise Reduction • AI Enhancement
                </p>
              </div>
              <div className="text-right">
                <span className="text-purple-400 font-semibold">Automatic</span>
                <p className="text-gray-500 text-sm">Quality Optimization</p>
              </div>
            </div>
          </button>

          {/* Quality Presets */}
          <div>
            <h3 className="text-white font-semibold mb-3 flex items-center gap-2">
              <Settings className="w-5 h-5 text-gray-400" />
              Quality Presets
            </h3>
            <div className="grid grid-cols-2 gap-3">
              {Object.entries(qualityPresets).map(([key, preset]) => {
                const Icon = preset.icon;
                const isRecommended = key === recommendedPreset;
                const isSelected = settings.resolution === preset.resolution && 
                                   settings.bitrate === preset.bitrate;
                
                return (
                  <button
                    key={key}
                    onClick={() => applyPreset(key)}
                    className={`p-4 rounded-xl border transition-all text-left relative ${
                      isSelected 
                        ? 'border-purple-500 bg-purple-600/10' 
                        : 'border-gray-700 hover:border-gray-600 bg-[#1a1a2e]'
                    }`}
                  >
                    {isRecommended && (
                      <span className="absolute -top-2 -right-2 bg-green-500 text-white text-xs px-2 py-0.5 rounded-full">
                        Recommended
                      </span>
                    )}
                    <div className="flex items-center gap-3 mb-2">
                      <div className={`p-2 rounded-lg bg-gradient-to-r ${preset.color}`}>
                        <Icon className="w-5 h-5 text-white" />
                      </div>
                      <div>
                        <h4 className="text-white font-medium">{preset.label}</h4>
                        <p className="text-gray-500 text-xs">{preset.description}</p>
                      </div>
                    </div>
                    <div className="flex items-center gap-3 text-xs text-gray-400">
                      <span>{preset.resolution}</span>
                      <span>•</span>
                      <span>{preset.frameRate}fps</span>
                      <span>•</span>
                      <span>{(preset.bitrate / 1000).toFixed(0)}k</span>
                    </div>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Enhancement Features */}
          <div className="bg-[#1a1a2e] rounded-xl p-4 border border-gray-700">
            <h3 className="text-white font-semibold mb-4 flex items-center gap-2">
              <Eye className="w-5 h-5 text-purple-400" />
              Visual Enhancements
            </h3>
            <div className="grid grid-cols-2 gap-3">
              {[
                { key: 'adaptiveBitrate', label: 'Adaptive Bitrate', desc: 'Auto-adjust to network conditions', icon: Wifi },
                { key: 'noiseReduction', label: 'Noise Reduction', desc: 'Remove video grain', icon: Sparkles },
                { key: 'sharpening', label: 'Smart Sharpening', desc: 'Enhance edge clarity', icon: Monitor },
                { key: 'colorEnhancement', label: 'Color Enhancement', desc: 'Vivid, accurate colors', icon: Film },
                { key: 'lowLatency', label: 'Low Latency', desc: 'Minimal stream delay', icon: Zap },
                { key: 'hdr', label: 'HDR Support', desc: 'High dynamic range', icon: Sparkles }
              ].map(({ key, label, desc, icon: Icon }) => (
                <button
                  key={key}
                  onClick={() => setSettings(prev => ({ ...prev, [key]: !prev[key as keyof StreamQualitySettings] }))}
                  className={`p-3 rounded-lg border transition-all text-left flex items-center gap-3 ${
                    settings[key as keyof StreamQualitySettings]
                      ? 'border-purple-500 bg-purple-600/10'
                      : 'border-gray-700 hover:border-gray-600'
                  }`}
                >
                  <div className={`p-2 rounded-lg ${settings[key as keyof StreamQualitySettings] ? 'bg-purple-600' : 'bg-gray-700'}`}>
                    <Icon className="w-4 h-4 text-white" />
                  </div>
                  <div>
                    <p className="text-white text-sm font-medium">{label}</p>
                    <p className="text-gray-500 text-xs">{desc}</p>
                  </div>
                </button>
              ))}
            </div>
          </div>

          {/* Advanced Settings Toggle */}
          <button
            onClick={() => setShowAdvanced(!showAdvanced)}
            className="w-full flex items-center justify-between p-3 bg-[#1a1a2e] rounded-lg border border-gray-700 text-gray-400 hover:text-white"
          >
            <span className="flex items-center gap-2">
              <Cpu className="w-5 h-5" />
              Advanced Encoder Settings
            </span>
            <span>{showAdvanced ? '−' : '+'}</span>
          </button>

          {showAdvanced && (
            <div className="bg-[#1a1a2e] rounded-xl p-4 border border-gray-700 space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="text-gray-400 text-sm mb-2 block">Encoder</label>
                  <select
                    value={settings.encoder}
                    onChange={(e) => setSettings(prev => ({ ...prev, encoder: e.target.value as any }))}
                    className="w-full bg-[#16213e] text-white px-3 py-2 rounded-lg border border-gray-700"
                  >
                    <option value="auto">Auto Detect</option>
                    <option value="x264">x264 (CPU)</option>
                    <option value="nvenc">NVENC (NVIDIA)</option>
                    <option value="quicksync">QuickSync (Intel)</option>
                  </select>
                </div>
                <div>
                  <label className="text-gray-400 text-sm mb-2 block">Encoder Preset</label>
                  <select
                    value={settings.preset}
                    onChange={(e) => setSettings(prev => ({ ...prev, preset: e.target.value }))}
                    className="w-full bg-[#16213e] text-white px-3 py-2 rounded-lg border border-gray-700"
                  >
                    <option value="ultrafast">Ultra Fast</option>
                    <option value="superfast">Super Fast</option>
                    <option value="veryfast">Very Fast</option>
                    <option value="faster">Faster</option>
                    <option value="fast">Fast</option>
                    <option value="balanced">Balanced</option>
                    <option value="quality">Quality</option>
                    <option value="max_quality">Max Quality</option>
                  </select>
                </div>
                <div>
                  <label className="text-gray-400 text-sm mb-2 block">Profile</label>
                  <select
                    value={settings.profile}
                    onChange={(e) => setSettings(prev => ({ ...prev, profile: e.target.value }))}
                    className="w-full bg-[#16213e] text-white px-3 py-2 rounded-lg border border-gray-700"
                  >
                    <option value="baseline">Baseline</option>
                    <option value="main">Main</option>
                    <option value="high">High</option>
                  </select>
                </div>
                <div>
                  <label className="text-gray-400 text-sm mb-2 block">Keyframe Interval (sec)</label>
                  <input
                    type="number"
                    value={settings.keyframeInterval}
                    onChange={(e) => setSettings(prev => ({ ...prev, keyframeInterval: parseInt(e.target.value) || 2 }))}
                    min={1}
                    max={10}
                    className="w-full bg-[#16213e] text-white px-3 py-2 rounded-lg border border-gray-700"
                  />
                </div>
              </div>

              <div>
                <label className="text-gray-400 text-sm mb-2 flex items-center gap-2">
                  <Gauge className="w-4 h-4" />
                  Custom Bitrate: {settings.bitrate.toLocaleString()} kbps
                </label>
                <input
                  type="range"
                  min={1000}
                  max={50000}
                  step={500}
                  value={settings.bitrate}
                  onChange={(e) => setSettings(prev => ({ ...prev, bitrate: parseInt(e.target.value) }))}
                  className="w-full accent-purple-500"
                />
                <div className="flex justify-between text-xs text-gray-500 mt-1">
                  <span>1 Mbps</span>
                  <span>50 Mbps</span>
                </div>
              </div>
            </div>
          )}

          {/* Current Settings Summary */}
          <div className="bg-gradient-to-r from-purple-900/30 to-pink-900/30 rounded-xl p-4 border border-purple-500/30">
            <h4 className="text-white font-medium mb-2">Current Configuration</h4>
            <div className="flex flex-wrap gap-2">
              <span className="px-3 py-1 bg-purple-600/30 text-purple-300 rounded-full text-sm">
                {settings.resolution}
              </span>
              <span className="px-3 py-1 bg-blue-600/30 text-blue-300 rounded-full text-sm">
                {settings.frameRate} FPS
              </span>
              <span className="px-3 py-1 bg-green-600/30 text-green-300 rounded-full text-sm">
                {(settings.bitrate / 1000).toFixed(1)} Mbps
              </span>
              <span className="px-3 py-1 bg-yellow-600/30 text-yellow-300 rounded-full text-sm">
                {settings.encoder.toUpperCase()}
              </span>
              {settings.hdr && (
                <span className="px-3 py-1 bg-pink-600/30 text-pink-300 rounded-full text-sm">HDR</span>
              )}
              {settings.lowLatency && (
                <span className="px-3 py-1 bg-cyan-600/30 text-cyan-300 rounded-full text-sm">Low Latency</span>
              )}
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="sticky bottom-0 bg-[#16213e] border-t border-gray-700 p-4 flex gap-3">
          <button
            onClick={onClose}
            className="flex-1 py-3 bg-gray-700 hover:bg-gray-600 text-white rounded-lg font-semibold transition-colors"
          >
            Cancel
          </button>
          <button
            onClick={() => { onApply(settings); onClose(); }}
            className="flex-1 py-3 bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-500 hover:to-pink-500 text-white rounded-lg font-semibold transition-colors"
          >
            Apply Settings
          </button>
        </div>
      </div>
    </div>
  );
};
