
import React from 'react';
import { Play, Eye, Clock } from 'lucide-react';

export interface VOD {
  id: string;
  stream_id: string;
  user_id: string;
  streamer_name: string;
  title: string;
  description: string;
  thumbnail_url: string;
  video_url: string;
  duration: number;
  views: number;
  category: string;
  started_at: string;
  ended_at: string;
  created_at: string;
  is_public: boolean;
}

interface VODCardProps {
  vod: VOD;
  onClick: () => void;
  showActions?: boolean;
  onEdit?: () => void;
  onDelete?: () => void;
}

const formatDuration = (seconds: number): string => {
  const hrs = Math.floor(seconds / 3600);
  const mins = Math.floor((seconds % 3600) / 60);
  const secs = seconds % 60;
  if (hrs > 0) return `${hrs}:${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  return `${mins}:${secs.toString().padStart(2, '0')}`;
};

const timeAgo = (date: string): string => {
  const seconds = Math.floor((Date.now() - new Date(date).getTime()) / 1000);
  if (seconds < 3600) return `${Math.floor(seconds / 60)}m ago`;
  if (seconds < 86400) return `${Math.floor(seconds / 3600)}h ago`;
  return `${Math.floor(seconds / 86400)}d ago`;
};

export const VODCard: React.FC<VODCardProps> = ({ vod, onClick, showActions, onEdit, onDelete }) => {
  return (
    <div className="group cursor-pointer" onClick={onClick}>
      <div className="relative aspect-video rounded-xl overflow-hidden bg-gray-800">
        <img src={vod.thumbnail_url || 'https://d64gsuwffb70l.cloudfront.net/6927ca8790687cc18bcac914_1764565042610_75ffd34f.webp'} alt={vod.title} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300" />
        <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
          <div className="w-16 h-16 rounded-full bg-purple-600/90 flex items-center justify-center">
            <Play className="w-8 h-8 text-white ml-1" fill="white" />
          </div>
        </div>
        <div className="absolute bottom-2 right-2 bg-black/80 text-white text-xs px-2 py-1 rounded flex items-center gap-1">
          <Clock className="w-3 h-3" /> {formatDuration(vod.duration)}
        </div>
        {vod.category && <div className="absolute top-2 left-2 bg-purple-600/90 text-white text-xs px-2 py-1 rounded">{vod.category}</div>}
      </div>
      <div className="mt-2">
        <h3 className="text-white font-medium truncate group-hover:text-purple-400 transition-colors">{vod.title}</h3>
        <p className="text-gray-400 text-sm">{vod.streamer_name}</p>
        <div className="flex items-center gap-3 text-gray-500 text-xs mt-1">
          <span className="flex items-center gap-1"><Eye className="w-3 h-3" /> {vod.views.toLocaleString()}</span>
          <span>{timeAgo(vod.created_at)}</span>
        </div>
      </div>
      {showActions && (
        <div className="flex gap-2 mt-2" onClick={e => e.stopPropagation()}>
          <button onClick={onEdit} className="text-xs bg-gray-700 hover:bg-gray-600 text-white px-3 py-1 rounded">Edit</button>
          <button onClick={onDelete} className="text-xs bg-red-600/20 hover:bg-red-600/40 text-red-400 px-3 py-1 rounded">Delete</button>
        </div>
      )}
    </div>
  );
};
