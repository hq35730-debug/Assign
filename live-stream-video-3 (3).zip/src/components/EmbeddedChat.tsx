import React, { useState, useEffect, useRef } from 'react';
import { Send, MessageSquare, X, Minimize2, Maximize2, Move, Settings, Smile, Lock, Eye, EyeOff } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/contexts/AuthContext';
import { ChatMessageItem } from './ChatMessageItem';
import { VIPChatBadge } from './wallet/VIPChatBadge';

export interface ChatMsg {
  id: string;
  stream_id: string;
  user_id: string;
  username: string;
  display_name: string;
  message: string;
  badge: string | null;
  is_deleted: boolean;
  created_at: string;
  is_highlighted?: boolean;
  vip_tier_level?: number;
  vip_badge_color?: string;
}

interface EmbeddedChatProps {
  streamId: string;
  streamerId: string;
  isStreamer?: boolean;
  subOnlyMode?: boolean;
  onToggleSubOnly?: () => void;
  isVisible: boolean;
  onToggleVisibility: () => void;
}

const EMOTES = [
  { code: ':hype:', emoji: '🔥' },
  { code: ':love:', emoji: '💜' },
  { code: ':gg:', emoji: '🎮' },
  { code: ':pog:', emoji: '😮' },
  { code: ':lul:', emoji: '😂' },
  { code: ':sad:', emoji: '😢' },
];

type ChatPosition = 'bottom-right' | 'bottom-left' | 'top-right' | 'top-left';

export const EmbeddedChat: React.FC<EmbeddedChatProps> = ({
  streamId,
  streamerId,
  isStreamer = false,
  subOnlyMode = false,
  onToggleSubOnly,
  isVisible,
  onToggleVisibility,
}) => {
  const { user } = useAuth();
  const [messages, setMessages] = useState<ChatMsg[]>([]);
  const [newMessage, setNewMessage] = useState('');
  const [isMod, setIsMod] = useState(false);
  const [isSubscribed, setIsSubscribed] = useState(false);
  const [banError, setBanError] = useState<string | null>(null);
  const [showEmotes, setShowEmotes] = useState(false);
  const [userVip, setUserVip] = useState<any>(null);
  const [isMinimized, setIsMinimized] = useState(false);
  const [position, setPosition] = useState<ChatPosition>('bottom-right');
  const [opacity, setOpacity] = useState(80);
  const [showSettings, setShowSettings] = useState(false);
  const [chatSize, setChatSize] = useState<'small' | 'medium' | 'large'>('medium');
  const [showInputOnly, setShowInputOnly] = useState(false);
  const chatRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    loadMessages();
    checkModStatus();
    checkSubscription();
    loadUserVIP();
    const channel = supabase
      .channel(`embedded-chat:${streamId}`)
      .on('postgres_changes', { event: 'INSERT', schema: 'public', table: 'chat_messages', filter: `stream_id=eq.${streamId}` },
        (payload) => { if (!payload.new.is_deleted) setMessages(prev => [...prev.slice(-49), payload.new as ChatMsg]); }
      )
      .on('postgres_changes', { event: 'UPDATE', schema: 'public', table: 'chat_messages', filter: `stream_id=eq.${streamId}` },
        (payload) => { if (payload.new.is_deleted) setMessages(prev => prev.filter(m => m.id !== payload.new.id)); }
      )
      .subscribe();
    return () => { supabase.removeChannel(channel); };
  }, [streamId]);

  useEffect(() => {
    if (chatRef.current) chatRef.current.scrollTop = chatRef.current.scrollHeight;
  }, [messages]);

  const loadMessages = async () => {
    const { data } = await supabase.functions.invoke('chat-manager', { body: { action: 'get_messages', stream_id: streamId } });
    if (data?.messages) setMessages(data.messages.slice(-50));
  };

  const loadUserVIP = async () => {
    if (!user) return;
    const { data } = await supabase.functions.invoke('vip-manager', { body: { action: 'get_user_vip', user_id: user.user_id } });
    if (data?.status?.current_tier) setUserVip(data.status.current_tier);
  };

  const checkModStatus = async () => {
    if (!user) return;
    const { data } = await supabase.from('stream_moderators').select('id').eq('stream_id', streamId).eq('user_id', user.user_id).single();
    setIsMod(!!data);
  };

  const checkSubscription = async () => {
    if (!user) return;
    const { data } = await supabase.functions.invoke('subscription-manager', {
      body: { action: 'check_subscription', subscriber_id: user.user_id, streamer_id: streamerId }
    });
    setIsSubscribed(data?.subscribed || false);
  };

  const sendMessage = async () => {
    if (!newMessage.trim() || !user) return;
    if (subOnlyMode && !isSubscribed && !isStreamer && !isMod) {
      setBanError('This chat is in subscriber-only mode');
      return;
    }
    setBanError(null);
    let badge = null;
    if (user.user_id === streamerId) badge = 'STREAMER';
    else if (isMod) badge = 'MOD';
    else if (isSubscribed) badge = 'SUB';
    
    const { data, error } = await supabase.functions.invoke('chat-manager', {
      body: { 
        action: 'send_message', stream_id: streamId, user_id: user.user_id, 
        username: user.username, display_name: user.display_name, message: newMessage.trim(), badge,
        vip_tier_level: userVip?.tier_level, vip_badge_color: userVip?.badge_color
      }
    });
    if (data?.error) { setBanError(data.error); return; }
    setNewMessage('');
  };

  const deleteMessage = async (msgId: string) => {
    if (!user) return;
    await supabase.functions.invoke('chat-manager', { body: { action: 'delete_message', stream_id: streamId, user_id: user.user_id, message_id: msgId } });
  };

  const addEmote = (code: string) => { setNewMessage(prev => prev + code); setShowEmotes(false); };
  const renderMessage = (msg: string) => { let r = msg; EMOTES.forEach(e => { r = r.replaceAll(e.code, e.emoji); }); return r; };
  const canModerate = isStreamer || isMod;
  const canChat = !subOnlyMode || isSubscribed || isStreamer || isMod;

  const positionClasses: Record<ChatPosition, string> = {
    'bottom-right': 'bottom-4 right-4',
    'bottom-left': 'bottom-4 left-4',
    'top-right': 'top-16 right-4',
    'top-left': 'top-16 left-4',
  };

  const sizeClasses: Record<string, { width: string; height: string }> = {
    small: { width: 'w-72', height: 'h-64' },
    medium: { width: 'w-80', height: 'h-80' },
    large: { width: 'w-96', height: 'h-96' },
  };

  const cyclePosition = () => {
    const positions: ChatPosition[] = ['bottom-right', 'bottom-left', 'top-left', 'top-right'];
    const currentIndex = positions.indexOf(position);
    setPosition(positions[(currentIndex + 1) % positions.length]);
  };

  if (!isVisible) {
    return (
      <button
        onClick={onToggleVisibility}
        className="absolute bottom-4 right-4 p-3 bg-purple-600/80 hover:bg-purple-600 rounded-full shadow-lg backdrop-blur-sm transition-all z-20"
        title="Show Chat"
      >
        <MessageSquare className="w-5 h-5 text-white" />
      </button>
    );
  }

  if (isMinimized) {
    return (
      <div className={`absolute ${positionClasses[position]} z-20`}>
        <div 
          className="flex items-center gap-2 px-3 py-2 rounded-full shadow-lg backdrop-blur-md transition-all"
          style={{ backgroundColor: `rgba(22, 33, 62, ${opacity / 100})` }}
        >
          <MessageSquare className="w-4 h-4 text-purple-400" />
          <span className="text-white text-sm font-medium">Chat</span>
          <span className="text-gray-400 text-xs">({messages.length})</span>
          <button onClick={() => setIsMinimized(false)} className="p-1 hover:bg-white/10 rounded">
            <Maximize2 className="w-4 h-4 text-gray-400" />
          </button>
          <button onClick={onToggleVisibility} className="p-1 hover:bg-white/10 rounded">
            <X className="w-4 h-4 text-gray-400" />
          </button>
        </div>
      </div>
    );
  }

  return (
    <div 
      className={`absolute ${positionClasses[position]} ${sizeClasses[chatSize].width} ${showInputOnly ? 'h-auto' : sizeClasses[chatSize].height} rounded-xl shadow-2xl backdrop-blur-md border border-white/10 flex flex-col overflow-hidden z-20 transition-all`}
      style={{ backgroundColor: `rgba(22, 33, 62, ${opacity / 100})` }}
    >
      {/* Header */}
      <div className="flex items-center justify-between px-3 py-2 border-b border-white/10 bg-black/20">
        <div className="flex items-center gap-2">
          <MessageSquare className="w-4 h-4 text-purple-400" />
          <span className="text-white text-sm font-semibold">Live Chat</span>
          {subOnlyMode && <Lock className="w-3 h-3 text-purple-400" />}
        </div>
        <div className="flex items-center gap-1">
          <button 
            onClick={() => setShowInputOnly(!showInputOnly)} 
            className="p-1.5 hover:bg-white/10 rounded transition-colors"
            title={showInputOnly ? "Show messages" : "Hide messages"}
          >
            {showInputOnly ? <Eye className="w-4 h-4 text-gray-400" /> : <EyeOff className="w-4 h-4 text-gray-400" />}
          </button>
          <button 
            onClick={cyclePosition} 
            className="p-1.5 hover:bg-white/10 rounded transition-colors"
            title="Move chat"
          >
            <Move className="w-4 h-4 text-gray-400" />
          </button>
          <button 
            onClick={() => setShowSettings(!showSettings)} 
            className="p-1.5 hover:bg-white/10 rounded transition-colors"
            title="Settings"
          >
            <Settings className="w-4 h-4 text-gray-400" />
          </button>
          <button 
            onClick={() => setIsMinimized(true)} 
            className="p-1.5 hover:bg-white/10 rounded transition-colors"
            title="Minimize"
          >
            <Minimize2 className="w-4 h-4 text-gray-400" />
          </button>
          <button 
            onClick={onToggleVisibility} 
            className="p-1.5 hover:bg-white/10 rounded transition-colors"
            title="Close"
          >
            <X className="w-4 h-4 text-gray-400" />
          </button>
        </div>
      </div>

      {/* Settings Panel */}
      {showSettings && (
        <div className="p-3 border-b border-white/10 bg-black/30 space-y-3">
          <div>
            <label className="text-xs text-gray-400 block mb-1">Opacity</label>
            <input
              type="range"
              min="30"
              max="100"
              value={opacity}
              onChange={(e) => setOpacity(Number(e.target.value))}
              className="w-full h-1 bg-gray-700 rounded-lg appearance-none cursor-pointer accent-purple-500"
            />
          </div>
          <div>
            <label className="text-xs text-gray-400 block mb-1">Size</label>
            <div className="flex gap-2">
              {(['small', 'medium', 'large'] as const).map((size) => (
                <button
                  key={size}
                  onClick={() => setChatSize(size)}
                  className={`px-2 py-1 text-xs rounded ${chatSize === size ? 'bg-purple-600 text-white' : 'bg-gray-700 text-gray-300 hover:bg-gray-600'}`}
                >
                  {size.charAt(0).toUpperCase() + size.slice(1)}
                </button>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* Messages */}
      {!showInputOnly && (
        <div ref={chatRef} className="flex-1 overflow-y-auto p-2 space-y-1.5 scrollbar-thin scrollbar-thumb-gray-700 scrollbar-track-transparent">
          {messages.map((msg) => (
            <EmbeddedChatMessage
              key={msg.id}
              msg={msg}
              canModerate={canModerate}
              onDelete={deleteMessage}
              currentUserId={user?.user_id}
              renderMessage={renderMessage}
            />
          ))}
        </div>
      )}

      {/* Error */}
      {banError && (
        <div className="px-3 py-1.5 bg-red-500/30 text-red-300 text-xs">
          {banError}
        </div>
      )}

      {/* Emotes */}
      {showEmotes && (
        <div className="p-2 bg-black/30 border-t border-white/10 grid grid-cols-6 gap-1">
          {EMOTES.map(e => (
            <button 
              key={e.code} 
              onClick={() => addEmote(e.code)} 
              className="p-1.5 hover:bg-white/10 rounded text-lg transition-colors" 
              title={e.code}
            >
              {e.emoji}
            </button>
          ))}
        </div>
      )}

      {/* Input */}
      <div className="p-2 border-t border-white/10 bg-black/20">
        <div className="flex gap-1.5">
          <button 
            onClick={() => setShowEmotes(!showEmotes)} 
            className="p-2 bg-white/5 hover:bg-white/10 rounded-lg transition-colors"
          >
            <Smile className="w-4 h-4 text-gray-400" />
          </button>
          <input
            value={newMessage}
            onChange={(e) => setNewMessage(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && sendMessage()}
            placeholder={!user ? "Login to chat" : !canChat ? "Subscribe to chat" : "Type a message..."}
            disabled={!user || !canChat}
            className="flex-1 bg-white/5 text-white px-3 py-2 rounded-lg border border-white/10 focus:border-purple-500 focus:outline-none text-sm disabled:opacity-50 placeholder-gray-500"
          />
          <button 
            onClick={sendMessage} 
            disabled={!user || !canChat}
            className="p-2 bg-purple-600 hover:bg-purple-700 disabled:opacity-50 rounded-lg transition-colors"
          >
            <Send className="w-4 h-4 text-white" />
          </button>
        </div>
      </div>
    </div>
  );
};

// Compact message component for embedded chat
const EmbeddedChatMessage: React.FC<{
  msg: ChatMsg;
  canModerate: boolean;
  onDelete: (id: string) => void;
  currentUserId?: string;
  renderMessage: (msg: string) => string;
}> = ({ msg, canModerate, onDelete, currentUserId, renderMessage }) => {
  const getBadgeColor = () => {
    switch (msg.badge) {
      case 'STREAMER': return 'bg-red-500';
      case 'MOD': return 'bg-green-500';
      case 'SUB': return 'bg-purple-500';
      default: return '';
    }
  };

  const getBadgeText = () => {
    switch (msg.badge) {
      case 'STREAMER': return 'S';
      case 'MOD': return 'M';
      case 'SUB': return 'S';
      default: return '';
    }
  };

  return (
    <div 
      className={`group px-2 py-1 rounded hover:bg-white/5 transition-colors ${msg.is_highlighted ? 'bg-yellow-500/20 border-l-2 border-yellow-500' : ''}`}
    >
      <div className="flex items-start gap-1.5">
        <div className="flex items-center gap-1 flex-shrink-0">
          {msg.badge && (
            <span className={`${getBadgeColor()} text-white text-[9px] font-bold px-1 rounded`}>
              {getBadgeText()}
            </span>
          )}
          {msg.vip_tier_level && msg.vip_tier_level > 0 && (
            <VIPChatBadge tierLevel={msg.vip_tier_level} badgeColor={msg.vip_badge_color} size="sm" />
          )}
        </div>
        <div className="flex-1 min-w-0">
          <span className={`font-medium text-xs ${msg.badge === 'STREAMER' ? 'text-red-400' : msg.badge === 'MOD' ? 'text-green-400' : 'text-purple-400'}`}>
            {msg.display_name || msg.username}
          </span>
          <span className="text-gray-400 text-xs">: </span>
          <span className="text-white/90 text-xs break-words">{renderMessage(msg.message)}</span>
        </div>
        {canModerate && msg.user_id !== currentUserId && (
          <button
            onClick={() => onDelete(msg.id)}
            className="opacity-0 group-hover:opacity-100 p-0.5 hover:bg-red-500/20 rounded transition-all"
          >
            <X className="w-3 h-3 text-red-400" />
          </button>
        )}
      </div>
    </div>
  );
};

export default EmbeddedChat;
