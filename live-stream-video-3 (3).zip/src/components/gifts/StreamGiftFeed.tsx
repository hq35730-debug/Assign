import { useState, useEffect } from 'react';
import { Heart, Star, Diamond, Crown, Rocket, Flame, Trophy, Sparkles, Flower, Coins } from 'lucide-react';
import { supabase } from '@/lib/supabase';

interface GiftTransaction {
  id: string;
  sender_id: string;
  quantity: number;
  coins_spent: number;
  message?: string;
  created_at: string;
  gift_types?: {
    name: string;
    icon: string;
    color: string;
  };
}

interface StreamGiftFeedProps {
  streamId: string;
  maxItems?: number;
}

const iconMap: Record<string, any> = {
  heart: Heart, star: Star, diamond: Diamond, crown: Crown,
  rocket: Rocket, flame: Flame, trophy: Trophy, sparkles: Sparkles,
  flower: Flower, rainbow: Sparkles
};

export function StreamGiftFeed({ streamId, maxItems = 5 }: StreamGiftFeedProps) {
  const [gifts, setGifts] = useState<GiftTransaction[]>([]);

  useEffect(() => {
    loadGifts();
    
    // Subscribe to new gifts
    const channel = supabase.channel(`stream-gifts:${streamId}`)
      .on('postgres_changes', {
        event: 'INSERT',
        schema: 'public',
        table: 'gift_transactions',
        filter: `stream_id=eq.${streamId}`
      }, (payload) => {
        if (payload.new) {
          setGifts(prev => {
            const safePrev = Array.isArray(prev) ? prev : [];
            return [payload.new as GiftTransaction, ...safePrev].slice(0, maxItems);
          });
        }
      })
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, [streamId, maxItems]);

  const loadGifts = async () => {
    try {
      const { data } = await supabase.functions.invoke('gifts-manager', {
        body: { action: 'get_stream_gifts', stream_id: streamId, limit: maxItems }
      });
      const txData = Array.isArray(data?.transactions) ? data.transactions : [];
      setGifts(txData);
    } catch (err) {
      console.error('Error loading stream gifts:', err);
      setGifts([]);
    }
  };

  const safeGifts = Array.isArray(gifts) ? gifts : [];

  if (safeGifts.length === 0) return null;

  return (
    <div className="space-y-2">
      <h4 className="text-sm font-semibold text-gray-400 px-2">Recent Gifts</h4>
      <div className="space-y-1">
        {safeGifts.map((gift) => {
          const Icon = iconMap[gift.gift_types?.icon || 'heart'] || Heart;
          return (
            <div
              key={gift.id}
              className="flex items-center gap-2 px-2 py-1.5 bg-gradient-to-r from-purple-500/10 to-pink-500/10 rounded-lg animate-fade-in"
            >
              <Icon
                className="w-4 h-4 flex-shrink-0"
                style={{ color: gift.gift_types?.color || '#ff69b4' }}
              />
              <div className="flex-1 min-w-0">
                <span className="text-xs">
                  <span className="font-medium text-purple-400">
                    {gift.sender_id?.slice(0, 8) || 'User'}
                  </span>
                  {' sent '}
                  <span className="font-bold" style={{ color: gift.gift_types?.color || '#ff69b4' }}>
                    {gift.quantity}x {gift.gift_types?.name || 'Gift'}
                  </span>
                </span>
              </div>
              <div className="flex items-center gap-0.5 text-yellow-500 text-xs">
                <Coins className="w-3 h-3" />
                <span>{gift.coins_spent}</span>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
