import { useState, useCallback } from 'react';
import { GiftAnimation } from './GiftAnimation';

interface GiftEvent {
  id: string;
  gift: {
    name: string;
    icon: string;
    color: string;
    animation_type: string;
    animation_duration: number;
    particle_count: number;
  };
  quantity: number;
  senderName: string;
}

interface GiftOverlayProps {
  onGiftReceived?: (gift: GiftEvent) => void;
}

export function GiftOverlay({ onGiftReceived }: GiftOverlayProps) {
  const [activeGifts, setActiveGifts] = useState<GiftEvent[]>([]);

  const addGift = useCallback((gift: GiftEvent) => {
    setActiveGifts(prev => {
      const safePrev = Array.isArray(prev) ? prev : [];
      return [...safePrev, gift];
    });
    onGiftReceived?.(gift);
  }, [onGiftReceived]);

  const removeGift = useCallback((id: string) => {
    setActiveGifts(prev => {
      const safePrev = Array.isArray(prev) ? prev : [];
      return safePrev.filter(g => g.id !== id);
    });
  }, []);

  // Expose addGift method via window for external triggering
  if (typeof window !== 'undefined') {
    (window as any).triggerGiftAnimation = addGift;
  }

  const safeActiveGifts = Array.isArray(activeGifts) ? activeGifts : [];

  return (
    <>
      {safeActiveGifts.map((giftEvent) => (
        <GiftAnimation
          key={giftEvent.id}
          gift={giftEvent.gift}
          quantity={giftEvent.quantity}
          senderName={giftEvent.senderName}
          onComplete={() => removeGift(giftEvent.id)}
        />
      ))}
    </>
  );
}

// Helper function to trigger gift animation from anywhere
export function triggerGift(gift: any, quantity: number, senderName: string) {
  if (typeof window !== 'undefined' && (window as any).triggerGiftAnimation) {
    (window as any).triggerGiftAnimation({
      id: `gift-${Date.now()}-${Math.random()}`,
      gift: {
        name: gift?.name || 'Gift',
        icon: gift?.icon || 'heart',
        color: gift?.color || '#ff69b4',
        animation_type: gift?.animation_type || 'float',
        animation_duration: gift?.animation_duration || 3000,
        particle_count: gift?.particle_count || 10
      },
      quantity,
      senderName
    });
  }
}
