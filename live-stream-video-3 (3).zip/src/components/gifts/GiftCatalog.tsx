import { useState, useEffect } from 'react';
import { Heart, Star, Diamond, Crown, Rocket, Flame, Trophy, Sparkles, Flower, Coins } from 'lucide-react';
import { Badge } from '@/components/ui/badge';
import { supabase } from '@/lib/supabase';

interface GiftType {
  id: string;
  name: string;
  icon: string;
  coin_cost: number;
  color: string;
  animation_type: string;
  is_premium: boolean;
}

interface GiftCatalogProps {
  onSelectGift: (gift: GiftType) => void;
  selectedGift: GiftType | null;
  balance: number;
}

const iconMap: Record<string, any> = {
  heart: Heart, star: Star, diamond: Diamond, crown: Crown,
  rocket: Rocket, flame: Flame, trophy: Trophy, sparkles: Sparkles,
  flower: Flower, rainbow: Sparkles
};

export function GiftCatalog({ onSelectGift, selectedGift, balance }: GiftCatalogProps) {
  const [gifts, setGifts] = useState<GiftType[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadGifts();
  }, []);

  const loadGifts = async () => {
    try {
      const { data } = await supabase.functions.invoke('gifts-manager', { 
        body: { action: 'get_gift_types' } 
      });
      const giftsData = Array.isArray(data?.gifts) ? data.gifts : [];
      setGifts(giftsData);
    } catch (err) {
      console.error('Error loading gifts:', err);
      setGifts([]);
    }
    setLoading(false);
  };

  if (loading) {
    return (
      <div className="grid grid-cols-5 gap-2">
        {Array.from({ length: 10 }).map((_, i) => (
          <div key={i} className="h-20 bg-gray-800 animate-pulse rounded-lg" />
        ))}
      </div>
    );
  }

  const safeGifts = Array.isArray(gifts) ? gifts : [];

  if (safeGifts.length === 0) {
    return <p className="text-center text-gray-500 py-8">No gifts available</p>;
  }

  return (
    <div className="grid grid-cols-5 gap-2">
      {safeGifts.map((gift) => {
        const Icon = iconMap[gift.icon] || Heart;
        const canAfford = balance >= gift.coin_cost;
        const isSelected = selectedGift?.id === gift.id;
        
        return (
          <button
            key={gift.id}
            onClick={() => canAfford && onSelectGift(gift)}
            disabled={!canAfford}
            className={`relative p-2 rounded-lg border-2 transition-all flex flex-col items-center ${
              isSelected 
                ? 'border-purple-500 bg-purple-500/20 scale-105' 
                : canAfford 
                  ? 'border-gray-700 hover:border-gray-500 hover:bg-gray-800/50' 
                  : 'border-gray-800 opacity-50 cursor-not-allowed'
            }`}
          >
            {gift.is_premium && (
              <Badge className="absolute -top-1 -right-1 text-[10px] px-1 bg-gradient-to-r from-yellow-500 to-orange-500">
                VIP
              </Badge>
            )}
            <Icon 
              className="w-6 h-6 mb-1" 
              style={{ color: gift.color, filter: `drop-shadow(0 0 4px ${gift.color}40)` }} 
            />
            <p className="text-[10px] font-medium truncate w-full text-center">{gift.name}</p>
            <div className="flex items-center gap-0.5 text-yellow-500">
              <Coins className="w-3 h-3" />
              <span className="text-[10px] font-bold">{gift.coin_cost}</span>
            </div>
          </button>
        );
      })}
    </div>
  );
}
