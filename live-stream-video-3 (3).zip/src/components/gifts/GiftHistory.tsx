import { useState, useEffect } from 'react';
import { Heart, Star, Diamond, Crown, Rocket, Flame, Trophy, Sparkles, Flower, Coins, ArrowUpRight, ArrowDownLeft } from 'lucide-react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/contexts/AuthContext';

interface GiftTransaction {
  id: string;
  sender_id: string;
  receiver_id: string;
  quantity: number;
  coins_spent: number;
  message?: string;
  created_at: string;
  gift_types?: {
    name: string;
    icon: string;
    color: string;
  };
}

const iconMap: Record<string, any> = {
  heart: Heart, star: Star, diamond: Diamond, crown: Crown,
  rocket: Rocket, flame: Flame, trophy: Trophy, sparkles: Sparkles,
  flower: Flower, rainbow: Sparkles
};

export function GiftHistory() {
  const { user } = useAuth();
  const [sentGifts, setSentGifts] = useState<GiftTransaction[]>([]);
  const [receivedGifts, setReceivedGifts] = useState<GiftTransaction[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (user) loadHistory();
    else setLoading(false);
  }, [user]);

  const loadHistory = async () => {
    if (!user) return;
    setLoading(true);
    
    try {
      const [sentRes, receivedRes] = await Promise.all([
        supabase.functions.invoke('gifts-manager', { body: { action: 'get_gift_history', user_id: user.id, type: 'sent' } }),
        supabase.functions.invoke('gifts-manager', { body: { action: 'get_gift_history', user_id: user.id, type: 'received' } })
      ]);
      
      const sentData = Array.isArray(sentRes.data?.transactions) ? sentRes.data.transactions : [];
      const receivedData = Array.isArray(receivedRes.data?.transactions) ? receivedRes.data.transactions : [];
      
      setSentGifts(sentData);
      setReceivedGifts(receivedData);
    } catch (err) {
      console.error('Error loading gift history:', err);
      setSentGifts([]);
      setReceivedGifts([]);
    }
    setLoading(false);
  };

  const formatDate = (date: string) => {
    return new Date(date).toLocaleDateString('en-US', { month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' });
  };

  const GiftList = ({ gifts, type }: { gifts: GiftTransaction[]; type: 'sent' | 'received' }) => {
    const safeGifts = Array.isArray(gifts) ? gifts : [];
    return (
      <div className="space-y-2">
        {safeGifts.length === 0 ? (
          <p className="text-center text-gray-500 py-8">No {type} gifts yet</p>
        ) : (
          safeGifts.map((tx) => {
            const Icon = iconMap[tx.gift_types?.icon || 'heart'] || Heart;
            return (
              <div key={tx.id} className="flex items-center gap-3 p-3 bg-gray-800/50 rounded-lg">
                <div className="p-2 rounded-full" style={{ backgroundColor: `${tx.gift_types?.color || '#ff69b4'}20` }}>
                  <Icon className="w-5 h-5" style={{ color: tx.gift_types?.color || '#ff69b4' }} />
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2">
                    <span className="font-medium">{tx.quantity}x {tx.gift_types?.name || 'Gift'}</span>
                    {type === 'sent' ? <ArrowUpRight className="w-4 h-4 text-red-400" /> : <ArrowDownLeft className="w-4 h-4 text-green-400" />}
                  </div>
                  {tx.message && <p className="text-sm text-gray-400 truncate">{tx.message}</p>}
                  <p className="text-xs text-gray-500">{formatDate(tx.created_at)}</p>
                </div>
                <div className="flex items-center gap-1 text-yellow-500">
                  <Coins className="w-4 h-4" />
                  <span className="font-bold">{type === 'sent' ? '-' : '+'}{tx.coins_spent}</span>
                </div>
              </div>
            );
          })
        )}
      </div>
    );
  };

  if (loading) {
    return <div className="space-y-2">{Array.from({ length: 5 }).map((_, i) => <div key={i} className="h-16 bg-gray-800 animate-pulse rounded-lg" />)}</div>;
  }

  return (
    <Tabs defaultValue="received" className="w-full">
      <TabsList className="w-full">
        <TabsTrigger value="received" className="flex-1">Received ({receivedGifts.length})</TabsTrigger>
        <TabsTrigger value="sent" className="flex-1">Sent ({sentGifts.length})</TabsTrigger>
      </TabsList>
      <TabsContent value="received"><GiftList gifts={receivedGifts} type="received" /></TabsContent>
      <TabsContent value="sent"><GiftList gifts={sentGifts} type="sent" /></TabsContent>
    </Tabs>
  );
}
