import { useState, useEffect } from 'react';
import { Heart, Star, Diamond, Crown, Rocket, Flame, Trophy, Sparkles, Flower } from 'lucide-react';

interface GiftAnimationProps {
  gift: {
    name: string;
    icon: string;
    color: string;
    animation_type: string;
    animation_duration: number;
    particle_count: number;
  };
  quantity: number;
  senderName: string;
  onComplete: () => void;
}

const iconMap: Record<string, any> = {
  heart: Heart, star: Star, diamond: Diamond, crown: Crown,
  rocket: Rocket, flame: Flame, trophy: Trophy, sparkles: Sparkles,
  flower: Flower, rainbow: Sparkles
};

export function GiftAnimation({ gift, quantity, senderName, onComplete }: GiftAnimationProps) {
  const [particles, setParticles] = useState<{ id: number; x: number; y: number; delay: number }[]>([]);
  
  // Safe defaults for gift properties
  const safeGift = {
    name: gift?.name || 'Gift',
    icon: gift?.icon || 'heart',
    color: gift?.color || '#ff69b4',
    animation_type: gift?.animation_type || 'float',
    animation_duration: gift?.animation_duration || 3000,
    particle_count: gift?.particle_count || 10
  };
  
  const Icon = iconMap[safeGift.icon] || Heart;

  useEffect(() => {
    const particleCount = Math.min(Math.max(safeGift.particle_count, 1), 50);
    const newParticles = Array.from({ length: particleCount }, (_, i) => ({
      id: i,
      x: Math.random() * 100,
      y: Math.random() * 100,
      delay: Math.random() * 0.5
    }));
    setParticles(newParticles);
    const timer = setTimeout(onComplete, safeGift.animation_duration);
    return () => clearTimeout(timer);
  }, [safeGift.particle_count, safeGift.animation_duration, onComplete]);

  const getAnimationClass = () => {
    switch (safeGift.animation_type) {
      case 'burst': return 'animate-ping';
      case 'sparkle': return 'animate-pulse';
      case 'launch': return 'animate-bounce';
      case 'explosion': return 'animate-spin';
      default: return 'animate-bounce';
    }
  };

  const safeParticles = Array.isArray(particles) ? particles : [];

  return (
    <div className="fixed inset-0 pointer-events-none z-50 overflow-hidden">
      {/* Background glow */}
      <div className="absolute inset-0 bg-gradient-radial from-purple-500/20 to-transparent animate-pulse" />
      
      {/* Main gift display */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 text-center animate-scale-in">
        <div className={`${getAnimationClass()}`} style={{ color: safeGift.color }}>
          <Icon className="w-32 h-32 mx-auto drop-shadow-2xl" style={{ filter: `drop-shadow(0 0 20px ${safeGift.color})` }} />
        </div>
        <div className="mt-4 bg-black/80 backdrop-blur-sm rounded-xl px-6 py-3 animate-fade-in">
          <p className="text-2xl font-bold text-white">{quantity}x {safeGift.name}</p>
          <p className="text-lg text-purple-400">from {senderName || 'Anonymous'}</p>
        </div>
      </div>

      {/* Floating particles */}
      {safeParticles.map((p) => (
        <div
          key={p.id}
          className="absolute animate-float-up"
          style={{
            left: `${p.x}%`,
            top: `${p.y}%`,
            animationDelay: `${p.delay}s`,
            color: safeGift.color
          }}
        >
          <Icon className="w-8 h-8 opacity-70" style={{ filter: `drop-shadow(0 0 10px ${safeGift.color})` }} />
        </div>
      ))}
    </div>
  );
}
