
import { useState, useEffect } from 'react';
import { Trophy, Sparkles, Crown, Medal, Award } from 'lucide-react';
import { supabase } from '@/lib/supabase';

interface PointsLeaderboardProps {
  channelId: string;
  limit?: number;
}

export function PointsLeaderboard({ channelId, limit = 10 }: PointsLeaderboardProps) {
  const [leaders, setLeaders] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchLeaderboard();
  }, [channelId]);

  const fetchLeaderboard = async () => {
    setLoading(true);
    const { data } = await supabase.functions.invoke('points-manager', {
      body: { action: 'get_leaderboard', channel_id: channelId, limit }
    });
    if (data?.data) setLeaders(data.data);
    setLoading(false);
  };

  const getRankIcon = (index: number) => {
    switch (index) {
      case 0: return <Crown className="w-5 h-5 text-yellow-400" />;
      case 1: return <Medal className="w-5 h-5 text-gray-300" />;
      case 2: return <Award className="w-5 h-5 text-amber-600" />;
      default: return <span className="w-5 h-5 flex items-center justify-center text-gray-400 text-sm font-bold">{index + 1}</span>;
    }
  };

  const getRankBg = (index: number) => {
    switch (index) {
      case 0: return 'bg-gradient-to-r from-yellow-500/20 to-amber-500/20 border-yellow-500/30';
      case 1: return 'bg-gradient-to-r from-gray-400/20 to-gray-300/20 border-gray-400/30';
      case 2: return 'bg-gradient-to-r from-amber-600/20 to-orange-500/20 border-amber-600/30';
      default: return 'bg-gray-800/50 border-gray-700';
    }
  };

  if (loading) {
    return (
      <div className="bg-gray-900 rounded-xl p-4 border border-gray-800">
        <div className="flex items-center gap-2 mb-4">
          <Trophy className="w-5 h-5 text-yellow-400" />
          <h3 className="font-bold text-white">Points Leaderboard</h3>
        </div>
        <div className="space-y-2">
          {[...Array(5)].map((_, i) => (
            <div key={i} className="h-12 bg-gray-800 rounded-lg animate-pulse" />
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="bg-gray-900 rounded-xl p-4 border border-gray-800">
      <div className="flex items-center gap-2 mb-4">
        <Trophy className="w-5 h-5 text-yellow-400" />
        <h3 className="font-bold text-white">Points Leaderboard</h3>
      </div>
      {leaders.length > 0 ? (
        <div className="space-y-2">
          {leaders.map((leader, index) => (
            <div
              key={leader.id}
              className={`flex items-center gap-3 p-2 rounded-lg border ${getRankBg(index)}`}
            >
              <div className="w-8 flex justify-center">{getRankIcon(index)}</div>
              <div className="flex-1 min-w-0">
                <p className="text-sm font-semibold text-white truncate">{leader.username}</p>
                <p className="text-xs text-gray-400">{leader.watch_time_minutes}m watched</p>
              </div>
              <div className="flex items-center gap-1 text-yellow-400">
                <Sparkles className="w-3 h-3" />
                <span className="text-sm font-bold">{leader.points.toLocaleString()}</span>
              </div>
              {leader.is_subscriber && (
                <span className="text-[10px] bg-purple-500 text-white px-1.5 py-0.5 rounded-full">SUB</span>
              )}
            </div>
          ))}
        </div>
      ) : (
        <p className="text-gray-400 text-sm text-center py-4">No points earned yet</p>
      )}
    </div>
  );
}
