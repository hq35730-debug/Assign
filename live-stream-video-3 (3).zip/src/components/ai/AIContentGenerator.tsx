import { useState } from 'react';
import { Wand2, Copy, Check, Loader2, RefreshCw, FileText, MessageSquare, Hash, Megaphone } from 'lucide-react';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/contexts/AuthContext';
import { useToast } from '@/hooks/use-toast';

interface GeneratedContent {
  id: string;
  type: string;
  content: string;
  timestamp: Date;
}

export function AIContentGenerator() {
  const { user } = useAuth();
  const { toast } = useToast();

  const [topic, setTopic] = useState('');
  const [context, setContext] = useState('');
  const [generatedContent, setGeneratedContent] = useState<GeneratedContent[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const [activeTab, setActiveTab] = useState('titles');

  const contentTypes = [
    { id: 'titles', label: 'Stream Titles', icon: FileText, prompt: 'Generate 5 catchy stream titles' },
    { id: 'descriptions', label: 'Descriptions', icon: MessageSquare, prompt: 'Generate a compelling stream description' },
    { id: 'social', label: 'Social Posts', icon: Megaphone, prompt: 'Generate social media posts to promote the stream' },
    { id: 'hashtags', label: 'Hashtags', icon: Hash, prompt: 'Generate relevant hashtags' }
  ];

  const generateContent = async (type: string) => {
    if (!topic.trim()) {
      toast({
        title: 'Topic Required',
        description: 'Please enter a topic or theme for your content',
        variant: 'destructive'
      });
      return;
    }

    setIsLoading(true);

    try {
      const contentType = contentTypes.find(t => t.id === type);
      const prompt = `${contentType?.prompt} for a stream about: ${topic}. ${context ? `Additional context: ${context}` : ''}`;

      const { data, error } = await supabase.functions.invoke('ai-assistant', {
        body: {
          action: 'generate_content',
          user_id: user?.user_id,
          prompt,
          context: { topic, type }
        }
      });

      if (error) throw error;

      const newContent: GeneratedContent = {
        id: `content-${Date.now()}`,
        type,
        content: data.content || 'Failed to generate content',
        timestamp: new Date()
      };

      setGeneratedContent(prev => [newContent, ...prev]);
    } catch (error: any) {
      console.error('Content generation error:', error);
      toast({
        title: 'Error',
        description: error.message || 'Failed to generate content',
        variant: 'destructive'
      });
    } finally {
      setIsLoading(false);
    }
  };

  const copyToClipboard = async (content: string, id: string) => {
    await navigator.clipboard.writeText(content);
    setCopiedId(id);
    toast({ title: 'Copied to clipboard!' });
    setTimeout(() => setCopiedId(null), 2000);
  };

  const clearHistory = () => {
    setGeneratedContent([]);
  };

  return (
    <Card className="p-6">
      <div className="flex items-center gap-3 mb-6">
        <div className="w-10 h-10 rounded-full bg-gradient-to-br from-pink-500 to-rose-600 flex items-center justify-center">
          <Wand2 className="w-5 h-5 text-white" />
        </div>
        <div>
          <h3 className="font-semibold">AI Content Generator</h3>
          <p className="text-sm text-muted-foreground">Generate stream content with AI</p>
        </div>
      </div>

      <div className="space-y-4">
        {/* Input Section */}
        <div className="space-y-3">
          <div>
            <Label htmlFor="topic">Topic / Theme</Label>
            <Input
              id="topic"
              value={topic}
              onChange={(e) => setTopic(e.target.value)}
              placeholder="e.g., Playing Elden Ring, Cooking stream, Just chatting about movies..."
              className="mt-1"
            />
          </div>
          
          <div>
            <Label htmlFor="context">Additional Context (optional)</Label>
            <Textarea
              id="context"
              value={context}
              onChange={(e) => setContext(e.target.value)}
              placeholder="Any specific details, tone, or style you want..."
              className="mt-1"
              rows={2}
            />
          </div>
        </div>

        {/* Content Type Tabs */}
        <Tabs value={activeTab} onValueChange={setActiveTab}>
          <TabsList className="grid w-full grid-cols-4">
            {contentTypes.map(type => (
              <TabsTrigger key={type.id} value={type.id} className="gap-1 text-xs">
                <type.icon className="w-3 h-3" />
                {type.label}
              </TabsTrigger>
            ))}
          </TabsList>

          {contentTypes.map(type => (
            <TabsContent key={type.id} value={type.id} className="mt-4">
              <Button
                onClick={() => generateContent(type.id)}
                disabled={isLoading || !topic.trim()}
                className="w-full bg-gradient-to-r from-pink-500 to-rose-600 hover:from-pink-600 hover:to-rose-700"
              >
                {isLoading ? (
                  <>
                    <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                    Generating...
                  </>
                ) : (
                  <>
                    <Wand2 className="w-4 h-4 mr-2" />
                    Generate {type.label}
                  </>
                )}
              </Button>
            </TabsContent>
          ))}
        </Tabs>

        {/* Generated Content */}
        {generatedContent.length > 0 && (
          <div className="space-y-3 mt-6">
            <div className="flex items-center justify-between">
              <h4 className="font-medium">Generated Content</h4>
              <Button variant="ghost" size="sm" onClick={clearHistory}>
                Clear All
              </Button>
            </div>

            <div className="space-y-3 max-h-96 overflow-y-auto">
              {generatedContent.map(item => (
                <Card key={item.id} className="p-4 bg-muted/50">
                  <div className="flex items-start justify-between gap-2 mb-2">
                    <Badge variant="secondary" className="text-xs">
                      {contentTypes.find(t => t.id === item.type)?.label}
                    </Badge>
                    <div className="flex gap-1">
                      <Button
                        variant="ghost"
                        size="sm"
                        className="h-6 px-2"
                        onClick={() => copyToClipboard(item.content, item.id)}
                      >
                        {copiedId === item.id ? (
                          <Check className="w-3 h-3" />
                        ) : (
                          <Copy className="w-3 h-3" />
                        )}
                      </Button>
                      <Button
                        variant="ghost"
                        size="sm"
                        className="h-6 px-2"
                        onClick={() => generateContent(item.type)}
                        disabled={isLoading}
                      >
                        <RefreshCw className="w-3 h-3" />
                      </Button>
                    </div>
                  </div>
                  <div className="text-sm whitespace-pre-wrap">{item.content}</div>
                  <p className="text-xs text-muted-foreground mt-2">
                    {item.timestamp.toLocaleTimeString()}
                  </p>
                </Card>
              ))}
            </div>
          </div>
        )}
      </div>
    </Card>
  );
}
