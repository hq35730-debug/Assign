import React, { useState, useEffect } from 'react';
import { Calendar, Clock, Bell, User } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/contexts/AuthContext';

interface Schedule {
  id: string;
  channel_id: string;
  title: string;
  category: string;
  scheduled_start: string;
  streamer_name?: string;
  streamer_avatar?: string;
}

export function UpcomingSchedules() {
  const { user } = useAuth();
  const [schedules, setSchedules] = useState<Schedule[]>([]);
  const [notified, setNotified] = useState<string[]>([]);

  useEffect(() => {
    fetchUpcomingSchedules();
  }, []);

  const fetchUpcomingSchedules = async () => {
    try {
      const { data } = await supabase.functions.invoke('schedule-manager', {
        body: { action: 'get_upcoming_schedules', limit: 6 }
      });
      const schedulesData = Array.isArray(data?.schedules) ? data.schedules : [];
      if (schedulesData.length > 0) {
        const schedulesWithNames = await Promise.all(
          schedulesData.map(async (s: Schedule) => {
            try {
              const { data: profile } = await supabase.from('profiles').select('display_name, username, avatar_url').eq('user_id', s.channel_id).single();
              return { ...s, streamer_name: profile?.display_name || profile?.username || 'Unknown', streamer_avatar: profile?.avatar_url };
            } catch {
              return { ...s, streamer_name: 'Unknown' };
            }
          })
        );
        setSchedules(schedulesWithNames);
      }
    } catch (err) {
      console.error('Error fetching schedules:', err);
    }
  };

  const handleNotify = async (schedule: Schedule) => {
    if (!user) return;
    const notifyTime = new Date(new Date(schedule.scheduled_start).getTime() - 15 * 60000).toISOString();
    await supabase.functions.invoke('schedule-manager', {
      body: { action: 'subscribe_notification', schedule_id: schedule.id, user_id: user.user_id, notification_time: notifyTime }
    });
    setNotified(prev => {
      const safePrev = Array.isArray(prev) ? prev : [];
      return [...safePrev, schedule.id];
    });
  };

  const formatTime = (date: string) => {
    const d = new Date(date);
    const now = new Date();
    const diff = d.getTime() - now.getTime();
    const hours = Math.floor(diff / (1000 * 60 * 60));
    const days = Math.floor(hours / 24);
    if (days > 0) return `in ${days} day${days > 1 ? 's' : ''}`;
    if (hours > 0) return `in ${hours} hour${hours > 1 ? 's' : ''}`;
    return 'Starting soon';
  };

  const safeSchedules = Array.isArray(schedules) ? schedules : [];
  const safeNotified = Array.isArray(notified) ? notified : [];

  if (safeSchedules.length === 0) return null;

  return (
    <div className="bg-[#16213e] rounded-2xl p-6 border border-gray-800">
      <h2 className="text-2xl font-bold text-white mb-4 flex items-center gap-2">
        <Calendar className="w-6 h-6 text-purple-400" /> Upcoming Streams
      </h2>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {safeSchedules.map(schedule => (
          <div key={schedule.id} className="bg-[#1a1a2e] rounded-xl p-4 border border-gray-700 hover:border-purple-500 transition-colors">
            <div className="flex items-start justify-between mb-3">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-full bg-gradient-to-br from-purple-500 to-pink-500 flex items-center justify-center overflow-hidden">
                  {schedule.streamer_avatar ? <img src={schedule.streamer_avatar} alt="" className="w-full h-full object-cover" /> : <User className="w-4 h-4 text-white" />}
                </div>
                <span className="text-gray-300 text-sm">{schedule.streamer_name}</span>
              </div>
              {user && !safeNotified.includes(schedule.id) ? (
                <button onClick={() => handleNotify(schedule)} className="p-1.5 rounded-lg bg-purple-600/20 text-purple-400 hover:bg-purple-600/40 transition-colors" title="Get notified">
                  <Bell className="w-4 h-4" />
                </button>
              ) : safeNotified.includes(schedule.id) && (
                <Bell className="w-4 h-4 text-yellow-400" />
              )}
            </div>
            <h3 className="text-white font-semibold mb-1 truncate">{schedule.title}</h3>
            <span className="text-purple-400 text-xs">{schedule.category}</span>
            <div className="flex items-center gap-2 mt-3 text-gray-400 text-sm">
              <Clock className="w-4 h-4" />
              <span>{formatTime(schedule.scheduled_start)}</span>
              <span className="text-gray-600">•</span>
              <span>{new Date(schedule.scheduled_start).toLocaleDateString()}</span>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
