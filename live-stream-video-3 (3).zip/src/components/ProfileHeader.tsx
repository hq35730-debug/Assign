import React, { useState, useRef } from 'react';
import { Camera, Edit2, Check, X, Phone, Hash, Copy, CheckCircle, QrCode } from 'lucide-react';
import { useAuth, UserProfile } from '@/contexts/AuthContext';
import { QRCodeDisplay } from '@/components/qr/QRCodeDisplay';


interface Props {
  profile: UserProfile;
  isOwnProfile: boolean;
  followersCount: number;
  followingCount: number;
  isFollowing: boolean;
  onFollow: () => void;
}

export default function ProfileHeader({ profile, isOwnProfile, followersCount, followingCount, isFollowing, onFollow }: Props) {
  const { updateProfile } = useAuth();
  const [editingBio, setEditingBio] = useState(false);
  const [bio, setBio] = useState(profile.bio || '');
  const [displayName, setDisplayName] = useState(profile.display_name || profile.username);
  const [editingName, setEditingName] = useState(false);
  const [copiedId, setCopiedId] = useState(false);
  const [copiedPhone, setCopiedPhone] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const saveBio = async () => {
    await updateProfile({ bio });
    setEditingBio(false);
  };

  const saveName = async () => {
    await updateProfile({ display_name: displayName });
    setEditingName(false);
  };

  const handleAvatarChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = async (ev) => {
        const url = ev.target?.result as string;
        await updateProfile({ avatar_url: url });
      };
      reader.readAsDataURL(file);
    }
  };

  const copyToClipboard = async (text: string, type: 'id' | 'phone') => {
    try {
      await navigator.clipboard.writeText(text);
      if (type === 'id') {
        setCopiedId(true);
        setTimeout(() => setCopiedId(false), 2000);
      } else {
        setCopiedPhone(true);
        setTimeout(() => setCopiedPhone(false), 2000);
      }
    } catch (err) {
      console.error('Failed to copy:', err);
    }
  };

  const formatPhoneNumber = (phone: string) => {
    // Format as (XXX) XXX-XXXX for US numbers
    const cleaned = phone.replace(/\D/g, '');
    if (cleaned.length === 11 && cleaned.startsWith('1')) {
      return `+1 (${cleaned.slice(1, 4)}) ${cleaned.slice(4, 7)}-${cleaned.slice(7)}`;
    }
    if (cleaned.length === 10) {
      return `(${cleaned.slice(0, 3)}) ${cleaned.slice(3, 6)}-${cleaned.slice(6)}`;
    }
    return phone;
  };

  return (
    <div className="bg-[#16213e] rounded-2xl p-6 border border-gray-800">
      <div className="flex flex-col md:flex-row gap-6 items-center md:items-start">
        <div className="relative group">
          <div className="w-32 h-32 rounded-full overflow-hidden bg-gradient-to-br from-purple-500 to-pink-500 p-1">
            <div className="w-full h-full rounded-full overflow-hidden bg-[#1a1a2e]">
              {profile.avatar_url ? (
                <img src={profile.avatar_url} alt={profile.username} className="w-full h-full object-cover" />
              ) : (
                <div className="w-full h-full flex items-center justify-center text-4xl font-bold text-purple-400">
                  {profile.username[0].toUpperCase()}
                </div>
              )}
            </div>
          </div>
          {isOwnProfile && (
            <>
              <button onClick={() => fileInputRef.current?.click()}
                className="absolute bottom-0 right-0 bg-purple-600 p-2 rounded-full hover:bg-purple-500 transition-colors">
                <Camera className="w-4 h-4 text-white" />
              </button>
              <input ref={fileInputRef} type="file" accept="image/*" onChange={handleAvatarChange} className="hidden" />
            </>
          )}
        </div>

        <div className="flex-1 text-center md:text-left">
          <div className="flex items-center justify-center md:justify-start gap-2 mb-1">
            {editingName && isOwnProfile ? (
              <div className="flex items-center gap-2">
                <input value={displayName} onChange={(e) => setDisplayName(e.target.value)}
                  className="bg-[#1a1a2e] text-white px-3 py-1 rounded border border-gray-700 focus:border-purple-500 focus:outline-none" />
                <button onClick={saveName} className="text-green-400 hover:text-green-300"><Check className="w-5 h-5" /></button>
                <button onClick={() => setEditingName(false)} className="text-red-400 hover:text-red-300"><X className="w-5 h-5" /></button>
              </div>
            ) : (
              <>
                <h1 className="text-2xl font-bold text-white">{profile.display_name || profile.username}</h1>
                {isOwnProfile && <button onClick={() => setEditingName(true)} className="text-gray-500 hover:text-purple-400"><Edit2 className="w-4 h-4" /></button>}
              </>
            )}
          </div>
          <p className="text-gray-400 mb-2">@{profile.username}</p>

          {/* Unique ID Display */}
          {profile.unique_id && (
            <div className="flex items-center justify-center md:justify-start gap-2 mb-2">
              <div className="flex items-center gap-2 bg-gradient-to-r from-purple-500/20 to-pink-500/20 px-3 py-1.5 rounded-lg border border-purple-500/30">
                <Hash className="w-4 h-4 text-purple-400" />
                <span className="text-purple-300 font-mono font-semibold">{profile.unique_id}</span>
                <button 
                  onClick={() => copyToClipboard(profile.unique_id!.toString(), 'id')}
                  className="text-gray-400 hover:text-purple-400 transition-colors"
                  title="Copy ID"
                >
                  {copiedId ? <CheckCircle className="w-4 h-4 text-green-400" /> : <Copy className="w-4 h-4" />}
                </button>
              </div>
            </div>
          )}

          {/* Phone Number Display */}
          {profile.phone_number && (
            <div className="flex items-center justify-center md:justify-start gap-2 mb-4">
              <div className="flex items-center gap-2 bg-gradient-to-r from-green-500/20 to-emerald-500/20 px-3 py-1.5 rounded-lg border border-green-500/30">
                <Phone className="w-4 h-4 text-green-400" />
                <span className="text-green-300 font-mono">{formatPhoneNumber(profile.phone_number)}</span>
                <button 
                  onClick={() => copyToClipboard(profile.phone_number!, 'phone')}
                  className="text-gray-400 hover:text-green-400 transition-colors"
                  title="Copy Phone Number"
                >
                  {copiedPhone ? <CheckCircle className="w-4 h-4 text-green-400" /> : <Copy className="w-4 h-4" />}
                </button>
              </div>
            </div>
          )}

          <div className="flex gap-6 justify-center md:justify-start mb-4">
            <div><span className="text-white font-bold">{followersCount}</span><span className="text-gray-400 ml-1">Followers</span></div>
            <div><span className="text-white font-bold">{followingCount}</span><span className="text-gray-400 ml-1">Following</span></div>
          </div>

          {editingBio && isOwnProfile ? (
            <div className="flex flex-col gap-2">
              <textarea value={bio} onChange={(e) => setBio(e.target.value)} rows={3}
                className="bg-[#1a1a2e] text-white px-3 py-2 rounded-lg border border-gray-700 focus:border-purple-500 focus:outline-none resize-none" placeholder="Tell us about yourself..." />
              <div className="flex gap-2">
                <button onClick={saveBio} className="bg-purple-600 text-white px-4 py-1 rounded-lg text-sm hover:bg-purple-500">Save</button>
                <button onClick={() => setEditingBio(false)} className="text-gray-400 hover:text-white px-4 py-1">Cancel</button>
              </div>
            </div>
          ) : (
            <div className="flex items-start gap-2">
              <p className="text-gray-300">{profile.bio || (isOwnProfile ? 'Add a bio...' : 'No bio yet')}</p>
              {isOwnProfile && <button onClick={() => setEditingBio(true)} className="text-gray-500 hover:text-purple-400"><Edit2 className="w-4 h-4" /></button>}
            </div>
          )}

          {!isOwnProfile && (
            <button onClick={onFollow}
              className={`mt-4 px-6 py-2 rounded-full font-semibold transition-all ${isFollowing ? 'bg-gray-700 text-white hover:bg-gray-600' : 'bg-gradient-to-r from-purple-600 to-pink-600 text-white hover:shadow-lg hover:shadow-purple-500/50'}`}>
              {isFollowing ? 'Following' : 'Follow'}
            </button>
          )}
        </div>
      </div>
    </div>
  );
}
