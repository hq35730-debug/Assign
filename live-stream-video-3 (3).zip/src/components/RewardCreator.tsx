
import { useState } from 'react';
import { X, Gift, MessageSquare, Music, Smile, Sparkles, Star } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Switch } from '@/components/ui/switch';
import { supabase } from '@/lib/supabase';
import { useToast } from '@/hooks/use-toast';

interface RewardCreatorProps {
  channelId: string;
  streamerName: string;
  isOpen: boolean;
  onClose: () => void;
  onCreated: () => void;
}

const icons = [
  { id: 'gift', icon: Gift, label: 'Gift' },
  { id: 'message', icon: MessageSquare, label: 'Message' },
  { id: 'music', icon: Music, label: 'Music' },
  { id: 'emote', icon: Smile, label: 'Emote' },
  { id: 'sparkles', icon: Sparkles, label: 'Sparkles' },
  { id: 'star', icon: Star, label: 'Star' }
];

const colors = ['#9147ff', '#ff6b6b', '#4ecdc4', '#ffe66d', '#95e1d3', '#f38181'];

export function RewardCreator({ channelId, streamerName, isOpen, onClose, onCreated }: RewardCreatorProps) {
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [cost, setCost] = useState(100);
  const [selectedIcon, setSelectedIcon] = useState('gift');
  const [selectedColor, setSelectedColor] = useState('#9147ff');
  const [requiresInput, setRequiresInput] = useState(false);
  const [loading, setLoading] = useState(false);
  const { toast } = useToast();

  const handleCreate = async () => {
    if (!title || cost < 1) return;
    setLoading(true);
    const { error } = await supabase.functions.invoke('points-manager', {
      body: {
        action: 'create_reward', channel_id: channelId, streamer_name: streamerName,
        title, description, cost, icon: selectedIcon, color: selectedColor, requires_input: requiresInput
      }
    });
    setLoading(false);
    if (error) {
      toast({ title: 'Error', description: 'Failed to create reward', variant: 'destructive' });
    } else {
      toast({ title: 'Success', description: 'Reward created!' });
      onCreated();
      onClose();
      setTitle(''); setDescription(''); setCost(100);
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black/80 flex items-center justify-center z-50 p-4">
      <div className="bg-gray-900 rounded-xl w-full max-w-md border border-gray-700">
        <div className="p-4 border-b border-gray-700 flex items-center justify-between">
          <h3 className="text-lg font-bold text-white">Create Reward</h3>
          <Button variant="ghost" size="icon" onClick={onClose}><X className="w-5 h-5" /></Button>
        </div>
        <div className="p-4 space-y-4">
          <div>
            <label className="text-sm text-gray-400 mb-1 block">Title</label>
            <Input value={title} onChange={(e) => setTitle(e.target.value)} placeholder="Highlight My Message" className="bg-gray-800 border-gray-600" />
          </div>
          <div>
            <label className="text-sm text-gray-400 mb-1 block">Description</label>
            <Textarea value={description} onChange={(e) => setDescription(e.target.value)} placeholder="Your message will be highlighted in chat" className="bg-gray-800 border-gray-600" rows={2} />
          </div>
          <div>
            <label className="text-sm text-gray-400 mb-1 block">Cost</label>
            <Input type="number" value={cost} onChange={(e) => setCost(Number(e.target.value))} min={1} className="bg-gray-800 border-gray-600" />
          </div>
          <div>
            <label className="text-sm text-gray-400 mb-2 block">Icon</label>
            <div className="flex gap-2">
              {icons.map(({ id, icon: Icon }) => (
                <button key={id} onClick={() => setSelectedIcon(id)} className={`p-2 rounded-lg ${selectedIcon === id ? 'bg-purple-600' : 'bg-gray-800'}`}>
                  <Icon className="w-5 h-5 text-white" />
                </button>
              ))}
            </div>
          </div>
          <div>
            <label className="text-sm text-gray-400 mb-2 block">Color</label>
            <div className="flex gap-2">
              {colors.map((color) => (
                <button key={color} onClick={() => setSelectedColor(color)} className={`w-8 h-8 rounded-full ${selectedColor === color ? 'ring-2 ring-white' : ''}`} style={{ backgroundColor: color }} />
              ))}
            </div>
          </div>
          <div className="flex items-center justify-between">
            <span className="text-sm text-gray-400">Requires user input</span>
            <Switch checked={requiresInput} onCheckedChange={setRequiresInput} />
          </div>
        </div>
        <div className="p-4 border-t border-gray-700">
          <Button onClick={handleCreate} disabled={loading || !title} className="w-full bg-purple-600 hover:bg-purple-700">
            {loading ? 'Creating...' : 'Create Reward'}
          </Button>
        </div>
      </div>
    </div>
  );
}
