import { useState, useEffect, useRef, useCallback } from 'react';
import { X, ChevronLeft, ChevronRight, Pause, Play, Volume2, VolumeX, Heart, Send, MoreHorizontal, Eye, Bookmark } from 'lucide-react';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { useAuth } from '@/contexts/AuthContext';
import { supabase } from '@/lib/supabase';
import { AddToHighlightModal } from './AddToHighlightModal';

interface Story {
  id: string;
  user_id: string;
  media_type: 'image' | 'video';
  media_url: string;
  caption?: string;
  created_at: string;
  views_count: number;
  duration?: number;
}

interface StoryUser {
  user_id: string;
  username: string;
  avatar_url?: string;
  stories: Story[];
}

interface StoryViewerProps {
  storyUsers: StoryUser[];
  initialUserIndex: number;
  onClose: () => void;
  onStoryViewed?: (storyId: string) => void;
}

export function StoryViewer({ storyUsers, initialUserIndex, onClose, onStoryViewed }: StoryViewerProps) {
  const { user } = useAuth();
  const [currentUserIndex, setCurrentUserIndex] = useState(initialUserIndex);
  const [currentStoryIndex, setCurrentStoryIndex] = useState(0);
  const [progress, setProgress] = useState(0);
  const [isPaused, setIsPaused] = useState(false);
  const [isMuted, setIsMuted] = useState(false);
  const [reply, setReply] = useState('');
  const [showViewers, setShowViewers] = useState(false);
  const [showAddToHighlight, setShowAddToHighlight] = useState(false);
  const videoRef = useRef<HTMLVideoElement>(null);
  const progressInterval = useRef<NodeJS.Timeout | null>(null);

  const currentUser = storyUsers[currentUserIndex];
  const currentStory = currentUser?.stories[currentStoryIndex];
  const storyDuration = currentStory?.media_type === 'video' ? (currentStory.duration || 15) * 1000 : 5000;

  const markAsViewed = useCallback(async (storyId: string) => {
    if (!user) return;
    try {
      await supabase.functions.invoke('stories-manager', {
        body: { action: 'view_story', story_id: storyId, user_id: user.user_id || user.id }
      });
      onStoryViewed?.(storyId);
    } catch (error) {
      console.error('Failed to mark story as viewed:', error);
    }
  }, [user, onStoryViewed]);

  const goToNextStory = useCallback(() => {
    if (currentStoryIndex < currentUser.stories.length - 1) {
      setCurrentStoryIndex(prev => prev + 1);
      setProgress(0);
    } else if (currentUserIndex < storyUsers.length - 1) {
      setCurrentUserIndex(prev => prev + 1);
      setCurrentStoryIndex(0);
      setProgress(0);
    } else {
      onClose();
    }
  }, [currentStoryIndex, currentUserIndex, currentUser?.stories.length, storyUsers.length, onClose]);

  const goToPrevStory = useCallback(() => {
    if (currentStoryIndex > 0) {
      setCurrentStoryIndex(prev => prev - 1);
      setProgress(0);
    } else if (currentUserIndex > 0) {
      setCurrentUserIndex(prev => prev - 1);
      const prevUser = storyUsers[currentUserIndex - 1];
      setCurrentStoryIndex(prevUser.stories.length - 1);
      setProgress(0);
    }
  }, [currentStoryIndex, currentUserIndex, storyUsers]);

  useEffect(() => {
    if (currentStory) {
      markAsViewed(currentStory.id);
    }
  }, [currentStory?.id, markAsViewed]);

  useEffect(() => {
    if (isPaused || showAddToHighlight) {
      if (progressInterval.current) {
        clearInterval(progressInterval.current);
      }
      if (videoRef.current) {
        videoRef.current.pause();
      }
      return;
    }

    if (videoRef.current) {
      videoRef.current.play();
    }

    const interval = 50;
    const increment = (interval / storyDuration) * 100;

    progressInterval.current = setInterval(() => {
      setProgress(prev => {
        if (prev >= 100) {
          goToNextStory();
          return 0;
        }
        return prev + increment;
      });
    }, interval);

    return () => {
      if (progressInterval.current) {
        clearInterval(progressInterval.current);
      }
    };
  }, [isPaused, showAddToHighlight, storyDuration, goToNextStory]);

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (showAddToHighlight) return;
      if (e.key === 'ArrowRight') goToNextStory();
      if (e.key === 'ArrowLeft') goToPrevStory();
      if (e.key === 'Escape') onClose();
      if (e.key === ' ') {
        e.preventDefault();
        setIsPaused(prev => !prev);
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [goToNextStory, goToPrevStory, onClose, showAddToHighlight]);

  const handleSendReply = async () => {
    if (!reply.trim() || !user || !currentStory) return;
    
    try {
      await supabase.functions.invoke('stories-manager', {
        body: {
          action: 'reply_to_story',
          story_id: currentStory.id,
          user_id: user.user_id || user.id,
          message: reply.trim()
        }
      });
      setReply('');
    } catch (error) {
      console.error('Failed to send reply:', error);
    }
  };

  const formatTime = (dateStr: string) => {
    const date = new Date(dateStr);
    const now = new Date();
    const diff = now.getTime() - date.getTime();
    const hours = Math.floor(diff / 3600000);
    
    if (hours < 1) return 'Just now';
    if (hours < 24) return `${hours}h ago`;
    return date.toLocaleDateString();
  };

  if (!currentUser || !currentStory) return null;

  const isOwnStory = user && (user.user_id === currentUser.user_id || user.id === currentUser.user_id);

  return (
    <div className="fixed inset-0 z-50 bg-black flex items-center justify-center">
      {/* Navigation Areas */}
      <div 
        className="absolute left-0 top-0 bottom-0 w-1/3 z-20 cursor-pointer"
        onClick={goToPrevStory}
      />
      <div 
        className="absolute right-0 top-0 bottom-0 w-1/3 z-20 cursor-pointer"
        onClick={goToNextStory}
      />

      {/* Story Container */}
      <div className="relative w-full max-w-md h-full max-h-[90vh] bg-gray-900 rounded-lg overflow-hidden">
        {/* Progress Bars */}
        <div className="absolute top-0 left-0 right-0 z-30 p-2 flex gap-1">
          {currentUser.stories.map((_, index) => (
            <div key={index} className="flex-1 h-0.5 bg-white/30 rounded-full overflow-hidden">
              <div 
                className="h-full bg-white transition-all duration-100"
                style={{ 
                  width: index < currentStoryIndex 
                    ? '100%' 
                    : index === currentStoryIndex 
                      ? `${progress}%` 
                      : '0%' 
                }}
              />
            </div>
          ))}
        </div>

        {/* Header */}
        <div className="absolute top-4 left-0 right-0 z-30 px-4 pt-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <Avatar className="w-10 h-10 ring-2 ring-white/50">
                <AvatarImage src={currentUser.avatar_url} />
                <AvatarFallback>{currentUser.username[0]?.toUpperCase()}</AvatarFallback>
              </Avatar>
              <div>
                <p className="text-white font-semibold text-sm">{currentUser.username}</p>
                <p className="text-white/60 text-xs">{formatTime(currentStory.created_at)}</p>
              </div>
            </div>
            <div className="flex items-center gap-2">
              <Button 
                variant="ghost" 
                size="icon" 
                className="text-white hover:bg-white/20"
                onClick={() => setIsPaused(!isPaused)}
              >
                {isPaused ? <Play className="w-5 h-5" /> : <Pause className="w-5 h-5" />}
              </Button>
              {currentStory.media_type === 'video' && (
                <Button 
                  variant="ghost" 
                  size="icon" 
                  className="text-white hover:bg-white/20"
                  onClick={() => setIsMuted(!isMuted)}
                >
                  {isMuted ? <VolumeX className="w-5 h-5" /> : <Volume2 className="w-5 h-5" />}
                </Button>
              )}
              <Button 
                variant="ghost" 
                size="icon" 
                className="text-white hover:bg-white/20"
                onClick={onClose}
              >
                <X className="w-5 h-5" />
              </Button>
            </div>
          </div>
        </div>

        {/* Media Content */}
        <div 
          className="w-full h-full flex items-center justify-center"
          onMouseDown={() => setIsPaused(true)}
          onMouseUp={() => setIsPaused(false)}
          onTouchStart={() => setIsPaused(true)}
          onTouchEnd={() => setIsPaused(false)}
        >
          {currentStory.media_type === 'video' ? (
            <video
              ref={videoRef}
              src={currentStory.media_url}
              className="w-full h-full object-contain"
              muted={isMuted}
              playsInline
              autoPlay
            />
          ) : (
            <img
              src={currentStory.media_url}
              alt=""
              className="w-full h-full object-contain"
            />
          )}
        </div>

        {/* Caption */}
        {currentStory.caption && (
          <div className="absolute bottom-24 left-0 right-0 z-30 px-4">
            <p className="text-white text-center bg-black/40 backdrop-blur rounded-lg px-4 py-2">
              {currentStory.caption}
            </p>
          </div>
        )}

        {/* Footer - Reply or Views */}
        <div className="absolute bottom-0 left-0 right-0 z-30 p-4 bg-gradient-to-t from-black/80 to-transparent">
          {isOwnStory ? (
            <div className="flex items-center justify-center gap-4">
              <Button 
                variant="ghost" 
                className="text-white gap-2"
                onClick={() => setShowViewers(!showViewers)}
              >
                <Eye className="w-5 h-5" />
                {currentStory.views_count} views
              </Button>
              <Button 
                variant="ghost" 
                className="text-white gap-2"
                onClick={() => setShowAddToHighlight(true)}
              >
                <Bookmark className="w-5 h-5" />
                Add to Highlight
              </Button>
            </div>
          ) : (
            <div className="flex items-center gap-2">
              <Input
                placeholder="Send a reply..."
                value={reply}
                onChange={(e) => setReply(e.target.value)}
                onKeyDown={(e) => e.key === 'Enter' && handleSendReply()}
                className="bg-white/10 border-white/20 text-white placeholder:text-white/50"
                onFocus={() => setIsPaused(true)}
                onBlur={() => setIsPaused(false)}
              />
              <Button 
                variant="ghost" 
                size="icon" 
                className="text-white hover:bg-white/20"
                onClick={handleSendReply}
              >
                <Send className="w-5 h-5" />
              </Button>
              <Button variant="ghost" size="icon" className="text-white hover:bg-white/20">
                <Heart className="w-5 h-5" />
              </Button>
            </div>
          )}
        </div>

        {/* Navigation Arrows */}
        {currentUserIndex > 0 && (
          <Button
            variant="ghost"
            size="icon"
            className="absolute left-2 top-1/2 -translate-y-1/2 z-30 text-white hover:bg-white/20 hidden md:flex"
            onClick={goToPrevStory}
          >
            <ChevronLeft className="w-8 h-8" />
          </Button>
        )}
        {(currentStoryIndex < currentUser.stories.length - 1 || currentUserIndex < storyUsers.length - 1) && (
          <Button
            variant="ghost"
            size="icon"
            className="absolute right-2 top-1/2 -translate-y-1/2 z-30 text-white hover:bg-white/20 hidden md:flex"
            onClick={goToNextStory}
          >
            <ChevronRight className="w-8 h-8" />
          </Button>
        )}
      </div>

      {/* Add to Highlight Modal */}
      {showAddToHighlight && currentStory && (
        <AddToHighlightModal
          story={{
            id: currentStory.id,
            media_type: currentStory.media_type,
            media_url: currentStory.media_url,
            caption: currentStory.caption,
            created_at: currentStory.created_at,
          }}
          userId={currentUser.user_id}
          onClose={() => setShowAddToHighlight(false)}
        />
      )}
    </div>
  );
}
