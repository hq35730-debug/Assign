import { useState, useEffect } from 'react';
import { X, Plus, Check, Sparkles } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';

interface StoryToAdd {
  id: string;
  media_type: 'image' | 'video';
  media_url: string;
  caption?: string;
  created_at: string;
}

interface ExistingHighlight {
  id: string;
  name: string;
  cover_url?: string;
  story_count: number;
}

interface AddToHighlightModalProps {
  story: StoryToAdd;
  userId: string;
  onClose: () => void;
  onAdded?: (highlightId: string) => void;
}

export function AddToHighlightModal({ story, userId, onClose, onAdded }: AddToHighlightModalProps) {
  const [highlights, setHighlights] = useState<ExistingHighlight[]>([]);
  const [loading, setLoading] = useState(true);
  const [showNewHighlight, setShowNewHighlight] = useState(false);
  const [newHighlightName, setNewHighlightName] = useState('');
  const [selectedHighlight, setSelectedHighlight] = useState<string | null>(null);
  const [saving, setSaving] = useState(false);
  const [success, setSuccess] = useState(false);

  useEffect(() => {
    fetchHighlights();
  }, [userId]);

  const fetchHighlights = async () => {
    setLoading(true);
    // Mock data - in production, fetch from supabase
    const mockHighlights: ExistingHighlight[] = [
      { id: '1', name: 'Gaming', cover_url: 'https://images.unsplash.com/photo-1542751371-adc38448a05e?w=100', story_count: 5 },
      { id: '2', name: 'Behind the Scenes', cover_url: 'https://images.unsplash.com/photo-1598488035139-bdbb2231ce04?w=100', story_count: 3 },
      { id: '3', name: 'Highlights', cover_url: 'https://images.unsplash.com/photo-1511512578047-dfb367046420?w=100', story_count: 8 },
    ];
    setHighlights(mockHighlights);
    setLoading(false);
  };

  const handleAddToHighlight = async (highlightId: string) => {
    setSaving(true);
    setSelectedHighlight(highlightId);
    
    // Simulate API call
    await new Promise(resolve => setTimeout(resolve, 500));
    
    setSuccess(true);
    onAdded?.(highlightId);
    
    setTimeout(() => {
      onClose();
    }, 1000);
  };

  const handleCreateNewHighlight = async () => {
    if (!newHighlightName.trim()) return;
    
    setSaving(true);
    
    // Simulate API call
    await new Promise(resolve => setTimeout(resolve, 500));
    
    const newHighlight: ExistingHighlight = {
      id: `new-${Date.now()}`,
      name: newHighlightName.trim(),
      cover_url: story.media_url,
      story_count: 1,
    };
    
    setHighlights(prev => [...prev, newHighlight]);
    setSuccess(true);
    onAdded?.(newHighlight.id);
    
    setTimeout(() => {
      onClose();
    }, 1000);
  };

  return (
    <Dialog open={true} onOpenChange={onClose}>
      <DialogContent className="bg-[#16213e] border-gray-800 max-w-sm">
        <DialogHeader>
          <DialogTitle className="text-white text-center">
            {success ? 'Added to Highlight!' : 'Add to Highlight'}
          </DialogTitle>
        </DialogHeader>

        {success ? (
          <div className="py-8 flex flex-col items-center gap-4">
            <div className="w-16 h-16 rounded-full bg-green-500/20 flex items-center justify-center">
              <Check className="w-8 h-8 text-green-400" />
            </div>
            <p className="text-gray-400 text-sm">Story saved to highlight</p>
          </div>
        ) : loading ? (
          <div className="py-8 flex justify-center">
            <div className="w-8 h-8 border-2 border-purple-500 border-t-transparent rounded-full animate-spin" />
          </div>
        ) : (
          <div className="space-y-4">
            {/* Story Preview */}
            <div className="flex items-center gap-3 p-3 bg-[#1a1a2e] rounded-lg">
              <div className="w-12 h-12 rounded-lg overflow-hidden bg-gray-800">
                <img src={story.media_url} alt="" className="w-full h-full object-cover" />
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-white text-sm truncate">{story.caption || 'Your story'}</p>
                <p className="text-gray-500 text-xs">
                  {new Date(story.created_at).toLocaleDateString()}
                </p>
              </div>
            </div>

            {/* Existing Highlights */}
            <div className="space-y-2">
              <p className="text-gray-400 text-sm">Add to existing highlight</p>
              <div className="max-h-48 overflow-y-auto space-y-2">
                {highlights.map((highlight) => (
                  <button
                    key={highlight.id}
                    onClick={() => handleAddToHighlight(highlight.id)}
                    disabled={saving}
                    className={`w-full flex items-center gap-3 p-3 rounded-lg transition-colors ${
                      selectedHighlight === highlight.id
                        ? 'bg-purple-600/30 border border-purple-500'
                        : 'bg-[#1a1a2e] hover:bg-[#1f1f3a] border border-transparent'
                    }`}
                  >
                    <div className="w-10 h-10 rounded-full overflow-hidden bg-gray-800 flex-shrink-0">
                      {highlight.cover_url ? (
                        <img src={highlight.cover_url} alt="" className="w-full h-full object-cover" />
                      ) : (
                        <div className="w-full h-full bg-gradient-to-br from-purple-500 to-pink-500 flex items-center justify-center">
                          <Sparkles className="w-4 h-4 text-white" />
                        </div>
                      )}
                    </div>
                    <div className="flex-1 text-left">
                      <p className="text-white text-sm font-medium">{highlight.name}</p>
                      <p className="text-gray-500 text-xs">{highlight.story_count} stories</p>
                    </div>
                    {selectedHighlight === highlight.id && saving && (
                      <div className="w-5 h-5 border-2 border-purple-500 border-t-transparent rounded-full animate-spin" />
                    )}
                  </button>
                ))}
              </div>
            </div>

            {/* Create New Highlight */}
            <div className="pt-2 border-t border-gray-800">
              {showNewHighlight ? (
                <div className="space-y-3">
                  <Input
                    value={newHighlightName}
                    onChange={(e) => setNewHighlightName(e.target.value)}
                    placeholder="Highlight name"
                    className="bg-[#1a1a2e] border-gray-700 text-white"
                    maxLength={30}
                    autoFocus
                  />
                  <div className="flex gap-2">
                    <Button
                      onClick={handleCreateNewHighlight}
                      disabled={!newHighlightName.trim() || saving}
                      className="flex-1 bg-purple-600 hover:bg-purple-700"
                    >
                      {saving ? 'Creating...' : 'Create & Add'}
                    </Button>
                    <Button
                      variant="ghost"
                      onClick={() => {
                        setShowNewHighlight(false);
                        setNewHighlightName('');
                      }}
                      className="text-gray-400"
                    >
                      Cancel
                    </Button>
                  </div>
                </div>
              ) : (
                <button
                  onClick={() => setShowNewHighlight(true)}
                  className="w-full flex items-center gap-3 p-3 rounded-lg bg-[#1a1a2e] hover:bg-[#1f1f3a] transition-colors"
                >
                  <div className="w-10 h-10 rounded-full border-2 border-dashed border-gray-600 flex items-center justify-center">
                    <Plus className="w-5 h-5 text-gray-500" />
                  </div>
                  <span className="text-gray-400 text-sm">Create new highlight</span>
                </button>
              )}
            </div>
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
}
