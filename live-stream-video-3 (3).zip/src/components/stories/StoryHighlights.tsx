import { useState, useEffect } from 'react';
import { Plus, Settings } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/contexts/AuthContext';
import { HighlightViewer } from './HighlightViewer';
import { HighlightCreator } from './HighlightCreator';

export interface Highlight {
  id: string;
  user_id: string;
  name: string;
  cover_url?: string;
  stories: HighlightStory[];
  created_at: string;
  updated_at: string;
}

export interface HighlightStory {
  id: string;
  highlight_id: string;
  story_id: string;
  media_type: 'image' | 'video';
  media_url: string;
  caption?: string;
  created_at: string;
  order_index: number;
}

interface StoryHighlightsProps {
  userId: string;
  isOwnProfile: boolean;
}

export function StoryHighlights({ userId, isOwnProfile }: StoryHighlightsProps) {
  const { user } = useAuth();
  const [highlights, setHighlights] = useState<Highlight[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedHighlight, setSelectedHighlight] = useState<Highlight | null>(null);
  const [showCreator, setShowCreator] = useState(false);
  const [editingHighlight, setEditingHighlight] = useState<Highlight | null>(null);

  useEffect(() => {
    fetchHighlights();
  }, [userId]);

  const fetchHighlights = async () => {
    setLoading(true);
    try {
      // For now, use mock data since we don't have a highlights table yet
      // In production, this would fetch from supabase
      const mockHighlights: Highlight[] = isOwnProfile ? [
        {
          id: '1',
          user_id: userId,
          name: 'Gaming',
          cover_url: 'https://images.unsplash.com/photo-1542751371-adc38448a05e?w=200&h=200&fit=crop',
          stories: [
            { id: 's1', highlight_id: '1', story_id: 'st1', media_type: 'image', media_url: 'https://images.unsplash.com/photo-1542751371-adc38448a05e?w=800', caption: 'Epic gaming session!', created_at: new Date().toISOString(), order_index: 0 },
            { id: 's2', highlight_id: '1', story_id: 'st2', media_type: 'image', media_url: 'https://images.unsplash.com/photo-1538481199705-c710c4e965fc?w=800', caption: 'New setup reveal', created_at: new Date().toISOString(), order_index: 1 },
          ],
          created_at: new Date().toISOString(),
          updated_at: new Date().toISOString(),
        },
        {
          id: '2',
          user_id: userId,
          name: 'Behind Scenes',
          cover_url: 'https://images.unsplash.com/photo-1598488035139-bdbb2231ce04?w=200&h=200&fit=crop',
          stories: [
            { id: 's3', highlight_id: '2', story_id: 'st3', media_type: 'image', media_url: 'https://images.unsplash.com/photo-1598488035139-bdbb2231ce04?w=800', caption: 'Studio tour', created_at: new Date().toISOString(), order_index: 0 },
          ],
          created_at: new Date().toISOString(),
          updated_at: new Date().toISOString(),
        },
        {
          id: '3',
          user_id: userId,
          name: 'Highlights',
          cover_url: 'https://images.unsplash.com/photo-1511512578047-dfb367046420?w=200&h=200&fit=crop',
          stories: [
            { id: 's4', highlight_id: '3', story_id: 'st4', media_type: 'image', media_url: 'https://images.unsplash.com/photo-1511512578047-dfb367046420?w=800', caption: 'Best moments', created_at: new Date().toISOString(), order_index: 0 },
            { id: 's5', highlight_id: '3', story_id: 'st5', media_type: 'image', media_url: 'https://images.unsplash.com/photo-1493711662062-fa541f7f3d24?w=800', caption: 'Victory!', created_at: new Date().toISOString(), order_index: 1 },
            { id: 's6', highlight_id: '3', story_id: 'st6', media_type: 'image', media_url: 'https://images.unsplash.com/photo-1560253023-3ec5d502959f?w=800', caption: 'Celebration', created_at: new Date().toISOString(), order_index: 2 },
          ],
          created_at: new Date().toISOString(),
          updated_at: new Date().toISOString(),
        },
      ] : [];

      setHighlights(mockHighlights);
    } catch (error) {
      console.error('Failed to fetch highlights:', error);
    }
    setLoading(false);
  };

  const handleCreateHighlight = (newHighlight: Highlight) => {
    setHighlights(prev => [...prev, newHighlight]);
    setShowCreator(false);
  };

  const handleUpdateHighlight = (updatedHighlight: Highlight) => {
    setHighlights(prev => prev.map(h => h.id === updatedHighlight.id ? updatedHighlight : h));
    setEditingHighlight(null);
  };

  const handleDeleteHighlight = (highlightId: string) => {
    setHighlights(prev => prev.filter(h => h.id !== highlightId));
  };

  if (loading) {
    return (
      <div className="flex gap-4 overflow-x-auto py-4 px-2">
        {[1, 2, 3].map(i => (
          <div key={i} className="flex-shrink-0 animate-pulse">
            <div className="w-16 h-16 rounded-full bg-gray-700" />
            <div className="w-12 h-3 bg-gray-700 rounded mt-2 mx-auto" />
          </div>
        ))}
      </div>
    );
  }

  if (!isOwnProfile && highlights.length === 0) {
    return null;
  }

  return (
    <div className="bg-[#16213e] rounded-2xl p-4 border border-gray-800">
      <div className="flex items-center justify-between mb-4">
        <h3 className="text-white font-semibold">Story Highlights</h3>
        {isOwnProfile && highlights.length > 0 && (
          <button
            onClick={() => setShowCreator(true)}
            className="text-purple-400 hover:text-purple-300 text-sm flex items-center gap-1"
          >
            <Plus className="w-4 h-4" />
            New
          </button>
        )}
      </div>
      
      <div className="flex gap-4 overflow-x-auto pb-2 scrollbar-hide">
        {/* Create New Highlight Button */}
        {isOwnProfile && (
          <button
            onClick={() => setShowCreator(true)}
            className="flex-shrink-0 flex flex-col items-center gap-2 group"
          >
            <div className="w-16 h-16 rounded-full border-2 border-dashed border-gray-600 flex items-center justify-center group-hover:border-purple-500 transition-colors">
              <Plus className="w-6 h-6 text-gray-500 group-hover:text-purple-400 transition-colors" />
            </div>
            <span className="text-xs text-gray-400 group-hover:text-white transition-colors">New</span>
          </button>
        )}

        {/* Highlight Circles */}
        {highlights.map((highlight) => (
          <div key={highlight.id} className="flex-shrink-0 relative group">
            <button
              onClick={() => setSelectedHighlight(highlight)}
              className="flex flex-col items-center gap-2"
            >
              <div className="w-16 h-16 rounded-full p-0.5 bg-gradient-to-br from-purple-500 via-pink-500 to-orange-500">
                <div className="w-full h-full rounded-full overflow-hidden bg-[#1a1a2e] p-0.5">
                  {highlight.cover_url ? (
                    <img
                      src={highlight.cover_url}
                      alt={highlight.name}
                      className="w-full h-full rounded-full object-cover"
                    />
                  ) : (
                    <div className="w-full h-full rounded-full bg-gradient-to-br from-purple-600 to-pink-600 flex items-center justify-center">
                      <span className="text-white font-bold text-lg">
                        {highlight.name[0]?.toUpperCase()}
                      </span>
                    </div>
                  )}
                </div>
              </div>
              <span className="text-xs text-gray-300 max-w-16 truncate">{highlight.name}</span>
            </button>
            
            {/* Edit button for own profile */}
            {isOwnProfile && (
              <button
                onClick={(e) => {
                  e.stopPropagation();
                  setEditingHighlight(highlight);
                }}
                className="absolute -top-1 -right-1 w-6 h-6 bg-gray-800 rounded-full flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity border border-gray-700 hover:bg-gray-700"
              >
                <Settings className="w-3 h-3 text-gray-400" />
              </button>
            )}
          </div>
        ))}
      </div>

      {/* Highlight Viewer Modal */}
      {selectedHighlight && (
        <HighlightViewer
          highlight={selectedHighlight}
          onClose={() => setSelectedHighlight(null)}
        />
      )}

      {/* Highlight Creator Modal */}
      {(showCreator || editingHighlight) && (
        <HighlightCreator
          userId={userId}
          highlight={editingHighlight}
          onClose={() => {
            setShowCreator(false);
            setEditingHighlight(null);
          }}
          onCreate={handleCreateHighlight}
          onUpdate={handleUpdateHighlight}
          onDelete={handleDeleteHighlight}
        />
      )}
    </div>
  );
}
