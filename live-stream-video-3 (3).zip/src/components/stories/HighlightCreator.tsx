import { useState, useEffect, useRef } from 'react';
import { X, Image, Plus, Trash2, GripVertical, Check, Camera } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Highlight, HighlightStory } from './StoryHighlights';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/contexts/AuthContext';

interface ArchivedStory {
  id: string;
  media_type: 'image' | 'video';
  media_url: string;
  caption?: string;
  created_at: string;
  thumbnail_url?: string;
}

interface HighlightCreatorProps {
  userId: string;
  highlight?: Highlight | null;
  onClose: () => void;
  onCreate: (highlight: Highlight) => void;
  onUpdate: (highlight: Highlight) => void;
  onDelete: (highlightId: string) => void;
}

export function HighlightCreator({ userId, highlight, onClose, onCreate, onUpdate, onDelete }: HighlightCreatorProps) {
  const { user } = useAuth();
  const [name, setName] = useState(highlight?.name || '');
  const [coverUrl, setCoverUrl] = useState(highlight?.cover_url || '');
  const [selectedStories, setSelectedStories] = useState<HighlightStory[]>(highlight?.stories || []);
  const [archivedStories, setArchivedStories] = useState<ArchivedStory[]>([]);
  const [loading, setLoading] = useState(false);
  const [showStorySelector, setShowStorySelector] = useState(false);
  const [showDeleteConfirm, setShowDeleteConfirm] = useState(false);
  const coverInputRef = useRef<HTMLInputElement>(null);

  const isEditing = !!highlight;

  useEffect(() => {
    fetchArchivedStories();
  }, [userId]);

  const fetchArchivedStories = async () => {
    // Mock archived stories - in production, fetch from supabase
    const mockArchived: ArchivedStory[] = [
      { id: 'a1', media_type: 'image', media_url: 'https://images.unsplash.com/photo-1542751371-adc38448a05e?w=400', caption: 'Gaming night', created_at: new Date(Date.now() - 86400000).toISOString() },
      { id: 'a2', media_type: 'image', media_url: 'https://images.unsplash.com/photo-1538481199705-c710c4e965fc?w=400', caption: 'New setup', created_at: new Date(Date.now() - 172800000).toISOString() },
      { id: 'a3', media_type: 'image', media_url: 'https://images.unsplash.com/photo-1598488035139-bdbb2231ce04?w=400', caption: 'Studio vibes', created_at: new Date(Date.now() - 259200000).toISOString() },
      { id: 'a4', media_type: 'image', media_url: 'https://images.unsplash.com/photo-1511512578047-dfb367046420?w=400', caption: 'Victory royale', created_at: new Date(Date.now() - 345600000).toISOString() },
      { id: 'a5', media_type: 'image', media_url: 'https://images.unsplash.com/photo-1493711662062-fa541f7f3d24?w=400', caption: 'Team win', created_at: new Date(Date.now() - 432000000).toISOString() },
      { id: 'a6', media_type: 'image', media_url: 'https://images.unsplash.com/photo-1560253023-3ec5d502959f?w=400', caption: 'Celebration', created_at: new Date(Date.now() - 518400000).toISOString() },
      { id: 'a7', media_type: 'image', media_url: 'https://images.unsplash.com/photo-1552820728-8b83bb6b2b0e?w=400', caption: 'Late night stream', created_at: new Date(Date.now() - 604800000).toISOString() },
      { id: 'a8', media_type: 'image', media_url: 'https://images.unsplash.com/photo-1593305841991-05c297ba4575?w=400', caption: 'Controller life', created_at: new Date(Date.now() - 691200000).toISOString() },
    ];
    setArchivedStories(mockArchived);
  };

  const handleCoverUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (ev) => {
        setCoverUrl(ev.target?.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleSelectStory = (story: ArchivedStory) => {
    const isSelected = selectedStories.some(s => s.story_id === story.id);
    
    if (isSelected) {
      setSelectedStories(prev => prev.filter(s => s.story_id !== story.id));
    } else {
      const newStory: HighlightStory = {
        id: `hs-${Date.now()}-${story.id}`,
        highlight_id: highlight?.id || '',
        story_id: story.id,
        media_type: story.media_type,
        media_url: story.media_url,
        caption: story.caption,
        created_at: story.created_at,
        order_index: selectedStories.length,
      };
      setSelectedStories(prev => [...prev, newStory]);
      
      // Auto-set cover if not set
      if (!coverUrl) {
        setCoverUrl(story.media_url);
      }
    }
  };

  const handleRemoveStory = (storyId: string) => {
    setSelectedStories(prev => prev.filter(s => s.id !== storyId));
  };

  const handleMoveStory = (index: number, direction: 'up' | 'down') => {
    const newIndex = direction === 'up' ? index - 1 : index + 1;
    if (newIndex < 0 || newIndex >= selectedStories.length) return;
    
    const newStories = [...selectedStories];
    [newStories[index], newStories[newIndex]] = [newStories[newIndex], newStories[index]];
    newStories.forEach((s, i) => s.order_index = i);
    setSelectedStories(newStories);
  };

  const handleSave = async () => {
    if (!name.trim() || selectedStories.length === 0) return;
    
    setLoading(true);
    try {
      if (isEditing && highlight) {
        const updatedHighlight: Highlight = {
          ...highlight,
          name: name.trim(),
          cover_url: coverUrl,
          stories: selectedStories,
          updated_at: new Date().toISOString(),
        };
        onUpdate(updatedHighlight);
      } else {
        const newHighlight: Highlight = {
          id: `h-${Date.now()}`,
          user_id: userId,
          name: name.trim(),
          cover_url: coverUrl,
          stories: selectedStories,
          created_at: new Date().toISOString(),
          updated_at: new Date().toISOString(),
        };
        onCreate(newHighlight);
      }
      onClose();
    } catch (error) {
      console.error('Failed to save highlight:', error);
    }
    setLoading(false);
  };

  const handleDelete = () => {
    if (highlight) {
      onDelete(highlight.id);
      onClose();
    }
  };

  const formatDate = (dateStr: string) => {
    const date = new Date(dateStr);
    return date.toLocaleDateString('en-US', { month: 'short', day: 'numeric' });
  };

  return (
    <Dialog open={true} onOpenChange={onClose}>
      <DialogContent className="bg-[#16213e] border-gray-800 max-w-2xl max-h-[90vh] overflow-hidden flex flex-col">
        <DialogHeader>
          <DialogTitle className="text-white">
            {isEditing ? 'Edit Highlight' : 'Create New Highlight'}
          </DialogTitle>
        </DialogHeader>

        <div className="flex-1 overflow-y-auto space-y-6 pr-2">
          {/* Cover & Name Section */}
          <div className="flex gap-4">
            {/* Cover Image */}
            <div className="flex-shrink-0">
              <button
                onClick={() => coverInputRef.current?.click()}
                className="w-20 h-20 rounded-full overflow-hidden bg-[#1a1a2e] border-2 border-dashed border-gray-600 hover:border-purple-500 transition-colors flex items-center justify-center group"
              >
                {coverUrl ? (
                  <img src={coverUrl} alt="Cover" className="w-full h-full object-cover" />
                ) : (
                  <Camera className="w-6 h-6 text-gray-500 group-hover:text-purple-400" />
                )}
              </button>
              <input
                ref={coverInputRef}
                type="file"
                accept="image/*"
                onChange={handleCoverUpload}
                className="hidden"
              />
              <p className="text-xs text-gray-500 text-center mt-1">Cover</p>
            </div>

            {/* Name Input */}
            <div className="flex-1">
              <label className="text-sm text-gray-400 mb-1 block">Highlight Name</label>
              <Input
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="e.g., Gaming, Behind the Scenes"
                className="bg-[#1a1a2e] border-gray-700 text-white"
                maxLength={30}
              />
              <p className="text-xs text-gray-500 mt-1">{name.length}/30 characters</p>
            </div>
          </div>

          {/* Selected Stories */}
          <div>
            <div className="flex items-center justify-between mb-3">
              <label className="text-sm text-gray-400">
                Selected Stories ({selectedStories.length})
              </label>
              <Button
                variant="ghost"
                size="sm"
                onClick={() => setShowStorySelector(!showStorySelector)}
                className="text-purple-400 hover:text-purple-300"
              >
                <Plus className="w-4 h-4 mr-1" />
                Add Stories
              </Button>
            </div>

            {selectedStories.length === 0 ? (
              <div className="bg-[#1a1a2e] rounded-lg p-8 text-center border border-dashed border-gray-700">
                <Image className="w-10 h-10 text-gray-600 mx-auto mb-2" />
                <p className="text-gray-500 text-sm">No stories selected</p>
                <p className="text-gray-600 text-xs">Add stories from your archive</p>
              </div>
            ) : (
              <div className="space-y-2 max-h-48 overflow-y-auto">
                {selectedStories.map((story, index) => (
                  <div
                    key={story.id}
                    className="flex items-center gap-3 bg-[#1a1a2e] rounded-lg p-2 group"
                  >
                    <div className="flex flex-col gap-0.5">
                      <button
                        onClick={() => handleMoveStory(index, 'up')}
                        disabled={index === 0}
                        className="text-gray-500 hover:text-white disabled:opacity-30 disabled:cursor-not-allowed"
                      >
                        <GripVertical className="w-4 h-4" />
                      </button>
                    </div>
                    <div className="w-12 h-12 rounded-lg overflow-hidden bg-gray-800 flex-shrink-0">
                      <img src={story.media_url} alt="" className="w-full h-full object-cover" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="text-white text-sm truncate">{story.caption || 'No caption'}</p>
                      <p className="text-gray-500 text-xs">{formatDate(story.created_at)}</p>
                    </div>
                    <button
                      onClick={() => handleRemoveStory(story.id)}
                      className="text-gray-500 hover:text-red-400 opacity-0 group-hover:opacity-100 transition-opacity"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Story Selector */}
          {showStorySelector && (
            <div>
              <label className="text-sm text-gray-400 mb-3 block">Your Story Archive</label>
              <div className="grid grid-cols-4 gap-2 max-h-64 overflow-y-auto bg-[#1a1a2e] rounded-lg p-3">
                {archivedStories.map((story) => {
                  const isSelected = selectedStories.some(s => s.story_id === story.id);
                  return (
                    <button
                      key={story.id}
                      onClick={() => handleSelectStory(story)}
                      className={`relative aspect-square rounded-lg overflow-hidden group ${
                        isSelected ? 'ring-2 ring-purple-500' : ''
                      }`}
                    >
                      <img
                        src={story.media_url}
                        alt=""
                        className="w-full h-full object-cover"
                      />
                      <div className={`absolute inset-0 transition-colors ${
                        isSelected ? 'bg-purple-500/30' : 'bg-black/0 group-hover:bg-black/30'
                      }`} />
                      {isSelected && (
                        <div className="absolute top-1 right-1 w-5 h-5 bg-purple-500 rounded-full flex items-center justify-center">
                          <Check className="w-3 h-3 text-white" />
                        </div>
                      )}
                      <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black/80 to-transparent p-1">
                        <p className="text-white text-xs truncate">{formatDate(story.created_at)}</p>
                      </div>
                    </button>
                  );
                })}
              </div>
            </div>
          )}

          {/* Delete Section (only for editing) */}
          {isEditing && (
            <div className="pt-4 border-t border-gray-800">
              {showDeleteConfirm ? (
                <div className="bg-red-500/10 border border-red-500/30 rounded-lg p-4">
                  <p className="text-red-400 text-sm mb-3">
                    Are you sure you want to delete this highlight? This action cannot be undone.
                  </p>
                  <div className="flex gap-2">
                    <Button
                      variant="destructive"
                      size="sm"
                      onClick={handleDelete}
                    >
                      Yes, Delete
                    </Button>
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => setShowDeleteConfirm(false)}
                      className="text-gray-400"
                    >
                      Cancel
                    </Button>
                  </div>
                </div>
              ) : (
                <button
                  onClick={() => setShowDeleteConfirm(true)}
                  className="text-red-400 hover:text-red-300 text-sm flex items-center gap-1"
                >
                  <Trash2 className="w-4 h-4" />
                  Delete Highlight
                </button>
              )}
            </div>
          )}
        </div>

        {/* Footer Actions */}
        <div className="flex justify-end gap-3 pt-4 border-t border-gray-800 mt-4">
          <Button
            variant="ghost"
            onClick={onClose}
            className="text-gray-400"
          >
            Cancel
          </Button>
          <Button
            onClick={handleSave}
            disabled={!name.trim() || selectedStories.length === 0 || loading}
            className="bg-purple-600 hover:bg-purple-700"
          >
            {loading ? 'Saving...' : isEditing ? 'Save Changes' : 'Create Highlight'}
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}
