import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Plus } from 'lucide-react';

interface StoryCircleProps {
  userId?: string;
  username: string;
  avatarUrl?: string;
  hasUnseenStory?: boolean;
  isOwn?: boolean;
  onClick?: () => void;
}

export function StoryCircle({ 
  username, 
  avatarUrl, 
  hasUnseenStory = false, 
  isOwn = false,
  onClick 
}: StoryCircleProps) {
  return (
    <div 
      className="flex flex-col items-center gap-1 cursor-pointer group"
      onClick={onClick}
    >
      <div className={`relative p-0.5 rounded-full ${
        hasUnseenStory 
          ? 'bg-gradient-to-tr from-yellow-400 via-pink-500 to-purple-600' 
          : isOwn 
            ? 'bg-gradient-to-tr from-gray-400 to-gray-500'
            : 'bg-gray-600'
      }`}>
        <div className="p-0.5 bg-[#0a0f1c] rounded-full">
          <Avatar className="w-14 h-14 md:w-16 md:h-16 group-hover:scale-105 transition-transform">
            <AvatarImage src={avatarUrl} />
            <AvatarFallback className="bg-gradient-to-br from-purple-500 to-pink-500 text-white text-lg">
              {username[0]?.toUpperCase()}
            </AvatarFallback>
          </Avatar>
        </div>
        {isOwn && (
          <div className="absolute -bottom-0.5 -right-0.5 w-6 h-6 bg-blue-500 rounded-full flex items-center justify-center border-2 border-[#0a0f1c]">
            <Plus className="w-4 h-4 text-white" />
          </div>
        )}
      </div>
      <span className="text-xs text-gray-300 truncate max-w-[70px] text-center">
        {isOwn ? 'Your Story' : username}
      </span>
    </div>
  );
}
