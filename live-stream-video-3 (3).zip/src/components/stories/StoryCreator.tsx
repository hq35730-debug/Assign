import { useState, useRef } from 'react';
import { X, Image, Video, Upload, Loader2, Send, Type, Sparkles } from 'lucide-react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { useAuth } from '@/contexts/AuthContext';
import { supabase } from '@/lib/supabase';
import { useToast } from '@/hooks/use-toast';

interface StoryCreatorProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onStoryCreated?: () => void;
}

export function StoryCreator({ open, onOpenChange, onStoryCreated }: StoryCreatorProps) {
  const { user } = useAuth();
  const { toast } = useToast();
  const [mediaFile, setMediaFile] = useState<File | null>(null);
  const [mediaPreview, setMediaPreview] = useState<string | null>(null);
  const [mediaType, setMediaType] = useState<'image' | 'video' | null>(null);
  const [caption, setCaption] = useState('');
  const [uploading, setUploading] = useState(false);
  const [showCaptionInput, setShowCaptionInput] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (file.type.startsWith('image/')) {
      setMediaType('image');
    } else if (file.type.startsWith('video/')) {
      setMediaType('video');
      // Check video duration (max 60 seconds for stories)
      const video = document.createElement('video');
      video.preload = 'metadata';
      video.onloadedmetadata = () => {
        URL.revokeObjectURL(video.src);
        if (video.duration > 60) {
          toast({ 
            title: 'Video too long', 
            description: 'Stories can be up to 60 seconds', 
            variant: 'destructive' 
          });
          return;
        }
      };
      video.src = URL.createObjectURL(file);
    } else {
      toast({ title: 'Invalid file type', description: 'Please select an image or video', variant: 'destructive' });
      return;
    }

    // Check file size (30MB max for stories)
    if (file.size > 30 * 1024 * 1024) {
      toast({ title: 'File too large', description: 'Maximum size is 30MB', variant: 'destructive' });
      return;
    }

    setMediaFile(file);
    setMediaPreview(URL.createObjectURL(file));
  };

  const handleUpload = async () => {
    if (!mediaFile || !user) return;

    setUploading(true);
    try {
      const userId = user.user_id || user.id;
      const fileExt = mediaFile.name.split('.').pop();
      const fileName = `stories/${userId}/${Date.now()}.${fileExt}`;

      // Upload to storage
      const { data: uploadData, error: uploadError } = await supabase.storage
        .from('media-posts')
        .upload(fileName, mediaFile, {
          cacheControl: '3600',
          upsert: false
        });

      if (uploadError) throw uploadError;

      // Get public URL
      const { data: { publicUrl } } = supabase.storage
        .from('media-posts')
        .getPublicUrl(fileName);

      // Create story
      const { data, error } = await supabase.functions.invoke('stories-manager', {
        body: {
          action: 'create_story',
          user_id: userId,
          username: user.username || user.email?.split('@')[0] || 'User',
          avatar_url: user.avatar_url,
          media_type: mediaType,
          media_url: publicUrl,
          caption
        }
      });

      if (error) throw error;

      toast({ title: 'Story created!', description: 'Your story is now live for 24 hours' });
      
      // Reset form
      resetForm();
      onOpenChange(false);
      onStoryCreated?.();
    } catch (error: any) {
      toast({ title: 'Upload failed', description: error.message, variant: 'destructive' });
    } finally {
      setUploading(false);
    }
  };

  const resetForm = () => {
    setMediaFile(null);
    setMediaPreview(null);
    setMediaType(null);
    setCaption('');
    setShowCaptionInput(false);
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  const clearMedia = () => {
    resetForm();
  };

  return (
    <Dialog open={open} onOpenChange={(isOpen) => {
      if (!isOpen) resetForm();
      onOpenChange(isOpen);
    }}>
      <DialogContent className="max-w-md p-0 overflow-hidden bg-gray-900 border-gray-800">
        <DialogHeader className="p-4 border-b border-gray-800">
          <DialogTitle className="flex items-center gap-2 text-white">
            <Sparkles className="w-5 h-5 text-purple-500" />
            Create Story
          </DialogTitle>
        </DialogHeader>

        <div className="relative">
          {!mediaPreview ? (
            <div 
              className="aspect-[9/16] max-h-[60vh] bg-gray-800 flex flex-col items-center justify-center cursor-pointer hover:bg-gray-750 transition-colors"
              onClick={() => fileInputRef.current?.click()}
            >
              <div className="flex gap-4 mb-6">
                <div className="w-16 h-16 rounded-full bg-purple-500/20 flex items-center justify-center">
                  <Image className="w-8 h-8 text-purple-500" />
                </div>
                <div className="w-16 h-16 rounded-full bg-pink-500/20 flex items-center justify-center">
                  <Video className="w-8 h-8 text-pink-500" />
                </div>
              </div>
              <p className="text-white font-medium mb-2">Add to your story</p>
              <p className="text-gray-400 text-sm text-center px-8">
                Share a photo or video that disappears after 24 hours
              </p>
              <Button className="mt-6 gap-2" variant="secondary">
                <Upload className="w-4 h-4" />
                Select Media
              </Button>
              <input
                ref={fileInputRef}
                type="file"
                accept="image/*,video/*"
                onChange={handleFileSelect}
                className="hidden"
              />
            </div>
          ) : (
            <div className="aspect-[9/16] max-h-[60vh] relative bg-black">
              {/* Close button */}
              <Button
                variant="ghost"
                size="icon"
                className="absolute top-2 right-2 z-10 bg-black/50 hover:bg-black/70 text-white"
                onClick={clearMedia}
              >
                <X className="w-5 h-5" />
              </Button>

              {/* Media preview */}
              {mediaType === 'image' ? (
                <img 
                  src={mediaPreview} 
                  alt="Preview" 
                  className="w-full h-full object-contain"
                />
              ) : (
                <video 
                  src={mediaPreview} 
                  controls 
                  className="w-full h-full object-contain"
                  autoPlay
                  muted
                  loop
                />
              )}

              {/* Caption overlay */}
              {showCaptionInput ? (
                <div className="absolute bottom-20 left-4 right-4">
                  <Input
                    placeholder="Add a caption..."
                    value={caption}
                    onChange={(e) => setCaption(e.target.value)}
                    className="bg-black/60 border-white/20 text-white placeholder:text-white/50 backdrop-blur"
                    maxLength={200}
                    autoFocus
                  />
                </div>
              ) : caption && (
                <div className="absolute bottom-20 left-4 right-4">
                  <p className="text-white text-center bg-black/40 backdrop-blur rounded-lg px-4 py-2">
                    {caption}
                  </p>
                </div>
              )}

              {/* Tools */}
              <div className="absolute right-4 top-1/2 -translate-y-1/2 flex flex-col gap-3">
                <Button
                  variant="ghost"
                  size="icon"
                  className="bg-black/50 hover:bg-black/70 text-white rounded-full"
                  onClick={() => setShowCaptionInput(!showCaptionInput)}
                >
                  <Type className="w-5 h-5" />
                </Button>
              </div>
            </div>
          )}
        </div>

        {/* Footer */}
        {mediaPreview && (
          <div className="p-4 border-t border-gray-800 flex gap-3">
            <Button 
              variant="outline" 
              className="flex-1"
              onClick={clearMedia}
            >
              Discard
            </Button>
            <Button 
              className="flex-1 gap-2 bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700"
              onClick={handleUpload}
              disabled={uploading}
            >
              {uploading ? (
                <>
                  <Loader2 className="w-4 h-4 animate-spin" />
                  Sharing...
                </>
              ) : (
                <>
                  <Send className="w-4 h-4" />
                  Share Story
                </>
              )}
            </Button>
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
}
