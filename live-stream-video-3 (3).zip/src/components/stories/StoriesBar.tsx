import { useState, useEffect } from 'react';
import { Loader2 } from 'lucide-react';
import { ScrollArea, ScrollBar } from '@/components/ui/scroll-area';
import { StoryCircle } from './StoryCircle';
import { StoryViewer } from './StoryViewer';
import { StoryCreator } from './StoryCreator';
import { useAuth } from '@/contexts/AuthContext';
import { supabase } from '@/lib/supabase';

interface Story {
  id: string;
  user_id: string;
  media_type: 'image' | 'video';
  media_url: string;
  caption?: string;
  created_at: string;
  views_count: number;
  duration?: number;
}

interface StoryUser {
  user_id: string;
  username: string;
  avatar_url?: string;
  stories: Story[];
  hasUnseenStory: boolean;
}

interface StoriesBarProps {
  refreshKey?: number;
}

export function StoriesBar({ refreshKey = 0 }: StoriesBarProps) {
  const { user } = useAuth();
  const [storyUsers, setStoryUsers] = useState<StoryUser[]>([]);
  const [loading, setLoading] = useState(true);
  const [viewerOpen, setViewerOpen] = useState(false);
  const [creatorOpen, setCreatorOpen] = useState(false);
  const [selectedUserIndex, setSelectedUserIndex] = useState(0);
  const [ownStories, setOwnStories] = useState<Story[]>([]);
  const [hasOwnStory, setHasOwnStory] = useState(false);

  useEffect(() => {
    loadStories();
  }, [user, refreshKey]);

  const loadStories = async () => {
    setLoading(true);
    try {
      const currentUserId = user?.user_id || user?.id;
      
      const { data, error } = await supabase.functions.invoke('stories-manager', {
        body: { 
          action: 'get_stories_feed',
          user_id: currentUserId
        }
      });

      if (error) throw error;

      // Separate own stories from others
      const allUsers = data?.storyUsers || [];
      const ownUser = allUsers.find((u: StoryUser) => u.user_id === currentUserId);
      const otherUsers = allUsers.filter((u: StoryUser) => u.user_id !== currentUserId);

      if (ownUser) {
        setOwnStories(ownUser.stories);
        setHasOwnStory(true);
      } else {
        setOwnStories([]);
        setHasOwnStory(false);
      }

      setStoryUsers(otherUsers);
    } catch (error) {
      console.error('Failed to load stories:', error);
      // Use mock data for demo
      setStoryUsers(getMockStoryUsers());
    } finally {
      setLoading(false);
    }
  };

  const getMockStoryUsers = (): StoryUser[] => {
    return [
      {
        user_id: 'user1',
        username: 'gaming_pro',
        avatar_url: 'https://api.dicebear.com/7.x/avataaars/svg?seed=gaming',
        hasUnseenStory: true,
        stories: [
          {
            id: 's1',
            user_id: 'user1',
            media_type: 'image',
            media_url: 'https://images.unsplash.com/photo-1542751371-adc38448a05e?w=800',
            caption: 'Epic gaming session! 🎮',
            created_at: new Date(Date.now() - 3600000).toISOString(),
            views_count: 234
          },
          {
            id: 's2',
            user_id: 'user1',
            media_type: 'image',
            media_url: 'https://images.unsplash.com/photo-1511512578047-dfb367046420?w=800',
            caption: 'New setup reveal',
            created_at: new Date(Date.now() - 7200000).toISOString(),
            views_count: 189
          }
        ]
      },
      {
        user_id: 'user2',
        username: 'music_vibes',
        avatar_url: 'https://api.dicebear.com/7.x/avataaars/svg?seed=music',
        hasUnseenStory: true,
        stories: [
          {
            id: 's3',
            user_id: 'user2',
            media_type: 'image',
            media_url: 'https://images.unsplash.com/photo-1493225457124-a3eb161ffa5f?w=800',
            caption: 'Live performance tonight!',
            created_at: new Date(Date.now() - 1800000).toISOString(),
            views_count: 567
          }
        ]
      },
      {
        user_id: 'user3',
        username: 'tech_guru',
        avatar_url: 'https://api.dicebear.com/7.x/avataaars/svg?seed=tech',
        hasUnseenStory: false,
        stories: [
          {
            id: 's4',
            user_id: 'user3',
            media_type: 'image',
            media_url: 'https://images.unsplash.com/photo-1518770660439-4636190af475?w=800',
            caption: 'Building something cool',
            created_at: new Date(Date.now() - 14400000).toISOString(),
            views_count: 432
          }
        ]
      },
      {
        user_id: 'user4',
        username: 'travel_adventures',
        avatar_url: 'https://api.dicebear.com/7.x/avataaars/svg?seed=travel',
        hasUnseenStory: true,
        stories: [
          {
            id: 's5',
            user_id: 'user4',
            media_type: 'image',
            media_url: 'https://images.unsplash.com/photo-1469474968028-56623f02e42e?w=800',
            caption: 'Amazing views!',
            created_at: new Date(Date.now() - 5400000).toISOString(),
            views_count: 891
          }
        ]
      },
      {
        user_id: 'user5',
        username: 'fitness_coach',
        avatar_url: 'https://api.dicebear.com/7.x/avataaars/svg?seed=fitness',
        hasUnseenStory: true,
        stories: [
          {
            id: 's6',
            user_id: 'user5',
            media_type: 'image',
            media_url: 'https://images.unsplash.com/photo-1534438327276-14e5300c3a48?w=800',
            caption: 'Morning workout done!',
            created_at: new Date(Date.now() - 9000000).toISOString(),
            views_count: 345
          }
        ]
      },
      {
        user_id: 'user6',
        username: 'food_lover',
        avatar_url: 'https://api.dicebear.com/7.x/avataaars/svg?seed=food',
        hasUnseenStory: false,
        stories: [
          {
            id: 's7',
            user_id: 'user6',
            media_type: 'image',
            media_url: 'https://images.unsplash.com/photo-1504674900247-0877df9cc836?w=800',
            caption: 'Delicious!',
            created_at: new Date(Date.now() - 18000000).toISOString(),
            views_count: 234
          }
        ]
      }
    ];
  };

  const handleOwnStoryClick = () => {
    if (hasOwnStory && ownStories.length > 0) {
      // View own stories
      const ownUser: StoryUser = {
        user_id: user?.user_id || user?.id || '',
        username: user?.username || 'You',
        avatar_url: user?.avatar_url,
        stories: ownStories,
        hasUnseenStory: false
      };
      setStoryUsers([ownUser, ...storyUsers]);
      setSelectedUserIndex(0);
      setViewerOpen(true);
    } else {
      // Create new story
      setCreatorOpen(true);
    }
  };

  const handleStoryClick = (index: number) => {
    setSelectedUserIndex(index);
    setViewerOpen(true);
  };

  const handleStoryViewed = (storyId: string) => {
    // Update local state to mark story as viewed
    setStoryUsers(prev => prev.map(user => ({
      ...user,
      hasUnseenStory: user.stories.some(s => s.id !== storyId && user.hasUnseenStory)
    })));
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center py-6">
        <Loader2 className="w-6 h-6 animate-spin text-purple-500" />
      </div>
    );
  }

  return (
    <>
      <div className="bg-gray-800/50 rounded-xl p-4 mb-6">
        <ScrollArea className="w-full whitespace-nowrap">
          <div className="flex gap-4">
            {/* Own story circle */}
            {user && (
              <StoryCircle
                username={user.username || 'You'}
                avatarUrl={user.avatar_url}
                hasUnseenStory={hasOwnStory}
                isOwn={true}
                onClick={handleOwnStoryClick}
              />
            )}

            {/* Other users' stories */}
            {storyUsers.map((storyUser, index) => (
              <StoryCircle
                key={storyUser.user_id}
                userId={storyUser.user_id}
                username={storyUser.username}
                avatarUrl={storyUser.avatar_url}
                hasUnseenStory={storyUser.hasUnseenStory}
                onClick={() => handleStoryClick(index)}
              />
            ))}
          </div>
          <ScrollBar orientation="horizontal" />
        </ScrollArea>
      </div>

      {/* Story Viewer */}
      {viewerOpen && storyUsers.length > 0 && (
        <StoryViewer
          storyUsers={storyUsers}
          initialUserIndex={selectedUserIndex}
          onClose={() => setViewerOpen(false)}
          onStoryViewed={handleStoryViewed}
        />
      )}

      {/* Story Creator */}
      <StoryCreator
        open={creatorOpen}
        onOpenChange={setCreatorOpen}
        onStoryCreated={loadStories}
      />
    </>
  );
}
