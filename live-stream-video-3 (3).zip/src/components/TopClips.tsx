import React, { useState, useEffect } from 'react';
import { ClipCard } from './ClipCard';
import { ClipModal } from './ClipModal';
import { Button } from '@/components/ui/button';
import { Scissors, TrendingUp, Clock, Flame } from 'lucide-react';
import { supabase } from '@/lib/supabase';

interface Clip {
  id: string;
  title: string;
  streamer_name: string;
  creator_name: string;
  thumbnail_url: string;
  video_url: string;
  duration: number;
  views: number;
  likes: number;
  shares: number;
  created_at: string;
}

const defaultClips: Clip[] = [
  { id: '1', title: 'Insane 1v5 Clutch Play', streamer_name: 'ProGamer99', creator_name: 'ClipMaster', thumbnail_url: 'https://d64gsuwffb70l.cloudfront.net/6927ca8790687cc18bcac914_1764564208471_1b97c902.webp', video_url: '', duration: 28, views: 125400, likes: 8420, shares: 1250, created_at: new Date(Date.now() - 3600000).toISOString() },
  { id: '2', title: 'Epic Fail Compilation', streamer_name: 'FunnyStreamer', creator_name: 'LaughFactory', thumbnail_url: 'https://d64gsuwffb70l.cloudfront.net/6927ca8790687cc18bcac914_1764564210584_101ee113.webp', video_url: '', duration: 45, views: 89200, likes: 5630, shares: 890, created_at: new Date(Date.now() - 7200000).toISOString() },
  { id: '3', title: 'World Record Speedrun', streamer_name: 'SpeedKing', creator_name: 'RecordBreaker', thumbnail_url: 'https://d64gsuwffb70l.cloudfront.net/6927ca8790687cc18bcac914_1764564212525_778ae1d9.webp', video_url: '', duration: 52, views: 234100, likes: 15200, shares: 3400, created_at: new Date(Date.now() - 14400000).toISOString() },
  { id: '4', title: 'Emotional Subscriber Moment', streamer_name: 'HeartfeltGamer', creator_name: 'FeelGood', thumbnail_url: 'https://d64gsuwffb70l.cloudfront.net/6927ca8790687cc18bcac914_1764564214412_0b4383f8.webp', video_url: '', duration: 35, views: 67800, likes: 9100, shares: 2100, created_at: new Date(Date.now() - 28800000).toISOString() },
  { id: '5', title: 'Impossible Trick Shot', streamer_name: 'TrickMaster', creator_name: 'SkillShot', thumbnail_url: 'https://d64gsuwffb70l.cloudfront.net/6927ca8790687cc18bcac914_1764564216298_e56360ed.webp', video_url: '', duration: 18, views: 156700, likes: 11300, shares: 2800, created_at: new Date(Date.now() - 43200000).toISOString() },
  { id: '6', title: 'Hilarious Rage Quit', streamer_name: 'RageGamer', creator_name: 'SaltMiner', thumbnail_url: 'https://d64gsuwffb70l.cloudfront.net/6927ca8790687cc18bcac914_1764564218175_aed1314d.webp', video_url: '', duration: 22, views: 98400, likes: 7200, shares: 1650, created_at: new Date(Date.now() - 86400000).toISOString() },
];

export const TopClips: React.FC = () => {
  const [clips, setClips] = useState<Clip[]>(defaultClips);
  const [selectedClip, setSelectedClip] = useState<Clip | null>(null);
  const [period, setPeriod] = useState<'24h' | '7d' | '30d'>('7d');

  useEffect(() => {
    const fetchClips = async () => {
      try {
        const { data } = await supabase.functions.invoke('clips-manager', { body: { action: 'get_top_clips', limit: 6, period } });
        const clipsData = Array.isArray(data?.clips) ? data.clips : [];
        if (clipsData.length > 0) setClips(clipsData);
      } catch (err) {
        console.error('Error fetching clips:', err);
      }
    };
    fetchClips();
  }, [period]);


  return (
    <section className="py-8">
      <div className="flex items-center justify-between mb-6">
        <h2 className="text-3xl font-bold text-white flex items-center gap-3"><Scissors className="w-8 h-8 text-purple-400" />Top Clips</h2>
        <div className="flex gap-2">
          {[{ key: '24h', icon: Clock, label: '24h' }, { key: '7d', icon: TrendingUp, label: '7 Days' }, { key: '30d', icon: Flame, label: '30 Days' }].map(({ key, icon: Icon, label }) => (
            <Button key={key} variant={period === key ? 'default' : 'outline'} size="sm" onClick={() => setPeriod(key as any)} className={period === key ? 'bg-purple-600' : 'border-gray-600 text-gray-300'}><Icon className="w-4 h-4 mr-1" />{label}</Button>
          ))}
        </div>
      </div>
      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
        {(Array.isArray(clips) ? clips : []).map(clip => (<ClipCard key={clip.id} clip={clip} onClick={() => setSelectedClip(clip)} />))}
      </div>

      <ClipModal clip={selectedClip} isOpen={!!selectedClip} onClose={() => setSelectedClip(null)} />
    </section>
  );
};
