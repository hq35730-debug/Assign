import React, { useState } from 'react';
import { X, Calendar, Clock, RefreshCw } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { supabase } from '@/lib/supabase';

interface ScheduleCreatorProps {
  channelId: string;
  isOpen: boolean;
  onClose: () => void;
  onCreated: () => void;
  editSchedule?: any;
}

const categories = ['Just Chatting', 'Gaming', 'Music', 'Art', 'Sports', 'Technology', 'Education', 'Cooking'];
const recurrenceOptions = [
  { value: '', label: 'One-time' },
  { value: 'daily', label: 'Daily' },
  { value: 'weekly', label: 'Weekly' },
  { value: 'biweekly', label: 'Every 2 weeks' },
  { value: 'monthly', label: 'Monthly' }
];
const days = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];

export function ScheduleCreator({ channelId, isOpen, onClose, onCreated, editSchedule }: ScheduleCreatorProps) {
  const [title, setTitle] = useState(editSchedule?.title || '');
  const [description, setDescription] = useState(editSchedule?.description || '');
  const [category, setCategory] = useState(editSchedule?.category || 'Just Chatting');
  const [date, setDate] = useState(editSchedule?.scheduled_start?.split('T')[0] || '');
  const [time, setTime] = useState(editSchedule?.scheduled_start?.split('T')[1]?.slice(0,5) || '');
  const [duration, setDuration] = useState('2');
  const [isRecurring, setIsRecurring] = useState(editSchedule?.is_recurring || false);
  const [recurrencePattern, setRecurrencePattern] = useState(editSchedule?.recurrence_pattern || '');
  const [recurrenceDays, setRecurrenceDays] = useState<number[]>(editSchedule?.recurrence_days || []);
  const [saving, setSaving] = useState(false);

  const toggleDay = (day: number) => {
    setRecurrenceDays(prev => prev.includes(day) ? prev.filter(d => d !== day) : [...prev, day]);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!title || !date || !time) return;
    setSaving(true);
    const scheduled_start = new Date(`${date}T${time}`).toISOString();
    const scheduled_end = new Date(new Date(`${date}T${time}`).getTime() + parseInt(duration) * 60 * 60 * 1000).toISOString();
    
    await supabase.functions.invoke('schedule-manager', {
      body: {
        action: editSchedule ? 'update_schedule' : 'create_schedule',
        schedule_id: editSchedule?.id,
        channel_id: channelId, title, description, category, scheduled_start, scheduled_end,
        is_recurring: isRecurring, recurrence_pattern: isRecurring ? recurrencePattern : null,
        recurrence_days: isRecurring && recurrencePattern === 'weekly' ? recurrenceDays : null
      }
    });
    setSaving(false);
    onCreated();
    onClose();
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black/80 flex items-center justify-center z-50 p-4">
      <div className="bg-[#16213e] rounded-2xl w-full max-w-lg max-h-[90vh] overflow-y-auto">
        <div className="p-4 border-b border-gray-700 flex items-center justify-between">
          <h2 className="text-xl font-bold text-white">{editSchedule ? 'Edit' : 'Schedule'} Stream</h2>
          <button onClick={onClose} className="text-gray-400 hover:text-white"><X className="w-6 h-6" /></button>
        </div>
        <form onSubmit={handleSubmit} className="p-4 space-y-4">
          <div>
            <label className="text-gray-300 text-sm mb-1 block">Title</label>
            <input type="text" value={title} onChange={e => setTitle(e.target.value)} className="w-full bg-[#1a1a2e] text-white px-3 py-2 rounded-lg border border-gray-700" placeholder="Stream title" required />
          </div>
          <div>
            <label className="text-gray-300 text-sm mb-1 block">Description</label>
            <textarea value={description} onChange={e => setDescription(e.target.value)} className="w-full bg-[#1a1a2e] text-white px-3 py-2 rounded-lg border border-gray-700 h-20" placeholder="What will you be streaming?" />
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="text-gray-300 text-sm mb-1 block">Category</label>
              <select value={category} onChange={e => setCategory(e.target.value)} className="w-full bg-[#1a1a2e] text-white px-3 py-2 rounded-lg border border-gray-700">
                {categories.map(c => <option key={c} value={c}>{c}</option>)}
              </select>
            </div>
            <div>
              <label className="text-gray-300 text-sm mb-1 block">Duration (hours)</label>
              <input type="number" value={duration} onChange={e => setDuration(e.target.value)} min="1" max="12" className="w-full bg-[#1a1a2e] text-white px-3 py-2 rounded-lg border border-gray-700" />
            </div>
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="text-gray-300 text-sm mb-1 block flex items-center gap-1"><Calendar className="w-4 h-4" /> Date</label>
              <input type="date" value={date} onChange={e => setDate(e.target.value)} className="w-full bg-[#1a1a2e] text-white px-3 py-2 rounded-lg border border-gray-700" required />
            </div>
            <div>
              <label className="text-gray-300 text-sm mb-1 block flex items-center gap-1"><Clock className="w-4 h-4" /> Time</label>
              <input type="time" value={time} onChange={e => setTime(e.target.value)} className="w-full bg-[#1a1a2e] text-white px-3 py-2 rounded-lg border border-gray-700" required />
            </div>
          </div>
          <div className="flex items-center gap-2">
            <input type="checkbox" id="recurring" checked={isRecurring} onChange={e => setIsRecurring(e.target.checked)} className="rounded" />
            <label htmlFor="recurring" className="text-gray-300 flex items-center gap-1"><RefreshCw className="w-4 h-4" /> Recurring stream</label>
          </div>
          {isRecurring && (
            <div className="space-y-3 pl-6 border-l-2 border-purple-500">
              <select value={recurrencePattern} onChange={e => setRecurrencePattern(e.target.value)} className="w-full bg-[#1a1a2e] text-white px-3 py-2 rounded-lg border border-gray-700">
                {recurrenceOptions.slice(1).map(o => <option key={o.value} value={o.value}>{o.label}</option>)}
              </select>
              {recurrencePattern === 'weekly' && (
                <div className="flex gap-1">{days.map((d, i) => (
                  <button key={d} type="button" onClick={() => toggleDay(i)} className={`px-2 py-1 rounded text-xs ${recurrenceDays.includes(i) ? 'bg-purple-600 text-white' : 'bg-gray-700 text-gray-400'}`}>{d}</button>
                ))}</div>
              )}
            </div>
          )}
          <Button type="submit" disabled={saving} className="w-full bg-purple-600 hover:bg-purple-700">{saving ? 'Saving...' : editSchedule ? 'Update Schedule' : 'Create Schedule'}</Button>
        </form>
      </div>
    </div>
  );
}
