import React, { useState, useEffect } from 'react';
import { X, Search, Users, Radio, Zap } from 'lucide-react';
import { supabase } from '@/lib/supabase';

interface Stream {
  id: string;
  user_id: string;
  streamer_name: string;
  title: string;
  category: string;
  viewer_count: number;
  thumbnail_url?: string;
}

interface RaidModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentStreamerId: string;
  currentStreamerName: string;
  viewerCount: number;
  onRaid: (target: Stream) => void;
}

export function RaidModal({ isOpen, onClose, currentStreamerId, currentStreamerName, viewerCount, onRaid }: RaidModalProps) {
  const [streams, setStreams] = useState<Stream[]>([]);
  const [search, setSearch] = useState('');
  const [loading, setLoading] = useState(false);
  const [raiding, setRaiding] = useState(false);

  useEffect(() => {
    if (isOpen) fetchStreams();
  }, [isOpen]);

  const fetchStreams = async () => {
    setLoading(true);
    // Use edge function to get inflated viewer counts
    try {
      const { data: edgeData } = await supabase.functions.invoke('stream-manager', {
        body: { action: 'get_live_streams' }
      });
      if (edgeData?.streams) {
        const filtered = edgeData.streams.filter((s: Stream) => s.user_id !== currentStreamerId);
        setStreams(filtered);
        setLoading(false);
        return;
      }
    } catch {}
    // Fallback to direct query with manual inflation
    const { data } = await supabase.from('live_streams').select('*').eq('is_live', true).neq('user_id', currentStreamerId).order('viewer_count', { ascending: false }).limit(20);
    // Apply inflation multiplier (1 real = 201 displayed)
    const inflatedStreams = (data || []).map(s => ({ ...s, viewer_count: (s.viewer_count || 0) * 201 }));
    setStreams(inflatedStreams);
    setLoading(false);
  };


  const filteredStreams = streams.filter(s => 
    s.streamer_name.toLowerCase().includes(search.toLowerCase()) || s.title.toLowerCase().includes(search.toLowerCase())
  );

  const handleRaid = async (target: Stream) => {
    setRaiding(true);
    await supabase.functions.invoke('raid-manager', {
      body: { action: 'start_raid', raider_id: currentStreamerId, raider_name: currentStreamerName, target_id: target.user_id, target_name: target.streamer_name, viewer_count: viewerCount }
    });
    onRaid(target);
    setRaiding(false);
    onClose();
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black/80 flex items-center justify-center z-50 p-4">
      <div className="bg-[#16213e] rounded-2xl w-full max-w-lg max-h-[80vh] flex flex-col">
        <div className="p-4 border-b border-gray-800 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <Zap className="w-6 h-6 text-yellow-400" />
            <h2 className="text-xl font-bold text-white">Raid a Channel</h2>
          </div>
          <button onClick={onClose} className="text-gray-400 hover:text-white"><X className="w-6 h-6" /></button>
        </div>
        <div className="p-4 border-b border-gray-800">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
            <input value={search} onChange={(e) => setSearch(e.target.value)} placeholder="Search channels..." className="w-full bg-[#1a1a2e] text-white pl-10 pr-4 py-3 rounded-lg border border-gray-700 focus:border-purple-500 focus:outline-none" />
          </div>
          <p className="text-gray-400 text-sm mt-2">Sending {viewerCount} viewers</p>
        </div>
        <div className="flex-1 overflow-y-auto p-4 space-y-2">
          {loading ? <p className="text-gray-400 text-center py-8">Loading streams...</p> : filteredStreams.length === 0 ? <p className="text-gray-400 text-center py-8">No live streams found</p> : filteredStreams.map(stream => (
            <button key={stream.id} onClick={() => handleRaid(stream)} disabled={raiding} className="w-full flex items-center gap-3 p-3 bg-[#1a1a2e] hover:bg-[#252550] rounded-lg transition-colors text-left">
              <div className="w-16 h-10 rounded bg-gray-800 overflow-hidden flex-shrink-0">{stream.thumbnail_url ? <img src={stream.thumbnail_url} className="w-full h-full object-cover" /> : <Radio className="w-full h-full p-2 text-gray-600" />}</div>
              <div className="flex-1 min-w-0">
                <p className="text-white font-semibold truncate">{stream.streamer_name}</p>
                <p className="text-gray-400 text-sm truncate">{stream.title}</p>
              </div>
              <div className="flex items-center gap-1 text-gray-400 text-sm"><Users className="w-4 h-4" />{stream.viewer_count}</div>
            </button>
          ))}
        </div>
      </div>
    </div>
  );
}
