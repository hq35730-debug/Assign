import React, { useState, useEffect, useRef, useCallback } from 'react';
import { Send, Smile, Heart, Star, Diamond, Crown, Rocket, Flame, Trophy, Sparkles, Coins, ThumbsUp, Zap } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/contexts/AuthContext';
import { VIPChatBadge } from './wallet/VIPChatBadge';

interface ChatMessage {
  id: string;
  stream_id: string;
  user_id: string;
  username: string;
  display_name: string;
  message: string;
  badge: string | null;
  is_deleted: boolean;
  created_at: string;
  is_highlighted?: boolean;
  vip_tier_level?: number;
  vip_badge_color?: string;
  type?: 'chat' | 'gift' | 'follow' | 'subscription';
  giftData?: {
    name: string;
    icon: string;
    color: string;
    quantity: number;
    coins: number;
  };
}

interface FloatingReaction {
  id: string;
  emoji: string;
  color: string;
  x: number;
  startTime: number;
}

interface StreamChatOverlayProps {
  streamId: string;
  streamerId: string;
  isStreamer?: boolean;
  showInput?: boolean;
}

const EMOTES = [
  { code: ':hype:', emoji: '🔥' },
  { code: ':love:', emoji: '💜' },
  { code: ':gg:', emoji: '🎮' },
  { code: ':pog:', emoji: '😮' },
  { code: ':lul:', emoji: '😂' },
  { code: ':sad:', emoji: '😢' },
];

// Quick reaction buttons configuration
const QUICK_REACTIONS = [
  { id: 'heart', emoji: '❤️', label: 'Love', color: '#ef4444', icon: Heart },
  { id: 'fire', emoji: '🔥', label: 'Fire', color: '#f97316', icon: Flame },
  { id: 'clap', emoji: '👏', label: 'Clap', color: '#eab308', icon: null },
  { id: 'star', emoji: '⭐', label: 'Star', color: '#fbbf24', icon: Star },
  { id: 'thumbsup', emoji: '👍', label: 'Like', color: '#3b82f6', icon: ThumbsUp },
  { id: 'rocket', emoji: '🚀', label: 'Rocket', color: '#8b5cf6', icon: Rocket },
  { id: 'sparkle', emoji: '✨', label: 'Sparkle', color: '#ec4899', icon: Sparkles },
  { id: 'lightning', emoji: '⚡', label: 'Hype', color: '#06b6d4', icon: Zap },
];

const giftIconMap: Record<string, any> = {
  heart: Heart, star: Star, diamond: Diamond, crown: Crown,
  rocket: Rocket, flame: Flame, trophy: Trophy, sparkles: Sparkles,
};

export const StreamChatOverlay: React.FC<StreamChatOverlayProps> = ({
  streamId,
  streamerId,
  isStreamer = false,
  showInput = true,
}) => {
  const { user } = useAuth();
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [newMessage, setNewMessage] = useState('');
  const [showEmotes, setShowEmotes] = useState(false);
  const [userVip, setUserVip] = useState<any>(null);
  const [isSubscribed, setIsSubscribed] = useState(false);
  const [isMod, setIsMod] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  
  // Reaction state
  const [floatingReactions, setFloatingReactions] = useState<FloatingReaction[]>([]);
  const [reactionCounts, setReactionCounts] = useState<Record<string, number>>({});
  const [totalReactions, setTotalReactions] = useState(0);
  const [showReactionPanel, setShowReactionPanel] = useState(true);
  const reactionIdCounter = useRef(0);

  useEffect(() => {
    loadMessages();
    loadUserVIP();
    checkModStatus();
    checkSubscription();
    loadReactionCounts();

    // Subscribe to chat messages
    const chatChannel = supabase
      .channel(`overlay-chat:${streamId}`)
      .on('postgres_changes', {
        event: 'INSERT',
        schema: 'public',
        table: 'chat_messages',
        filter: `stream_id=eq.${streamId}`
      }, (payload) => {
        if (!payload.new.is_deleted) {
          const newMsg = { ...payload.new, type: 'chat' } as ChatMessage;
          setMessages(prev => [...prev.slice(-29), newMsg]);
        }
      })
      .on('postgres_changes', {
        event: 'UPDATE',
        schema: 'public',
        table: 'chat_messages',
        filter: `stream_id=eq.${streamId}`
      }, (payload) => {
        if (payload.new.is_deleted) {
          setMessages(prev => prev.filter(m => m.id !== payload.new.id));
        }
      })
      .subscribe();

    // Subscribe to gift transactions
    const giftChannel = supabase
      .channel(`overlay-gifts:${streamId}`)
      .on('postgres_changes', {
        event: 'INSERT',
        schema: 'public',
        table: 'gift_transactions',
        filter: `stream_id=eq.${streamId}`
      }, async (payload) => {
        try {
          const tx = payload.new as any;
          const { data } = await supabase.functions.invoke('gifts-manager', {
            body: { action: 'get_gift_types' }
          });
          const gift = (data?.gifts || []).find((g: any) => g.id === tx.gift_type_id);
          if (gift) {
            const giftMessage: ChatMessage = {
              id: `gift-${tx.id}`,
              stream_id: streamId,
              user_id: tx.sender_id,
              username: tx.sender_id?.slice(0, 8) || 'User',
              display_name: tx.sender_id?.slice(0, 8) || 'User',
              message: tx.message || '',
              badge: null,
              is_deleted: false,
              created_at: tx.created_at,
              type: 'gift',
              giftData: {
                name: gift.name,
                icon: gift.icon,
                color: gift.color,
                quantity: tx.quantity,
                coins: tx.coins_spent,
              }
            };
            setMessages(prev => [...prev.slice(-29), giftMessage]);
          }
        } catch (err) {
          console.error('Error processing gift:', err);
        }
      })
      .subscribe();

    // Subscribe to stream reactions
    const reactionChannel = supabase
      .channel(`stream-reactions:${streamId}`)
      .on('postgres_changes', {
        event: 'INSERT',
        schema: 'public',
        table: 'stream_reactions',
        filter: `stream_id=eq.${streamId}`
      }, (payload) => {
        const reaction = payload.new as any;
        const reactionConfig = QUICK_REACTIONS.find(r => r.id === reaction.reaction_type);
        if (reactionConfig) {
          // Add floating reaction from other users
          addFloatingReaction(reactionConfig.emoji, reactionConfig.color, false);
          // Update counts
          setReactionCounts(prev => ({
            ...prev,
            [reaction.reaction_type]: (prev[reaction.reaction_type] || 0) + 1
          }));
          setTotalReactions(prev => prev + 1);
        }
      })
      .subscribe();

    return () => {
      supabase.removeChannel(chatChannel);
      supabase.removeChannel(giftChannel);
      supabase.removeChannel(reactionChannel);
    };
  }, [streamId]);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  // Clean up old floating reactions
  useEffect(() => {
    const interval = setInterval(() => {
      const now = Date.now();
      setFloatingReactions(prev => prev.filter(r => now - r.startTime < 3000));
    }, 100);
    return () => clearInterval(interval);
  }, []);

  const loadMessages = async () => {
    const { data } = await supabase.functions.invoke('chat-manager', {
      body: { action: 'get_messages', stream_id: streamId }
    });
    if (data?.messages) {
      const chatMessages = data.messages.slice(-30).map((m: any) => ({ ...m, type: 'chat' }));
      setMessages(chatMessages);
    }
  };

  const loadUserVIP = async () => {
    if (!user) return;
    const { data } = await supabase.functions.invoke('vip-manager', {
      body: { action: 'get_user_vip', user_id: user.user_id }
    });
    if (data?.status?.current_tier) setUserVip(data.status.current_tier);
  };

  const checkModStatus = async () => {
    if (!user) return;
    const { data } = await supabase
      .from('stream_moderators')
      .select('id')
      .eq('stream_id', streamId)
      .eq('user_id', user.user_id)
      .single();
    setIsMod(!!data);
  };

  const checkSubscription = async () => {
    if (!user) return;
    const { data } = await supabase.functions.invoke('subscription-manager', {
      body: { action: 'check_subscription', subscriber_id: user.user_id, streamer_id: streamerId }
    });
    setIsSubscribed(data?.subscribed || false);
  };

  const loadReactionCounts = async () => {
    // Load existing reaction counts for this stream
    const { data } = await supabase
      .from('stream_reactions')
      .select('reaction_type')
      .eq('stream_id', streamId);
    
    if (data) {
      const counts: Record<string, number> = {};
      data.forEach((r: any) => {
        counts[r.reaction_type] = (counts[r.reaction_type] || 0) + 1;
      });
      setReactionCounts(counts);
      setTotalReactions(data.length);
    }
  };

  const addFloatingReaction = useCallback((emoji: string, color: string, isLocal: boolean = true) => {
    const id = `reaction-${reactionIdCounter.current++}`;
    const x = 70 + Math.random() * 25; // Random x position on right side (70-95%)
    
    setFloatingReactions(prev => [...prev, {
      id,
      emoji,
      color,
      x,
      startTime: Date.now()
    }]);
  }, []);

  const sendReaction = async (reactionType: string, emoji: string, color: string) => {
    // Add local floating reaction immediately for responsiveness
    addFloatingReaction(emoji, color, true);
    
    // Update local counts immediately
    setReactionCounts(prev => ({
      ...prev,
      [reactionType]: (prev[reactionType] || 0) + 1
    }));
    setTotalReactions(prev => prev + 1);

    // Save to database if user is logged in
    if (user) {
      try {
        await supabase.from('stream_reactions').insert({
          stream_id: streamId,
          user_id: user.user_id,
          reaction_type: reactionType
        });
      } catch (err) {
        console.error('Error saving reaction:', err);
      }
    }
  };

  const sendMessage = async () => {
    if (!newMessage.trim() || !user) return;

    let badge = null;
    if (user.user_id === streamerId) badge = 'STREAMER';
    else if (isMod) badge = 'MOD';
    else if (isSubscribed) badge = 'SUB';

    await supabase.functions.invoke('chat-manager', {
      body: {
        action: 'send_message',
        stream_id: streamId,
        user_id: user.user_id,
        username: user.username,
        display_name: user.display_name,
        message: newMessage.trim(),
        badge,
        vip_tier_level: userVip?.tier_level,
        vip_badge_color: userVip?.badge_color
      }
    });
    setNewMessage('');
    setShowEmotes(false);
  };

  const addEmote = (code: string) => {
    setNewMessage(prev => prev + code);
    setShowEmotes(false);
  };

  const renderMessage = (msg: string) => {
    let result = msg;
    EMOTES.forEach(e => {
      result = result.replaceAll(e.code, e.emoji);
    });
    return result;
  };

  const getBadgeStyle = (badge: string | null) => {
    switch (badge) {
      case 'STREAMER': return 'bg-red-500 text-white';
      case 'MOD': return 'bg-green-500 text-white';
      case 'SUB': return 'bg-purple-500 text-white';
      default: return '';
    }
  };

  const getBadgeText = (badge: string | null) => {
    switch (badge) {
      case 'STREAMER': return 'HOST';
      case 'MOD': return 'MOD';
      case 'SUB': return 'SUB';
      default: return '';
    }
  };

  const formatReactionCount = (count: number) => {
    if (count >= 1000000) return `${(count / 1000000).toFixed(1)}M`;
    if (count >= 1000) return `${(count / 1000).toFixed(1)}K`;
    return count.toString();
  };

  return (
    <div className="absolute inset-0 pointer-events-none flex flex-col justify-end overflow-hidden">
      {/* Floating Reactions Animation Layer */}
      <div className="absolute inset-0 pointer-events-none overflow-hidden">
        {floatingReactions.map((reaction) => (
          <div
            key={reaction.id}
            className="absolute animate-float-up"
            style={{
              left: `${reaction.x}%`,
              bottom: '120px',
              fontSize: '28px',
              filter: `drop-shadow(0 0 8px ${reaction.color})`,
              zIndex: 50,
            }}
          >
            {reaction.emoji}
          </div>
        ))}
      </div>

      {/* Total Reaction Counter - Top Right */}
      {totalReactions > 0 && (
        <div className="absolute top-4 right-4 pointer-events-auto">
          <div className="bg-black/60 backdrop-blur-md rounded-full px-4 py-2 flex items-center gap-2 border border-white/10">
            <div className="flex -space-x-1">
              {QUICK_REACTIONS.slice(0, 3).map((r) => (
                <span key={r.id} className="text-sm">{r.emoji}</span>
              ))}
            </div>
            <span className="text-white font-bold text-sm">
              {formatReactionCount(totalReactions)}
            </span>
          </div>
        </div>
      )}

      {/* Messages Container - scrolls up from bottom */}
      <div className="flex-1 flex flex-col justify-end px-4 pb-2 max-h-[50%] overflow-hidden">
        <div className="space-y-2 overflow-y-auto scrollbar-hide">
          {messages.map((msg, index) => (
            <div
              key={msg.id}
              className="animate-slide-up"
              style={{
                animationDelay: `${index * 0.05}s`,
                opacity: Math.max(0.4, 1 - (messages.length - index - 1) * 0.05)
              }}
            >
              {msg.type === 'gift' ? (
                // Gift Message
                <div className="flex items-center gap-2 bg-gradient-to-r from-pink-500/30 to-purple-500/30 backdrop-blur-sm rounded-full px-3 py-2 max-w-fit border border-pink-500/30">
                  {msg.giftData && (
                    <>
                      {(() => {
                        const GiftIcon = giftIconMap[msg.giftData.icon] || Heart;
                        return (
                          <GiftIcon
                            className="w-5 h-5 animate-bounce"
                            style={{ color: msg.giftData.color }}
                          />
                        );
                      })()}
                      <span className="text-white text-sm font-medium">
                        <span className="text-pink-300">{msg.display_name}</span>
                        {' sent '}
                        <span className="font-bold" style={{ color: msg.giftData.color }}>
                          {msg.giftData.quantity}x {msg.giftData.name}
                        </span>
                      </span>
                      <div className="flex items-center gap-1 text-yellow-400 text-xs">
                        <Coins className="w-3 h-3" />
                        <span>{msg.giftData.coins}</span>
                      </div>
                    </>
                  )}
                </div>
              ) : (
                // Regular Chat Message
                <div className="flex items-start gap-2 max-w-[75%]">
                  <div className="flex items-center gap-1.5 bg-black/40 backdrop-blur-sm rounded-2xl px-3 py-1.5">
                    {/* Badges */}
                    {msg.badge && (
                      <span className={`text-[10px] font-bold px-1.5 py-0.5 rounded ${getBadgeStyle(msg.badge)}`}>
                        {getBadgeText(msg.badge)}
                      </span>
                    )}
                    {msg.vip_tier_level && msg.vip_tier_level > 0 && (
                      <VIPChatBadge tierLevel={msg.vip_tier_level} badgeColor={msg.vip_badge_color} size="sm" />
                    )}
                    
                    {/* Username */}
                    <span className={`font-semibold text-sm ${
                      msg.badge === 'STREAMER' ? 'text-red-400' :
                      msg.badge === 'MOD' ? 'text-green-400' :
                      msg.badge === 'SUB' ? 'text-purple-400' :
                      'text-blue-400'
                    }`}>
                      {msg.display_name || msg.username}
                    </span>
                    
                    {/* Message */}
                    <span className="text-white text-sm">
                      {renderMessage(msg.message)}
                    </span>
                  </div>
                </div>
              )}
            </div>
          ))}
          <div ref={messagesEndRef} />
        </div>
      </div>

      {/* Quick Reaction Buttons - Right Side */}
      <div className="absolute right-4 bottom-32 pointer-events-auto">
        <div className="flex flex-col gap-2">
          {/* Toggle Button */}
          <button
            onClick={() => setShowReactionPanel(!showReactionPanel)}
            className="w-12 h-12 rounded-full bg-black/50 backdrop-blur-sm border border-white/20 flex items-center justify-center hover:bg-black/70 transition-all hover:scale-110"
          >
            <Heart className={`w-5 h-5 ${showReactionPanel ? 'text-red-500' : 'text-white'}`} />
          </button>

          {/* Reaction Buttons */}
          {showReactionPanel && (
            <div className="flex flex-col gap-2 animate-fade-in">
              {QUICK_REACTIONS.map((reaction) => (
                <button
                  key={reaction.id}
                  onClick={() => sendReaction(reaction.id, reaction.emoji, reaction.color)}
                  className="group relative w-12 h-12 rounded-full bg-black/50 backdrop-blur-sm border border-white/20 flex items-center justify-center hover:scale-125 transition-all duration-200 active:scale-90"
                  style={{
                    boxShadow: `0 0 0 0 ${reaction.color}`,
                  }}
                  title={reaction.label}
                >
                  <span className="text-xl group-hover:animate-bounce-small">{reaction.emoji}</span>
                  
                  {/* Reaction count badge */}
                  {reactionCounts[reaction.id] > 0 && (
                    <span 
                      className="absolute -top-1 -right-1 text-[10px] font-bold px-1.5 py-0.5 rounded-full min-w-[18px] text-center"
                      style={{ backgroundColor: reaction.color, color: 'white' }}
                    >
                      {formatReactionCount(reactionCounts[reaction.id])}
                    </span>
                  )}
                  
                  {/* Hover label */}
                  <span className="absolute right-full mr-2 px-2 py-1 bg-black/80 text-white text-xs rounded opacity-0 group-hover:opacity-100 transition-opacity whitespace-nowrap">
                    {reaction.label}
                  </span>
                </button>
              ))}
            </div>
          )}
        </div>
      </div>

      {/* Input Area */}
      {showInput && (
        <div className="pointer-events-auto px-4 pb-4 pr-20">
          {/* Emote Picker */}
          {showEmotes && (
            <div className="mb-2 flex gap-1 bg-black/60 backdrop-blur-md rounded-full px-3 py-2 max-w-fit">
              {EMOTES.map(e => (
                <button
                  key={e.code}
                  onClick={() => addEmote(e.code)}
                  className="p-2 hover:bg-white/10 rounded-full text-lg transition-colors"
                  title={e.code}
                >
                  {e.emoji}
                </button>
              ))}
            </div>
          )}
          
          {/* Message Input */}
          <div className="flex items-center gap-2">
            <button
              onClick={() => setShowEmotes(!showEmotes)}
              className="p-3 bg-black/50 hover:bg-black/70 backdrop-blur-sm rounded-full transition-colors"
            >
              <Smile className="w-5 h-5 text-white" />
            </button>
            
            <div className="flex-1 flex items-center bg-black/50 backdrop-blur-sm rounded-full border border-white/10 overflow-hidden">
              <input
                value={newMessage}
                onChange={(e) => setNewMessage(e.target.value)}
                onKeyDown={(e) => e.key === 'Enter' && sendMessage()}
                placeholder={user ? "Say something..." : "Sign in to chat"}
                disabled={!user}
                className="flex-1 bg-transparent text-white px-4 py-3 focus:outline-none text-sm placeholder-gray-400 disabled:opacity-50"
              />
              <button
                onClick={sendMessage}
                disabled={!user || !newMessage.trim()}
                className="px-4 py-3 bg-purple-600 hover:bg-purple-700 disabled:opacity-50 disabled:hover:bg-purple-600 transition-colors"
              >
                <Send className="w-5 h-5 text-white" />
              </button>
            </div>
          </div>
        </div>
      )}

      {/* CSS for animations */}
      <style>{`
        @keyframes slide-up {
          from {
            opacity: 0;
            transform: translateY(20px);
          }
          to {
            opacity: 1;
            transform: translateY(0);
          }
        }
        .animate-slide-up {
          animation: slide-up 0.3s ease-out forwards;
        }
        
        @keyframes float-up {
          0% {
            opacity: 1;
            transform: translateY(0) scale(1) rotate(0deg);
          }
          25% {
            transform: translateY(-100px) scale(1.2) rotate(-10deg);
          }
          50% {
            transform: translateY(-200px) scale(1.1) rotate(10deg);
          }
          75% {
            opacity: 0.7;
            transform: translateY(-300px) scale(1) rotate(-5deg);
          }
          100% {
            opacity: 0;
            transform: translateY(-400px) scale(0.8) rotate(0deg);
          }
        }
        .animate-float-up {
          animation: float-up 3s ease-out forwards;
        }
        
        @keyframes fade-in {
          from {
            opacity: 0;
            transform: translateX(20px);
          }
          to {
            opacity: 1;
            transform: translateX(0);
          }
        }
        .animate-fade-in {
          animation: fade-in 0.3s ease-out forwards;
        }
        
        @keyframes bounce-small {
          0%, 100% {
            transform: translateY(0);
          }
          50% {
            transform: translateY(-4px);
          }
        }
        .group-hover\\:animate-bounce-small:hover {
          animation: bounce-small 0.4s ease-in-out infinite;
        }
        
        .scrollbar-hide::-webkit-scrollbar {
          display: none;
        }
        .scrollbar-hide {
          -ms-overflow-style: none;
          scrollbar-width: none;
        }
      `}</style>
    </div>
  );
};

export default StreamChatOverlay;
