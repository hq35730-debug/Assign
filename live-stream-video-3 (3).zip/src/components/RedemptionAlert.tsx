
import { useState, useEffect } from 'react';
import { Gift, X, Check, XCircle } from 'lucide-react';
import { Button } from '@/components/ui/button';

interface Redemption {
  id: string;
  username: string;
  reward_title: string;
  cost: number;
  user_input?: string;
  status: string;
}

interface RedemptionAlertProps {
  redemption: Redemption;
  isStreamer?: boolean;
  onComplete?: (id: string) => void;
  onReject?: (id: string) => void;
  onDismiss: () => void;
}

export function RedemptionAlert({ redemption, isStreamer, onComplete, onReject, onDismiss }: RedemptionAlertProps) {
  const [visible, setVisible] = useState(true);

  useEffect(() => {
    if (!isStreamer) {
      const timer = setTimeout(() => {
        setVisible(false);
        onDismiss();
      }, 5000);
      return () => clearTimeout(timer);
    }
  }, [isStreamer, onDismiss]);

  if (!visible) return null;

  return (
    <div className="bg-gradient-to-r from-purple-600/90 to-pink-600/90 rounded-lg p-3 border border-purple-400/30 shadow-lg animate-in slide-in-from-right">
      <div className="flex items-start gap-3">
        <div className="w-10 h-10 rounded-full bg-white/20 flex items-center justify-center">
          <Gift className="w-5 h-5 text-white" />
        </div>
        <div className="flex-1 min-w-0">
          <p className="text-sm text-white">
            <span className="font-bold">{redemption.username}</span> redeemed
          </p>
          <p className="text-white font-semibold">{redemption.reward_title}</p>
          {redemption.user_input && (
            <p className="text-sm text-white/80 mt-1 bg-black/20 rounded px-2 py-1">
              "{redemption.user_input}"
            </p>
          )}
          {isStreamer && redemption.status === 'pending' && (
            <div className="flex gap-2 mt-2">
              <Button
                size="sm"
                variant="secondary"
                className="h-7 bg-green-500 hover:bg-green-600 text-white"
                onClick={() => onComplete?.(redemption.id)}
              >
                <Check className="w-3 h-3 mr-1" /> Complete
              </Button>
              <Button
                size="sm"
                variant="secondary"
                className="h-7 bg-red-500 hover:bg-red-600 text-white"
                onClick={() => onReject?.(redemption.id)}
              >
                <XCircle className="w-3 h-3 mr-1" /> Reject
              </Button>
            </div>
          )}
        </div>
        <Button
          variant="ghost"
          size="icon"
          className="h-6 w-6 text-white/70 hover:text-white"
          onClick={onDismiss}
        >
          <X className="w-4 h-4" />
        </Button>
      </div>
    </div>
  );
}
