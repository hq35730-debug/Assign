import React, { useState, useEffect } from 'react';
import { ChevronLeft, ChevronRight, Calendar, Clock, RefreshCw, Bell, Trash2, Edit2 } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/contexts/AuthContext';

interface Schedule {
  id: string;
  channel_id: string;
  title: string;
  description: string;
  category: string;
  scheduled_start: string;
  scheduled_end: string;
  is_recurring: boolean;
  recurrence_pattern: string;
  is_cancelled: boolean;
}

interface ScheduleCalendarProps {
  channelId: string;
  isOwnProfile: boolean;
  onEdit?: (schedule: Schedule) => void;
}

export function ScheduleCalendar({ channelId, isOwnProfile, onEdit }: ScheduleCalendarProps) {
  const { user } = useAuth();
  const [schedules, setSchedules] = useState<Schedule[]>([]);
  const [currentDate, setCurrentDate] = useState(new Date());
  const [view, setView] = useState<'calendar' | 'list'>('calendar');
  const [notifiedSchedules, setNotifiedSchedules] = useState<string[]>([]);

  useEffect(() => {
    fetchSchedules();
  }, [channelId, currentDate]);

  const fetchSchedules = async () => {
    const startOfMonth = new Date(currentDate.getFullYear(), currentDate.getMonth(), 1);
    const endOfMonth = new Date(currentDate.getFullYear(), currentDate.getMonth() + 1, 0);
    const { data } = await supabase.functions.invoke('schedule-manager', {
      body: { action: 'get_channel_schedules', channel_id: channelId, start_date: startOfMonth.toISOString(), end_date: endOfMonth.toISOString() }
    });
    setSchedules(data?.schedules || []);
  };

  const handleDelete = async (id: string) => {
    if (!confirm('Cancel this scheduled stream?')) return;
    await supabase.functions.invoke('schedule-manager', { body: { action: 'cancel_schedule', schedule_id: id } });
    fetchSchedules();
  };

  const handleNotify = async (schedule: Schedule) => {
    if (!user) return;
    const notifyTime = new Date(new Date(schedule.scheduled_start).getTime() - 15 * 60000).toISOString();
    await supabase.functions.invoke('schedule-manager', {
      body: { action: 'subscribe_notification', schedule_id: schedule.id, user_id: user.user_id, notification_time: notifyTime }
    });
    setNotifiedSchedules(prev => [...prev, schedule.id]);
  };

  const getDaysInMonth = () => {
    const year = currentDate.getFullYear();
    const month = currentDate.getMonth();
    const firstDay = new Date(year, month, 1).getDay();
    const daysInMonth = new Date(year, month + 1, 0).getDate();
    const days = [];
    for (let i = 0; i < firstDay; i++) days.push(null);
    for (let i = 1; i <= daysInMonth; i++) days.push(i);
    return days;
  };

  const getSchedulesForDay = (day: number) => {
    return schedules.filter(s => {
      const scheduleDate = new Date(s.scheduled_start);
      return scheduleDate.getDate() === day && scheduleDate.getMonth() === currentDate.getMonth();
    });
  };

  const formatTime = (date: string) => new Date(date).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });

  return (
    <div className="bg-[#16213e] rounded-2xl p-6 border border-gray-800">
      <div className="flex items-center justify-between mb-4">
        <h2 className="text-xl font-bold text-white flex items-center gap-2"><Calendar className="w-5 h-5 text-purple-400" /> Stream Schedule</h2>
        <div className="flex items-center gap-2">
          <button onClick={() => setView('calendar')} className={`px-3 py-1 rounded text-sm ${view === 'calendar' ? 'bg-purple-600 text-white' : 'text-gray-400'}`}>Calendar</button>
          <button onClick={() => setView('list')} className={`px-3 py-1 rounded text-sm ${view === 'list' ? 'bg-purple-600 text-white' : 'text-gray-400'}`}>List</button>
        </div>
      </div>

      <div className="flex items-center justify-between mb-4">
        <button onClick={() => setCurrentDate(new Date(currentDate.getFullYear(), currentDate.getMonth() - 1))} className="text-gray-400 hover:text-white p-1"><ChevronLeft className="w-5 h-5" /></button>
        <span className="text-white font-semibold">{currentDate.toLocaleDateString('en-US', { month: 'long', year: 'numeric' })}</span>
        <button onClick={() => setCurrentDate(new Date(currentDate.getFullYear(), currentDate.getMonth() + 1))} className="text-gray-400 hover:text-white p-1"><ChevronRight className="w-5 h-5" /></button>
      </div>

      {view === 'calendar' ? (
        <div>
          <div className="grid grid-cols-7 gap-1 mb-2">{['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'].map(d => <div key={d} className="text-center text-gray-500 text-xs py-1">{d}</div>)}</div>
          <div className="grid grid-cols-7 gap-1">
            {getDaysInMonth().map((day, i) => {
              const daySchedules = day ? getSchedulesForDay(day) : [];
              const isToday = day === new Date().getDate() && currentDate.getMonth() === new Date().getMonth();
              return (
                <div key={i} className={`min-h-[60px] p-1 rounded ${day ? 'bg-[#1a1a2e]' : ''} ${isToday ? 'ring-2 ring-purple-500' : ''}`}>
                  {day && <span className={`text-xs ${isToday ? 'text-purple-400 font-bold' : 'text-gray-400'}`}>{day}</span>}
                  {daySchedules.slice(0, 2).map(s => (
                    <div key={s.id} className="mt-1 p-1 bg-purple-600/30 rounded text-xs text-purple-300 truncate cursor-pointer hover:bg-purple-600/50" title={s.title}>
                      {formatTime(s.scheduled_start)}
                    </div>
                  ))}
                  {daySchedules.length > 2 && <div className="text-xs text-gray-500 mt-1">+{daySchedules.length - 2} more</div>}
                </div>
              );
            })}
          </div>
        </div>
      ) : (
        <div className="space-y-3 max-h-96 overflow-y-auto">
          {schedules.length === 0 ? <p className="text-gray-400 text-center py-8">No scheduled streams</p> : schedules.map(s => (
            <div key={s.id} className="bg-[#1a1a2e] rounded-lg p-3 border border-gray-700">
              <div className="flex items-start justify-between">
                <div className="flex-1">
                  <div className="flex items-center gap-2">
                    <h3 className="text-white font-semibold">{s.title}</h3>
                    {s.is_recurring && <RefreshCw className="w-3 h-3 text-purple-400" />}
                  </div>
                  <p className="text-gray-400 text-sm">{s.category}</p>
                  <div className="flex items-center gap-2 mt-1 text-xs text-gray-500">
                    <Clock className="w-3 h-3" />
                    {new Date(s.scheduled_start).toLocaleDateString()} at {formatTime(s.scheduled_start)}
                  </div>
                </div>
                <div className="flex items-center gap-1">
                  {!isOwnProfile && user && !notifiedSchedules.includes(s.id) && (
                    <button onClick={() => handleNotify(s)} className="p-1 text-gray-400 hover:text-yellow-400" title="Get notified"><Bell className="w-4 h-4" /></button>
                  )}
                  {notifiedSchedules.includes(s.id) && <Bell className="w-4 h-4 text-yellow-400" />}
                  {isOwnProfile && onEdit && <button onClick={() => onEdit(s)} className="p-1 text-gray-400 hover:text-white"><Edit2 className="w-4 h-4" /></button>}
                  {isOwnProfile && <button onClick={() => handleDelete(s.id)} className="p-1 text-gray-400 hover:text-red-400"><Trash2 className="w-4 h-4" /></button>}
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
