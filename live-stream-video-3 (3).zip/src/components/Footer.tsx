import React from 'react';
import { Link } from 'react-router-dom';
import { Smartphone, Mic } from 'lucide-react';

export const Footer: React.FC = () => {
  return (
    <footer className="bg-[#16213e] border-t border-gray-800 mt-16">
      <div className="max-w-7xl mx-auto px-4 py-12">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8 mb-8">
          <div>
            <h3 className="text-2xl font-bold bg-gradient-to-r from-purple-500 to-pink-500 bg-clip-text text-transparent mb-4">
              Assigned
            </h3>
            <p className="text-gray-400 text-sm mb-4">
              Connect with creators, join dialogues, and share live experiences with communities worldwide.
            </p>
            <div className="space-y-2">
              <p className="text-white text-sm font-semibold flex items-center gap-2">
                <Smartphone className="w-4 h-4" /> Get the App
              </p>
              <div className="flex flex-col gap-2">
                <a 
                  href="https://play.google.com/store/search?q=assigned+live+streaming&c=apps" 
                  target="_blank" 
                  rel="noopener noreferrer"
                  className="inline-flex items-center gap-2 bg-black text-white px-3 py-2 rounded-lg hover:bg-gray-900 transition-colors text-sm"
                >
                  <svg className="w-5 h-5" viewBox="0 0 24 24" fill="currentColor">
                    <path d="M3.609 1.814L13.792 12 3.61 22.186a.996.996 0 0 1-.61-.92V2.734a1 1 0 0 1 .609-.92zm10.89 10.893l2.302 2.302-10.937 6.333 8.635-8.635zm3.199-3.198l2.807 1.626a1 1 0 0 1 0 1.73l-2.808 1.626L15.206 12l2.492-2.491zM5.864 2.658L16.8 8.99l-2.302 2.302-8.634-8.634z"/>
                  </svg>
                  Google Play
                </a>
                <a 
                  href="https://apps.apple.com/search?term=assigned+live+streaming" 
                  target="_blank" 
                  rel="noopener noreferrer"
                  className="inline-flex items-center gap-2 bg-black text-white px-3 py-2 rounded-lg hover:bg-gray-900 transition-colors text-sm"
                >
                  <svg className="w-5 h-5" viewBox="0 0 24 24" fill="currentColor">
                    <path d="M18.71 19.5c-.83 1.24-1.71 2.45-3.05 2.47-1.34.03-1.77-.79-3.29-.79-1.53 0-2 .77-3.27.82-1.31.05-2.3-1.32-3.14-2.53C4.25 17 2.94 12.45 4.7 9.39c.87-1.52 2.43-2.48 4.12-2.51 1.28-.02 2.5.87 3.29.87.78 0 2.26-1.07 3.81-.91.65.03 2.47.26 3.64 1.98-.09.06-2.17 1.28-2.15 3.81.03 3.02 2.65 4.03 2.68 4.04-.03.07-.42 1.44-1.38 2.83M13 3.5c.73-.83 1.94-1.46 2.94-1.5.13 1.17-.34 2.35-1.04 3.19-.69.85-1.83 1.51-2.95 1.42-.15-1.15.41-2.35 1.05-3.11z"/>
                  </svg>
                  App Store
                </a>
              </div>
            </div>
          </div>
          
          <div>
            <h4 className="text-white font-semibold mb-4">Platform</h4>
            <ul className="space-y-2">
              <li><Link to="/" className="text-gray-400 hover:text-purple-400 text-sm">Browse Streams</Link></li>
              <li><Link to="/" className="text-gray-400 hover:text-purple-400 text-sm">Categories</Link></li>
              <li><Link to="/messages" className="text-gray-400 hover:text-purple-400 text-sm">Dialogues</Link></li>
              <li><Link to="/broadcast" className="text-gray-400 hover:text-purple-400 text-sm">Go Live</Link></li>
              <li>
                <Link to="/voice" className="text-gray-400 hover:text-green-400 text-sm flex items-center gap-2">
                  <Mic className="w-3 h-3" /> Voice Rooms
                </Link>
              </li>
            </ul>
          </div>
          
          <div>
            <h4 className="text-white font-semibold mb-4">Support</h4>
            <ul className="space-y-2">
              <li><a href="/" className="text-gray-400 hover:text-purple-400 text-sm">Help Center</a></li>
              <li><a href="/" className="text-gray-400 hover:text-purple-400 text-sm">Community Guidelines</a></li>
              <li><a href="/" className="text-gray-400 hover:text-purple-400 text-sm">Safety</a></li>
              <li><a href="/" className="text-gray-400 hover:text-purple-400 text-sm">Contact Us</a></li>
            </ul>
          </div>
          
          <div>
            <h4 className="text-white font-semibold mb-4">Legal</h4>
            <ul className="space-y-2">
              <li><a href="/" className="text-gray-400 hover:text-purple-400 text-sm">Terms of Service</a></li>
              <li><a href="/" className="text-gray-400 hover:text-purple-400 text-sm">Privacy Policy</a></li>
              <li><a href="/" className="text-gray-400 hover:text-purple-400 text-sm">Cookie Policy</a></li>
              <li><a href="/" className="text-gray-400 hover:text-purple-400 text-sm">DMCA</a></li>
            </ul>
          </div>
        </div>
        
        <div className="border-t border-gray-700 pt-8 text-center">
          <p className="text-gray-400 text-sm">© 2025 Assigned. All rights reserved.</p>
        </div>
      </div>
    </footer>
  );
};
