import React, { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { Slider } from '@/components/ui/slider';
import { Scissors, Clock, Save, X } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { useToast } from '@/hooks/use-toast';

interface ClipCreatorProps {
  isOpen: boolean;
  onClose: () => void;
  streamId: string;
  streamerId: string;
  streamerName: string;
  maxDuration: number;
  currentTime: number;
  thumbnailUrl: string;
}

export const ClipCreator: React.FC<ClipCreatorProps> = ({
  isOpen, onClose, streamId, streamerId, streamerName, maxDuration, currentTime, thumbnailUrl
}) => {
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [startTime, setStartTime] = useState(Math.max(0, currentTime - 30));
  const [endTime, setEndTime] = useState(currentTime);
  const [isCreating, setIsCreating] = useState(false);
  const { toast } = useToast();

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = Math.floor(seconds % 60);
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  const clipDuration = endTime - startTime;

  const handleCreate = async () => {
    if (!title.trim()) {
      toast({ title: 'Error', description: 'Please enter a clip title', variant: 'destructive' });
      return;
    }
    if (clipDuration < 5 || clipDuration > 60) {
      toast({ title: 'Error', description: 'Clip must be between 5-60 seconds', variant: 'destructive' });
      return;
    }

    setIsCreating(true);
    try {
      const { error } = await supabase.functions.invoke('clips-manager', {
        body: {
          action: 'create_clip',
          stream_id: streamId, streamer_id: streamerId, streamer_name: streamerName,
          creator_id: 'user-1', creator_name: 'CurrentUser',
          title, description, start_time: Math.floor(startTime), end_time: Math.floor(endTime),
          thumbnail_url: thumbnailUrl
        }
      });
      if (error) throw error;
      toast({ title: 'Clip Created!', description: 'Your clip has been saved successfully' });
      onClose();
    } catch (err) {
      toast({ title: 'Error', description: 'Failed to create clip', variant: 'destructive' });
    } finally {
      setIsCreating(false);
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="bg-gray-900 border-gray-700 text-white max-w-lg">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2"><Scissors className="w-5 h-5 text-purple-400" />Create Clip</DialogTitle>
        </DialogHeader>
        <div className="space-y-4">
          <div><Label>Title</Label><Input value={title} onChange={(e) => setTitle(e.target.value)} placeholder="Epic moment..." className="bg-gray-800 border-gray-600" maxLength={100} /></div>
          <div><Label>Description (optional)</Label><Textarea value={description} onChange={(e) => setDescription(e.target.value)} placeholder="What happened..." className="bg-gray-800 border-gray-600" rows={2} /></div>
          <div className="bg-gray-800 p-4 rounded-lg space-y-3">
            <div className="flex justify-between text-sm"><span>Start: {formatTime(startTime)}</span><span className="text-purple-400"><Clock className="w-4 h-4 inline mr-1" />{clipDuration}s</span><span>End: {formatTime(endTime)}</span></div>
            <Slider value={[startTime, endTime]} min={0} max={maxDuration} step={1} onValueChange={([s, e]) => { setStartTime(s); setEndTime(e); }} className="my-4" />
            <p className="text-xs text-gray-400 text-center">Clips must be 5-60 seconds</p>
          </div>
          <div className="flex gap-2">
            <Button variant="outline" onClick={onClose} className="flex-1 border-gray-600"><X className="w-4 h-4 mr-2" />Cancel</Button>
            <Button onClick={handleCreate} disabled={isCreating || clipDuration < 5 || clipDuration > 60} className="flex-1 bg-purple-600 hover:bg-purple-700"><Save className="w-4 h-4 mr-2" />{isCreating ? 'Creating...' : 'Create Clip'}</Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
};
