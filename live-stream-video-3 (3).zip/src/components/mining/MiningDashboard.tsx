import { useState, useEffect } from 'react';
import { Pickaxe, Wallet, History, Trophy, Zap, Play, Square, RefreshCw, ArrowRightLeft } from 'lucide-react';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { MiningWallet } from './MiningWallet';
import { MiningHistory } from './MiningHistory';
import { MiningLeaderboard } from './MiningLeaderboard';
import { ActiveMiningIndicator } from './ActiveMiningIndicator';
import { STCConverter } from './STCConverter';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/contexts/AuthContext';
import { useStream } from '@/contexts/StreamContext';
import { useToast } from '@/hooks/use-toast';

export function MiningDashboard() {
  const { user } = useAuth();
  const { isStreaming, currentStream } = useStream();
  const { toast } = useToast();
  
  const [wallet, setWallet] = useState<any>(null);
  const [stats, setStats] = useState<any>(null);
  const [activeSession, setActiveSession] = useState<any>(null);
  const [transactions, setTransactions] = useState<any[]>([]);
  const [sessions, setSessions] = useState<any[]>([]);
  const [blocks, setBlocks] = useState<any[]>([]);
  const [leaderboard, setLeaderboard] = useState<any[]>([]);
  const [networkStats, setNetworkStats] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [miningLoading, setMiningLoading] = useState(false);

  useEffect(() => {
    if (user?.user_id) {
      loadWalletData();
      loadHistory();
      loadLeaderboard();
    } else {
      setLoading(false);
    }
  }, [user?.user_id]);

  // Auto-start mining when stream starts
  useEffect(() => {
    if (isStreaming && currentStream && user?.user_id && !activeSession) {
      startMining();
    }
  }, [isStreaming, currentStream]);

  // Update mining progress periodically
  useEffect(() => {
    if (!activeSession) return;

    const interval = setInterval(async () => {
      try {
        await supabase.functions.invoke('mining-manager', {
          body: {
            action: 'update_mining',
            user_id: user?.user_id,
            viewer_count: currentStream?.viewer_count || 0
          }
        });
      } catch (error) {
        console.error('Failed to update mining:', error);
      }
    }, 60000); // Update every minute

    return () => clearInterval(interval);
  }, [activeSession, currentStream]);

  const loadWalletData = async () => {
    try {
      const { data, error } = await supabase.functions.invoke('mining-manager', {
        body: { action: 'get_wallet', user_id: user?.user_id }
      });

      if (data) {
        setWallet(data.wallet);
        setStats(data.stats);
        setActiveSession(data.activeSession);
        setTransactions(data.transactions || []);
      }
    } catch (error) {
      console.error('Failed to load wallet:', error);
    } finally {
      setLoading(false);
    }
  };

  const loadHistory = async () => {
    try {
      const { data } = await supabase.functions.invoke('mining-manager', {
        body: { action: 'get_history', user_id: user?.user_id }
      });

      if (data) {
        setSessions(data.sessions || []);
        setTransactions(data.transactions || []);
        setBlocks(data.blocks || []);
      }
    } catch (error) {
      console.error('Failed to load history:', error);
    }
  };

  const loadLeaderboard = async () => {
    try {
      const { data } = await supabase.functions.invoke('mining-manager', {
        body: { action: 'get_leaderboard' }
      });

      if (data) {
        setLeaderboard(data.leaderboard || []);
        setNetworkStats(data.network_stats);
      }
    } catch (error) {
      console.error('Failed to load leaderboard:', error);
    }
  };

  const startMining = async () => {
    if (!user?.user_id) {
      toast({ title: 'Sign In Required', description: 'Please sign in to start mining', variant: 'destructive' });
      return;
    }

    if (!isStreaming && !currentStream) {
      toast({ title: 'Stream Required', description: 'You need to be streaming to mine StreamCoin', variant: 'destructive' });
      return;
    }

    setMiningLoading(true);
    try {
      const { data, error } = await supabase.functions.invoke('mining-manager', {
        body: {
          action: 'start_mining',
          user_id: user.user_id,
          stream_id: currentStream?.id || `stream_${Date.now()}`
        }
      });

      if (data?.success) {
        setActiveSession(data.session);
        toast({ title: 'Mining Started!', description: data.message });
      } else {
        toast({ title: 'Mining Active', description: data?.message || 'Mining is already running' });
      }
    } catch (error) {
      console.error('Failed to start mining:', error);
      toast({ title: 'Error', description: 'Failed to start mining', variant: 'destructive' });
    } finally {
      setMiningLoading(false);
    }
  };

  const stopMining = async () => {
    if (!user?.user_id || !activeSession) return;

    setMiningLoading(true);
    try {
      const { data, error } = await supabase.functions.invoke('mining-manager', {
        body: { action: 'stop_mining', user_id: user.user_id }
      });

      if (data?.success) {
        setActiveSession(null);
        toast({
          title: 'Mining Complete!',
          description: `You earned ${data.rewards.total.toFixed(8)} ${wallet?.currency_symbol || 'STC'}`
        });
        // Refresh data
        loadWalletData();
        loadHistory();
        loadLeaderboard();
      }
    } catch (error) {
      console.error('Failed to stop mining:', error);
      toast({ title: 'Error', description: 'Failed to stop mining', variant: 'destructive' });
    } finally {
      setMiningLoading(false);
    }
  };

  if (!user) {
    return (
      <Card className="p-8 text-center">
        <Pickaxe className="w-16 h-16 text-amber-500 mx-auto mb-4" />
        <h2 className="text-2xl font-bold mb-2">StreamCoin Mining</h2>
        <p className="text-muted-foreground mb-4">
          Sign in to start mining cryptocurrency while you stream!
        </p>
        <Button onClick={() => window.location.href = '/login'}>Sign In to Mine</Button>
      </Card>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 rounded-full bg-gradient-to-br from-amber-400 to-orange-500 flex items-center justify-center">
            <Pickaxe className="w-6 h-6 text-white" />
          </div>
          <div>
            <h1 className="text-2xl font-bold">StreamCoin Mining</h1>
            <p className="text-muted-foreground">Mine cryptocurrency while you stream</p>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <Button variant="outline" size="sm" onClick={() => { loadWalletData(); loadHistory(); loadLeaderboard(); }}>
            <RefreshCw className="w-4 h-4 mr-1" />
            Refresh
          </Button>
          {activeSession ? (
            <Button variant="destructive" onClick={stopMining} disabled={miningLoading}>
              <Square className="w-4 h-4 mr-2" />
              Stop Mining
            </Button>
          ) : (
            <Button
              onClick={startMining}
              disabled={miningLoading || (!isStreaming && !currentStream)}
              className="bg-gradient-to-r from-amber-500 to-orange-500 hover:from-amber-600 hover:to-orange-600"
            >
              <Play className="w-4 h-4 mr-2" />
              {isStreaming ? 'Start Mining' : 'Go Live to Mine'}
            </Button>
          )}
        </div>
      </div>

      {/* Active Mining Indicator */}
      {activeSession && (
        <ActiveMiningIndicator
          session={activeSession}
          currencySymbol={wallet?.currency_symbol}
        />
      )}

      {/* How Mining Works */}
      {!activeSession && (
        <Card className="p-6 bg-gradient-to-r from-amber-500/10 via-orange-500/5 to-yellow-500/10 border-amber-500/20">
          <h3 className="font-semibold mb-3 flex items-center gap-2">
            <Zap className="w-5 h-5 text-amber-400" />
            How Mining Works
          </h3>
          <div className="grid md:grid-cols-4 gap-4 text-sm">
            <div className="flex items-start gap-2">
              <div className="w-6 h-6 rounded-full bg-amber-500/20 flex items-center justify-center text-amber-400 font-bold text-xs">1</div>
              <div>
                <p className="font-medium">Go Live</p>
                <p className="text-muted-foreground">Start streaming to begin mining</p>
              </div>
            </div>
            <div className="flex items-start gap-2">
              <div className="w-6 h-6 rounded-full bg-amber-500/20 flex items-center justify-center text-amber-400 font-bold text-xs">2</div>
              <div>
                <p className="font-medium">Earn Coins</p>
                <p className="text-muted-foreground">Mine {wallet?.currency_symbol || 'STC'} every minute</p>
              </div>
            </div>
            <div className="flex items-start gap-2">
              <div className="w-6 h-6 rounded-full bg-amber-500/20 flex items-center justify-center text-amber-400 font-bold text-xs">3</div>
              <div>
                <p className="font-medium">Viewer Bonus</p>
                <p className="text-muted-foreground">More viewers = more coins</p>
              </div>
            </div>
            <div className="flex items-start gap-2">
              <div className="w-6 h-6 rounded-full bg-amber-500/20 flex items-center justify-center text-amber-400 font-bold text-xs">4</div>
              <div>
                <p className="font-medium">Mine Blocks</p>
                <p className="text-muted-foreground">Earn block rewards every 5 min</p>
              </div>
            </div>
          </div>
        </Card>
      )}

      {/* Main Content Tabs */}
      <Tabs defaultValue="wallet" className="space-y-4">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="wallet" className="gap-2">
            <Wallet className="w-4 h-4" />
            Wallet
          </TabsTrigger>
          <TabsTrigger value="convert" className="gap-2">
            <ArrowRightLeft className="w-4 h-4" />
            Convert
          </TabsTrigger>
          <TabsTrigger value="history" className="gap-2">
            <History className="w-4 h-4" />
            History
          </TabsTrigger>
          <TabsTrigger value="leaderboard" className="gap-2">
            <Trophy className="w-4 h-4" />
            Leaderboard
          </TabsTrigger>
        </TabsList>

        <TabsContent value="wallet">
          {loading ? (
            <div className="space-y-4">
              <div className="h-48 bg-black/20 rounded-lg animate-pulse" />
              <div className="grid grid-cols-4 gap-4">
                {[...Array(4)].map((_, i) => (
                  <div key={i} className="h-24 bg-black/20 rounded-lg animate-pulse" />
                ))}
              </div>
            </div>
          ) : (
            <MiningWallet wallet={wallet} stats={stats} />
          )}
        </TabsContent>

        <TabsContent value="convert">
          <STCConverter />
        </TabsContent>

        <TabsContent value="history">
          <MiningHistory
            transactions={transactions}
            sessions={sessions}
            blocks={blocks}
            currencySymbol={wallet?.currency_symbol}
          />
        </TabsContent>

        <TabsContent value="leaderboard">
          <MiningLeaderboard
            leaderboard={leaderboard}
            networkStats={networkStats}
          />
        </TabsContent>
      </Tabs>
    </div>
  );
}
