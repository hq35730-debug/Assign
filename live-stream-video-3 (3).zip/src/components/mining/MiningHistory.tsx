import { useState } from 'react';
import { Clock, ArrowUpRight, ArrowDownLeft, Pickaxe, Gift, ExternalLink } from 'lucide-react';
import { Card } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { ScrollArea } from '@/components/ui/scroll-area';

interface Transaction {
  id: string;
  tx_hash: string;
  tx_type: string;
  amount: number;
  from_address?: string;
  to_address?: string;
  status: string;
  created_at: string;
  metadata?: any;
}

interface Session {
  id: string;
  stream_id: string;
  started_at: string;
  ended_at?: string;
  duration_minutes: number;
  coins_mined: number;
  avg_viewers: number;
  blocks_mined: number;
  is_active: boolean;
}

interface Block {
  id: string;
  block_number: number;
  block_hash: string;
  previous_hash: string;
  reward: number;
  created_at: string;
}

interface MiningHistoryProps {
  transactions: Transaction[];
  sessions: Session[];
  blocks: Block[];
  currencySymbol?: string;
}

export function MiningHistory({ transactions, sessions, blocks, currencySymbol = 'STC' }: MiningHistoryProps) {
  const formatDate = (dateStr: string) => {
    const date = new Date(dateStr);
    return date.toLocaleDateString('en-US', {
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  const formatDuration = (minutes: number) => {
    const hrs = Math.floor(minutes / 60);
    const mins = minutes % 60;
    if (hrs > 0) return `${hrs}h ${mins}m`;
    return `${mins}m`;
  };

  const truncateHash = (hash: string) => {
    if (!hash) return '';
    return `${hash.slice(0, 10)}...${hash.slice(-6)}`;
  };

  const getTransactionIcon = (type: string) => {
    switch (type) {
      case 'mine':
        return <Pickaxe className="w-4 h-4 text-amber-400" />;
      case 'transfer':
        return <ArrowUpRight className="w-4 h-4 text-blue-400" />;
      case 'bonus':
        return <Gift className="w-4 h-4 text-pink-400" />;
      default:
        return <Clock className="w-4 h-4 text-gray-400" />;
    }
  };

  return (
    <Tabs defaultValue="transactions" className="space-y-4">
      <TabsList className="grid w-full grid-cols-3">
        <TabsTrigger value="transactions">Transactions</TabsTrigger>
        <TabsTrigger value="sessions">Mining Sessions</TabsTrigger>
        <TabsTrigger value="blocks">Blocks Mined</TabsTrigger>
      </TabsList>

      <TabsContent value="transactions">
        <Card className="p-4">
          <ScrollArea className="h-[400px]">
            {transactions.length === 0 ? (
              <div className="text-center py-8 text-muted-foreground">
                <Pickaxe className="w-12 h-12 mx-auto mb-3 opacity-50" />
                <p>No transactions yet</p>
                <p className="text-sm">Start streaming to mine {currencySymbol}!</p>
              </div>
            ) : (
              <div className="space-y-3">
                {transactions.map((tx) => (
                  <div
                    key={tx.id}
                    className="flex items-center justify-between p-3 rounded-lg bg-black/20 hover:bg-black/30 transition-colors"
                  >
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 rounded-full bg-black/30 flex items-center justify-center">
                        {getTransactionIcon(tx.tx_type)}
                      </div>
                      <div>
                        <div className="flex items-center gap-2">
                          <span className="font-medium capitalize">{tx.tx_type}</span>
                          <Badge variant="outline" className="text-xs">
                            {tx.status}
                          </Badge>
                        </div>
                        <p className="text-xs text-muted-foreground font-mono">
                          {truncateHash(tx.tx_hash)}
                        </p>
                      </div>
                    </div>
                    <div className="text-right">
                      <p className={`font-bold ${tx.amount >= 0 ? 'text-green-400' : 'text-red-400'}`}>
                        {tx.amount >= 0 ? '+' : ''}{tx.amount.toFixed(8)} {currencySymbol}
                      </p>
                      <p className="text-xs text-muted-foreground">{formatDate(tx.created_at)}</p>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </ScrollArea>
        </Card>
      </TabsContent>

      <TabsContent value="sessions">
        <Card className="p-4">
          <ScrollArea className="h-[400px]">
            {sessions.length === 0 ? (
              <div className="text-center py-8 text-muted-foreground">
                <Clock className="w-12 h-12 mx-auto mb-3 opacity-50" />
                <p>No mining sessions yet</p>
                <p className="text-sm">Go live to start mining!</p>
              </div>
            ) : (
              <div className="space-y-3">
                {sessions.map((session) => (
                  <div
                    key={session.id}
                    className="p-4 rounded-lg bg-black/20 hover:bg-black/30 transition-colors"
                  >
                    <div className="flex items-center justify-between mb-3">
                      <div className="flex items-center gap-2">
                        {session.is_active ? (
                          <Badge className="bg-green-500/20 text-green-400 border-green-500/30">
                            <div className="w-2 h-2 rounded-full bg-green-400 mr-1 animate-pulse" />
                            Active
                          </Badge>
                        ) : (
                          <Badge variant="outline">Completed</Badge>
                        )}
                        <span className="text-sm text-muted-foreground">
                          {formatDate(session.started_at)}
                        </span>
                      </div>
                      <span className="text-lg font-bold text-amber-400">
                        +{session.coins_mined.toFixed(8)} {currencySymbol}
                      </span>
                    </div>
                    <div className="grid grid-cols-3 gap-4 text-sm">
                      <div>
                        <p className="text-muted-foreground">Duration</p>
                        <p className="font-medium">{formatDuration(session.duration_minutes)}</p>
                      </div>
                      <div>
                        <p className="text-muted-foreground">Avg Viewers</p>
                        <p className="font-medium">{session.avg_viewers}</p>
                      </div>
                      <div>
                        <p className="text-muted-foreground">Blocks</p>
                        <p className="font-medium">{session.blocks_mined}</p>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </ScrollArea>
        </Card>
      </TabsContent>

      <TabsContent value="blocks">
        <Card className="p-4">
          <ScrollArea className="h-[400px]">
            {blocks.length === 0 ? (
              <div className="text-center py-8 text-muted-foreground">
                <svg className="w-12 h-12 mx-auto mb-3 opacity-50" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                  <rect x="3" y="3" width="18" height="18" rx="2" />
                  <path d="M3 9h18M9 21V9" />
                </svg>
                <p>No blocks mined yet</p>
                <p className="text-sm">Stream for 5+ minutes to mine a block!</p>
              </div>
            ) : (
              <div className="space-y-3">
                {blocks.map((block) => (
                  <div
                    key={block.id}
                    className="p-4 rounded-lg bg-gradient-to-r from-amber-500/10 to-orange-500/5 border border-amber-500/20"
                  >
                    <div className="flex items-center justify-between mb-2">
                      <div className="flex items-center gap-2">
                        <div className="w-8 h-8 rounded bg-amber-500/20 flex items-center justify-center">
                          <span className="text-sm font-bold text-amber-400">#{block.block_number}</span>
                        </div>
                        <span className="font-medium">Block #{block.block_number}</span>
                      </div>
                      <span className="text-green-400 font-bold">
                        +{block.reward.toFixed(8)} {currencySymbol}
                      </span>
                    </div>
                    <div className="space-y-1 text-xs">
                      <div className="flex items-center justify-between">
                        <span className="text-muted-foreground">Hash</span>
                        <code className="font-mono text-amber-300/70">{truncateHash(block.block_hash)}</code>
                      </div>
                      <div className="flex items-center justify-between">
                        <span className="text-muted-foreground">Previous</span>
                        <code className="font-mono text-gray-500">{truncateHash(block.previous_hash)}</code>
                      </div>
                      <div className="flex items-center justify-between">
                        <span className="text-muted-foreground">Mined</span>
                        <span>{formatDate(block.created_at)}</span>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </ScrollArea>
        </Card>
      </TabsContent>
    </Tabs>
  );
}
