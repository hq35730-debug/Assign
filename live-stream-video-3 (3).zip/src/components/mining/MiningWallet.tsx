import { useState } from 'react';
import { Wallet, Copy, Check, ExternalLink, TrendingUp, Zap, Shield, Key, Coins, ArrowUpRight } from 'lucide-react';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { useToast } from '@/hooks/use-toast';

interface MiningWalletProps {
  wallet: {
    balance: number;
    total_mined: number;
    total_withdrawn: number;
    mining_power: number;
    wallet_address: string;
    currency_name: string;
    currency_symbol: string;
    address_type?: string;
    public_key?: string;
    pending_balance?: number;
    locked_balance?: number;
  } | null;
  stats: {
    blocks_mined: number;
    latest_block: number;
    mining_rate: number;
    viewer_bonus: number;
    current_block_reward?: number;
    network_difficulty?: number;
    total_supply?: number;
    max_supply?: number;
    circulating_percentage?: string;
  } | null;
}

export function MiningWallet({ wallet, stats }: MiningWalletProps) {
  const { toast } = useToast();
  const [copied, setCopied] = useState<string | null>(null);

  const copyToClipboard = (text: string, label: string) => {
    navigator.clipboard.writeText(text);
    setCopied(label);
    toast({ title: `${label} Copied`, description: 'Copied to clipboard' });
    setTimeout(() => setCopied(null), 2000);
  };

  const formatBalance = (balance: number) => {
    return balance?.toFixed(8) || '0.00000000';
  };

  const truncateAddress = (address: string) => {
    if (!address) return '';
    return `${address.slice(0, 10)}...${address.slice(-8)}`;
  };

  const formatNumber = (num: number, decimals = 2) => {
    if (num >= 1000000) return (num / 1000000).toFixed(decimals) + 'M';
    if (num >= 1000) return (num / 1000).toFixed(decimals) + 'K';
    return num.toFixed(decimals);
  };

  return (
    <div className="space-y-4">
      {/* Main Balance Card - Bitcoin Style */}
      <Card className="p-6 bg-gradient-to-br from-amber-500/20 via-orange-500/10 to-yellow-500/20 border-amber-500/30 relative overflow-hidden">
        {/* Background Pattern */}
        <div className="absolute inset-0 opacity-5">
          <div className="absolute inset-0" style={{
            backgroundImage: `url("data:image/svg+xml,%3Csvg width='60' height='60' viewBox='0 0 60 60' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='none' fill-rule='evenodd'%3E%3Cg fill='%23ffffff' fill-opacity='1'%3E%3Cpath d='M36 34v-4h-2v4h-4v2h4v4h2v-4h4v-2h-4zm0-30V0h-2v4h-4v2h4v4h2V6h4V4h-4zM6 34v-4H4v4H0v2h4v4h2v-4h4v-2H6zM6 4V0H4v4H0v2h4v4h2V6h4V4H6z'/%3E%3C/g%3E%3C/g%3E%3C/svg%3E")`,
          }} />
        </div>

        <div className="relative">
          <div className="flex items-start justify-between mb-6">
            <div className="flex items-center gap-3">
              <div className="w-14 h-14 rounded-full bg-gradient-to-br from-amber-400 to-orange-500 flex items-center justify-center shadow-lg shadow-amber-500/30">
                <Coins className="w-7 h-7 text-white" />
              </div>
              <div>
                <h3 className="text-xl font-bold">{wallet?.currency_name || 'StreamCoin'}</h3>
                <p className="text-sm text-muted-foreground flex items-center gap-2">
                  <Shield className="w-3 h-3" />
                  {wallet?.address_type || 'P2PKH'} Wallet
                </p>
              </div>
            </div>
            <div className="text-right">
              <Badge variant="outline" className="border-amber-500/50 text-amber-400 mb-1">
                <Zap className="w-3 h-3 mr-1" />
                {wallet?.mining_power || 1}x Hash Power
              </Badge>
              <p className="text-xs text-muted-foreground">Block #{stats?.latest_block || 0}</p>
            </div>
          </div>

          {/* Balance Display */}
          <div className="bg-black/40 rounded-xl p-5 mb-4 backdrop-blur-sm">
            <div className="flex items-center justify-between mb-2">
              <p className="text-sm text-muted-foreground">Available Balance</p>
              <Badge variant="secondary" className="text-xs">
                {wallet?.currency_symbol || 'STC'}
              </Badge>
            </div>
            <div className="flex items-baseline gap-2 mb-4">
              <span className="text-4xl font-bold text-amber-400 font-mono">
                {formatBalance(wallet?.balance || 0)}
              </span>
              <span className="text-xl text-amber-400/70">{wallet?.currency_symbol || 'STC'}</span>
            </div>
            
            {/* Pending & Locked */}
            <div className="grid grid-cols-2 gap-4 pt-3 border-t border-white/10">
              <div>
                <p className="text-xs text-muted-foreground">Pending</p>
                <p className="font-mono text-sm">{formatBalance(wallet?.pending_balance || 0)} {wallet?.currency_symbol}</p>
              </div>
              <div>
                <p className="text-xs text-muted-foreground">Locked</p>
                <p className="font-mono text-sm">{formatBalance(wallet?.locked_balance || 0)} {wallet?.currency_symbol}</p>
              </div>
            </div>
          </div>

          {/* Wallet Address */}
          <div className="bg-black/30 rounded-lg p-4 space-y-3">
            <div>
              <p className="text-xs text-muted-foreground mb-2 flex items-center gap-1">
                <Key className="w-3 h-3" />
                Wallet Address (Bitcoin-style)
              </p>
              <div className="flex items-center gap-2">
                <code className="flex-1 text-sm font-mono text-amber-300/90 bg-black/40 px-3 py-2 rounded border border-amber-500/20">
                  {wallet?.wallet_address || 'Generating...'}
                </code>
                <Button
                  size="sm"
                  variant="ghost"
                  onClick={() => copyToClipboard(wallet?.wallet_address || '', 'Address')}
                  className="hover:bg-amber-500/20"
                >
                  {copied === 'Address' ? <Check className="w-4 h-4 text-green-400" /> : <Copy className="w-4 h-4" />}
                </Button>
              </div>
            </div>
            
            {wallet?.public_key && (
              <div>
                <p className="text-xs text-muted-foreground mb-2">Public Key</p>
                <div className="flex items-center gap-2">
                  <code className="flex-1 text-xs font-mono text-muted-foreground bg-black/40 px-3 py-2 rounded truncate">
                    {truncateAddress(wallet.public_key)}
                  </code>
                  <Button
                    size="sm"
                    variant="ghost"
                    onClick={() => copyToClipboard(wallet.public_key || '', 'Public Key')}
                    className="hover:bg-amber-500/20"
                  >
                    {copied === 'Public Key' ? <Check className="w-4 h-4 text-green-400" /> : <Copy className="w-4 h-4" />}
                  </Button>
                </div>
              </div>
            )}
          </div>
        </div>
      </Card>

      {/* Network Supply Progress */}
      <Card className="p-4">
        <div className="flex items-center justify-between mb-2">
          <span className="text-sm font-medium">Total Supply Mined</span>
          <span className="text-sm text-muted-foreground">
            {formatNumber(stats?.total_supply || 0)} / {formatNumber(stats?.max_supply || 21000000)} {wallet?.currency_symbol}
          </span>
        </div>
        <Progress 
          value={parseFloat(stats?.circulating_percentage || '0')} 
          className="h-2 mb-2" 
        />
        <div className="flex items-center justify-between text-xs text-muted-foreground">
          <span>{stats?.circulating_percentage || '0'}% mined</span>
          <span>Max: 21M {wallet?.currency_symbol} (like Bitcoin)</span>
        </div>
      </Card>

      {/* Stats Grid */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <Card className="p-4 bg-gradient-to-br from-green-500/10 to-emerald-500/5">
          <div className="flex items-center gap-2 mb-2">
            <TrendingUp className="w-4 h-4 text-green-400" />
            <span className="text-xs text-muted-foreground">Total Mined</span>
          </div>
          <p className="text-xl font-bold text-green-400 font-mono">
            {formatBalance(wallet?.total_mined || 0)}
          </p>
          <p className="text-xs text-muted-foreground">{wallet?.currency_symbol || 'STC'}</p>
        </Card>

        <Card className="p-4 bg-gradient-to-br from-blue-500/10 to-cyan-500/5">
          <div className="flex items-center gap-2 mb-2">
            <svg className="w-4 h-4 text-blue-400" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
              <rect x="3" y="3" width="18" height="18" rx="2" />
              <path d="M3 9h18M9 21V9" />
            </svg>
            <span className="text-xs text-muted-foreground">Blocks Mined</span>
          </div>
          <p className="text-xl font-bold text-blue-400">{stats?.blocks_mined || 0}</p>
          <p className="text-xs text-muted-foreground">blocks</p>
        </Card>

        <Card className="p-4 bg-gradient-to-br from-purple-500/10 to-violet-500/5">
          <div className="flex items-center gap-2 mb-2">
            <Coins className="w-4 h-4 text-purple-400" />
            <span className="text-xs text-muted-foreground">Block Reward</span>
          </div>
          <p className="text-xl font-bold text-purple-400">
            {stats?.current_block_reward || 50}
          </p>
          <p className="text-xs text-muted-foreground">{wallet?.currency_symbol || 'STC'}/block</p>
        </Card>

        <Card className="p-4 bg-gradient-to-br from-pink-500/10 to-rose-500/5">
          <div className="flex items-center gap-2 mb-2">
            <Zap className="w-4 h-4 text-pink-400" />
            <span className="text-xs text-muted-foreground">Difficulty</span>
          </div>
          <p className="text-xl font-bold text-pink-400">
            {stats?.network_difficulty || 4}
          </p>
          <p className="text-xs text-muted-foreground">network difficulty</p>
        </Card>
      </div>

      {/* Mining Rates */}
      <Card className="p-4">
        <h4 className="font-medium mb-3 flex items-center gap-2">
          <Zap className="w-4 h-4 text-amber-400" />
          Mining Rates
        </h4>
        <div className="grid grid-cols-2 gap-4">
          <div className="bg-muted/50 rounded-lg p-3">
            <p className="text-xs text-muted-foreground mb-1">Base Mining Rate</p>
            <p className="font-mono font-medium">
              {((stats?.mining_rate || 0) * 60).toFixed(4)} {wallet?.currency_symbol}/hr
            </p>
          </div>
          <div className="bg-muted/50 rounded-lg p-3">
            <p className="text-xs text-muted-foreground mb-1">Viewer Bonus</p>
            <p className="font-mono font-medium">
              +{((stats?.viewer_bonus || 0) * 60).toFixed(4)} {wallet?.currency_symbol}/viewer/hr
            </p>
          </div>
        </div>
      </Card>

      {/* Network Info */}
      <Card className="p-4 bg-gradient-to-r from-slate-800/50 to-slate-900/50">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-2 h-2 rounded-full bg-green-400 animate-pulse" />
            <span className="text-sm font-medium">StreamCoin Network</span>
            <Badge variant="outline" className="text-xs">Mainnet</Badge>
          </div>
          <div className="flex items-center gap-4 text-sm text-muted-foreground">
            <span>Block #{stats?.latest_block || 0}</span>
            <Button variant="ghost" size="sm" className="gap-1 text-xs">
              <ExternalLink className="w-3 h-3" />
              View Explorer
            </Button>
          </div>
        </div>
        <div className="mt-3 pt-3 border-t border-white/10 grid grid-cols-3 gap-4 text-xs">
          <div>
            <p className="text-muted-foreground">Protocol</p>
            <p className="font-medium">Bitcoin-style PoW</p>
          </div>
          <div>
            <p className="text-muted-foreground">Block Time</p>
            <p className="font-medium">~5 minutes</p>
          </div>
          <div>
            <p className="text-muted-foreground">Halving</p>
            <p className="font-medium">Every 210,000 blocks</p>
          </div>
        </div>
      </Card>
    </div>
  );
}
