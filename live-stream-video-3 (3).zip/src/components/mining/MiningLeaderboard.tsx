import { useState, useEffect } from 'react';
import { Trophy, Medal, Crown, TrendingUp, Users, Pickaxe, Blocks, Zap, Clock, Coins } from 'lucide-react';
import { Card } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Progress } from '@/components/ui/progress';
import { supabase } from '@/lib/supabase';

interface LeaderboardEntry {
  user_id: string;
  total_mined: number;
  mining_power: number;
  balance?: number;
  username?: string;
  avatar_url?: string;
}

interface NetworkStats {
  total_supply: number;
  max_supply: number;
  total_miners: number;
  total_blocks: number;
  current_difficulty: number;
  current_block_reward: number;
  halving_interval: number;
  next_halving: number;
  currency_name: string;
  currency_symbol: string;
}

interface MiningLeaderboardProps {
  leaderboard?: LeaderboardEntry[];
  networkStats?: NetworkStats;
}

export function MiningLeaderboard({ leaderboard: initialLeaderboard, networkStats: initialStats }: MiningLeaderboardProps) {
  const [leaderboard, setLeaderboard] = useState<LeaderboardEntry[]>(initialLeaderboard || []);
  const [networkStats, setNetworkStats] = useState<NetworkStats | null>(initialStats || null);
  const [loading, setLoading] = useState(!initialLeaderboard);

  useEffect(() => {
    if (!initialLeaderboard) {
      loadLeaderboard();
    }
  }, []);

  const loadLeaderboard = async () => {
    try {
      const { data } = await supabase.functions.invoke('mining-manager', {
        body: { action: 'get_leaderboard' }
      });
      if (data?.leaderboard) setLeaderboard(data.leaderboard);
      if (data?.network_stats) setNetworkStats(data.network_stats);
    } catch (error) {
      console.error('Failed to load leaderboard:', error);
    } finally {
      setLoading(false);
    }
  };

  const getRankIcon = (index: number) => {
    switch (index) {
      case 0:
        return <Crown className="w-5 h-5 text-yellow-400" />;
      case 1:
        return <Medal className="w-5 h-5 text-gray-300" />;
      case 2:
        return <Medal className="w-5 h-5 text-amber-600" />;
      default:
        return <span className="w-5 h-5 flex items-center justify-center text-sm font-bold text-muted-foreground">#{index + 1}</span>;
    }
  };

  const getRankBg = (index: number) => {
    switch (index) {
      case 0:
        return 'bg-gradient-to-r from-yellow-500/20 to-amber-500/10 border-yellow-500/30';
      case 1:
        return 'bg-gradient-to-r from-gray-400/20 to-gray-500/10 border-gray-400/30';
      case 2:
        return 'bg-gradient-to-r from-amber-600/20 to-orange-600/10 border-amber-600/30';
      default:
        return 'bg-black/20 border-transparent';
    }
  };

  const formatNumber = (num: number, decimals = 2) => {
    if (num >= 1000000) return (num / 1000000).toFixed(decimals) + 'M';
    if (num >= 1000) return (num / 1000).toFixed(decimals) + 'K';
    return num.toFixed(decimals);
  };

  return (
    <div className="space-y-4">
      {/* Network Stats - Bitcoin Style */}
      {networkStats && (
        <div className="space-y-4">
          {/* Supply Progress */}
          <Card className="p-4 bg-gradient-to-r from-amber-500/10 to-orange-500/5 border-amber-500/20">
            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center gap-2">
                <Coins className="w-5 h-5 text-amber-400" />
                <span className="font-medium">Total Supply</span>
              </div>
              <Badge variant="outline" className="border-amber-500/50 text-amber-400">
                {((networkStats.total_supply / networkStats.max_supply) * 100).toFixed(4)}% Mined
              </Badge>
            </div>
            <Progress 
              value={(networkStats.total_supply / networkStats.max_supply) * 100} 
              className="h-3 mb-2"
            />
            <div className="flex justify-between text-sm text-muted-foreground">
              <span>{formatNumber(networkStats.total_supply)} {networkStats.currency_symbol}</span>
              <span>Max: {formatNumber(networkStats.max_supply)} {networkStats.currency_symbol}</span>
            </div>
          </Card>

          {/* Network Stats Grid */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <Card className="p-4 bg-gradient-to-br from-blue-500/10 to-cyan-500/5">
              <div className="flex items-center gap-2 mb-2">
                <Users className="w-4 h-4 text-blue-400" />
                <span className="text-xs text-muted-foreground">Active Miners</span>
              </div>
              <p className="text-2xl font-bold text-blue-400">{networkStats.total_miners}</p>
              <p className="text-xs text-muted-foreground">streamers mining</p>
            </Card>

            <Card className="p-4 bg-gradient-to-br from-purple-500/10 to-violet-500/5">
              <div className="flex items-center gap-2 mb-2">
                <Blocks className="w-4 h-4 text-purple-400" />
                <span className="text-xs text-muted-foreground">Total Blocks</span>
              </div>
              <p className="text-2xl font-bold text-purple-400">{networkStats.total_blocks}</p>
              <p className="text-xs text-muted-foreground">blocks mined</p>
            </Card>

            <Card className="p-4 bg-gradient-to-br from-green-500/10 to-emerald-500/5">
              <div className="flex items-center gap-2 mb-2">
                <Coins className="w-4 h-4 text-green-400" />
                <span className="text-xs text-muted-foreground">Block Reward</span>
              </div>
              <p className="text-2xl font-bold text-green-400">{networkStats.current_block_reward}</p>
              <p className="text-xs text-muted-foreground">{networkStats.currency_symbol}/block</p>
            </Card>

            <Card className="p-4 bg-gradient-to-br from-pink-500/10 to-rose-500/5">
              <div className="flex items-center gap-2 mb-2">
                <Zap className="w-4 h-4 text-pink-400" />
                <span className="text-xs text-muted-foreground">Difficulty</span>
              </div>
              <p className="text-2xl font-bold text-pink-400">{networkStats.current_difficulty}</p>
              <p className="text-xs text-muted-foreground">network difficulty</p>
            </Card>
          </div>

          {/* Halving Info */}
          <Card className="p-4 bg-gradient-to-r from-orange-500/10 to-red-500/5 border-orange-500/20">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-full bg-orange-500/20 flex items-center justify-center">
                  <Clock className="w-5 h-5 text-orange-400" />
                </div>
                <div>
                  <p className="font-medium">Next Halving Event</p>
                  <p className="text-sm text-muted-foreground">
                    Block reward will reduce from {networkStats.current_block_reward} to {networkStats.current_block_reward / 2} {networkStats.currency_symbol}
                  </p>
                </div>
              </div>
              <div className="text-right">
                <p className="text-2xl font-bold text-orange-400">{formatNumber(networkStats.next_halving, 0)}</p>
                <p className="text-xs text-muted-foreground">blocks remaining</p>
              </div>
            </div>
            <div className="mt-3">
              <Progress 
                value={100 - ((networkStats.next_halving / networkStats.halving_interval) * 100)} 
                className="h-2"
              />
            </div>
          </Card>
        </div>
      )}

      {/* Leaderboard */}
      <Card className="p-4">
        <div className="flex items-center gap-2 mb-4">
          <Trophy className="w-5 h-5 text-amber-400" />
          <h3 className="font-semibold">Top Miners Leaderboard</h3>
        </div>

        {loading ? (
          <div className="space-y-3">
            {[...Array(5)].map((_, i) => (
              <div key={i} className="h-16 bg-black/20 rounded-lg animate-pulse" />
            ))}
          </div>
        ) : leaderboard.length === 0 ? (
          <div className="text-center py-8 text-muted-foreground">
            <Pickaxe className="w-12 h-12 mx-auto mb-3 opacity-50" />
            <p>No miners yet</p>
            <p className="text-sm">Be the first to mine StreamCoin!</p>
          </div>
        ) : (
          <div className="space-y-2">
            {leaderboard.map((entry, index) => (
              <div
                key={entry.user_id}
                className={`flex items-center gap-3 p-3 rounded-lg border ${getRankBg(index)} transition-colors hover:bg-white/5`}
              >
                <div className="w-8 flex items-center justify-center">
                  {getRankIcon(index)}
                </div>
                <Avatar className="w-10 h-10 border-2 border-background">
                  <AvatarImage src={entry.avatar_url || `https://api.dicebear.com/7.x/avataaars/svg?seed=${entry.user_id}`} />
                  <AvatarFallback>{entry.user_id.slice(0, 2).toUpperCase()}</AvatarFallback>
                </Avatar>
                <div className="flex-1 min-w-0">
                  <p className="font-medium truncate">{entry.username || `Miner ${entry.user_id.slice(0, 8)}`}</p>
                  <div className="flex items-center gap-2 text-xs text-muted-foreground">
                    <Badge variant="outline" className="text-xs">
                      <Zap className="w-3 h-3 mr-1" />
                      {entry.mining_power}x Power
                    </Badge>
                    {entry.balance !== undefined && (
                      <span className="text-green-400">
                        Balance: {parseFloat(entry.balance?.toString() || '0').toFixed(4)}
                      </span>
                    )}
                  </div>
                </div>
                <div className="text-right">
                  <p className="font-bold text-amber-400 font-mono">
                    {parseFloat(entry.total_mined?.toString() || '0').toFixed(6)}
                  </p>
                  <p className="text-xs text-muted-foreground">{networkStats?.currency_symbol || 'STC'} mined</p>
                </div>
              </div>
            ))}
          </div>
        )}
      </Card>

      {/* Bitcoin-like Info */}
      <Card className="p-4 bg-gradient-to-r from-slate-800/50 to-slate-900/50">
        <h4 className="font-medium mb-3 flex items-center gap-2">
          <Coins className="w-4 h-4 text-amber-400" />
          StreamCoin Economics (Bitcoin-style)
        </h4>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
          <div>
            <p className="text-muted-foreground">Max Supply</p>
            <p className="font-medium">21,000,000 STC</p>
          </div>
          <div>
            <p className="text-muted-foreground">Block Time</p>
            <p className="font-medium">~5 minutes</p>
          </div>
          <div>
            <p className="text-muted-foreground">Halving Interval</p>
            <p className="font-medium">210,000 blocks</p>
          </div>
          <div>
            <p className="text-muted-foreground">Consensus</p>
            <p className="font-medium">Proof of Stream</p>
          </div>
        </div>
      </Card>
    </div>
  );
}
