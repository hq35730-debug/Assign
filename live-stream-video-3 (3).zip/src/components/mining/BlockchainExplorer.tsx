import { useState, useEffect } from 'react';
import { Blocks, Search, ArrowRight, Clock, Hash, Cpu, TrendingUp, Users, Coins, ChevronRight, ExternalLink, Copy, Check } from 'lucide-react';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Progress } from '@/components/ui/progress';
import { supabase } from '@/lib/supabase';
import { useToast } from '@/hooks/use-toast';

interface BlockchainInfo {
  blockchain: {
    name: string;
    symbol: string;
    protocol_version: number;
    network: string;
  };
  chain: {
    height: number;
    best_block_hash: string;
    difficulty: number;
    total_blocks: number;
    median_time: string;
  };
  supply: {
    total_mined: number;
    max_supply: number;
    circulating: number;
    percentage_mined: string;
  };
  mining: {
    current_reward: number;
    next_halving_block: number;
    blocks_until_halving: number;
    total_miners: number;
    network_hashrate: number;
  };
  mempool: {
    pending_transactions: number;
    min_fee: number;
  };
  recent_blocks: any[];
}

interface BlockDetail {
  block_number: number;
  block_hash: string;
  previous_hash: string;
  merkle_root: string;
  timestamp: string;
  nonce: number;
  difficulty: number;
  miner_id: string;
  miner_address: string;
  reward: number;
  transaction_count: number;
  block_size: number;
  confirmations: number;
  transactions?: any[];
}

interface TransactionDetail {
  tx_hash: string;
  tx_type: string;
  amount: number;
  from_address?: string;
  to_address: string;
  fee: number;
  status: string;
  confirmations: number;
  block_number?: number;
  created_at: string;
}

export function BlockchainExplorer() {
  const { toast } = useToast();
  
  const [blockchainInfo, setBlockchainInfo] = useState<BlockchainInfo | null>(null);
  const [selectedBlock, setSelectedBlock] = useState<BlockDetail | null>(null);
  const [selectedTx, setSelectedTx] = useState<TransactionDetail | null>(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [loading, setLoading] = useState(true);
  const [searchLoading, setSearchLoading] = useState(false);
  const [copiedText, setCopiedText] = useState<string | null>(null);
  const [activeTab, setActiveTab] = useState('overview');

  useEffect(() => {
    loadBlockchainInfo();
    const interval = setInterval(loadBlockchainInfo, 30000); // Refresh every 30s
    return () => clearInterval(interval);
  }, []);

  const loadBlockchainInfo = async () => {
    try {
      const { data, error } = await supabase.functions.invoke('mining-manager', {
        body: { action: 'get_blockchain_info' }
      });

      if (data) {
        setBlockchainInfo(data);
      }
    } catch (error) {
      console.error('Failed to load blockchain info:', error);
    } finally {
      setLoading(false);
    }
  };

  const searchBlockchain = async () => {
    if (!searchQuery.trim()) return;

    setSearchLoading(true);
    try {
      // Try to search as block number
      if (/^\d+$/.test(searchQuery)) {
        const { data } = await supabase.functions.invoke('mining-manager', {
          body: { action: 'get_block', block_number: parseInt(searchQuery) }
        });
        if (data?.block) {
          setSelectedBlock(data.block);
          setSelectedTx(null);
          setActiveTab('block');
          return;
        }
      }

      // Try to search as block/tx hash
      if (searchQuery.startsWith('0x')) {
        // Try block hash first
        const blockResult = await supabase.functions.invoke('mining-manager', {
          body: { action: 'get_block', block_hash: searchQuery }
        });
        if (blockResult.data?.block) {
          setSelectedBlock(blockResult.data.block);
          setSelectedTx(null);
          setActiveTab('block');
          return;
        }

        // Try transaction hash
        const txResult = await supabase.functions.invoke('mining-manager', {
          body: { action: 'get_transaction', tx_hash: searchQuery }
        });
        if (txResult.data?.transaction) {
          setSelectedTx(txResult.data.transaction);
          setSelectedBlock(null);
          setActiveTab('transaction');
          return;
        }
      }

      toast({
        title: 'Not Found',
        description: 'No block or transaction found with that identifier',
        variant: 'destructive'
      });
    } catch (error) {
      console.error('Search error:', error);
    } finally {
      setSearchLoading(false);
    }
  };

  const viewBlock = async (blockNumber: number) => {
    try {
      const { data } = await supabase.functions.invoke('mining-manager', {
        body: { action: 'get_block', block_number: blockNumber }
      });
      if (data?.block) {
        setSelectedBlock(data.block);
        setSelectedTx(null);
        setActiveTab('block');
      }
    } catch (error) {
      console.error('Failed to load block:', error);
    }
  };

  const copyToClipboard = async (text: string) => {
    await navigator.clipboard.writeText(text);
    setCopiedText(text);
    setTimeout(() => setCopiedText(null), 2000);
  };

  const truncateHash = (hash: string, length = 8) => {
    if (!hash) return '';
    return `${hash.slice(0, length)}...${hash.slice(-length)}`;
  };

  const formatNumber = (num: number, decimals = 2) => {
    if (num >= 1000000) return (num / 1000000).toFixed(decimals) + 'M';
    if (num >= 1000) return (num / 1000).toFixed(decimals) + 'K';
    return num.toFixed(decimals);
  };

  if (loading) {
    return (
      <Card className="p-8">
        <div className="flex items-center justify-center">
          <div className="animate-spin w-8 h-8 border-4 border-amber-500 border-t-transparent rounded-full" />
        </div>
      </Card>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 rounded-full bg-gradient-to-br from-amber-400 to-orange-500 flex items-center justify-center">
            <Blocks className="w-6 h-6 text-white" />
          </div>
          <div>
            <h2 className="text-2xl font-bold">Blockchain Explorer</h2>
            <p className="text-muted-foreground">
              {blockchainInfo?.blockchain.name} ({blockchainInfo?.blockchain.symbol}) - {blockchainInfo?.blockchain.network}
            </p>
          </div>
        </div>
        <Badge variant="outline" className="text-green-500 border-green-500">
          <span className="w-2 h-2 rounded-full bg-green-500 mr-2 animate-pulse" />
          Live
        </Badge>
      </div>

      {/* Search */}
      <Card className="p-4">
        <div className="flex gap-2">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
            <Input
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              onKeyDown={(e) => e.key === 'Enter' && searchBlockchain()}
              placeholder="Search by Block Number, Block Hash, or Transaction Hash..."
              className="pl-10"
            />
          </div>
          <Button onClick={searchBlockchain} disabled={searchLoading}>
            {searchLoading ? 'Searching...' : 'Search'}
          </Button>
        </div>
      </Card>

      {/* Network Stats */}
      <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-4">
        <Card className="p-4">
          <div className="flex items-center gap-2 text-muted-foreground text-sm mb-1">
            <Blocks className="w-4 h-4" />
            Block Height
          </div>
          <p className="text-2xl font-bold">{blockchainInfo?.chain.height?.toLocaleString() || 0}</p>
        </Card>
        
        <Card className="p-4">
          <div className="flex items-center gap-2 text-muted-foreground text-sm mb-1">
            <Cpu className="w-4 h-4" />
            Difficulty
          </div>
          <p className="text-2xl font-bold">{blockchainInfo?.chain.difficulty || 4}</p>
        </Card>
        
        <Card className="p-4">
          <div className="flex items-center gap-2 text-muted-foreground text-sm mb-1">
            <Coins className="w-4 h-4" />
            Block Reward
          </div>
          <p className="text-2xl font-bold">{blockchainInfo?.mining.current_reward || 50} STC</p>
        </Card>
        
        <Card className="p-4">
          <div className="flex items-center gap-2 text-muted-foreground text-sm mb-1">
            <Users className="w-4 h-4" />
            Total Miners
          </div>
          <p className="text-2xl font-bold">{blockchainInfo?.mining.total_miners?.toLocaleString() || 0}</p>
        </Card>
        
        <Card className="p-4">
          <div className="flex items-center gap-2 text-muted-foreground text-sm mb-1">
            <TrendingUp className="w-4 h-4" />
            Circulating
          </div>
          <p className="text-2xl font-bold">{formatNumber(blockchainInfo?.supply.total_mined || 0)} STC</p>
        </Card>
        
        <Card className="p-4">
          <div className="flex items-center gap-2 text-muted-foreground text-sm mb-1">
            <Clock className="w-4 h-4" />
            Next Halving
          </div>
          <p className="text-2xl font-bold">{formatNumber(blockchainInfo?.mining.blocks_until_halving || 0, 0)}</p>
          <p className="text-xs text-muted-foreground">blocks</p>
        </Card>
      </div>

      {/* Supply Progress */}
      <Card className="p-4">
        <div className="flex items-center justify-between mb-2">
          <span className="text-sm font-medium">Total Supply Mined</span>
          <span className="text-sm text-muted-foreground">
            {formatNumber(blockchainInfo?.supply.total_mined || 0)} / {formatNumber(blockchainInfo?.supply.max_supply || 21000000)} STC
          </span>
        </div>
        <Progress value={parseFloat(blockchainInfo?.supply.percentage_mined || '0')} className="h-2" />
        <p className="text-xs text-muted-foreground mt-1">
          {blockchainInfo?.supply.percentage_mined || '0'}% of maximum supply
        </p>
      </Card>

      {/* Main Content */}
      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList>
          <TabsTrigger value="overview">Recent Blocks</TabsTrigger>
          <TabsTrigger value="block" disabled={!selectedBlock}>Block Details</TabsTrigger>
          <TabsTrigger value="transaction" disabled={!selectedTx}>Transaction</TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="mt-4">
          <Card>
            <div className="p-4 border-b">
              <h3 className="font-semibold">Latest Blocks</h3>
            </div>
            <ScrollArea className="h-[400px]">
              {blockchainInfo?.recent_blocks?.length ? (
                <div className="divide-y">
                  {blockchainInfo.recent_blocks.map((block) => (
                    <div
                      key={block.block_number}
                      className="p-4 hover:bg-muted/50 cursor-pointer transition-colors"
                      onClick={() => viewBlock(block.block_number)}
                    >
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-4">
                          <div className="w-10 h-10 rounded-lg bg-amber-500/10 flex items-center justify-center">
                            <Blocks className="w-5 h-5 text-amber-500" />
                          </div>
                          <div>
                            <div className="flex items-center gap-2">
                              <span className="font-mono font-semibold">#{block.block_number}</span>
                              <Badge variant="secondary" className="text-xs">
                                {block.transaction_count || 1} txn
                              </Badge>
                            </div>
                            <div className="flex items-center gap-2 text-sm text-muted-foreground">
                              <Hash className="w-3 h-3" />
                              <span className="font-mono">{truncateHash(block.block_hash)}</span>
                              <Button
                                variant="ghost"
                                size="sm"
                                className="h-5 w-5 p-0"
                                onClick={(e) => {
                                  e.stopPropagation();
                                  copyToClipboard(block.block_hash);
                                }}
                              >
                                {copiedText === block.block_hash ? (
                                  <Check className="w-3 h-3 text-green-500" />
                                ) : (
                                  <Copy className="w-3 h-3" />
                                )}
                              </Button>
                            </div>
                          </div>
                        </div>
                        <div className="text-right">
                          <p className="font-semibold text-amber-500">+{block.reward} STC</p>
                          <p className="text-xs text-muted-foreground">
                            {new Date(block.timestamp).toLocaleString()}
                          </p>
                        </div>
                        <ChevronRight className="w-5 h-5 text-muted-foreground" />
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="p-8 text-center text-muted-foreground">
                  <Blocks className="w-12 h-12 mx-auto mb-4 opacity-50" />
                  <p>No blocks mined yet</p>
                  <p className="text-sm">Start streaming to mine blocks!</p>
                </div>
              )}
            </ScrollArea>
          </Card>
        </TabsContent>

        <TabsContent value="block" className="mt-4">
          {selectedBlock && (
            <Card className="p-6">
              <div className="flex items-center justify-between mb-6">
                <h3 className="text-xl font-bold">Block #{selectedBlock.block_number}</h3>
                <Badge variant={selectedBlock.confirmations >= 6 ? 'default' : 'secondary'}>
                  {selectedBlock.confirmations} Confirmations
                </Badge>
              </div>

              <div className="grid gap-4">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <p className="text-sm text-muted-foreground">Block Hash</p>
                    <div className="flex items-center gap-2">
                      <code className="text-sm font-mono break-all">{selectedBlock.block_hash}</code>
                      <Button variant="ghost" size="sm" onClick={() => copyToClipboard(selectedBlock.block_hash)}>
                        {copiedText === selectedBlock.block_hash ? <Check className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
                      </Button>
                    </div>
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground">Previous Hash</p>
                    <code className="text-sm font-mono break-all">{selectedBlock.previous_hash}</code>
                  </div>
                </div>

                <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                  <div>
                    <p className="text-sm text-muted-foreground">Timestamp</p>
                    <p className="font-medium">{new Date(selectedBlock.timestamp).toLocaleString()}</p>
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground">Nonce</p>
                    <p className="font-medium font-mono">{selectedBlock.nonce}</p>
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground">Difficulty</p>
                    <p className="font-medium">{selectedBlock.difficulty}</p>
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground">Block Size</p>
                    <p className="font-medium">{selectedBlock.block_size} bytes</p>
                  </div>
                </div>

                <div>
                  <p className="text-sm text-muted-foreground">Merkle Root</p>
                  <code className="text-sm font-mono break-all">{selectedBlock.merkle_root}</code>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <p className="text-sm text-muted-foreground">Miner Address</p>
                    <code className="text-sm font-mono">{selectedBlock.miner_address}</code>
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground">Block Reward</p>
                    <p className="font-medium text-amber-500">{selectedBlock.reward} STC</p>
                  </div>
                </div>

                <div>
                  <p className="text-sm text-muted-foreground mb-2">Transactions ({selectedBlock.transaction_count})</p>
                  <Card className="p-4 bg-muted/50">
                    <div className="flex items-center gap-2">
                      <Badge>Coinbase</Badge>
                      <ArrowRight className="w-4 h-4" />
                      <span className="font-mono text-sm">{truncateHash(selectedBlock.miner_address, 12)}</span>
                      <span className="ml-auto text-amber-500 font-medium">+{selectedBlock.reward} STC</span>
                    </div>
                  </Card>
                </div>
              </div>
            </Card>
          )}
        </TabsContent>

        <TabsContent value="transaction" className="mt-4">
          {selectedTx && (
            <Card className="p-6">
              <div className="flex items-center justify-between mb-6">
                <h3 className="text-xl font-bold">Transaction Details</h3>
                <Badge variant={selectedTx.status === 'confirmed' ? 'default' : 'secondary'}>
                  {selectedTx.status}
                </Badge>
              </div>

              <div className="grid gap-4">
                <div>
                  <p className="text-sm text-muted-foreground">Transaction Hash</p>
                  <div className="flex items-center gap-2">
                    <code className="text-sm font-mono break-all">{selectedTx.tx_hash}</code>
                    <Button variant="ghost" size="sm" onClick={() => copyToClipboard(selectedTx.tx_hash)}>
                      {copiedText === selectedTx.tx_hash ? <Check className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
                    </Button>
                  </div>
                </div>

                <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                  <div>
                    <p className="text-sm text-muted-foreground">Type</p>
                    <Badge>{selectedTx.tx_type}</Badge>
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground">Amount</p>
                    <p className="font-medium text-lg">{Math.abs(selectedTx.amount).toFixed(8)} STC</p>
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground">Fee</p>
                    <p className="font-medium">{selectedTx.fee?.toFixed(8) || '0'} STC</p>
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground">Confirmations</p>
                    <p className="font-medium">{selectedTx.confirmations || 0}</p>
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  {selectedTx.from_address && (
                    <div>
                      <p className="text-sm text-muted-foreground">From</p>
                      <code className="text-sm font-mono">{selectedTx.from_address}</code>
                    </div>
                  )}
                  <div>
                    <p className="text-sm text-muted-foreground">To</p>
                    <code className="text-sm font-mono">{selectedTx.to_address}</code>
                  </div>
                </div>

                <div>
                  <p className="text-sm text-muted-foreground">Timestamp</p>
                  <p className="font-medium">{new Date(selectedTx.created_at).toLocaleString()}</p>
                </div>
              </div>
            </Card>
          )}
        </TabsContent>
      </Tabs>
    </div>
  );
}
