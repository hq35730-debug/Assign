import { useState, useEffect } from 'react';
import { Pickaxe, Zap, TrendingUp, Users } from 'lucide-react';
import { Card } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';

interface ActiveMiningIndicatorProps {
  session: {
    id: string;
    started_at: string;
    coins_mined: number;
    hash_rate: number;
    blocks_mined: number;
    avg_viewers: number;
  } | null;
  currencySymbol?: string;
}

export function ActiveMiningIndicator({ session, currencySymbol = 'STC' }: ActiveMiningIndicatorProps) {
  const [elapsedTime, setElapsedTime] = useState(0);
  const [animatedCoins, setAnimatedCoins] = useState(0);

  useEffect(() => {
    if (!session) return;

    const interval = setInterval(() => {
      const start = new Date(session.started_at).getTime();
      const now = Date.now();
      const elapsed = Math.floor((now - start) / 1000);
      setElapsedTime(elapsed);

      // Simulate coin accumulation animation
      const baseRate = 0.0001 * (session.hash_rate || 1);
      const viewerBonus = 0.00001 * (session.avg_viewers || 0);
      const coinsPerSecond = (baseRate + viewerBonus) / 60;
      setAnimatedCoins(elapsed * coinsPerSecond);
    }, 1000);

    return () => clearInterval(interval);
  }, [session]);

  if (!session) return null;

  const formatTime = (seconds: number) => {
    const hrs = Math.floor(seconds / 3600);
    const mins = Math.floor((seconds % 3600) / 60);
    const secs = seconds % 60;
    return `${hrs.toString().padStart(2, '0')}:${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  const blockProgress = ((elapsedTime % 300) / 300) * 100; // 5 minutes per block

  return (
    <Card className="p-4 bg-gradient-to-r from-amber-500/20 via-orange-500/15 to-yellow-500/20 border-amber-500/40 animate-pulse-slow">
      <div className="flex items-center gap-4">
        {/* Mining Animation */}
        <div className="relative">
          <div className="w-14 h-14 rounded-full bg-gradient-to-br from-amber-400 to-orange-500 flex items-center justify-center animate-bounce">
            <Pickaxe className="w-7 h-7 text-white" />
          </div>
          <div className="absolute -top-1 -right-1 w-4 h-4 rounded-full bg-green-400 animate-ping" />
          <div className="absolute -top-1 -right-1 w-4 h-4 rounded-full bg-green-400" />
        </div>

        {/* Mining Stats */}
        <div className="flex-1 space-y-2">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Badge className="bg-green-500/20 text-green-400 border-green-500/30">
                <Zap className="w-3 h-3 mr-1" />
                Mining Active
              </Badge>
              <span className="text-sm text-muted-foreground font-mono">{formatTime(elapsedTime)}</span>
            </div>
            <div className="flex items-center gap-1 text-amber-400">
              <TrendingUp className="w-4 h-4" />
              <span className="font-bold font-mono">{animatedCoins.toFixed(8)}</span>
              <span className="text-xs">{currencySymbol}</span>
            </div>
          </div>

          {/* Block Progress */}
          <div className="space-y-1">
            <div className="flex items-center justify-between text-xs text-muted-foreground">
              <span>Next Block</span>
              <span>{Math.floor(blockProgress)}%</span>
            </div>
            <Progress value={blockProgress} className="h-2 bg-black/30" />
          </div>

          {/* Quick Stats */}
          <div className="flex items-center gap-4 text-xs text-muted-foreground">
            <span className="flex items-center gap-1">
              <Zap className="w-3 h-3 text-purple-400" />
              Hash Rate: {session.hash_rate || 1}x
            </span>
            <span className="flex items-center gap-1">
              <Users className="w-3 h-3 text-blue-400" />
              Viewers: {session.avg_viewers || 0}
            </span>
            <span className="flex items-center gap-1">
              <svg className="w-3 h-3 text-amber-400" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                <rect x="3" y="3" width="18" height="18" rx="2" />
                <path d="M3 9h18M9 21V9" />
              </svg>
              Blocks: {session.blocks_mined || 0}
            </span>
          </div>
        </div>
      </div>
    </Card>
  );
}
