import { useState, useEffect } from 'react';
import { ArrowRightLeft, Coins, Pickaxe, AlertCircle, CheckCircle, History, TrendingUp, Info, Loader2 } from 'lucide-react';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { useToast } from '@/hooks/use-toast';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/contexts/AuthContext';

interface ConversionSettings {
  exchange_rate: number;
  min_conversion_amount: number;
  max_conversion_per_day: number;
  conversion_fee_percent: number;
}

interface ConversionRecord {
  id: string;
  stc_amount: number;
  coins_received: number;
  exchange_rate: number;
  fee_amount: number;
  tx_hash: string;
  status: string;
  created_at: string;
}

export function STCConverter() {
  const { user } = useAuth();
  const { toast } = useToast();
  const [settings, setSettings] = useState<ConversionSettings | null>(null);
  const [stcBalance, setStcBalance] = useState(0);
  const [dailyConverted, setDailyConverted] = useState(0);
  const [remainingLimit, setRemainingLimit] = useState(0);
  const [amount, setAmount] = useState('');
  const [converting, setConverting] = useState(false);
  const [history, setHistory] = useState<ConversionRecord[]>([]);
  const [totals, setTotals] = useState({ total_stc_converted: 0, total_coins_received: 0, total_fees_paid: 0 });
  const [loading, setLoading] = useState(true);

  const userId = user?.user_id || user?.id;

  useEffect(() => {
    if (userId) {
      loadConversionData();
      loadConversionHistory();
    }
  }, [userId]);

  const loadConversionData = async () => {
    try {
      const { data, error } = await supabase.functions.invoke('mining-manager', {
        body: { action: 'get_conversion_settings', user_id: userId }
      });

      if (data) {
        setSettings(data.settings);
        setStcBalance(parseFloat(data.stc_balance) || 0);
        setDailyConverted(data.daily_converted || 0);
        setRemainingLimit(data.remaining_daily_limit || 0);
      }
    } catch (error) {
      console.error('Failed to load conversion settings:', error);
    } finally {
      setLoading(false);
    }
  };

  const loadConversionHistory = async () => {
    try {
      const { data } = await supabase.functions.invoke('mining-manager', {
        body: { action: 'get_conversion_history', user_id: userId }
      });

      if (data) {
        setHistory(data.conversions || []);
        setTotals(data.totals || { total_stc_converted: 0, total_coins_received: 0, total_fees_paid: 0 });
      }
    } catch (error) {
      console.error('Failed to load conversion history:', error);
    }
  };

  const calculatePreview = () => {
    if (!settings || !amount) return { coins: 0, fee: 0, net: 0 };
    const stcAmount = parseFloat(amount) || 0;
    const fee = stcAmount * (settings.conversion_fee_percent / 100);
    const net = stcAmount - fee;
    const coins = Math.floor(net * settings.exchange_rate);
    return { coins, fee, net };
  };

  const handleConvert = async () => {
    if (!userId || !amount || !settings) return;

    const stcAmount = parseFloat(amount);
    
    if (stcAmount < settings.min_conversion_amount) {
      toast({
        title: 'Invalid Amount',
        description: `Minimum conversion is ${settings.min_conversion_amount} STC`,
        variant: 'destructive'
      });
      return;
    }

    if (stcAmount > stcBalance) {
      toast({
        title: 'Insufficient Balance',
        description: 'You do not have enough STC to convert',
        variant: 'destructive'
      });
      return;
    }

    if (stcAmount > remainingLimit) {
      toast({
        title: 'Daily Limit Exceeded',
        description: `You can only convert ${remainingLimit.toFixed(8)} more STC today`,
        variant: 'destructive'
      });
      return;
    }

    setConverting(true);

    try {
      const { data, error } = await supabase.functions.invoke('mining-manager', {
        body: { action: 'convert_stc_to_coins', user_id: userId, amount: stcAmount }
      });

      if (error || !data?.success) {
        throw new Error(data?.error || 'Conversion failed');
      }

      toast({
        title: 'Conversion Successful!',
        description: data.message,
      });

      setAmount('');
      loadConversionData();
      loadConversionHistory();
    } catch (error: any) {
      toast({
        title: 'Conversion Failed',
        description: error.message || 'An error occurred during conversion',
        variant: 'destructive'
      });
    } finally {
      setConverting(false);
    }
  };

  const setMaxAmount = () => {
    const maxPossible = Math.min(stcBalance, remainingLimit);
    setAmount(maxPossible.toFixed(8));
  };

  const preview = calculatePreview();
  const dailyProgress = settings ? (dailyConverted / settings.max_conversion_per_day) * 100 : 0;

  if (loading) {
    return (
      <Card className="p-6">
        <div className="flex items-center justify-center py-12">
          <Loader2 className="w-8 h-8 animate-spin text-amber-500" />
        </div>
      </Card>
    );
  }

  return (
    <div className="space-y-6">
      <Tabs defaultValue="convert" className="space-y-6">
        <TabsList className="grid w-full grid-cols-2">
          <TabsTrigger value="convert" className="gap-2">
            <ArrowRightLeft className="w-4 h-4" />
            Convert STC
          </TabsTrigger>
          <TabsTrigger value="history" className="gap-2">
            <History className="w-4 h-4" />
            History
          </TabsTrigger>
        </TabsList>

        <TabsContent value="convert" className="space-y-6">
          {/* Exchange Rate Info */}
          <Card className="p-4 bg-gradient-to-r from-amber-500/10 to-yellow-500/10 border-amber-500/30">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-full bg-gradient-to-br from-amber-400 to-orange-500 flex items-center justify-center">
                  <TrendingUp className="w-5 h-5 text-white" />
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Current Exchange Rate</p>
                  <p className="text-xl font-bold">
                    1 STC = <span className="text-yellow-500">{settings?.exchange_rate?.toLocaleString() || 100}</span> Coins
                  </p>
                </div>
              </div>
              {settings?.conversion_fee_percent > 0 && (
                <Badge variant="outline" className="border-amber-500/50">
                  {settings.conversion_fee_percent}% Fee
                </Badge>
              )}
            </div>
          </Card>

          {/* Balances */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <Card className="p-4 bg-gradient-to-br from-amber-500/20 to-orange-500/10">
              <div className="flex items-center gap-3">
                <Pickaxe className="w-8 h-8 text-amber-500" />
                <div>
                  <p className="text-sm text-muted-foreground">Your STC Balance</p>
                  <p className="text-2xl font-bold text-amber-400">{stcBalance.toFixed(8)}</p>
                </div>
              </div>
            </Card>
            <Card className="p-4 bg-gradient-to-br from-yellow-500/20 to-amber-500/10">
              <div className="flex items-center gap-3">
                <Coins className="w-8 h-8 text-yellow-500" />
                <div>
                  <p className="text-sm text-muted-foreground">Potential Coins</p>
                  <p className="text-2xl font-bold text-yellow-400">
                    {Math.floor(stcBalance * (settings?.exchange_rate || 100)).toLocaleString()}
                  </p>
                </div>
              </div>
            </Card>
          </div>

          {/* Daily Limit Progress */}
          <Card className="p-4">
            <div className="flex items-center justify-between mb-2">
              <span className="text-sm text-muted-foreground">Daily Conversion Limit</span>
              <span className="text-sm font-medium">
                {dailyConverted.toFixed(4)} / {settings?.max_conversion_per_day || 10} STC
              </span>
            </div>
            <Progress value={dailyProgress} className="h-2" />
            <p className="text-xs text-muted-foreground mt-2">
              Remaining today: <span className="text-amber-400">{remainingLimit.toFixed(8)} STC</span>
            </p>
          </Card>

          {/* Conversion Form */}
          <Card className="p-6">
            <h3 className="text-lg font-semibold mb-4 flex items-center gap-2">
              <ArrowRightLeft className="w-5 h-5 text-amber-500" />
              Convert StreamCoin to Platform Coins
            </h3>

            <div className="space-y-4">
              {/* Input */}
              <div className="space-y-2">
                <label className="text-sm text-muted-foreground">Amount to Convert (STC)</label>
                <div className="flex gap-2">
                  <div className="relative flex-1">
                    <Input
                      type="number"
                      step="0.00000001"
                      min={settings?.min_conversion_amount || 0.001}
                      max={Math.min(stcBalance, remainingLimit)}
                      value={amount}
                      onChange={(e) => setAmount(e.target.value)}
                      placeholder="0.00000000"
                      className="pr-16"
                    />
                    <span className="absolute right-3 top-1/2 -translate-y-1/2 text-sm text-muted-foreground">
                      STC
                    </span>
                  </div>
                  <Button variant="outline" onClick={setMaxAmount}>
                    MAX
                  </Button>
                </div>
                <p className="text-xs text-muted-foreground">
                  Minimum: {settings?.min_conversion_amount || 0.001} STC
                </p>
              </div>

              {/* Preview */}
              {amount && parseFloat(amount) > 0 && (
                <Card className="p-4 bg-gradient-to-r from-green-500/10 to-emerald-500/10 border-green-500/30">
                  <h4 className="text-sm font-medium mb-3 flex items-center gap-2">
                    <Info className="w-4 h-4" />
                    Conversion Preview
                  </h4>
                  <div className="space-y-2">
                    <div className="flex justify-between text-sm">
                      <span className="text-muted-foreground">STC to Convert:</span>
                      <span className="font-medium">{parseFloat(amount).toFixed(8)} STC</span>
                    </div>
                    {settings?.conversion_fee_percent > 0 && (
                      <div className="flex justify-between text-sm">
                        <span className="text-muted-foreground">Fee ({settings.conversion_fee_percent}%):</span>
                        <span className="font-medium text-red-400">-{preview.fee.toFixed(8)} STC</span>
                      </div>
                    )}
                    <div className="flex justify-between text-sm">
                      <span className="text-muted-foreground">Exchange Rate:</span>
                      <span className="font-medium">1 STC = {settings?.exchange_rate} Coins</span>
                    </div>
                    <div className="border-t border-border pt-2 mt-2">
                      <div className="flex justify-between">
                        <span className="font-medium">You Will Receive:</span>
                        <span className="text-xl font-bold text-green-400">
                          {preview.coins.toLocaleString()} Coins
                        </span>
                      </div>
                    </div>
                  </div>
                </Card>
              )}

              {/* Warnings */}
              {parseFloat(amount) > stcBalance && (
                <div className="flex items-center gap-2 text-red-400 text-sm">
                  <AlertCircle className="w-4 h-4" />
                  Insufficient STC balance
                </div>
              )}
              {parseFloat(amount) > remainingLimit && (
                <div className="flex items-center gap-2 text-orange-400 text-sm">
                  <AlertCircle className="w-4 h-4" />
                  Exceeds daily conversion limit
                </div>
              )}

              {/* Convert Button */}
              <Button
                onClick={handleConvert}
                disabled={
                  converting ||
                  !amount ||
                  parseFloat(amount) <= 0 ||
                  parseFloat(amount) > stcBalance ||
                  parseFloat(amount) > remainingLimit ||
                  parseFloat(amount) < (settings?.min_conversion_amount || 0.001)
                }
                className="w-full bg-gradient-to-r from-amber-500 to-orange-500 hover:from-amber-600 hover:to-orange-600"
                size="lg"
              >
                {converting ? (
                  <>
                    <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                    Converting...
                  </>
                ) : (
                  <>
                    <ArrowRightLeft className="w-4 h-4 mr-2" />
                    Convert to {preview.coins.toLocaleString()} Coins
                  </>
                )}
              </Button>
            </div>
          </Card>
        </TabsContent>

        <TabsContent value="history" className="space-y-6">
          {/* Totals Summary */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <Card className="p-4 bg-gradient-to-br from-amber-500/10 to-orange-500/5">
              <div className="flex items-center gap-2 mb-2">
                <Pickaxe className="w-4 h-4 text-amber-400" />
                <span className="text-xs text-muted-foreground">Total STC Converted</span>
              </div>
              <p className="text-xl font-bold text-amber-400">
                {totals.total_stc_converted.toFixed(8)}
              </p>
              <p className="text-xs text-muted-foreground">STC</p>
            </Card>
            <Card className="p-4 bg-gradient-to-br from-yellow-500/10 to-amber-500/5">
              <div className="flex items-center gap-2 mb-2">
                <Coins className="w-4 h-4 text-yellow-400" />
                <span className="text-xs text-muted-foreground">Total Coins Received</span>
              </div>
              <p className="text-xl font-bold text-yellow-400">
                {totals.total_coins_received.toLocaleString()}
              </p>
              <p className="text-xs text-muted-foreground">Coins</p>
            </Card>
            <Card className="p-4 bg-gradient-to-br from-red-500/10 to-orange-500/5">
              <div className="flex items-center gap-2 mb-2">
                <AlertCircle className="w-4 h-4 text-red-400" />
                <span className="text-xs text-muted-foreground">Total Fees Paid</span>
              </div>
              <p className="text-xl font-bold text-red-400">
                {totals.total_fees_paid.toFixed(8)}
              </p>
              <p className="text-xs text-muted-foreground">STC</p>
            </Card>
          </div>

          {/* Conversion History Table */}
          <Card className="p-4">
            <h3 className="text-lg font-semibold mb-4 flex items-center gap-2">
              <History className="w-5 h-5" />
              Conversion History
            </h3>

            {history.length === 0 ? (
              <div className="text-center py-12 text-muted-foreground">
                <ArrowRightLeft className="w-12 h-12 mx-auto mb-4 opacity-50" />
                <p>No conversions yet</p>
                <p className="text-sm">Convert your STC to platform coins to see history here</p>
              </div>
            ) : (
              <div className="space-y-3">
                {history.map((record) => (
                  <div
                    key={record.id}
                    className="flex items-center justify-between p-4 bg-muted/30 rounded-lg hover:bg-muted/50 transition-colors"
                  >
                    <div className="flex items-center gap-4">
                      <div className="w-10 h-10 rounded-full bg-gradient-to-br from-amber-400 to-orange-500 flex items-center justify-center">
                        <ArrowRightLeft className="w-5 h-5 text-white" />
                      </div>
                      <div>
                        <div className="flex items-center gap-2">
                          <span className="font-medium text-amber-400">
                            -{parseFloat(record.stc_amount.toString()).toFixed(8)} STC
                          </span>
                          <span className="text-muted-foreground">→</span>
                          <span className="font-medium text-green-400">
                            +{record.coins_received.toLocaleString()} Coins
                          </span>
                        </div>
                        <div className="flex items-center gap-2 text-xs text-muted-foreground">
                          <span>Rate: 1 STC = {record.exchange_rate} Coins</span>
                          {parseFloat(record.fee_amount?.toString() || '0') > 0 && (
                            <span className="text-red-400">
                              Fee: {parseFloat(record.fee_amount.toString()).toFixed(8)} STC
                            </span>
                          )}
                        </div>
                      </div>
                    </div>
                    <div className="text-right">
                      <Badge
                        variant={record.status === 'completed' ? 'default' : 'secondary'}
                        className={record.status === 'completed' ? 'bg-green-500/20 text-green-400' : ''}
                      >
                        {record.status === 'completed' ? (
                          <CheckCircle className="w-3 h-3 mr-1" />
                        ) : null}
                        {record.status}
                      </Badge>
                      <p className="text-xs text-muted-foreground mt-1">
                        {new Date(record.created_at).toLocaleDateString()} {new Date(record.created_at).toLocaleTimeString()}
                      </p>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
