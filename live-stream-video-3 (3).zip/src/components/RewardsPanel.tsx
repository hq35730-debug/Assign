
import { useState, useEffect } from 'react';
import { X, Sparkles, Send } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { RewardCard } from './RewardCard';
import { supabase } from '@/lib/supabase';
import { useToast } from '@/hooks/use-toast';

interface RewardsPanelProps {
  channelId: string;
  userId: string;
  username: string;
  userPoints: number;
  isOpen: boolean;
  onClose: () => void;
  onPointsUpdate: (points: number) => void;
}

export function RewardsPanel({ channelId, userId, username, userPoints, isOpen, onClose, onPointsUpdate }: RewardsPanelProps) {
  const [rewards, setRewards] = useState<any[]>([]);
  const [selectedReward, setSelectedReward] = useState<any>(null);
  const [userInput, setUserInput] = useState('');
  const [loading, setLoading] = useState(false);
  const { toast } = useToast();

  useEffect(() => {
    if (isOpen) fetchRewards();
  }, [isOpen, channelId]);

  const fetchRewards = async () => {
    const { data } = await supabase.functions.invoke('points-manager', {
      body: { action: 'get_rewards', channel_id: channelId }
    });
    if (data?.data) setRewards(data.data);
  };

  const handleRedeem = async () => {
    if (!selectedReward) return;
    setLoading(true);
    const { data, error } = await supabase.functions.invoke('points-manager', {
      body: {
        action: 'redeem_reward',
        reward_id: selectedReward.id,
        channel_id: channelId,
        user_id: userId,
        username,
        user_input: userInput || null
      }
    });
    setLoading(false);
    if (error || data?.error) {
      toast({ title: 'Error', description: data?.error || 'Failed to redeem', variant: 'destructive' });
    } else {
      toast({ title: 'Redeemed!', description: `You redeemed ${selectedReward.title}` });
      onPointsUpdate(data.new_balance);
      setSelectedReward(null);
      setUserInput('');
    }
  };

  if (!isOpen) return null;

  return (
    <div className="absolute bottom-full right-0 mb-2 w-80 bg-gray-900 rounded-xl border border-gray-700 shadow-2xl z-50 overflow-hidden">
      <div className="p-3 border-b border-gray-700 flex items-center justify-between bg-gradient-to-r from-purple-600/20 to-pink-600/20">
        <div className="flex items-center gap-2">
          <Sparkles className="w-5 h-5 text-yellow-400" />
          <span className="font-semibold text-white">Channel Rewards</span>
        </div>
        <Button variant="ghost" size="icon" onClick={onClose} className="h-7 w-7">
          <X className="w-4 h-4" />
        </Button>
      </div>
      <div className="p-3 max-h-80 overflow-y-auto space-y-2">
        {selectedReward ? (
          <div className="space-y-3">
            <h4 className="text-sm font-semibold text-white">{selectedReward.title}</h4>
            {selectedReward.requires_input && (
              <Input placeholder="Enter your message..." value={userInput} onChange={(e) => setUserInput(e.target.value)} className="bg-gray-800 border-gray-600" />
            )}
            <div className="flex gap-2">
              <Button variant="outline" size="sm" onClick={() => setSelectedReward(null)} className="flex-1">Cancel</Button>
              <Button size="sm" onClick={handleRedeem} disabled={loading} className="flex-1 bg-purple-600 hover:bg-purple-700">
                <Send className="w-3 h-3 mr-1" /> Confirm
              </Button>
            </div>
          </div>
        ) : rewards.length > 0 ? (
          rewards.map((reward) => (
            <RewardCard key={reward.id} reward={reward} userPoints={userPoints} onRedeem={setSelectedReward} />
          ))
        ) : (
          <p className="text-gray-400 text-sm text-center py-4">No rewards available</p>
        )}
      </div>
    </div>
  );
}
