import React, { useState, useEffect, useRef } from 'react';
import { Download, Copy, CheckCircle, RefreshCw, Share2 } from 'lucide-react';

interface QRCodeDisplayProps {
  url: string;
  size?: number;
  label?: string;
  showActions?: boolean;
  darkMode?: boolean;
  logoText?: string;
  color?: string;
  bgColor?: string;
}

export const QRCodeDisplay: React.FC<QRCodeDisplayProps> = ({
  url,
  size = 200,
  label,
  showActions = true,
  darkMode = true,
  logoText,
  color = '9333ea',
  bgColor = 'ffffff',
}) => {
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(false);
  const [copied, setCopied] = useState(false);
  const [downloaded, setDownloaded] = useState(false);
  const canvasRef = useRef<HTMLCanvasElement>(null);

  // Generate QR code URL using the free API
  const qrApiUrl = `https://api.qrserver.com/v1/create-qr-code/?size=${size}x${size}&data=${encodeURIComponent(url)}&color=${color}&bgcolor=${bgColor}&format=png&margin=10`;

  const handleCopyLink = async () => {
    try {
      await navigator.clipboard.writeText(url);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch (err) {
      console.error('Failed to copy:', err);
    }
  };

  const handleDownload = async () => {
    try {
      const response = await fetch(qrApiUrl);
      const blob = await response.blob();
      const downloadUrl = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = downloadUrl;
      a.download = `assigned-qr-code-${Date.now()}.png`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(downloadUrl);
      setDownloaded(true);
      setTimeout(() => setDownloaded(false), 2000);
    } catch (err) {
      console.error('Failed to download:', err);
    }
  };

  const handleShare = async () => {
    if (navigator.share) {
      try {
        await navigator.share({
          title: 'Join Assigned',
          text: 'Sign up for Assigned - Connect with creators and join dialogues!',
          url: url,
        });
      } catch (err) {
        // User cancelled or share failed, fallback to copy
        handleCopyLink();
      }
    } else {
      handleCopyLink();
    }
  };

  return (
    <div className="flex flex-col items-center gap-4">
      {/* QR Code Container */}
      <div className={`relative rounded-2xl p-4 ${darkMode ? 'bg-white' : 'bg-white'} shadow-lg shadow-purple-500/20`}>
        {/* Decorative corner accents */}
        <div className="absolute -top-1 -left-1 w-6 h-6 border-t-2 border-l-2 border-purple-500 rounded-tl-lg" />
        <div className="absolute -top-1 -right-1 w-6 h-6 border-t-2 border-r-2 border-pink-500 rounded-tr-lg" />
        <div className="absolute -bottom-1 -left-1 w-6 h-6 border-b-2 border-l-2 border-pink-500 rounded-bl-lg" />
        <div className="absolute -bottom-1 -right-1 w-6 h-6 border-b-2 border-r-2 border-purple-500 rounded-br-lg" />

        {/* Loading state */}
        {loading && !error && (
          <div 
            className="flex items-center justify-center bg-gray-100 rounded-lg"
            style={{ width: size, height: size }}
          >
            <RefreshCw className="w-8 h-8 text-purple-500 animate-spin" />
          </div>
        )}

        {/* Error state */}
        {error && (
          <div 
            className="flex flex-col items-center justify-center bg-gray-100 rounded-lg gap-2"
            style={{ width: size, height: size }}
          >
            <RefreshCw className="w-8 h-8 text-gray-400" />
            <span className="text-gray-500 text-xs">Failed to load</span>
          </div>
        )}

        {/* QR Code Image */}
        <img
          src={qrApiUrl}
          alt="QR Code"
          width={size}
          height={size}
          className={`rounded-lg ${loading ? 'hidden' : 'block'}`}
          onLoad={() => { setLoading(false); setError(false); }}
          onError={() => { setLoading(false); setError(true); }}
        />

        {/* Logo overlay in center */}
        {logoText && !loading && !error && (
          <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
            <div className="bg-white px-2 py-1 rounded-md shadow-sm">
              <span className="text-xs font-bold bg-gradient-to-r from-purple-600 to-pink-600 bg-clip-text text-transparent">
                {logoText}
              </span>
            </div>
          </div>
        )}
      </div>

      {/* Label */}
      {label && (
        <p className={`text-sm font-medium ${darkMode ? 'text-gray-300' : 'text-gray-600'}`}>
          {label}
        </p>
      )}

      {/* URL display */}
      <div className={`flex items-center gap-2 px-3 py-2 rounded-lg text-xs font-mono max-w-full overflow-hidden ${darkMode ? 'bg-[#1a1a2e] text-gray-400 border border-gray-700' : 'bg-gray-100 text-gray-500 border border-gray-200'}`}>
        <span className="truncate">{url}</span>
      </div>

      {/* Action buttons */}
      {showActions && (
        <div className="flex items-center gap-2">
          <button
            onClick={handleCopyLink}
            className={`flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-medium transition-all ${
              copied
                ? 'bg-green-500/20 text-green-400 border border-green-500/30'
                : darkMode
                ? 'bg-[#1a1a2e] text-gray-300 border border-gray-700 hover:border-purple-500 hover:text-purple-400'
                : 'bg-gray-100 text-gray-600 border border-gray-200 hover:border-purple-500 hover:text-purple-600'
            }`}
          >
            {copied ? <CheckCircle className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
            {copied ? 'Copied!' : 'Copy Link'}
          </button>

          <button
            onClick={handleDownload}
            className={`flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-medium transition-all ${
              downloaded
                ? 'bg-green-500/20 text-green-400 border border-green-500/30'
                : 'bg-gradient-to-r from-purple-600 to-pink-600 text-white hover:shadow-lg hover:shadow-purple-500/30'
            }`}
          >
            {downloaded ? <CheckCircle className="w-4 h-4" /> : <Download className="w-4 h-4" />}
            {downloaded ? 'Saved!' : 'Download'}
          </button>

          <button
            onClick={handleShare}
            className={`flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-medium transition-all ${
              darkMode
                ? 'bg-[#1a1a2e] text-gray-300 border border-gray-700 hover:border-cyan-500 hover:text-cyan-400'
                : 'bg-gray-100 text-gray-600 border border-gray-200 hover:border-cyan-500 hover:text-cyan-600'
            }`}
          >
            <Share2 className="w-4 h-4" />
            Share
          </button>
        </div>
      )}
    </div>
  );
};
