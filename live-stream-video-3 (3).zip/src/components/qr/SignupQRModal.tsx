import React, { useState } from 'react';
import { X, QrCode, UserPlus, Link2, Palette, Smartphone, Monitor, Globe, Users, Sparkles, Hash, Phone } from 'lucide-react';
import { QRCodeDisplay } from './QRCodeDisplay';
import { useAuth } from '@/contexts/AuthContext';

interface SignupQRModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const SignupQRModal: React.FC<SignupQRModalProps> = ({ isOpen, onClose }) => {
  const { user } = useAuth();
  const [activeTab, setActiveTab] = useState<'signup' | 'profile' | 'custom'>('signup');
  const [customUrl, setCustomUrl] = useState('');
  const [qrColor, setQrColor] = useState('9333ea');
  const [qrSize, setQrSize] = useState<number>(220);

  if (!isOpen) return null;

  const baseUrl = window.location.origin;
  
  // Generate signup URL with optional referral
  const signupUrl = user?.unique_id 
    ? `${baseUrl}/signup?ref=${user.unique_id}` 
    : `${baseUrl}/signup`;

  // Profile URL
  const profileUrl = user?.username 
    ? `${baseUrl}/profile/${user.username}` 
    : `${baseUrl}/signup`;

  const colorPresets = [
    { name: 'Purple', value: '9333ea' },
    { name: 'Pink', value: 'ec4899' },
    { name: 'Blue', value: '3b82f6' },
    { name: 'Green', value: '22c55e' },
    { name: 'Red', value: 'ef4444' },
    { name: 'Orange', value: 'f97316' },
    { name: 'Cyan', value: '06b6d4' },
    { name: 'Black', value: '000000' },
  ];

  const sizeOptions = [
    { label: 'Small', value: 150 },
    { label: 'Medium', value: 220 },
    { label: 'Large', value: 300 },
  ];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      {/* Backdrop */}
      <div className="absolute inset-0 bg-black/70 backdrop-blur-sm" onClick={onClose} />
      
      {/* Modal */}
      <div className="relative bg-[#16213e] rounded-2xl border border-gray-700 w-full max-w-2xl max-h-[90vh] overflow-y-auto shadow-2xl shadow-purple-500/20">
        {/* Header */}
        <div className="sticky top-0 bg-[#16213e] border-b border-gray-700 p-6 rounded-t-2xl z-10">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-purple-500 to-pink-500 flex items-center justify-center">
                <QrCode className="w-5 h-5 text-white" />
              </div>
              <div>
                <h2 className="text-xl font-bold text-white">QR Code Generator</h2>
                <p className="text-gray-400 text-sm">Share signup links via QR code</p>
              </div>
            </div>
            <button
              onClick={onClose}
              className="p-2 text-gray-400 hover:text-white hover:bg-gray-700 rounded-lg transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Tabs */}
          <div className="flex gap-2 mt-4">
            <button
              onClick={() => setActiveTab('signup')}
              className={`flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-medium transition-all ${
                activeTab === 'signup'
                  ? 'bg-purple-600 text-white'
                  : 'text-gray-400 hover:text-white hover:bg-gray-700'
              }`}
            >
              <UserPlus className="w-4 h-4" />
              Signup QR
            </button>
            {user && (
              <button
                onClick={() => setActiveTab('profile')}
                className={`flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-medium transition-all ${
                  activeTab === 'profile'
                    ? 'bg-purple-600 text-white'
                    : 'text-gray-400 hover:text-white hover:bg-gray-700'
                }`}
              >
                <Globe className="w-4 h-4" />
                Profile QR
              </button>
            )}
            <button
              onClick={() => setActiveTab('custom')}
              className={`flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-medium transition-all ${
                activeTab === 'custom'
                  ? 'bg-purple-600 text-white'
                  : 'text-gray-400 hover:text-white hover:bg-gray-700'
              }`}
            >
              <Link2 className="w-4 h-4" />
              Custom URL
            </button>
          </div>
        </div>

        {/* Content */}
        <div className="p-6">
          {/* Signup QR Tab */}
          {activeTab === 'signup' && (
            <div className="space-y-6">
              {/* Referral info banner */}
              {user && (
                <div className="bg-gradient-to-r from-purple-500/10 to-pink-500/10 rounded-xl p-4 border border-purple-500/20">
                  <div className="flex items-start gap-3">
                    <Sparkles className="w-5 h-5 text-purple-400 mt-0.5 flex-shrink-0" />
                    <div>
                      <p className="text-purple-300 text-sm font-medium">Referral QR Code</p>
                      <p className="text-gray-400 text-xs mt-1">
                        This QR code includes your referral ID (<span className="text-purple-400 font-mono">{user.unique_id}</span>). 
                        When someone scans it and signs up, they'll be linked to your account.
                      </p>
                    </div>
                  </div>
                </div>
              )}

              {/* QR Code Display */}
              <div className="flex justify-center">
                <QRCodeDisplay
                  url={signupUrl}
                  size={qrSize}
                  label="Scan to sign up for Assigned"
                  color={qrColor}
                  logoText="Assigned"
                />
              </div>

              {/* Stats for referrals */}
              {user && (
                <div className="grid grid-cols-3 gap-3">
                  <div className="bg-[#1a1a2e] rounded-xl p-4 border border-gray-700 text-center">
                    <Users className="w-5 h-5 text-purple-400 mx-auto mb-2" />
                    <p className="text-white font-bold text-lg">0</p>
                    <p className="text-gray-400 text-xs">Referrals</p>
                  </div>
                  <div className="bg-[#1a1a2e] rounded-xl p-4 border border-gray-700 text-center">
                    <Smartphone className="w-5 h-5 text-cyan-400 mx-auto mb-2" />
                    <p className="text-white font-bold text-lg">0</p>
                    <p className="text-gray-400 text-xs">QR Scans</p>
                  </div>
                  <div className="bg-[#1a1a2e] rounded-xl p-4 border border-gray-700 text-center">
                    <Monitor className="w-5 h-5 text-green-400 mx-auto mb-2" />
                    <p className="text-white font-bold text-lg">0</p>
                    <p className="text-gray-400 text-xs">Link Clicks</p>
                  </div>
                </div>
              )}

              {/* User info card */}
              {user && (
                <div className="bg-[#1a1a2e] rounded-xl p-4 border border-gray-700">
                  <p className="text-gray-400 text-xs uppercase tracking-wider mb-3">Your Account Info</p>
                  <div className="space-y-2">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <Hash className="w-4 h-4 text-purple-400" />
                        <span className="text-gray-300 text-sm">Unique ID</span>
                      </div>
                      <span className="text-purple-400 font-mono font-semibold">{user.unique_id || 'N/A'}</span>
                    </div>
                    {user.phone_number && (
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-2">
                          <Phone className="w-4 h-4 text-green-400" />
                          <span className="text-gray-300 text-sm">Phone</span>
                        </div>
                        <span className="text-green-400 font-mono">{user.phone_number}</span>
                      </div>
                    )}
                  </div>
                </div>
              )}
            </div>
          )}

          {/* Profile QR Tab */}
          {activeTab === 'profile' && user && (
            <div className="space-y-6">
              <div className="bg-gradient-to-r from-cyan-500/10 to-blue-500/10 rounded-xl p-4 border border-cyan-500/20">
                <div className="flex items-start gap-3">
                  <Globe className="w-5 h-5 text-cyan-400 mt-0.5 flex-shrink-0" />
                  <div>
                    <p className="text-cyan-300 text-sm font-medium">Profile QR Code</p>
                    <p className="text-gray-400 text-xs mt-1">
                      Share this QR code to let people visit your profile directly. 
                      They can follow you, subscribe, and see your content.
                    </p>
                  </div>
                </div>
              </div>

              <div className="flex justify-center">
                <QRCodeDisplay
                  url={profileUrl}
                  size={qrSize}
                  label={`@${user.username}'s Profile`}
                  color={qrColor}
                  logoText="Assigned"
                />
              </div>

              {/* Profile preview card */}
              <div className="bg-[#1a1a2e] rounded-xl p-4 border border-gray-700">
                <div className="flex items-center gap-4">
                  <div className="w-14 h-14 rounded-full bg-gradient-to-br from-purple-500 to-pink-500 flex items-center justify-center overflow-hidden">
                    {user.avatar_url ? (
                      <img src={user.avatar_url} alt="" className="w-full h-full object-cover" />
                    ) : (
                      <span className="text-white font-bold text-xl">{user.username[0].toUpperCase()}</span>
                    )}
                  </div>
                  <div>
                    <p className="text-white font-bold">{user.display_name || user.username}</p>
                    <p className="text-gray-400 text-sm">@{user.username}</p>
                    {user.unique_id && (
                      <p className="text-purple-400 text-xs font-mono mt-1">ID: {user.unique_id}</p>
                    )}
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* Custom URL Tab */}
          {activeTab === 'custom' && (
            <div className="space-y-6">
              <div className="bg-gradient-to-r from-amber-500/10 to-orange-500/10 rounded-xl p-4 border border-amber-500/20">
                <div className="flex items-start gap-3">
                  <Link2 className="w-5 h-5 text-amber-400 mt-0.5 flex-shrink-0" />
                  <div>
                    <p className="text-amber-300 text-sm font-medium">Custom QR Code</p>
                    <p className="text-gray-400 text-xs mt-1">
                      Generate a QR code for any URL. Perfect for sharing stream links, 
                      social media, or any other web address.
                    </p>
                  </div>
                </div>
              </div>

              {/* URL Input */}
              <div>
                <label className="text-gray-300 text-sm mb-2 block">Enter URL</label>
                <input
                  type="url"
                  value={customUrl}
                  onChange={(e) => setCustomUrl(e.target.value)}
                  placeholder="https://example.com"
                  className="w-full bg-[#1a1a2e] text-white px-4 py-3 rounded-lg border border-gray-700 focus:border-purple-500 focus:outline-none transition-colors"
                />
              </div>

              {customUrl && (
                <div className="flex justify-center">
                  <QRCodeDisplay
                    url={customUrl}
                    size={qrSize}
                    label="Custom QR Code"
                    color={qrColor}
                  />
                </div>
              )}

              {!customUrl && (
                <div className="flex flex-col items-center justify-center py-12 text-gray-500">
                  <QrCode className="w-16 h-16 mb-4 opacity-30" />
                  <p className="text-sm">Enter a URL above to generate a QR code</p>
                </div>
              )}
            </div>
          )}

          {/* Customization Section */}
          <div className="mt-8 pt-6 border-t border-gray-700">
            <h3 className="text-white font-semibold mb-4 flex items-center gap-2">
              <Palette className="w-4 h-4 text-purple-400" />
              Customize QR Code
            </h3>

            {/* Color presets */}
            <div className="mb-4">
              <label className="text-gray-400 text-xs mb-2 block">Color</label>
              <div className="flex flex-wrap gap-2">
                {colorPresets.map((preset) => (
                  <button
                    key={preset.value}
                    onClick={() => setQrColor(preset.value)}
                    className={`w-8 h-8 rounded-lg border-2 transition-all ${
                      qrColor === preset.value
                        ? 'border-white scale-110 shadow-lg'
                        : 'border-gray-600 hover:border-gray-400'
                    }`}
                    style={{ backgroundColor: `#${preset.value}` }}
                    title={preset.name}
                  />
                ))}
              </div>
            </div>

            {/* Size options */}
            <div>
              <label className="text-gray-400 text-xs mb-2 block">Size</label>
              <div className="flex gap-2">
                {sizeOptions.map((option) => (
                  <button
                    key={option.value}
                    onClick={() => setQrSize(option.value)}
                    className={`px-4 py-2 rounded-lg text-sm font-medium transition-all ${
                      qrSize === option.value
                        ? 'bg-purple-600 text-white'
                        : 'bg-[#1a1a2e] text-gray-400 border border-gray-700 hover:border-purple-500 hover:text-purple-400'
                    }`}
                  >
                    {option.label}
                  </button>
                ))}
              </div>
            </div>
          </div>

          {/* How it works section */}
          <div className="mt-8 pt-6 border-t border-gray-700">
            <h3 className="text-white font-semibold mb-4">How It Works</h3>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="bg-[#1a1a2e] rounded-xl p-4 border border-gray-700 text-center">
                <div className="w-10 h-10 rounded-full bg-purple-500/20 flex items-center justify-center mx-auto mb-3">
                  <span className="text-purple-400 font-bold">1</span>
                </div>
                <p className="text-white text-sm font-medium">Share QR Code</p>
                <p className="text-gray-400 text-xs mt-1">Download or display the QR code for others to scan</p>
              </div>
              <div className="bg-[#1a1a2e] rounded-xl p-4 border border-gray-700 text-center">
                <div className="w-10 h-10 rounded-full bg-pink-500/20 flex items-center justify-center mx-auto mb-3">
                  <span className="text-pink-400 font-bold">2</span>
                </div>
                <p className="text-white text-sm font-medium">Scan & Visit</p>
                <p className="text-gray-400 text-xs mt-1">Users scan with their phone camera to open the signup page</p>
              </div>
              <div className="bg-[#1a1a2e] rounded-xl p-4 border border-gray-700 text-center">
                <div className="w-10 h-10 rounded-full bg-cyan-500/20 flex items-center justify-center mx-auto mb-3">
                  <span className="text-cyan-400 font-bold">3</span>
                </div>
                <p className="text-white text-sm font-medium">Sign Up & Connect</p>
                <p className="text-gray-400 text-xs mt-1">New users create an account and get their phone number & ID</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
