import { useState, useEffect } from 'react';
import { Heart, MessageCircle, Eye, Play, Image as ImageIcon, Video, MoreHorizontal, Trash2, Share2, Bookmark, Loader2 } from 'lucide-react';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from '@/components/ui/dropdown-menu';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { ScrollArea } from '@/components/ui/scroll-area';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/contexts/AuthContext';
import { useToast } from '@/hooks/use-toast';

interface MediaPost {
  id: string;
  user_id: string;
  username: string;
  avatar_url: string;
  media_type: 'image' | 'video';
  media_url: string;
  thumbnail_url: string;
  caption: string;
  tags: string[];
  likes_count: number;
  comments_count: number;
  views_count: number;
  created_at: string;
}

interface Comment {
  id: string;
  user_id: string;
  username: string;
  avatar_url: string;
  content: string;
  created_at: string;
}

interface MediaFeedProps {
  filter?: 'all' | 'image' | 'video';
  userId?: string;
}

export function MediaFeed({ filter = 'all', userId }: MediaFeedProps) {
  const { user } = useAuth();
  const { toast } = useToast();
  const [posts, setPosts] = useState<MediaPost[]>([]);
  const [loading, setLoading] = useState(true);
  const [loadingMore, setLoadingMore] = useState(false);
  const [hasMore, setHasMore] = useState(true);
  const [offset, setOffset] = useState(0);
  const [selectedPost, setSelectedPost] = useState<MediaPost | null>(null);
  const [comments, setComments] = useState<Comment[]>([]);
  const [newComment, setNewComment] = useState('');
  const [likedPosts, setLikedPosts] = useState<Set<string>>(new Set());
  const [submittingComment, setSubmittingComment] = useState(false);

  useEffect(() => {
    loadPosts();
  }, [filter, userId]);

  const loadPosts = async () => {
    setLoading(true);
    try {
      const action = userId ? 'get_user_posts' : 'get_feed';
      const { data, error } = await supabase.functions.invoke('media-manager', {
        body: { 
          action, 
          user_id: userId,
          media_type: filter,
          limit: 12,
          offset: 0
        }
      });

      if (error) throw error;
      setPosts(data?.posts || []);
      setHasMore(data?.hasMore || false);
      setOffset(data?.posts?.length || 0);
    } catch (error: any) {
      console.error('Failed to load posts:', error);
    } finally {
      setLoading(false);
    }
  };

  const loadMorePosts = async () => {
    if (loadingMore || !hasMore) return;
    setLoadingMore(true);
    try {
      const action = userId ? 'get_user_posts' : 'get_feed';
      const { data, error } = await supabase.functions.invoke('media-manager', {
        body: { 
          action, 
          user_id: userId,
          media_type: filter,
          limit: 12,
          offset
        }
      });

      if (error) throw error;
      setPosts(prev => [...prev, ...(data?.posts || [])]);
      setHasMore(data?.hasMore || false);
      setOffset(prev => prev + (data?.posts?.length || 0));
    } catch (error: any) {
      console.error('Failed to load more posts:', error);
    } finally {
      setLoadingMore(false);
    }
  };

  const handleLike = async (postId: string) => {
    if (!user) {
      toast({ title: 'Sign in required', description: 'Please sign in to like posts', variant: 'destructive' });
      return;
    }

    const currentUserId = user.user_id || user.id;
    const wasLiked = likedPosts.has(postId);

    // Optimistic update
    setLikedPosts(prev => {
      const newSet = new Set(prev);
      if (wasLiked) newSet.delete(postId);
      else newSet.add(postId);
      return newSet;
    });

    setPosts(prev => prev.map(p => 
      p.id === postId 
        ? { ...p, likes_count: wasLiked ? p.likes_count - 1 : p.likes_count + 1 }
        : p
    ));

    try {
      await supabase.functions.invoke('media-manager', {
        body: { action: 'like_post', post_id: postId, user_id: currentUserId }
      });
    } catch (error) {
      // Revert on error
      setLikedPosts(prev => {
        const newSet = new Set(prev);
        if (wasLiked) newSet.add(postId);
        else newSet.delete(postId);
        return newSet;
      });
      setPosts(prev => prev.map(p => 
        p.id === postId 
          ? { ...p, likes_count: wasLiked ? p.likes_count + 1 : p.likes_count - 1 }
          : p
      ));
    }
  };

  const openPostDetails = async (post: MediaPost) => {
    setSelectedPost(post);
    setComments([]);
    
    try {
      const currentUserId = user?.user_id || user?.id;
      const { data } = await supabase.functions.invoke('media-manager', {
        body: { action: 'get_post', post_id: post.id, user_id: currentUserId }
      });

      if (data) {
        setComments(data.comments || []);
        if (data.userLiked) {
          setLikedPosts(prev => new Set([...prev, post.id]));
        }
      }
    } catch (error) {
      console.error('Failed to load post details:', error);
    }
  };

  const handleComment = async () => {
    if (!user || !selectedPost || !newComment.trim()) return;

    setSubmittingComment(true);
    try {
      const currentUserId = user.user_id || user.id;
      const { data, error } = await supabase.functions.invoke('media-manager', {
        body: {
          action: 'add_comment',
          post_id: selectedPost.id,
          user_id: currentUserId,
          username: user.username || user.email?.split('@')[0] || 'User',
          avatar_url: user.avatar_url,
          content: newComment.trim()
        }
      });

      if (error) throw error;

      setComments(prev => [data.comment, ...prev]);
      setPosts(prev => prev.map(p => 
        p.id === selectedPost.id 
          ? { ...p, comments_count: p.comments_count + 1 }
          : p
      ));
      setNewComment('');
    } catch (error: any) {
      toast({ title: 'Failed to comment', description: error.message, variant: 'destructive' });
    } finally {
      setSubmittingComment(false);
    }
  };

  const handleDelete = async (postId: string) => {
    if (!user) return;
    
    try {
      const currentUserId = user.user_id || user.id;
      await supabase.functions.invoke('media-manager', {
        body: { action: 'delete_post', post_id: postId, user_id: currentUserId }
      });

      setPosts(prev => prev.filter(p => p.id !== postId));
      setSelectedPost(null);
      toast({ title: 'Post deleted' });
    } catch (error: any) {
      toast({ title: 'Failed to delete', description: error.message, variant: 'destructive' });
    }
  };

  const formatDate = (dateStr: string) => {
    const date = new Date(dateStr);
    const now = new Date();
    const diff = now.getTime() - date.getTime();
    const minutes = Math.floor(diff / 60000);
    const hours = Math.floor(diff / 3600000);
    const days = Math.floor(diff / 86400000);

    if (minutes < 1) return 'Just now';
    if (minutes < 60) return `${minutes}m ago`;
    if (hours < 24) return `${hours}h ago`;
    if (days < 7) return `${days}d ago`;
    return date.toLocaleDateString();
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center py-12">
        <Loader2 className="w-8 h-8 animate-spin text-purple-500" />
      </div>
    );
  }

  if (posts.length === 0) {
    return (
      <div className="text-center py-12">
        <div className="w-16 h-16 rounded-full bg-muted flex items-center justify-center mx-auto mb-4">
          {filter === 'video' ? <Video className="w-8 h-8 text-muted-foreground" /> : <ImageIcon className="w-8 h-8 text-muted-foreground" />}
        </div>
        <h3 className="text-lg font-semibold mb-2">No posts yet</h3>
        <p className="text-muted-foreground">Be the first to share something!</p>
      </div>
    );
  }

  return (
    <>
      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
        {posts.map(post => (
          <Card 
            key={post.id} 
            className="overflow-hidden group cursor-pointer hover:ring-2 hover:ring-purple-500 transition-all"
            onClick={() => openPostDetails(post)}
          >
            <div className="aspect-square relative bg-black">
              {post.media_type === 'video' ? (
                <>
                  <video 
                    src={post.media_url} 
                    className="w-full h-full object-cover"
                    muted
                  />
                  <div className="absolute inset-0 flex items-center justify-center bg-black/30">
                    <div className="w-12 h-12 rounded-full bg-white/20 backdrop-blur flex items-center justify-center">
                      <Play className="w-6 h-6 text-white fill-white" />
                    </div>
                  </div>
                </>
              ) : (
                <img 
                  src={post.media_url} 
                  alt={post.caption} 
                  className="w-full h-full object-cover"
                />
              )}
              
              {/* Hover overlay */}
              <div className="absolute inset-0 bg-black/60 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center gap-6">
                <div className="flex items-center gap-2 text-white">
                  <Heart className={`w-6 h-6 ${likedPosts.has(post.id) ? 'fill-red-500 text-red-500' : ''}`} />
                  <span className="font-semibold">{post.likes_count}</span>
                </div>
                <div className="flex items-center gap-2 text-white">
                  <MessageCircle className="w-6 h-6" />
                  <span className="font-semibold">{post.comments_count}</span>
                </div>
              </div>

              {/* Media type badge */}
              <Badge 
                variant="secondary" 
                className="absolute top-2 right-2 bg-black/50 backdrop-blur"
              >
                {post.media_type === 'video' ? <Video className="w-3 h-3" /> : <ImageIcon className="w-3 h-3" />}
              </Badge>
            </div>
          </Card>
        ))}
      </div>

      {hasMore && (
        <div className="flex justify-center mt-6">
          <Button 
            variant="outline" 
            onClick={loadMorePosts}
            disabled={loadingMore}
          >
            {loadingMore ? <Loader2 className="w-4 h-4 animate-spin mr-2" /> : null}
            Load More
          </Button>
        </div>
      )}

      {/* Post Detail Modal */}
      <Dialog open={!!selectedPost} onOpenChange={() => setSelectedPost(null)}>
        <DialogContent className="max-w-4xl p-0 overflow-hidden">
          {selectedPost && (
            <div className="grid md:grid-cols-2">
              {/* Media */}
              <div className="bg-black flex items-center justify-center max-h-[80vh]">
                {selectedPost.media_type === 'video' ? (
                  <video 
                    src={selectedPost.media_url} 
                    controls 
                    autoPlay
                    className="max-w-full max-h-[80vh]"
                  />
                ) : (
                  <img 
                    src={selectedPost.media_url} 
                    alt={selectedPost.caption} 
                    className="max-w-full max-h-[80vh] object-contain"
                  />
                )}
              </div>

              {/* Details */}
              <div className="flex flex-col max-h-[80vh]">
                {/* Header */}
                <div className="p-4 border-b flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <Avatar>
                      <AvatarImage src={selectedPost.avatar_url} />
                      <AvatarFallback>{selectedPost.username[0]?.toUpperCase()}</AvatarFallback>
                    </Avatar>
                    <div>
                      <p className="font-semibold">{selectedPost.username}</p>
                      <p className="text-xs text-muted-foreground">{formatDate(selectedPost.created_at)}</p>
                    </div>
                  </div>
                  <DropdownMenu>
                    <DropdownMenuTrigger asChild>
                      <Button variant="ghost" size="icon">
                        <MoreHorizontal className="w-5 h-5" />
                      </Button>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent align="end">
                      <DropdownMenuItem className="gap-2">
                        <Share2 className="w-4 h-4" /> Share
                      </DropdownMenuItem>
                      <DropdownMenuItem className="gap-2">
                        <Bookmark className="w-4 h-4" /> Save
                      </DropdownMenuItem>
                      {user && (user.user_id === selectedPost.user_id || user.id === selectedPost.user_id) && (
                        <DropdownMenuItem 
                          className="gap-2 text-red-500"
                          onClick={() => handleDelete(selectedPost.id)}
                        >
                          <Trash2 className="w-4 h-4" /> Delete
                        </DropdownMenuItem>
                      )}
                    </DropdownMenuContent>
                  </DropdownMenu>
                </div>

                {/* Caption & Comments */}
                <ScrollArea className="flex-1 p-4">
                  {selectedPost.caption && (
                    <div className="mb-4">
                      <p className="text-sm">
                        <span className="font-semibold mr-2">{selectedPost.username}</span>
                        {selectedPost.caption}
                      </p>
                      {selectedPost.tags?.length > 0 && (
                        <div className="flex flex-wrap gap-1 mt-2">
                          {selectedPost.tags.map(tag => (
                            <span key={tag} className="text-purple-500 text-sm">#{tag}</span>
                          ))}
                        </div>
                      )}
                    </div>
                  )}

                  <div className="space-y-4">
                    {comments.map(comment => (
                      <div key={comment.id} className="flex gap-3">
                        <Avatar className="w-8 h-8">
                          <AvatarImage src={comment.avatar_url} />
                          <AvatarFallback>{comment.username[0]?.toUpperCase()}</AvatarFallback>
                        </Avatar>
                        <div>
                          <p className="text-sm">
                            <span className="font-semibold mr-2">{comment.username}</span>
                            {comment.content}
                          </p>
                          <p className="text-xs text-muted-foreground mt-1">{formatDate(comment.created_at)}</p>
                        </div>
                      </div>
                    ))}
                  </div>
                </ScrollArea>

                {/* Actions */}
                <div className="border-t p-4">
                  <div className="flex items-center gap-4 mb-4">
                    <Button 
                      variant="ghost" 
                      size="icon"
                      onClick={() => handleLike(selectedPost.id)}
                    >
                      <Heart className={`w-6 h-6 ${likedPosts.has(selectedPost.id) ? 'fill-red-500 text-red-500' : ''}`} />
                    </Button>
                    <Button variant="ghost" size="icon">
                      <MessageCircle className="w-6 h-6" />
                    </Button>
                    <Button variant="ghost" size="icon">
                      <Share2 className="w-6 h-6" />
                    </Button>
                    <div className="ml-auto flex items-center gap-1 text-sm text-muted-foreground">
                      <Eye className="w-4 h-4" />
                      {selectedPost.views_count} views
                    </div>
                  </div>
                  <p className="font-semibold text-sm mb-3">{selectedPost.likes_count} likes</p>
                  
                  {/* Comment input */}
                  {user && (
                    <div className="flex gap-2">
                      <Input
                        placeholder="Add a comment..."
                        value={newComment}
                        onChange={(e) => setNewComment(e.target.value)}
                        onKeyDown={(e) => e.key === 'Enter' && handleComment()}
                      />
                      <Button 
                        onClick={handleComment}
                        disabled={!newComment.trim() || submittingComment}
                      >
                        {submittingComment ? <Loader2 className="w-4 h-4 animate-spin" /> : 'Post'}
                      </Button>
                    </div>
                  )}
                </div>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </>
  );
}
