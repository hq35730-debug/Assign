
import React, { useRef, useCallback } from 'react';
import { Play, Eye, Heart, Clock, Scissors } from 'lucide-react';

interface Clip {
  id: string;
  title: string;
  streamer_id: string;
  streamer_name: string;
  creator_name: string;
  thumbnail_url: string;
  duration: number;
  views: number;
  likes: number;
  created_at: string;
}

interface Props {
  clips: Clip[];
  loading: boolean;
  hasMore: boolean;
  onLoadMore: () => void;
  onSelect: (clip: Clip) => void;
}

const formatDuration = (seconds: number) => {
  const mins = Math.floor(seconds / 60);
  const secs = seconds % 60;
  return `${mins}:${secs.toString().padStart(2, '0')}`;
};

const formatCount = (n: number) => {
  if (n >= 1000000) return `${(n / 1000000).toFixed(1)}M`;
  if (n >= 1000) return `${(n / 1000).toFixed(1)}K`;
  return n.toString();
};

const timeAgo = (date: string) => {
  const seconds = Math.floor((Date.now() - new Date(date).getTime()) / 1000);
  if (seconds < 3600) return `${Math.floor(seconds / 60)}m ago`;
  if (seconds < 86400) return `${Math.floor(seconds / 3600)}h ago`;
  return `${Math.floor(seconds / 86400)}d ago`;
};

export const FeedClips: React.FC<Props> = ({ clips, loading, hasMore, onLoadMore, onSelect }) => {
  const observer = useRef<IntersectionObserver>();
  const lastRef = useCallback((node: HTMLDivElement) => {
    if (loading) return;
    if (observer.current) observer.current.disconnect();
    observer.current = new IntersectionObserver(entries => {
      if (entries[0].isIntersecting && hasMore) onLoadMore();
    });
    if (node) observer.current.observe(node);
  }, [loading, hasMore, onLoadMore]);

  if (!loading && clips.length === 0) {
    return (
      <div className="text-center py-12 bg-gray-800/50 rounded-xl">
        <Scissors className="w-12 h-12 text-gray-500 mx-auto mb-3" />
        <p className="text-gray-400">No clips from followed channels yet</p>
      </div>
    );
  }

  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
      {clips.map((clip, i) => (
        <div key={clip.id} ref={i === clips.length - 1 ? lastRef : null} onClick={() => onSelect(clip)} className="group cursor-pointer bg-gray-800/50 rounded-xl overflow-hidden hover:bg-gray-800 transition-colors">
          <div className="relative aspect-video">
            <img src={clip.thumbnail_url || 'https://d64gsuwffb70l.cloudfront.net/6927ca8790687cc18bcac914_1764565042610_75ffd34f.webp'} alt={clip.title} className="w-full h-full object-cover" />
            <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
              <div className="w-12 h-12 rounded-full bg-purple-600 flex items-center justify-center">
                <Play className="w-5 h-5 text-white fill-white ml-0.5" />
              </div>
            </div>
            <div className="absolute bottom-2 right-2 bg-black/80 text-white text-xs px-2 py-1 rounded flex items-center gap-1">
              <Clock className="w-3 h-3" /> {formatDuration(clip.duration)}
            </div>
          </div>
          <div className="p-3">
            <h3 className="font-medium text-white truncate group-hover:text-purple-400">{clip.title}</h3>
            <p className="text-sm text-gray-400 mt-1">Clipped from {clip.streamer_name}</p>
            <p className="text-xs text-gray-500">by {clip.creator_name}</p>
            <div className="flex items-center gap-3 mt-2 text-xs text-gray-400">
              <span className="flex items-center gap-1"><Eye className="w-3 h-3" />{formatCount(clip.views || 0)}</span>
              <span className="flex items-center gap-1"><Heart className="w-3 h-3" />{formatCount(clip.likes || 0)}</span>
              <span className="ml-auto">{timeAgo(clip.created_at)}</span>
            </div>
          </div>
        </div>
      ))}
      {loading && [...Array(4)].map((_, i) => (
        <div key={`loading-${i}`} className="animate-pulse bg-gray-800/50 rounded-xl overflow-hidden">
          <div className="aspect-video bg-gray-700" />
          <div className="p-3">
            <div className="h-4 bg-gray-700 rounded w-3/4 mb-2" />
            <div className="h-3 bg-gray-700 rounded w-1/2" />
          </div>
        </div>
      ))}
    </div>
  );
};
