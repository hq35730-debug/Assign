
import React from 'react';
import { Calendar, Clock, Bell, BellOff } from 'lucide-react';
import { Button } from '@/components/ui/button';

interface Schedule {
  id: string;
  channel_id: string;
  title: string;
  description: string;
  category: string;
  scheduled_start: string;
  scheduled_end: string;
  thumbnail_url: string;
  is_recurring: boolean;
}

interface Props {
  schedules: Schedule[];
  loading: boolean;
  subscribedIds: string[];
  onToggleNotification: (scheduleId: string) => void;
}

export const FeedSchedules: React.FC<Props> = ({ schedules, loading, subscribedIds, onToggleNotification }) => {
  const formatDate = (date: string) => {
    const d = new Date(date);
    const today = new Date();
    const tomorrow = new Date(today);
    tomorrow.setDate(tomorrow.getDate() + 1);
    
    if (d.toDateString() === today.toDateString()) return 'Today';
    if (d.toDateString() === tomorrow.toDateString()) return 'Tomorrow';
    return d.toLocaleDateString('en-US', { weekday: 'short', month: 'short', day: 'numeric' });
  };

  const formatTime = (date: string) => new Date(date).toLocaleTimeString('en-US', { hour: 'numeric', minute: '2-digit' });

  if (loading) {
    return (
      <div className="space-y-3">
        {[...Array(4)].map((_, i) => (
          <div key={i} className="animate-pulse flex gap-4 p-4 bg-gray-800/50 rounded-xl">
            <div className="w-20 h-20 bg-gray-700 rounded-lg" />
            <div className="flex-1">
              <div className="h-4 bg-gray-700 rounded w-3/4 mb-2" />
              <div className="h-3 bg-gray-700 rounded w-1/2" />
            </div>
          </div>
        ))}
      </div>
    );
  }

  if (schedules.length === 0) {
    return (
      <div className="text-center py-12 bg-gray-800/50 rounded-xl">
        <Calendar className="w-12 h-12 text-gray-500 mx-auto mb-3" />
        <p className="text-gray-400">No upcoming scheduled streams</p>
        <p className="text-gray-500 text-sm mt-1">Channels you follow haven't scheduled any streams yet</p>
      </div>
    );
  }

  return (
    <div className="space-y-3">
      {schedules.map(schedule => {
        const isSubscribed = subscribedIds.includes(schedule.id);
        return (
          <div key={schedule.id} className="flex gap-4 p-4 bg-gray-800/50 hover:bg-gray-800 rounded-xl transition-colors">
            <div className="w-20 h-20 rounded-lg overflow-hidden bg-gray-700 flex-shrink-0">
              {schedule.thumbnail_url ? (
                <img src={schedule.thumbnail_url} alt={schedule.title} className="w-full h-full object-cover" />
              ) : (
                <div className="w-full h-full flex items-center justify-center">
                  <Calendar className="w-8 h-8 text-gray-500" />
                </div>
              )}
            </div>
            <div className="flex-1 min-w-0">
              <h4 className="text-white font-medium truncate">{schedule.title}</h4>
              <p className="text-sm text-gray-400 truncate">{schedule.description}</p>
              <div className="flex items-center gap-3 mt-2 text-xs text-gray-500">
                <span className="flex items-center gap-1"><Calendar className="w-3 h-3" /> {formatDate(schedule.scheduled_start)}</span>
                <span className="flex items-center gap-1"><Clock className="w-3 h-3" /> {formatTime(schedule.scheduled_start)}</span>
                {schedule.category && <span className="bg-purple-600/30 text-purple-300 px-2 py-0.5 rounded">{schedule.category}</span>}
              </div>
            </div>
            <Button size="sm" variant={isSubscribed ? "secondary" : "outline"} onClick={() => onToggleNotification(schedule.id)} className="flex-shrink-0">
              {isSubscribed ? <BellOff className="w-4 h-4" /> : <Bell className="w-4 h-4" />}
            </Button>
          </div>
        );
      })}
    </div>
  );
};
