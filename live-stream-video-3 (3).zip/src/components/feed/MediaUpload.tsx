import { useState, useRef } from 'react';
import { Upload, Image, Video, X, Loader2, Send, Hash } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Card } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/contexts/AuthContext';
import { useToast } from '@/hooks/use-toast';

interface MediaUploadProps {
  onPostCreated?: () => void;
}

export function MediaUpload({ onPostCreated }: MediaUploadProps) {
  const { user } = useAuth();
  const { toast } = useToast();
  const [open, setOpen] = useState(false);
  const [mediaFile, setMediaFile] = useState<File | null>(null);
  const [mediaPreview, setMediaPreview] = useState<string | null>(null);
  const [mediaType, setMediaType] = useState<'image' | 'video' | null>(null);
  const [caption, setCaption] = useState('');
  const [tagInput, setTagInput] = useState('');
  const [tags, setTags] = useState<string[]>([]);
  const [uploading, setUploading] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    // Check file type
    if (file.type.startsWith('image/')) {
      setMediaType('image');
    } else if (file.type.startsWith('video/')) {
      setMediaType('video');
    } else {
      toast({ title: 'Invalid file type', description: 'Please select an image or video file', variant: 'destructive' });
      return;
    }

    // Check file size (50MB max for videos, 10MB for images)
    const maxSize = file.type.startsWith('video/') ? 50 * 1024 * 1024 : 10 * 1024 * 1024;
    if (file.size > maxSize) {
      toast({ 
        title: 'File too large', 
        description: `Maximum size is ${file.type.startsWith('video/') ? '50MB' : '10MB'}`, 
        variant: 'destructive' 
      });
      return;
    }

    setMediaFile(file);
    setMediaPreview(URL.createObjectURL(file));
  };

  const handleAddTag = () => {
    if (tagInput.trim() && tags.length < 10) {
      const newTag = tagInput.trim().toLowerCase().replace(/[^a-z0-9]/g, '');
      if (newTag && !tags.includes(newTag)) {
        setTags([...tags, newTag]);
      }
      setTagInput('');
    }
  };

  const handleRemoveTag = (tag: string) => {
    setTags(tags.filter(t => t !== tag));
  };

  const handleUpload = async () => {
    if (!mediaFile || !user) return;

    setUploading(true);
    try {
      const userId = user.user_id || user.id;
      const fileExt = mediaFile.name.split('.').pop();
      const fileName = `${userId}/${Date.now()}.${fileExt}`;

      // Upload to storage
      const { data: uploadData, error: uploadError } = await supabase.storage
        .from('media-posts')
        .upload(fileName, mediaFile, {
          cacheControl: '3600',
          upsert: false
        });

      if (uploadError) throw uploadError;

      // Get public URL
      const { data: { publicUrl } } = supabase.storage
        .from('media-posts')
        .getPublicUrl(fileName);

      // Create post
      const { data, error } = await supabase.functions.invoke('media-manager', {
        body: {
          action: 'create_post',
          user_id: userId,
          username: user.username || user.email?.split('@')[0] || 'User',
          avatar_url: user.avatar_url,
          media_type: mediaType,
          media_url: publicUrl,
          thumbnail_url: mediaType === 'image' ? publicUrl : null,
          caption,
          tags
        }
      });

      if (error) throw error;

      toast({ title: 'Post created!', description: 'Your media has been shared successfully' });
      
      // Reset form
      setMediaFile(null);
      setMediaPreview(null);
      setMediaType(null);
      setCaption('');
      setTags([]);
      setOpen(false);
      
      onPostCreated?.();
    } catch (error: any) {
      toast({ title: 'Upload failed', description: error.message, variant: 'destructive' });
    } finally {
      setUploading(false);
    }
  };

  const clearMedia = () => {
    setMediaFile(null);
    setMediaPreview(null);
    setMediaType(null);
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button className="gap-2 bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700">
          <Upload className="w-4 h-4" />
          Create Post
        </Button>
      </DialogTrigger>
      <DialogContent className="max-w-lg">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Upload className="w-5 h-5 text-purple-500" />
            Create New Post
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-4">
          {/* Media Upload Area */}
          {!mediaPreview ? (
            <div 
              className="border-2 border-dashed border-border rounded-lg p-8 text-center cursor-pointer hover:border-purple-500 transition-colors"
              onClick={() => fileInputRef.current?.click()}
            >
              <div className="flex justify-center gap-4 mb-4">
                <div className="w-12 h-12 rounded-full bg-purple-500/10 flex items-center justify-center">
                  <Image className="w-6 h-6 text-purple-500" />
                </div>
                <div className="w-12 h-12 rounded-full bg-pink-500/10 flex items-center justify-center">
                  <Video className="w-6 h-6 text-pink-500" />
                </div>
              </div>
              <p className="text-muted-foreground mb-2">Click to upload a photo or video</p>
              <p className="text-xs text-muted-foreground">Images up to 10MB, Videos up to 50MB</p>
              <input
                ref={fileInputRef}
                type="file"
                accept="image/*,video/*"
                onChange={handleFileSelect}
                className="hidden"
              />
            </div>
          ) : (
            <div className="relative">
              <Button
                variant="ghost"
                size="icon"
                className="absolute top-2 right-2 z-10 bg-black/50 hover:bg-black/70"
                onClick={clearMedia}
              >
                <X className="w-4 h-4" />
              </Button>
              {mediaType === 'image' ? (
                <img 
                  src={mediaPreview} 
                  alt="Preview" 
                  className="w-full max-h-64 object-contain rounded-lg bg-black"
                />
              ) : (
                <video 
                  src={mediaPreview} 
                  controls 
                  className="w-full max-h-64 rounded-lg bg-black"
                />
              )}
            </div>
          )}

          {/* Caption */}
          <div>
            <Textarea
              placeholder="Write a caption..."
              value={caption}
              onChange={(e) => setCaption(e.target.value)}
              className="resize-none"
              rows={3}
              maxLength={500}
            />
            <p className="text-xs text-muted-foreground text-right mt-1">{caption.length}/500</p>
          </div>

          {/* Tags */}
          <div>
            <div className="flex gap-2 mb-2">
              <div className="relative flex-1">
                <Hash className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                <Input
                  placeholder="Add tags..."
                  value={tagInput}
                  onChange={(e) => setTagInput(e.target.value)}
                  onKeyDown={(e) => e.key === 'Enter' && (e.preventDefault(), handleAddTag())}
                  className="pl-9"
                />
              </div>
              <Button variant="outline" onClick={handleAddTag} disabled={tags.length >= 10}>
                Add
              </Button>
            </div>
            {tags.length > 0 && (
              <div className="flex flex-wrap gap-2">
                {tags.map(tag => (
                  <Badge key={tag} variant="secondary" className="gap-1">
                    #{tag}
                    <X 
                      className="w-3 h-3 cursor-pointer hover:text-red-500" 
                      onClick={() => handleRemoveTag(tag)}
                    />
                  </Badge>
                ))}
              </div>
            )}
          </div>

          {/* Submit */}
          <Button 
            className="w-full gap-2" 
            onClick={handleUpload}
            disabled={!mediaFile || uploading}
          >
            {uploading ? (
              <>
                <Loader2 className="w-4 h-4 animate-spin" />
                Uploading...
              </>
            ) : (
              <>
                <Send className="w-4 h-4" />
                Share Post
              </>
            )}
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}
