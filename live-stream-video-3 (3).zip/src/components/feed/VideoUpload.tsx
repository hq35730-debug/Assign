import { useState, useRef, useCallback } from 'react';
import { 
  Upload, Video, X, Loader2, Send, Hash, Film, Clock, 
  FileVideo, CheckCircle, AlertCircle, Play, Pause
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Card } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/contexts/AuthContext';
import { useToast } from '@/hooks/use-toast';

interface VideoUploadProps {
  onVideoUploaded?: () => void;
}

export function VideoUpload({ onVideoUploaded }: VideoUploadProps) {
  const { user } = useAuth();
  const { toast } = useToast();
  const [open, setOpen] = useState(false);
  const [videoFile, setVideoFile] = useState<File | null>(null);
  const [videoPreview, setVideoPreview] = useState<string | null>(null);
  const [thumbnailUrl, setThumbnailUrl] = useState<string | null>(null);
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [tagInput, setTagInput] = useState('');
  const [tags, setTags] = useState<string[]>([]);
  const [category, setCategory] = useState('');
  const [visibility, setVisibility] = useState<'public' | 'private' | 'unlisted'>('public');
  const [uploading, setUploading] = useState(false);
  const [uploadProgress, setUploadProgress] = useState(0);
  const [uploadStage, setUploadStage] = useState<'idle' | 'uploading' | 'processing' | 'complete'>('idle');
  const [videoDuration, setVideoDuration] = useState(0);
  const [videoSize, setVideoSize] = useState(0);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const videoRef = useRef<HTMLVideoElement>(null);

  const categories = [
    'Gaming', 'Music', 'Sports', 'Education', 'Entertainment', 
    'News', 'Technology', 'Art', 'Cooking', 'Travel', 'Fitness', 'Other'
  ];

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (!file.type.startsWith('video/')) {
      toast({ title: 'Invalid file type', description: 'Please select a video file', variant: 'destructive' });
      return;
    }

    // Check file size (500MB max)
    const maxSize = 500 * 1024 * 1024;
    if (file.size > maxSize) {
      toast({ title: 'File too large', description: 'Maximum video size is 500MB', variant: 'destructive' });
      return;
    }

    setVideoFile(file);
    setVideoSize(file.size);
    const previewUrl = URL.createObjectURL(file);
    setVideoPreview(previewUrl);

    // Get video duration and generate thumbnail
    const video = document.createElement('video');
    video.preload = 'metadata';
    video.onloadedmetadata = () => {
      setVideoDuration(video.duration);
      
      // Generate thumbnail at 1 second mark
      video.currentTime = Math.min(1, video.duration / 2);
    };
    video.onseeked = () => {
      const canvas = document.createElement('canvas');
      canvas.width = video.videoWidth;
      canvas.height = video.videoHeight;
      const ctx = canvas.getContext('2d');
      if (ctx) {
        ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
        setThumbnailUrl(canvas.toDataURL('image/jpeg', 0.8));
      }
      URL.revokeObjectURL(video.src);
    };
    video.src = previewUrl;
  };

  const handleAddTag = () => {
    if (tagInput.trim() && tags.length < 15) {
      const newTag = tagInput.trim().toLowerCase().replace(/[^a-z0-9]/g, '');
      if (newTag && !tags.includes(newTag)) {
        setTags([...tags, newTag]);
      }
      setTagInput('');
    }
  };

  const handleRemoveTag = (tag: string) => {
    setTags(tags.filter(t => t !== tag));
  };

  const formatDuration = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = Math.floor(seconds % 60);
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  const formatFileSize = (bytes: number) => {
    if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
    return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
  };

  const handleUpload = async () => {
    if (!videoFile || !user || !title.trim()) {
      toast({ title: 'Missing information', description: 'Please add a title for your video', variant: 'destructive' });
      return;
    }

    setUploading(true);
    setUploadStage('uploading');
    setUploadProgress(0);

    try {
      const userId = user.user_id || user.id;
      const fileExt = videoFile.name.split('.').pop();
      const fileName = `videos/${userId}/${Date.now()}.${fileExt}`;

      // Simulate upload progress
      const progressInterval = setInterval(() => {
        setUploadProgress(prev => {
          if (prev >= 90) {
            clearInterval(progressInterval);
            return 90;
          }
          return prev + Math.random() * 10;
        });
      }, 500);

      // Upload video to storage
      const { data: uploadData, error: uploadError } = await supabase.storage
        .from('media-posts')
        .upload(fileName, videoFile, {
          cacheControl: '3600',
          upsert: false
        });

      clearInterval(progressInterval);

      if (uploadError) throw uploadError;

      setUploadProgress(95);
      setUploadStage('processing');

      // Get public URL
      const { data: { publicUrl } } = supabase.storage
        .from('media-posts')
        .getPublicUrl(fileName);

      // Upload thumbnail if generated
      let thumbnailPublicUrl = null;
      if (thumbnailUrl) {
        const thumbnailBlob = await fetch(thumbnailUrl).then(r => r.blob());
        const thumbnailFileName = `thumbnails/${userId}/${Date.now()}.jpg`;
        
        const { error: thumbError } = await supabase.storage
          .from('media-posts')
          .upload(thumbnailFileName, thumbnailBlob, {
            cacheControl: '3600',
            contentType: 'image/jpeg'
          });

        if (!thumbError) {
          const { data: { publicUrl: thumbUrl } } = supabase.storage
            .from('media-posts')
            .getPublicUrl(thumbnailFileName);
          thumbnailPublicUrl = thumbUrl;
        }
      }

      // Create video post
      const { data, error } = await supabase.functions.invoke('media-manager', {
        body: {
          action: 'create_post',
          user_id: userId,
          username: user.username || user.email?.split('@')[0] || 'User',
          avatar_url: user.avatar_url,
          media_type: 'video',
          media_url: publicUrl,
          thumbnail_url: thumbnailPublicUrl,
          caption: description,
          title,
          tags,
          category,
          visibility,
          duration: videoDuration,
          file_size: videoSize
        }
      });

      if (error) throw error;

      setUploadProgress(100);
      setUploadStage('complete');

      toast({ title: 'Video uploaded!', description: 'Your video has been shared successfully' });
      
      // Reset form after short delay
      setTimeout(() => {
        resetForm();
        setOpen(false);
        onVideoUploaded?.();
      }, 1500);

    } catch (error: any) {
      toast({ title: 'Upload failed', description: error.message, variant: 'destructive' });
      setUploadStage('idle');
    } finally {
      setUploading(false);
    }
  };

  const resetForm = () => {
    setVideoFile(null);
    setVideoPreview(null);
    setThumbnailUrl(null);
    setTitle('');
    setDescription('');
    setTags([]);
    setTagInput('');
    setCategory('');
    setVisibility('public');
    setUploadProgress(0);
    setUploadStage('idle');
    setVideoDuration(0);
    setVideoSize(0);
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  const clearVideo = () => {
    if (videoPreview) {
      URL.revokeObjectURL(videoPreview);
    }
    resetForm();
  };

  return (
    <Dialog open={open} onOpenChange={(isOpen) => {
      if (!isOpen && !uploading) resetForm();
      if (!uploading) setOpen(isOpen);
    }}>
      <DialogTrigger asChild>
        <Button className="gap-2 bg-gradient-to-r from-pink-600 to-red-600 hover:from-pink-700 hover:to-red-700">
          <Film className="w-4 h-4" />
          Upload Video
        </Button>
      </DialogTrigger>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Video className="w-5 h-5 text-pink-500" />
            Upload Video
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-6">
          {/* Video Upload Area */}
          {!videoPreview ? (
            <div 
              className="border-2 border-dashed border-border rounded-lg p-8 text-center cursor-pointer hover:border-pink-500 transition-colors"
              onClick={() => fileInputRef.current?.click()}
            >
              <div className="w-16 h-16 rounded-full bg-pink-500/10 flex items-center justify-center mx-auto mb-4">
                <FileVideo className="w-8 h-8 text-pink-500" />
              </div>
              <p className="text-lg font-medium mb-2">Select a video to upload</p>
              <p className="text-muted-foreground text-sm mb-4">
                MP4, WebM, MOV supported. Max 500MB.
              </p>
              <Button variant="secondary" className="gap-2">
                <Upload className="w-4 h-4" />
                Choose File
              </Button>
              <input
                ref={fileInputRef}
                type="file"
                accept="video/*"
                onChange={handleFileSelect}
                className="hidden"
              />
            </div>
          ) : (
            <div className="space-y-4">
              {/* Video Preview */}
              <div className="relative rounded-lg overflow-hidden bg-black">
                <video 
                  ref={videoRef}
                  src={videoPreview} 
                  controls 
                  className="w-full max-h-64"
                />
                {!uploading && (
                  <Button
                    variant="ghost"
                    size="icon"
                    className="absolute top-2 right-2 bg-black/50 hover:bg-black/70 text-white"
                    onClick={clearVideo}
                  >
                    <X className="w-4 h-4" />
                  </Button>
                )}
              </div>

              {/* Video Info */}
              <div className="flex items-center gap-4 text-sm text-muted-foreground">
                <div className="flex items-center gap-1">
                  <Clock className="w-4 h-4" />
                  {formatDuration(videoDuration)}
                </div>
                <div className="flex items-center gap-1">
                  <FileVideo className="w-4 h-4" />
                  {formatFileSize(videoSize)}
                </div>
              </div>

              {/* Upload Progress */}
              {uploading && (
                <Card className="p-4">
                  <div className="flex items-center gap-3 mb-3">
                    {uploadStage === 'complete' ? (
                      <CheckCircle className="w-5 h-5 text-green-500" />
                    ) : (
                      <Loader2 className="w-5 h-5 animate-spin text-pink-500" />
                    )}
                    <span className="font-medium">
                      {uploadStage === 'uploading' && 'Uploading video...'}
                      {uploadStage === 'processing' && 'Processing video...'}
                      {uploadStage === 'complete' && 'Upload complete!'}
                    </span>
                  </div>
                  <Progress value={uploadProgress} className="h-2" />
                  <p className="text-xs text-muted-foreground mt-2 text-right">
                    {Math.round(uploadProgress)}%
                  </p>
                </Card>
              )}

              {/* Video Details Form */}
              {!uploading && (
                <>
                  {/* Title */}
                  <div>
                    <label className="text-sm font-medium mb-2 block">Title *</label>
                    <Input
                      placeholder="Enter video title..."
                      value={title}
                      onChange={(e) => setTitle(e.target.value)}
                      maxLength={100}
                    />
                    <p className="text-xs text-muted-foreground text-right mt-1">{title.length}/100</p>
                  </div>

                  {/* Description */}
                  <div>
                    <label className="text-sm font-medium mb-2 block">Description</label>
                    <Textarea
                      placeholder="Describe your video..."
                      value={description}
                      onChange={(e) => setDescription(e.target.value)}
                      className="resize-none"
                      rows={3}
                      maxLength={2000}
                    />
                    <p className="text-xs text-muted-foreground text-right mt-1">{description.length}/2000</p>
                  </div>

                  {/* Category & Visibility */}
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <label className="text-sm font-medium mb-2 block">Category</label>
                      <Select value={category} onValueChange={setCategory}>
                        <SelectTrigger>
                          <SelectValue placeholder="Select category" />
                        </SelectTrigger>
                        <SelectContent>
                          {categories.map(cat => (
                            <SelectItem key={cat} value={cat.toLowerCase()}>{cat}</SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                    <div>
                      <label className="text-sm font-medium mb-2 block">Visibility</label>
                      <Select value={visibility} onValueChange={(v: any) => setVisibility(v)}>
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="public">Public</SelectItem>
                          <SelectItem value="unlisted">Unlisted</SelectItem>
                          <SelectItem value="private">Private</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>

                  {/* Tags */}
                  <div>
                    <label className="text-sm font-medium mb-2 block">Tags</label>
                    <div className="flex gap-2 mb-2">
                      <div className="relative flex-1">
                        <Hash className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                        <Input
                          placeholder="Add tags..."
                          value={tagInput}
                          onChange={(e) => setTagInput(e.target.value)}
                          onKeyDown={(e) => e.key === 'Enter' && (e.preventDefault(), handleAddTag())}
                          className="pl-9"
                        />
                      </div>
                      <Button variant="outline" onClick={handleAddTag} disabled={tags.length >= 15}>
                        Add
                      </Button>
                    </div>
                    {tags.length > 0 && (
                      <div className="flex flex-wrap gap-2">
                        {tags.map(tag => (
                          <Badge key={tag} variant="secondary" className="gap-1">
                            #{tag}
                            <X 
                              className="w-3 h-3 cursor-pointer hover:text-red-500" 
                              onClick={() => handleRemoveTag(tag)}
                            />
                          </Badge>
                        ))}
                      </div>
                    )}
                    <p className="text-xs text-muted-foreground mt-1">{tags.length}/15 tags</p>
                  </div>

                  {/* Thumbnail Preview */}
                  {thumbnailUrl && (
                    <div>
                      <label className="text-sm font-medium mb-2 block">Thumbnail (auto-generated)</label>
                      <img 
                        src={thumbnailUrl} 
                        alt="Thumbnail" 
                        className="w-40 h-24 object-cover rounded-lg border"
                      />
                    </div>
                  )}
                </>
              )}
            </div>
          )}

          {/* Submit Button */}
          {videoPreview && !uploading && (
            <Button 
              className="w-full gap-2 bg-gradient-to-r from-pink-600 to-red-600 hover:from-pink-700 hover:to-red-700" 
              onClick={handleUpload}
              disabled={!videoFile || !title.trim()}
            >
              <Send className="w-4 h-4" />
              Upload Video
            </Button>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
}
