
import { Gift, MessageSquare, Music, Smile, Sparkles, Star } from 'lucide-react';
import { Button } from '@/components/ui/button';

interface Reward {
  id: string;
  title: string;
  description?: string;
  cost: number;
  icon: string;
  color: string;
  requires_input: boolean;
  redemption_count: number;
}

interface RewardCardProps {
  reward: Reward;
  userPoints: number;
  onRedeem: (reward: Reward) => void;
}

const iconMap: Record<string, React.ReactNode> = {
  gift: <Gift className="w-5 h-5" />,
  message: <MessageSquare className="w-5 h-5" />,
  music: <Music className="w-5 h-5" />,
  emote: <Smile className="w-5 h-5" />,
  sparkles: <Sparkles className="w-5 h-5" />,
  star: <Star className="w-5 h-5" />
};

export function RewardCard({ reward, userPoints, onRedeem }: RewardCardProps) {
  const canAfford = userPoints >= reward.cost;

  return (
    <div 
      className={`bg-gray-800/50 rounded-lg p-3 border transition-all ${
        canAfford ? 'border-gray-700 hover:border-purple-500 cursor-pointer' : 'border-gray-800 opacity-60'
      }`}
      onClick={() => canAfford && onRedeem(reward)}
    >
      <div className="flex items-start gap-3">
        <div 
          className="w-10 h-10 rounded-lg flex items-center justify-center"
          style={{ backgroundColor: reward.color + '30' }}
        >
          <span style={{ color: reward.color }}>
            {iconMap[reward.icon] || <Gift className="w-5 h-5" />}
          </span>
        </div>
        <div className="flex-1 min-w-0">
          <h4 className="text-sm font-semibold text-white truncate">{reward.title}</h4>
          {reward.description && (
            <p className="text-xs text-gray-400 line-clamp-2 mt-0.5">{reward.description}</p>
          )}
          <div className="flex items-center gap-2 mt-2">
            <div className="flex items-center gap-1 text-yellow-400">
              <Sparkles className="w-3 h-3" />
              <span className="text-xs font-bold">{reward.cost.toLocaleString()}</span>
            </div>
            <span className="text-[10px] text-gray-500">{reward.redemption_count} redeemed</span>
          </div>
        </div>
      </div>
    </div>
  );
}
