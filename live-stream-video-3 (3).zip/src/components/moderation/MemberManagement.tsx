import { useState, useEffect } from 'react';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/contexts/AuthContext';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { UserX, VolumeX, Volume2, Shield, Crown, User } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

interface Member {
  user_id: string;
  role: string;
  profile: { username: string; avatar_url?: string };
  isMuted: boolean;
  mutedUntil?: string;
}

export function MemberManagement({ dialogueId, userRole }: { dialogueId: string; userRole: string }) {
  const { user } = useAuth();
  const { toast } = useToast();
  const [members, setMembers] = useState<Member[]>([]);
  const [loading, setLoading] = useState(true);
  const [muteModal, setMuteModal] = useState<Member | null>(null);
  const [muteDuration, setMuteDuration] = useState('10');
  const [muteReason, setMuteReason] = useState('');

  useEffect(() => { loadMembers(); }, [dialogueId]);

  const loadMembers = async () => {
    const { data } = await supabase.functions.invoke('messages-manager', {
      body: { action: 'get_dialogue_members', dialogue_id: dialogueId }
    });
    setMembers(data?.members || []);
    setLoading(false);
  };

  const removeMember = async (member: Member) => {
    if (!confirm(`Remove ${member.profile.username}?`)) return;
    await supabase.functions.invoke('messages-manager', {
      body: { action: 'remove_member', dialogue_id: dialogueId, user_id: user?.id, target_id: member.user_id, actor_username: user?.username, target_username: member.profile.username }
    });
    toast({ title: 'Member removed' });
    loadMembers();
  };

  const muteMember = async () => {
    if (!muteModal) return;
    await supabase.functions.invoke('messages-manager', {
      body: { action: 'mute_member', dialogue_id: dialogueId, user_id: user?.id, target_id: muteModal.user_id, duration_minutes: parseInt(muteDuration), reason: muteReason, actor_username: user?.username, target_username: muteModal.profile.username }
    });
    toast({ title: `${muteModal.profile.username} muted for ${muteDuration} minutes` });
    setMuteModal(null);
    setMuteReason('');
    loadMembers();
  };

  const unmuteMember = async (member: Member) => {
    await supabase.functions.invoke('messages-manager', {
      body: { action: 'unmute_member', dialogue_id: dialogueId, user_id: user?.id, target_id: member.user_id, actor_username: user?.username, target_username: member.profile.username }
    });
    toast({ title: `${member.profile.username} unmuted` });
    loadMembers();
  };

  const updateRole = async (member: Member, newRole: string) => {
    await supabase.functions.invoke('messages-manager', {
      body: { action: 'update_member_role', dialogue_id: dialogueId, user_id: user?.id, target_id: member.user_id, new_role: newRole, actor_username: user?.username, target_username: member.profile.username }
    });
    toast({ title: `Role updated to ${newRole}` });
    loadMembers();
  };

  const canModerate = (member: Member) => {
    if (member.user_id === user?.id) return false;
    if (userRole === 'owner') return member.role !== 'owner';
    if (userRole === 'admin') return member.role === 'member';
    return false;
  };

  const getRoleIcon = (role: string) => {
    if (role === 'owner') return <Crown className="w-4 h-4 text-yellow-500" />;
    if (role === 'admin') return <Shield className="w-4 h-4 text-purple-500" />;
    return <User className="w-4 h-4 text-gray-500" />;
  };

  if (loading) return <div className="text-center py-8 text-gray-400">Loading...</div>;

  return (
    <div className="space-y-4">
      {members.map((member) => (
        <Card key={member.user_id} className="bg-gray-800 border-gray-700">
          <CardContent className="p-4 flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-full bg-gradient-to-br from-purple-500 to-pink-500 flex items-center justify-center text-white font-bold">
                {member.profile.username[0].toUpperCase()}
              </div>
              <div>
                <div className="flex items-center gap-2">
                  <span className="font-medium">{member.profile.username}</span>
                  {getRoleIcon(member.role)}
                  {member.isMuted && <Badge variant="destructive" className="text-xs">Muted</Badge>}
                </div>
                <span className="text-sm text-gray-400 capitalize">{member.role}</span>
              </div>
            </div>
            {canModerate(member) && (
              <div className="flex gap-2">
                {userRole === 'owner' && (
                  <Select value={member.role} onValueChange={(v) => updateRole(member, v)}>
                    <SelectTrigger className="w-28 bg-gray-700 border-gray-600"><SelectValue /></SelectTrigger>
                    <SelectContent><SelectItem value="member">Member</SelectItem><SelectItem value="admin">Admin</SelectItem></SelectContent>
                  </Select>
                )}
                {member.isMuted ? (
                  <Button size="sm" variant="outline" onClick={() => unmuteMember(member)}><Volume2 className="w-4 h-4" /></Button>
                ) : (
                  <Button size="sm" variant="outline" onClick={() => setMuteModal(member)}><VolumeX className="w-4 h-4" /></Button>
                )}
                <Button size="sm" variant="destructive" onClick={() => removeMember(member)}><UserX className="w-4 h-4" /></Button>
              </div>
            )}
          </CardContent>
        </Card>
      ))}

      <Dialog open={!!muteModal} onOpenChange={() => setMuteModal(null)}>
        <DialogContent className="bg-gray-800 border-gray-700">
          <DialogHeader><DialogTitle>Mute {muteModal?.profile.username}</DialogTitle></DialogHeader>
          <div className="space-y-4">
            <Select value={muteDuration} onValueChange={setMuteDuration}>
              <SelectTrigger className="bg-gray-700 border-gray-600"><SelectValue /></SelectTrigger>
              <SelectContent><SelectItem value="5">5 minutes</SelectItem><SelectItem value="10">10 minutes</SelectItem><SelectItem value="30">30 minutes</SelectItem><SelectItem value="60">1 hour</SelectItem><SelectItem value="1440">24 hours</SelectItem></SelectContent>
            </Select>
            <Input placeholder="Reason (optional)" value={muteReason} onChange={(e) => setMuteReason(e.target.value)} className="bg-gray-700 border-gray-600" />
          </div>
          <DialogFooter><Button onClick={muteMember}>Mute</Button></DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
