
import { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { AlertTriangle, Flag } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { useToast } from '@/hooks/use-toast';

interface ReportModalProps {
  open: boolean;
  onClose: () => void;
  dialogueId: string;
  reporterId: string;
  reporterUsername: string;
  targetUserId?: string;
  targetUsername?: string;
  messageId?: string;
  messageContent?: string;
}

const REPORT_REASONS = [
  { value: 'spam', label: 'Spam or advertising' },
  { value: 'harassment', label: 'Harassment or bullying' },
  { value: 'hate_speech', label: 'Hate speech or discrimination' },
  { value: 'inappropriate', label: 'Inappropriate content' },
  { value: 'impersonation', label: 'Impersonation' },
  { value: 'other', label: 'Other' }
];

export function ReportModal({ open, onClose, dialogueId, reporterId, reporterUsername, targetUserId, targetUsername, messageId, messageContent }: ReportModalProps) {
  const [reason, setReason] = useState('');
  const [details, setDetails] = useState('');
  const [loading, setLoading] = useState(false);
  const { toast } = useToast();

  const handleSubmit = async () => {
    if (!reason) {
      toast({ title: 'Please select a reason', variant: 'destructive' });
      return;
    }
    setLoading(true);
    try {
      await supabase.functions.invoke('moderation-queue', {
        body: {
          action: 'submit_report',
          dialogue_id: dialogueId, reporter_id: reporterId, reporter_username: reporterUsername,
          reported_user_id: targetUserId, reported_username: targetUsername,
          message_id: messageId, message_content: messageContent, reason, details
        }
      });
      toast({ title: 'Report submitted', description: 'Moderators will review your report.' });
      onClose();
      setReason(''); setDetails('');
    } catch (e) {
      toast({ title: 'Failed to submit report', variant: 'destructive' });
    }
    setLoading(false);
  };

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="bg-gray-900 border-gray-800">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2 text-white">
            <Flag className="h-5 w-5 text-red-500" /> Report {messageId ? 'Message' : 'User'}
          </DialogTitle>
        </DialogHeader>
        {messageContent && (
          <div className="bg-gray-800 p-3 rounded-lg border-l-4 border-red-500">
            <p className="text-sm text-gray-300 line-clamp-3">{messageContent}</p>
            <p className="text-xs text-gray-500 mt-1">by {targetUsername}</p>
          </div>
        )}
        <div className="space-y-4">
          <Label className="text-gray-300">Reason for report</Label>
          <RadioGroup value={reason} onValueChange={setReason}>
            {REPORT_REASONS.map(r => (
              <div key={r.value} className="flex items-center space-x-2">
                <RadioGroupItem value={r.value} id={r.value} className="border-gray-600" />
                <Label htmlFor={r.value} className="text-gray-300 cursor-pointer">{r.label}</Label>
              </div>
            ))}
          </RadioGroup>
          <div>
            <Label className="text-gray-300">Additional details (optional)</Label>
            <Textarea value={details} onChange={e => setDetails(e.target.value)} placeholder="Provide more context..." className="bg-gray-800 border-gray-700 mt-2" />
          </div>
          <div className="flex items-start gap-2 p-3 bg-yellow-500/10 rounded-lg">
            <AlertTriangle className="h-5 w-5 text-yellow-500 flex-shrink-0" />
            <p className="text-xs text-yellow-400">False reports may result in action against your account.</p>
          </div>
          <div className="flex gap-2">
            <Button variant="outline" onClick={onClose} className="flex-1 border-gray-700">Cancel</Button>
            <Button onClick={handleSubmit} disabled={loading} className="flex-1 bg-red-600 hover:bg-red-700">{loading ? 'Submitting...' : 'Submit Report'}</Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
