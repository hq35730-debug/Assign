import { useState, useEffect } from 'react';
import { supabase } from '@/lib/supabase';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { UserX, VolumeX, Volume2, Trash2, Settings, Shield } from 'lucide-react';
import { formatDistanceToNow } from 'date-fns';

interface Log {
  id: string;
  action_type: string;
  actor_username: string;
  target_username?: string;
  details?: any;
  created_at: string;
}

export function ModerationLogs({ dialogueId }: { dialogueId: string }) {
  const [logs, setLogs] = useState<Log[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadLogs();
  }, [dialogueId]);

  const loadLogs = async () => {
    const { data } = await supabase.functions.invoke('messages-manager', {
      body: { action: 'get_moderation_logs', dialogue_id: dialogueId }
    });
    setLogs(data?.logs || []);
    setLoading(false);
  };

  const getActionIcon = (type: string) => {
    switch (type) {
      case 'remove_member': return <UserX className="w-4 h-4 text-red-400" />;
      case 'mute_member': return <VolumeX className="w-4 h-4 text-orange-400" />;
      case 'unmute_member': return <Volume2 className="w-4 h-4 text-green-400" />;
      case 'delete_message': return <Trash2 className="w-4 h-4 text-red-400" />;
      case 'update_settings': return <Settings className="w-4 h-4 text-blue-400" />;
      case 'update_role': return <Shield className="w-4 h-4 text-purple-400" />;
      default: return <Settings className="w-4 h-4 text-gray-400" />;
    }
  };

  const getActionText = (log: Log) => {
    switch (log.action_type) {
      case 'remove_member':
        return `removed ${log.target_username}`;
      case 'mute_member':
        return `muted ${log.target_username} for ${log.details?.duration_minutes} minutes${log.details?.reason ? ` (${log.details.reason})` : ''}`;
      case 'unmute_member':
        return `unmuted ${log.target_username}`;
      case 'delete_message':
        return `deleted a message`;
      case 'update_settings':
        const changes = [];
        if (log.details?.rules !== undefined) changes.push('rules');
        if (log.details?.slow_mode_enabled !== undefined) changes.push('slow mode');
        return `updated ${changes.join(', ') || 'settings'}`;
      case 'update_role':
        return `changed ${log.target_username}'s role to ${log.details?.new_role}`;
      default:
        return log.action_type;
    }
  };

  const getActionBadge = (type: string) => {
    const colors: Record<string, string> = {
      remove_member: 'bg-red-500/20 text-red-400',
      mute_member: 'bg-orange-500/20 text-orange-400',
      unmute_member: 'bg-green-500/20 text-green-400',
      delete_message: 'bg-red-500/20 text-red-400',
      update_settings: 'bg-blue-500/20 text-blue-400',
      update_role: 'bg-purple-500/20 text-purple-400'
    };
    return colors[type] || 'bg-gray-500/20 text-gray-400';
  };

  if (loading) {
    return <div className="text-center py-8 text-gray-400">Loading logs...</div>;
  }

  if (logs.length === 0) {
    return (
      <Card className="bg-gray-800 border-gray-700">
        <CardContent className="py-12 text-center">
          <Shield className="w-12 h-12 mx-auto text-gray-600 mb-4" />
          <p className="text-gray-400">No moderation activity yet</p>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="space-y-3">
      {logs.map((log) => (
        <Card key={log.id} className="bg-gray-800 border-gray-700">
          <CardContent className="p-4">
            <div className="flex items-start gap-3">
              <div className="w-8 h-8 rounded-full bg-gray-700 flex items-center justify-center mt-0.5">
                {getActionIcon(log.action_type)}
              </div>
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2 flex-wrap">
                  <span className="font-medium text-white">{log.actor_username}</span>
                  <span className="text-gray-400">{getActionText(log)}</span>
                </div>
                <div className="flex items-center gap-2 mt-1">
                  <Badge className={getActionBadge(log.action_type)}>
                    {log.action_type.replace('_', ' ')}
                  </Badge>
                  <span className="text-xs text-gray-500">
                    {formatDistanceToNow(new Date(log.created_at), { addSuffix: true })}
                  </span>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      ))}
    </div>
  );
}
