import { useState, useEffect } from 'react';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/contexts/AuthContext';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Switch } from '@/components/ui/switch';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { FileText, Clock, Save } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

interface DialogueData {
  rules?: string;
  slow_mode_enabled?: boolean;
  slow_mode_seconds?: number;
}

export function DialogueSettings({ dialogueId, userRole }: { dialogueId: string; userRole: string }) {
  const { user } = useAuth();
  const { toast } = useToast();
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [rules, setRules] = useState('');
  const [slowModeEnabled, setSlowModeEnabled] = useState(false);
  const [slowModeSeconds, setSlowModeSeconds] = useState('5');

  useEffect(() => {
    loadSettings();
  }, [dialogueId]);

  const loadSettings = async () => {
    const { data } = await supabase.functions.invoke('messages-manager', {
      body: { action: 'get_dialogue', dialogue_id: dialogueId }
    });
    if (data?.dialogue) {
      setRules(data.dialogue.rules || '');
      setSlowModeEnabled(data.dialogue.slow_mode_enabled || false);
      setSlowModeSeconds(String(data.dialogue.slow_mode_seconds || 5));
    }
    setLoading(false);
  };

  const saveSettings = async () => {
    setSaving(true);
    await supabase.functions.invoke('messages-manager', {
      body: {
        action: 'update_dialogue_settings',
        dialogue_id: dialogueId,
        user_id: user?.id,
        actor_username: user?.username,
        rules,
        slow_mode_enabled: slowModeEnabled,
        slow_mode_seconds: parseInt(slowModeSeconds)
      }
    });
    toast({ title: 'Settings saved' });
    setSaving(false);
  };

  if (loading) {
    return <div className="text-center py-8 text-gray-400">Loading settings...</div>;
  }

  return (
    <div className="space-y-6">
      <Card className="bg-gray-800 border-gray-700">
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-lg">
            <FileText className="w-5 h-5 text-purple-400" />
            Dialogue Rules
          </CardTitle>
        </CardHeader>
        <CardContent>
          <Textarea
            placeholder="Enter rules for this dialogue (e.g., Be respectful, No spam, Stay on topic...)"
            value={rules}
            onChange={(e) => setRules(e.target.value)}
            className="bg-gray-700 border-gray-600 min-h-[150px]"
          />
          <p className="text-xs text-gray-500 mt-2">
            These rules will be visible to all members
          </p>
        </CardContent>
      </Card>

      <Card className="bg-gray-800 border-gray-700">
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-lg">
            <Clock className="w-5 h-5 text-blue-400" />
            Slow Mode
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <Label>Enable Slow Mode</Label>
              <p className="text-sm text-gray-400">
                Limit how often members can send messages
              </p>
            </div>
            <Switch
              checked={slowModeEnabled}
              onCheckedChange={setSlowModeEnabled}
            />
          </div>

          {slowModeEnabled && (
            <div className="space-y-2">
              <Label>Delay between messages</Label>
              <Select value={slowModeSeconds} onValueChange={setSlowModeSeconds}>
                <SelectTrigger className="bg-gray-700 border-gray-600">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="5">5 seconds</SelectItem>
                  <SelectItem value="10">10 seconds</SelectItem>
                  <SelectItem value="30">30 seconds</SelectItem>
                  <SelectItem value="60">1 minute</SelectItem>
                  <SelectItem value="120">2 minutes</SelectItem>
                  <SelectItem value="300">5 minutes</SelectItem>
                </SelectContent>
              </Select>
            </div>
          )}
        </CardContent>
      </Card>

      <Button onClick={saveSettings} disabled={saving} className="w-full bg-purple-600 hover:bg-purple-700">
        <Save className="w-4 h-4 mr-2" />
        {saving ? 'Saving...' : 'Save Settings'}
      </Button>
    </div>
  );
}
