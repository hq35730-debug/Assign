import { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { AlertCircle, Send } from 'lucide-react';
import { supabase } from '@/lib/supabase';

interface Props {
  isOpen: boolean;
  onClose: () => void;
  dialogueId: string;
  userId: string;
  username: string;
  violation: {
    type: string;
    id?: string;
    date?: string;
    reason?: string;
  };
  onSuccess?: () => void;
}

export function AppealSubmitModal({ isOpen, onClose, dialogueId, userId, username, violation, onSuccess }: Props) {
  const [appealReason, setAppealReason] = useState('');
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState('');

  const handleSubmit = async () => {
    if (!appealReason.trim()) {
      setError('Please explain why you are appealing');
      return;
    }
    setSubmitting(true);
    setError('');

    try {
      const { data, error: err } = await supabase.functions.invoke('appeals-manager', {
        body: {
          action: 'submit_appeal',
          dialogue_id: dialogueId,
          user_id: userId,
          username,
          violation_type: violation.type,
          violation_id: violation.id,
          violation_date: violation.date,
          violation_reason: violation.reason,
          appeal_reason: appealReason.trim()
        }
      });

      if (err || data?.error) throw new Error(data?.error || err?.message);
      onSuccess?.();
      onClose();
      setAppealReason('');
    } catch (e: any) {
      setError(e.message || 'Failed to submit appeal');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="bg-gray-900 border-gray-700 max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <AlertCircle className="w-5 h-5 text-yellow-500" />
            Submit Appeal
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-4">
          <div className="bg-gray-800 p-3 rounded-lg text-sm">
            <p className="text-gray-400 mb-1">Violation Type</p>
            <p className="text-white capitalize">{violation.type.replace(/_/g, ' ')}</p>
            {violation.reason && (
              <>
                <p className="text-gray-400 mt-2 mb-1">Reason</p>
                <p className="text-white">{violation.reason}</p>
              </>
            )}
          </div>

          <div className="space-y-2">
            <Label>Why should this action be reversed?</Label>
            <Textarea
              value={appealReason}
              onChange={(e) => setAppealReason(e.target.value)}
              placeholder="Explain your appeal..."
              className="bg-gray-800 border-gray-700 min-h-[120px]"
            />
          </div>

          {error && <p className="text-red-400 text-sm">{error}</p>}

          <div className="flex gap-3">
            <Button variant="outline" onClick={onClose} className="flex-1">Cancel</Button>
            <Button onClick={handleSubmit} disabled={submitting} className="flex-1 bg-purple-600 hover:bg-purple-700">
              <Send className="w-4 h-4 mr-2" />
              {submitting ? 'Submitting...' : 'Submit Appeal'}
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
