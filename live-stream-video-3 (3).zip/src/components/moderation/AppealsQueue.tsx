import { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Textarea } from '@/components/ui/textarea';
import { ScrollArea } from '@/components/ui/scroll-area';
import { AlertCircle, CheckCircle, XCircle, Clock, User, MessageSquare } from 'lucide-react';
import { supabase } from '@/lib/supabase';

interface Appeal {
  id: string;
  user_id: string;
  username: string;
  violation_type: string;
  violation_reason: string;
  appeal_reason: string;
  status: string;
  reviewer_notes: string;
  decision: string;
  created_at: string;
  reviewed_at: string;
}

interface Props {
  dialogueId: string;
  currentUserId: string;
  currentUsername: string;
}

export function AppealsQueue({ dialogueId, currentUserId, currentUsername }: Props) {
  const [appeals, setAppeals] = useState<Appeal[]>([]);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState<'pending' | 'all'>('pending');
  const [reviewingId, setReviewingId] = useState<string | null>(null);
  const [notes, setNotes] = useState('');
  const [stats, setStats] = useState({ pending: 0, approved: 0, denied: 0 });

  useEffect(() => {
    loadAppeals();
    loadStats();
  }, [dialogueId, filter]);

  const loadAppeals = async () => {
    setLoading(true);
    const { data } = await supabase.functions.invoke('appeals-manager', {
      body: { action: 'get_appeals', dialogue_id: dialogueId, status: filter === 'pending' ? 'pending' : undefined }
    });
    setAppeals(data?.appeals || []);
    setLoading(false);
  };

  const loadStats = async () => {
    const { data } = await supabase.functions.invoke('appeals-manager', {
      body: { action: 'get_appeal_stats', dialogue_id: dialogueId }
    });
    if (data?.stats) setStats(data.stats);
  };

  const handleReview = async (appealId: string, decision: 'approved' | 'denied') => {
    await supabase.functions.invoke('appeals-manager', {
      body: {
        action: 'review_appeal', appeal_id: appealId, reviewed_by: currentUserId,
        reviewer_username: currentUsername, decision, reviewer_notes: notes
      }
    });
    setReviewingId(null);
    setNotes('');
    loadAppeals();
    loadStats();
  };

  const formatDate = (date: string) => new Date(date).toLocaleDateString('en-US', {
    month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit'
  });

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <div className="flex gap-2">
          <Button variant={filter === 'pending' ? 'default' : 'outline'} size="sm" onClick={() => setFilter('pending')}>
            Pending ({stats.pending})
          </Button>
          <Button variant={filter === 'all' ? 'default' : 'outline'} size="sm" onClick={() => setFilter('all')}>
            All Appeals
          </Button>
        </div>
        <div className="flex gap-2 text-sm">
          <Badge variant="outline" className="bg-green-500/20 text-green-400">{stats.approved} Approved</Badge>
          <Badge variant="outline" className="bg-red-500/20 text-red-400">{stats.denied} Denied</Badge>
        </div>
      </div>

      <ScrollArea className="h-[500px]">
        {loading ? (
          <div className="text-center py-8 text-gray-400">Loading appeals...</div>
        ) : appeals.length === 0 ? (
          <Card className="bg-gray-800/50 border-gray-700">
            <CardContent className="py-8 text-center text-gray-400">
              <AlertCircle className="w-12 h-12 mx-auto mb-3 opacity-50" />
              <p>No {filter === 'pending' ? 'pending ' : ''}appeals</p>
            </CardContent>
          </Card>
        ) : (
          <div className="space-y-3">
            {appeals.map((appeal) => (
              <Card key={appeal.id} className="bg-gray-800/50 border-gray-700">
                <CardHeader className="pb-2">
                  <div className="flex items-start justify-between">
                    <div className="flex items-center gap-2">
                      <User className="w-4 h-4 text-gray-400" />
                      <span className="font-medium">{appeal.username}</span>
                      <Badge variant="outline" className="capitalize">{appeal.violation_type.replace(/_/g, ' ')}</Badge>
                    </div>
                    <Badge className={appeal.status === 'pending' ? 'bg-yellow-500/20 text-yellow-400' : 
                      appeal.status === 'approved' ? 'bg-green-500/20 text-green-400' : 'bg-red-500/20 text-red-400'}>
                      {appeal.status}
                    </Badge>
                  </div>
                </CardHeader>
                <CardContent className="space-y-3">
                  {appeal.violation_reason && (
                    <div className="text-sm"><span className="text-gray-400">Violation:</span> {appeal.violation_reason}</div>
                  )}
                  <div className="bg-gray-900 p-3 rounded text-sm">
                    <p className="text-gray-400 mb-1 flex items-center gap-1"><MessageSquare className="w-3 h-3" /> Appeal</p>
                    <p>{appeal.appeal_reason}</p>
                  </div>
                  <div className="flex items-center gap-2 text-xs text-gray-500">
                    <Clock className="w-3 h-3" /> {formatDate(appeal.created_at)}
                  </div>

                  {appeal.status === 'pending' && reviewingId === appeal.id ? (
                    <div className="space-y-2 pt-2 border-t border-gray-700">
                      <Textarea value={notes} onChange={(e) => setNotes(e.target.value)} placeholder="Add notes (optional)" className="bg-gray-900 border-gray-700 text-sm" />
                      <div className="flex gap-2">
                        <Button size="sm" onClick={() => handleReview(appeal.id, 'approved')} className="bg-green-600 hover:bg-green-700">
                          <CheckCircle className="w-4 h-4 mr-1" /> Approve & Unmute
                        </Button>
                        <Button size="sm" onClick={() => handleReview(appeal.id, 'denied')} variant="destructive">
                          <XCircle className="w-4 h-4 mr-1" /> Deny
                        </Button>
                        <Button size="sm" variant="ghost" onClick={() => setReviewingId(null)}>Cancel</Button>
                      </div>
                    </div>
                  ) : appeal.status === 'pending' ? (
                    <Button size="sm" onClick={() => setReviewingId(appeal.id)} className="w-full">Review Appeal</Button>
                  ) : (
                    <div className="text-xs text-gray-500 pt-2 border-t border-gray-700">
                      Reviewed by {appeal.reviewer_notes && <span>: {appeal.reviewer_notes}</span>}
                    </div>
                  )}
                </CardContent>
              </Card>
            ))}
          </div>
        )}
      </ScrollArea>
    </div>
  );
}
