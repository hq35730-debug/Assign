import { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { AlertCircle, Scale, Clock, CheckCircle, XCircle } from 'lucide-react';
import { AppealSubmitModal } from './AppealSubmitModal';
import { supabase } from '@/lib/supabase';

interface Props {
  dialogueId: string;
  userId: string;
  username: string;
  isMuted: boolean;
  mutedUntil?: string;
  muteReason?: string;
}

interface Appeal {
  id: string;
  violation_type: string;
  appeal_reason: string;
  status: string;
  reviewer_notes?: string;
  created_at: string;
  reviewed_at?: string;
}

export function UserAppealPanel({ dialogueId, userId, username, isMuted, mutedUntil, muteReason }: Props) {
  const [appeals, setAppeals] = useState<Appeal[]>([]);
  const [showAppealModal, setShowAppealModal] = useState(false);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadAppeals();
  }, [dialogueId, userId]);

  const loadAppeals = async () => {
    setLoading(true);
    const { data } = await supabase.functions.invoke('appeals-manager', {
      body: { action: 'get_user_appeals', user_id: userId, dialogue_id: dialogueId }
    });
    setAppeals(data?.appeals || []);
    setLoading(false);
  };

  const hasPendingAppeal = appeals.some(a => a.status === 'pending');
  const formatDate = (date: string) => new Date(date).toLocaleDateString('en-US', {
    month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit'
  });

  if (!isMuted && appeals.length === 0) return null;

  return (
    <div className="space-y-4">
      {isMuted && (
        <Card className="bg-red-900/20 border-red-800">
          <CardHeader className="pb-2">
            <CardTitle className="text-lg flex items-center gap-2 text-red-400">
              <AlertCircle className="w-5 h-5" />
              You are muted in this dialogue
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            {muteReason && <p className="text-sm text-gray-300">Reason: {muteReason}</p>}
            {mutedUntil && <p className="text-sm text-gray-400">Until: {formatDate(mutedUntil)}</p>}
            {!hasPendingAppeal ? (
              <Button onClick={() => setShowAppealModal(true)} className="bg-purple-600 hover:bg-purple-700">
                <Scale className="w-4 h-4 mr-2" />Submit Appeal
              </Button>
            ) : (
              <Badge className="bg-yellow-500/20 text-yellow-400">Appeal Pending</Badge>
            )}
          </CardContent>
        </Card>
      )}

      {appeals.length > 0 && (
        <Card className="bg-gray-800/50 border-gray-700">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm text-gray-400">Your Appeals</CardTitle>
          </CardHeader>
          <CardContent className="space-y-2">
            {appeals.map((appeal) => (
              <div key={appeal.id} className="bg-gray-900 p-3 rounded-lg text-sm">
                <div className="flex items-center justify-between mb-2">
                  <span className="capitalize">{appeal.violation_type.replace(/_/g, ' ')}</span>
                  <Badge className={
                    appeal.status === 'pending' ? 'bg-yellow-500/20 text-yellow-400' :
                    appeal.status === 'approved' ? 'bg-green-500/20 text-green-400' : 'bg-red-500/20 text-red-400'
                  }>
                    {appeal.status === 'pending' && <Clock className="w-3 h-3 mr-1" />}
                    {appeal.status === 'approved' && <CheckCircle className="w-3 h-3 mr-1" />}
                    {appeal.status === 'denied' && <XCircle className="w-3 h-3 mr-1" />}
                    {appeal.status}
                  </Badge>
                </div>
                <p className="text-gray-400 text-xs">{formatDate(appeal.created_at)}</p>
                {appeal.reviewer_notes && appeal.status !== 'pending' && (
                  <p className="mt-2 text-gray-300 text-xs">Response: {appeal.reviewer_notes}</p>
                )}
              </div>
            ))}
          </CardContent>
        </Card>
      )}

      <AppealSubmitModal
        isOpen={showAppealModal}
        onClose={() => setShowAppealModal(false)}
        dialogueId={dialogueId}
        userId={userId}
        username={username}
        violation={{ type: 'mute', reason: muteReason, date: new Date().toISOString() }}
        onSuccess={loadAppeals}
      />
    </div>
  );
}
