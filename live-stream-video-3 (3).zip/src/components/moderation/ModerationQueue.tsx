
import { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import { AlertTriangle, Flag, Check, X, Ban, MessageSquare, Clock } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { useToast } from '@/hooks/use-toast';

interface QueueItem {
  id: string;
  dialogue_id: string;
  user_id: string;
  username: string;
  message_content?: string;
  flag_type: string;
  flag_reason?: string;
  severity: string;
  status: string;
  created_at: string;
}

interface Report {
  id: string;
  dialogue_id: string;
  reporter_username: string;
  reported_username?: string;
  message_content?: string;
  reason: string;
  details?: string;
  status: string;
  created_at: string;
}

interface ModerationQueueProps {
  dialogueId: string;
  currentUserId: string;
  currentUsername: string;
}

export function ModerationQueue({ dialogueId, currentUserId, currentUsername }: ModerationQueueProps) {
  const [queue, setQueue] = useState<QueueItem[]>([]);
  const [reports, setReports] = useState<Report[]>([]);
  const [loading, setLoading] = useState(true);
  const [tab, setTab] = useState('queue');
  const { toast } = useToast();

  const fetchData = async () => {
    setLoading(true);
    const [qRes, rRes] = await Promise.all([
      supabase.functions.invoke('moderation-queue', { body: { action: 'get_queue', dialogue_id: dialogueId } }),
      supabase.functions.invoke('moderation-queue', { body: { action: 'get_reports', dialogue_id: dialogueId } })
    ]);
    setQueue(qRes.data?.queue || []);
    setReports(rRes.data?.reports || []);
    setLoading(false);
  };

  useEffect(() => { fetchData(); }, [dialogueId]);

  const handleQueueAction = async (item: QueueItem, status: string, action?: string) => {
    await supabase.functions.invoke('moderation-queue', {
      body: { action: 'review_queue_item', item_id: item.id, status, action_taken: action, reviewed_by: currentUserId, reviewed_by_username: currentUsername, dialogue_id: dialogueId }
    });
    toast({ title: `Item ${status}` });
    fetchData();
  };

  const handleReportAction = async (report: Report, status: string, action?: string) => {
    await supabase.functions.invoke('moderation-queue', {
      body: { action: 'review_report', report_id: report.id, status, action_taken: action, reviewed_by: currentUserId, reviewed_by_username: currentUsername, dialogue_id: dialogueId }
    });
    toast({ title: `Report ${status}` });
    fetchData();
  };

  const getSeverityColor = (s: string) => {
    if (s === 'high') return 'bg-red-500/20 text-red-400';
    if (s === 'medium') return 'bg-yellow-500/20 text-yellow-400';
    return 'bg-blue-500/20 text-blue-400';
  };

  const pendingQueue = queue.filter(q => q.status === 'pending');
  const pendingReports = reports.filter(r => r.status === 'pending');

  return (
    <div className="space-y-4">
      <div className="grid grid-cols-2 gap-4">
        <Card className="bg-gray-800/50 border-gray-700">
          <CardContent className="p-4 flex items-center gap-3">
            <div className="p-2 bg-orange-500/20 rounded-lg"><AlertTriangle className="h-5 w-5 text-orange-400" /></div>
            <div><p className="text-2xl font-bold text-white">{pendingQueue.length}</p><p className="text-xs text-gray-400">Flagged Items</p></div>
          </CardContent>
        </Card>
        <Card className="bg-gray-800/50 border-gray-700">
          <CardContent className="p-4 flex items-center gap-3">
            <div className="p-2 bg-red-500/20 rounded-lg"><Flag className="h-5 w-5 text-red-400" /></div>
            <div><p className="text-2xl font-bold text-white">{pendingReports.length}</p><p className="text-xs text-gray-400">User Reports</p></div>
          </CardContent>
        </Card>
      </div>

      <Tabs value={tab} onValueChange={setTab}>
        <TabsList className="bg-gray-800"><TabsTrigger value="queue">Flagged ({pendingQueue.length})</TabsTrigger><TabsTrigger value="reports">Reports ({pendingReports.length})</TabsTrigger></TabsList>
        <TabsContent value="queue" className="space-y-3 mt-4">
          {pendingQueue.length === 0 ? <p className="text-gray-400 text-center py-8">No flagged items</p> : pendingQueue.map(item => (
            <Card key={item.id} className="bg-gray-800/50 border-gray-700">
              <CardContent className="p-4">
                <div className="flex items-start justify-between mb-3">
                  <div className="flex items-center gap-2">
                    <Avatar className="h-8 w-8"><AvatarFallback className="bg-purple-600 text-xs">{item.username[0]}</AvatarFallback></Avatar>
                    <div><p className="text-white font-medium">{item.username}</p><p className="text-xs text-gray-400">{new Date(item.created_at).toLocaleString()}</p></div>
                  </div>
                  <Badge className={getSeverityColor(item.severity)}>{item.severity}</Badge>
                </div>
                {item.message_content && <div className="bg-gray-900 p-3 rounded-lg mb-3"><p className="text-sm text-gray-300">{item.message_content}</p></div>}
                <div className="flex items-center gap-2 mb-3"><Badge variant="outline" className="border-gray-600">{item.flag_type}</Badge>{item.flag_reason && <span className="text-xs text-gray-400">{item.flag_reason}</span>}</div>
                <div className="flex gap-2">
                  <Button size="sm" variant="outline" onClick={() => handleQueueAction(item, 'approved')} className="border-green-600 text-green-400"><Check className="h-4 w-4 mr-1" />Approve</Button>
                  <Button size="sm" variant="outline" onClick={() => handleQueueAction(item, 'deleted', 'delete_message')} className="border-red-600 text-red-400"><X className="h-4 w-4 mr-1" />Delete</Button>
                  <Button size="sm" variant="outline" onClick={() => handleQueueAction(item, 'actioned', 'mute_user')} className="border-orange-600 text-orange-400"><Ban className="h-4 w-4 mr-1" />Mute</Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </TabsContent>
        <TabsContent value="reports" className="space-y-3 mt-4">
          {pendingReports.length === 0 ? <p className="text-gray-400 text-center py-8">No pending reports</p> : pendingReports.map(report => (
            <Card key={report.id} className="bg-gray-800/50 border-gray-700">
              <CardContent className="p-4">
                <div className="flex items-start justify-between mb-3">
                  <div><p className="text-white font-medium">Report against {report.reported_username || 'Unknown'}</p><p className="text-xs text-gray-400">by {report.reporter_username} • {new Date(report.created_at).toLocaleString()}</p></div>
                  <Badge className="bg-red-500/20 text-red-400">{report.reason}</Badge>
                </div>
                {report.message_content && <div className="bg-gray-900 p-3 rounded-lg mb-3"><MessageSquare className="h-4 w-4 text-gray-500 mb-1" /><p className="text-sm text-gray-300">{report.message_content}</p></div>}
                {report.details && <p className="text-sm text-gray-400 mb-3">{report.details}</p>}
                <div className="flex gap-2">
                  <Button size="sm" variant="outline" onClick={() => handleReportAction(report, 'dismissed')} className="border-gray-600"><X className="h-4 w-4 mr-1" />Dismiss</Button>
                  <Button size="sm" variant="outline" onClick={() => handleReportAction(report, 'resolved', 'warned')} className="border-yellow-600 text-yellow-400">Warn</Button>
                  <Button size="sm" variant="outline" onClick={() => handleReportAction(report, 'resolved', 'muted')} className="border-orange-600 text-orange-400">Mute</Button>
                  <Button size="sm" variant="outline" onClick={() => handleReportAction(report, 'resolved', 'removed')} className="border-red-600 text-red-400">Remove</Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </TabsContent>
      </Tabs>
    </div>
  );
}
