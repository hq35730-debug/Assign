import { useState, useEffect } from 'react';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/contexts/AuthContext';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Shield, Users, Settings, ChevronRight } from 'lucide-react';
import { DialogueModerationPanel } from './DialogueModerationPanel';

interface Dialogue {
  id: string;
  name: string;
  description: string;
  userRole: string;
  member_count?: number;
}

export function ModerationDashboard() {
  const { user } = useAuth();
  const [dialogues, setDialogues] = useState<Dialogue[]>([]);
  const [selectedDialogue, setSelectedDialogue] = useState<Dialogue | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (user) loadDialogues();
  }, [user]);

  const loadDialogues = async () => {
    const { data } = await supabase.functions.invoke('messages-manager', {
      body: { action: 'get_user_dialogues', user_id: user?.id }
    });
    const modDialogues = (data?.dialogues || []).filter(
      (d: Dialogue) => d.userRole === 'owner' || d.userRole === 'admin'
    );
    setDialogues(modDialogues);
    setLoading(false);
  };

  if (selectedDialogue) {
    return (
      <DialogueModerationPanel
        dialogue={selectedDialogue}
        onBack={() => setSelectedDialogue(null)}
      />
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-3">
        <Shield className="w-8 h-8 text-purple-500" />
        <div>
          <h1 className="text-2xl font-bold">Moderation Dashboard</h1>
          <p className="text-gray-400">Manage your dialogues</p>
        </div>
      </div>

      {loading ? (
        <div className="text-center py-12 text-gray-400">Loading...</div>
      ) : dialogues.length === 0 ? (
        <Card className="bg-gray-800 border-gray-700">
          <CardContent className="py-12 text-center">
            <Shield className="w-12 h-12 mx-auto text-gray-600 mb-4" />
            <p className="text-gray-400">No dialogues to moderate</p>
          </CardContent>
        </Card>
      ) : (
        <div className="grid gap-4">
          {dialogues.map((dialogue) => (
            <Card key={dialogue.id} className="bg-gray-800 border-gray-700 hover:border-purple-500/50 transition-colors cursor-pointer" onClick={() => setSelectedDialogue(dialogue)}>
              <CardContent className="p-4 flex items-center justify-between">
                <div className="flex items-center gap-4">
                  <div className="w-12 h-12 rounded-lg bg-purple-500/20 flex items-center justify-center">
                    <Users className="w-6 h-6 text-purple-400" />
                  </div>
                  <div>
                    <h3 className="font-semibold">{dialogue.name}</h3>
                    <p className="text-sm text-gray-400">{dialogue.description}</p>
                  </div>
                </div>
                <div className="flex items-center gap-3">
                  <Badge variant={dialogue.userRole === 'owner' ? 'default' : 'secondary'}>
                    {dialogue.userRole}
                  </Badge>
                  <ChevronRight className="w-5 h-5 text-gray-400" />
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
}
