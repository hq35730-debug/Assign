import { useState, useEffect } from 'react';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/contexts/AuthContext';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Switch } from '@/components/ui/switch';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { Shield, Link, MessageSquare, Type, X, Plus, Save } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

interface AutoModSettingsProps {
  dialogueId: string;
}

export function AutoModSettings({ dialogueId }: AutoModSettingsProps) {
  const { user } = useAuth();
  const { toast } = useToast();
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [newWord, setNewWord] = useState('');
  const [settings, setSettings] = useState({
    automod_enabled: false,
    banned_words: [] as string[],
    link_filter_enabled: false,
    link_filter_action: 'warn',
    spam_filter_enabled: false,
    spam_threshold: 5,
    spam_timeframe_seconds: 10,
    spam_action: 'mute',
    banned_word_action: 'warn',
    auto_mute_duration_minutes: 10,
    caps_filter_enabled: false,
    caps_threshold: 70,
    caps_action: 'warn'
  });

  useEffect(() => { loadSettings(); }, [dialogueId]);

  const loadSettings = async () => {
    const { data } = await supabase.functions.invoke('automod-manager', {
      body: { action: 'get_settings', dialogue_id: dialogueId }
    });
    if (data?.settings) setSettings({ ...settings, ...data.settings });
    setLoading(false);
  };

  const saveSettings = async () => {
    setSaving(true);
    await supabase.functions.invoke('automod-manager', {
      body: { action: 'update_settings', dialogue_id: dialogueId, user_id: user?.id, actor_username: user?.username, ...settings }
    });
    toast({ title: 'AutoMod settings saved' });
    setSaving(false);
  };

  const addWord = async () => {
    if (!newWord.trim()) return;
    const { data } = await supabase.functions.invoke('automod-manager', {
      body: { action: 'add_banned_word', dialogue_id: dialogueId, user_id: user?.id, actor_username: user?.username, word: newWord }
    });
    if (data?.banned_words) setSettings({ ...settings, banned_words: data.banned_words });
    setNewWord('');
  };

  const removeWord = async (word: string) => {
    const { data } = await supabase.functions.invoke('automod-manager', {
      body: { action: 'remove_banned_word', dialogue_id: dialogueId, user_id: user?.id, actor_username: user?.username, word }
    });
    if (data?.banned_words) setSettings({ ...settings, banned_words: data.banned_words });
  };

  if (loading) return <div className="text-center py-8 text-gray-400">Loading...</div>;

  return (
    <div className="space-y-4">
      <Card className="bg-gray-800 border-gray-700">
        <CardHeader className="pb-3">
          <div className="flex items-center justify-between">
            <CardTitle className="flex items-center gap-2 text-lg"><Shield className="w-5 h-5 text-green-400" />AutoMod</CardTitle>
            <Switch checked={settings.automod_enabled} onCheckedChange={(v) => setSettings({ ...settings, automod_enabled: v })} />
          </div>
        </CardHeader>
      </Card>

      {settings.automod_enabled && (
        <>
          <Card className="bg-gray-800 border-gray-700">
            <CardHeader className="pb-2"><CardTitle className="text-sm flex items-center gap-2"><Type className="w-4 h-4" />Banned Words</CardTitle></CardHeader>
            <CardContent className="space-y-3">
              <div className="flex gap-2">
                <Input value={newWord} onChange={(e) => setNewWord(e.target.value)} placeholder="Add word..." className="bg-gray-700 border-gray-600" />
                <Button onClick={addWord} size="sm"><Plus className="w-4 h-4" /></Button>
              </div>
              <div className="flex flex-wrap gap-2">
                {settings.banned_words.map((w) => (
                  <Badge key={w} variant="secondary" className="bg-red-900/50">
                    {w}<X className="w-3 h-3 ml-1 cursor-pointer" onClick={() => removeWord(w)} />
                  </Badge>
                ))}
              </div>
              <Select value={settings.banned_word_action} onValueChange={(v) => setSettings({ ...settings, banned_word_action: v })}>
                <SelectTrigger className="bg-gray-700 border-gray-600"><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="warn">Warn</SelectItem>
                  <SelectItem value="mute">Mute</SelectItem>
                  <SelectItem value="remove">Remove</SelectItem>
                </SelectContent>
              </Select>
            </CardContent>
          </Card>

          <Card className="bg-gray-800 border-gray-700">
            <CardHeader className="pb-2">
              <div className="flex items-center justify-between">
                <CardTitle className="text-sm flex items-center gap-2"><Link className="w-4 h-4" />Link Filter</CardTitle>
                <Switch checked={settings.link_filter_enabled} onCheckedChange={(v) => setSettings({ ...settings, link_filter_enabled: v })} />
              </div>
            </CardHeader>
            {settings.link_filter_enabled && (
              <CardContent>
                <Select value={settings.link_filter_action} onValueChange={(v) => setSettings({ ...settings, link_filter_action: v })}>
                  <SelectTrigger className="bg-gray-700 border-gray-600"><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="warn">Warn</SelectItem>
                    <SelectItem value="mute">Mute</SelectItem>
                    <SelectItem value="remove">Remove</SelectItem>
                  </SelectContent>
                </Select>
              </CardContent>
            )}
          </Card>

          <Card className="bg-gray-800 border-gray-700">
            <CardHeader className="pb-2">
              <div className="flex items-center justify-between">
                <CardTitle className="text-sm flex items-center gap-2"><MessageSquare className="w-4 h-4" />Spam Filter</CardTitle>
                <Switch checked={settings.spam_filter_enabled} onCheckedChange={(v) => setSettings({ ...settings, spam_filter_enabled: v })} />
              </div>
            </CardHeader>
            {settings.spam_filter_enabled && (
              <CardContent className="space-y-3">
                <div className="grid grid-cols-2 gap-2">
                  <div>
                    <Label className="text-xs">Messages</Label>
                    <Input type="number" value={settings.spam_threshold} onChange={(e) => setSettings({ ...settings, spam_threshold: parseInt(e.target.value) })} className="bg-gray-700 border-gray-600" />
                  </div>
                  <div>
                    <Label className="text-xs">Seconds</Label>
                    <Input type="number" value={settings.spam_timeframe_seconds} onChange={(e) => setSettings({ ...settings, spam_timeframe_seconds: parseInt(e.target.value) })} className="bg-gray-700 border-gray-600" />
                  </div>
                </div>
                <Select value={settings.spam_action} onValueChange={(v) => setSettings({ ...settings, spam_action: v })}>
                  <SelectTrigger className="bg-gray-700 border-gray-600"><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="warn">Warn</SelectItem>
                    <SelectItem value="mute">Mute</SelectItem>
                    <SelectItem value="remove">Remove</SelectItem>
                  </SelectContent>
                </Select>
              </CardContent>
            )}
          </Card>

          <div>
            <Label className="text-sm">Auto-mute Duration (minutes)</Label>
            <Input type="number" value={settings.auto_mute_duration_minutes} onChange={(e) => setSettings({ ...settings, auto_mute_duration_minutes: parseInt(e.target.value) })} className="bg-gray-700 border-gray-600 mt-1" />
          </div>
        </>
      )}

      <Button onClick={saveSettings} disabled={saving} className="w-full bg-purple-600 hover:bg-purple-700">
        <Save className="w-4 h-4 mr-2" />{saving ? 'Saving...' : 'Save Settings'}
      </Button>
    </div>
  );
}
