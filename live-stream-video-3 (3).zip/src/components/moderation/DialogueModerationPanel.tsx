import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { ArrowLeft, Users, ScrollText, FileText, Shield, Flag, Scale } from 'lucide-react';
import { MemberManagement } from './MemberManagement';
import { ModerationLogs } from './ModerationLogs';
import { DialogueSettings } from './DialogueSettings';
import { AutoModSettings } from './AutoModSettings';
import { ModerationQueue } from './ModerationQueue';
import { AppealsQueue } from './AppealsQueue';
import { useAuth } from '@/contexts/AuthContext';

interface Dialogue {
  id: string;
  name: string;
  description: string;
  userRole: string;
}

interface Props {
  dialogue: Dialogue;
  onBack: () => void;
}

export function DialogueModerationPanel({ dialogue, onBack }: Props) {
  const [activeTab, setActiveTab] = useState('queue');
  const { user } = useAuth();

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-4">
        <Button variant="ghost" size="icon" onClick={onBack}>
          <ArrowLeft className="w-5 h-5" />
        </Button>
        <div>
          <h1 className="text-2xl font-bold">{dialogue.name}</h1>
          <p className="text-gray-400">Moderation Panel</p>
        </div>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="bg-gray-800 border border-gray-700 flex-wrap h-auto">
          <TabsTrigger value="queue" className="data-[state=active]:bg-purple-600">
            <Flag className="w-4 h-4 mr-2" />Queue
          </TabsTrigger>
          <TabsTrigger value="appeals" className="data-[state=active]:bg-purple-600">
            <Scale className="w-4 h-4 mr-2" />Appeals
          </TabsTrigger>
          <TabsTrigger value="members" className="data-[state=active]:bg-purple-600">
            <Users className="w-4 h-4 mr-2" />Members
          </TabsTrigger>
          <TabsTrigger value="automod" className="data-[state=active]:bg-purple-600">
            <Shield className="w-4 h-4 mr-2" />AutoMod
          </TabsTrigger>
          <TabsTrigger value="settings" className="data-[state=active]:bg-purple-600">
            <FileText className="w-4 h-4 mr-2" />Settings
          </TabsTrigger>
          <TabsTrigger value="logs" className="data-[state=active]:bg-purple-600">
            <ScrollText className="w-4 h-4 mr-2" />Logs
          </TabsTrigger>
        </TabsList>

        <TabsContent value="queue" className="mt-6">
          <ModerationQueue 
            dialogueId={dialogue.id} 
            currentUserId={user?.id || ''} 
            currentUsername={user?.username || 'Moderator'} 
          />
        </TabsContent>

        <TabsContent value="appeals" className="mt-6">
          <AppealsQueue 
            dialogueId={dialogue.id} 
            currentUserId={user?.id || ''} 
            currentUsername={user?.username || 'Moderator'} 
          />
        </TabsContent>

        <TabsContent value="members" className="mt-6">
          <MemberManagement dialogueId={dialogue.id} userRole={dialogue.userRole} />
        </TabsContent>

        <TabsContent value="automod" className="mt-6">
          <AutoModSettings dialogueId={dialogue.id} />
        </TabsContent>

        <TabsContent value="settings" className="mt-6">
          <DialogueSettings dialogueId={dialogue.id} userRole={dialogue.userRole} />
        </TabsContent>

        <TabsContent value="logs" className="mt-6">
          <ModerationLogs dialogueId={dialogue.id} />
        </TabsContent>
      </Tabs>
    </div>
  );
}
