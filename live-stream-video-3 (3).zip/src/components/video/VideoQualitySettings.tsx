import React, { useState } from 'react';
import { Settings, Monitor, Zap, Sparkles, Gauge } from 'lucide-react';

interface VideoQualitySettingsProps {
  isOpen: boolean;
  onClose: () => void;
  onApply: (settings: VideoSettings) => void;
}

export interface VideoSettings {
  resolution: string;
  bitrate: number;
  frameRate: number;
  hdrEnabled: boolean;
  lowLatency: boolean;
  adaptiveQuality: boolean;
}

const resolutions = [
  { label: '4K Ultra HD', value: '2160p', bitrate: 35000 },
  { label: '1440p QHD', value: '1440p', bitrate: 16000 },
  { label: '1080p Full HD', value: '1080p', bitrate: 8000 },
  { label: '720p HD', value: '720p', bitrate: 5000 },
  { label: '480p SD', value: '480p', bitrate: 2500 },
  { label: '360p', value: '360p', bitrate: 1000 },
];

export const VideoQualitySettings: React.FC<VideoQualitySettingsProps> = ({ isOpen, onClose, onApply }) => {
  const [settings, setSettings] = useState<VideoSettings>({
    resolution: '1080p',
    bitrate: 8000,
    frameRate: 60,
    hdrEnabled: false,
    lowLatency: true,
    adaptiveQuality: true,
  });

  const handleResolutionChange = (value: string) => {
    const res = resolutions.find(r => r.value === value);
    setSettings(prev => ({ ...prev, resolution: value, bitrate: res?.bitrate || prev.bitrate }));
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black/80 flex items-center justify-center z-50">
      <div className="bg-gradient-to-br from-[#16213e] to-[#1a1a2e] rounded-2xl p-6 w-full max-w-md border border-purple-500/30 shadow-2xl">
        <div className="flex items-center gap-3 mb-6">
          <div className="p-2 bg-purple-600 rounded-lg"><Settings className="w-6 h-6 text-white" /></div>
          <h3 className="text-white text-xl font-bold">Video Quality</h3>
        </div>
        <div className="space-y-5">
          <div>
            <label className="text-gray-300 text-sm mb-2 flex items-center gap-2"><Monitor className="w-4 h-4" /> Resolution</label>
            <select value={settings.resolution} onChange={(e) => handleResolutionChange(e.target.value)} className="w-full bg-[#1a1a2e] text-white px-4 py-3 rounded-lg border border-gray-700">
              {resolutions.map(r => <option key={r.value} value={r.value}>{r.label}</option>)}
            </select>
          </div>
          <div>
            <label className="text-gray-300 text-sm mb-2 flex items-center gap-2"><Gauge className="w-4 h-4" /> Bitrate: {settings.bitrate} kbps</label>
            <input type="range" min="1000" max="50000" step="500" value={settings.bitrate} onChange={(e) => setSettings(prev => ({ ...prev, bitrate: +e.target.value }))} className="w-full accent-purple-500" />
          </div>
          <div>
            <label className="text-gray-300 text-sm mb-2">Frame Rate</label>
            <div className="flex gap-2">
              {[30, 60, 120].map(fps => (
                <button key={fps} onClick={() => setSettings(prev => ({ ...prev, frameRate: fps }))} className={`flex-1 py-2 rounded-lg font-semibold ${settings.frameRate === fps ? 'bg-purple-600 text-white' : 'bg-gray-700 text-gray-300'}`}>{fps} FPS</button>
              ))}
            </div>
          </div>
          <div className="flex items-center justify-between p-3 bg-[#1a1a2e] rounded-lg">
            <span className="text-white flex items-center gap-2"><Sparkles className="w-4 h-4 text-yellow-400" /> HDR</span>
            <button onClick={() => setSettings(prev => ({ ...prev, hdrEnabled: !prev.hdrEnabled }))} className={`w-12 h-6 rounded-full ${settings.hdrEnabled ? 'bg-purple-600' : 'bg-gray-600'}`}><div className={`w-5 h-5 bg-white rounded-full transition-transform ${settings.hdrEnabled ? 'translate-x-6' : 'translate-x-0.5'}`} /></button>
          </div>
          <div className="flex items-center justify-between p-3 bg-[#1a1a2e] rounded-lg">
            <span className="text-white flex items-center gap-2"><Zap className="w-4 h-4 text-green-400" /> Low Latency</span>
            <button onClick={() => setSettings(prev => ({ ...prev, lowLatency: !prev.lowLatency }))} className={`w-12 h-6 rounded-full ${settings.lowLatency ? 'bg-green-600' : 'bg-gray-600'}`}><div className={`w-5 h-5 bg-white rounded-full transition-transform ${settings.lowLatency ? 'translate-x-6' : 'translate-x-0.5'}`} /></button>
          </div>
        </div>
        <div className="flex gap-3 mt-6">
          <button onClick={onClose} className="flex-1 py-3 bg-gray-700 hover:bg-gray-600 text-white rounded-lg font-semibold">Cancel</button>
          <button onClick={() => { onApply(settings); onClose(); }} className="flex-1 py-3 bg-gradient-to-r from-purple-600 to-pink-600 text-white rounded-lg font-semibold">Apply</button>
        </div>
      </div>
    </div>
  );
};
