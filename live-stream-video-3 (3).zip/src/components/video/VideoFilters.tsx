import React, { useState } from 'react';
import { Palette, Sun, Contrast, Droplets, Sparkles, User, Image } from 'lucide-react';

interface VideoFiltersProps {
  isOpen: boolean;
  onClose: () => void;
  onApply: (filters: FilterSettings) => void;
}

export interface FilterSettings {
  brightness: number;
  contrast: number;
  saturation: number;
  preset: string;
  beautyMode: number;
  backgroundBlur: number;
}

const presets = [
  { id: 'none', name: 'None', icon: '○' },
  { id: 'warm', name: 'Warm', color: 'from-orange-500 to-yellow-500' },
  { id: 'cool', name: 'Cool', color: 'from-blue-500 to-cyan-500' },
  { id: 'vintage', name: 'Vintage', color: 'from-amber-600 to-orange-400' },
  { id: 'noir', name: 'Noir', color: 'from-gray-700 to-gray-900' },
  { id: 'vivid', name: 'Vivid', color: 'from-pink-500 to-purple-500' },
  { id: 'cinematic', name: 'Cinema', color: 'from-teal-600 to-blue-800' },
  { id: 'dreamy', name: 'Dreamy', color: 'from-pink-300 to-purple-300' },
];

export const VideoFilters: React.FC<VideoFiltersProps> = ({ isOpen, onClose, onApply }) => {
  const [filters, setFilters] = useState<FilterSettings>({
    brightness: 100,
    contrast: 100,
    saturation: 100,
    preset: 'none',
    beautyMode: 0,
    backgroundBlur: 0,
  });

  const SliderControl = ({ label, icon: Icon, value, onChange, min = 0, max = 200, color }: any) => (
    <div>
      <div className="flex items-center justify-between mb-2">
        <span className="text-gray-300 text-sm flex items-center gap-2"><Icon className={`w-4 h-4 ${color}`} /> {label}</span>
        <span className="text-purple-400 font-mono text-sm">{value}%</span>
      </div>
      <input type="range" min={min} max={max} value={value} onChange={(e) => onChange(+e.target.value)} className="w-full accent-purple-500 h-2 rounded-lg" />
    </div>
  );

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black/80 flex items-center justify-center z-50">
      <div className="bg-gradient-to-br from-[#16213e] to-[#1a1a2e] rounded-2xl p-6 w-full max-w-lg border border-pink-500/30 shadow-2xl max-h-[90vh] overflow-y-auto">
        <div className="flex items-center gap-3 mb-6">
          <div className="p-2 bg-gradient-to-r from-pink-600 to-purple-600 rounded-lg"><Palette className="w-6 h-6 text-white" /></div>
          <h3 className="text-white text-xl font-bold">Video Filters</h3>
        </div>
        <div className="space-y-6">
          <div>
            <label className="text-gray-300 text-sm mb-3 block">Filter Presets</label>
            <div className="grid grid-cols-4 gap-2">
              {presets.map(p => (
                <button key={p.id} onClick={() => setFilters(prev => ({ ...prev, preset: p.id }))} className={`p-3 rounded-xl border-2 transition-all ${filters.preset === p.id ? 'border-purple-500 scale-105' : 'border-transparent'}`}>
                  <div className={`w-full h-8 rounded-lg mb-1 ${p.color ? `bg-gradient-to-r ${p.color}` : 'bg-gray-700 flex items-center justify-center text-gray-400'}`}>{!p.color && p.icon}</div>
                  <span className="text-xs text-gray-300">{p.name}</span>
                </button>
              ))}
            </div>
          </div>
          <div className="space-y-4 p-4 bg-[#1a1a2e] rounded-xl">
            <SliderControl label="Brightness" icon={Sun} value={filters.brightness} onChange={(v: number) => setFilters(prev => ({ ...prev, brightness: v }))} color="text-yellow-400" />
            <SliderControl label="Contrast" icon={Contrast} value={filters.contrast} onChange={(v: number) => setFilters(prev => ({ ...prev, contrast: v }))} color="text-blue-400" />
            <SliderControl label="Saturation" icon={Droplets} value={filters.saturation} onChange={(v: number) => setFilters(prev => ({ ...prev, saturation: v }))} color="text-pink-400" />
          </div>
          <div className="space-y-4 p-4 bg-[#1a1a2e] rounded-xl">
            <SliderControl label="Beauty Mode" icon={Sparkles} value={filters.beautyMode} onChange={(v: number) => setFilters(prev => ({ ...prev, beautyMode: v }))} min={0} max={100} color="text-pink-400" />
            <SliderControl label="Background Blur" icon={Image} value={filters.backgroundBlur} onChange={(v: number) => setFilters(prev => ({ ...prev, backgroundBlur: v }))} min={0} max={100} color="text-purple-400" />
          </div>
        </div>
        <div className="flex gap-3 mt-6">
          <button onClick={() => setFilters({ brightness: 100, contrast: 100, saturation: 100, preset: 'none', beautyMode: 0, backgroundBlur: 0 })} className="px-4 py-3 bg-gray-700 hover:bg-gray-600 text-white rounded-lg font-semibold">Reset</button>
          <button onClick={onClose} className="flex-1 py-3 bg-gray-700 hover:bg-gray-600 text-white rounded-lg font-semibold">Cancel</button>
          <button onClick={() => { onApply(filters); onClose(); }} className="flex-1 py-3 bg-gradient-to-r from-pink-600 to-purple-600 text-white rounded-lg font-semibold">Apply</button>
        </div>
      </div>
    </div>
  );
};
