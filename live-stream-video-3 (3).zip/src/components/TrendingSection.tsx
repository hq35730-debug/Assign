import React from 'react';
import { Stream } from '../data/streamData';

interface TrendingSectionProps {
  streams: Stream[];
  onStreamClick: (stream: Stream) => void;
}

export const TrendingSection: React.FC<TrendingSectionProps> = ({ streams, onStreamClick }) => {
  const topStreams = [...streams].sort((a, b) => b.viewers - a.viewers).slice(0, 5);

  return (
    <div className="mb-12">
      <h2 className="text-3xl font-bold text-white mb-6 flex items-center gap-3">
        <span className="bg-gradient-to-r from-yellow-500 to-orange-500 bg-clip-text text-transparent">
          Trending Now
        </span>
      </h2>
      <div className="grid grid-cols-1 md:grid-cols-5 gap-4">
        {topStreams.map((stream, index) => (
          <div
            key={stream.id}
            onClick={() => onStreamClick(stream)}
            className="relative group cursor-pointer rounded-xl overflow-hidden transform transition-all duration-300 hover:scale-105"
          >
            <img 
              src={stream.thumbnail} 
              alt={stream.streamerName}
              className="w-full aspect-square object-cover"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-black/40 to-transparent" />
            <div className="absolute top-2 left-2 bg-yellow-500 text-black font-bold px-3 py-1 rounded-full text-sm">
              #{index + 1}
            </div>
            <div className="absolute bottom-0 left-0 right-0 p-3">
              <h3 className="text-white font-bold text-sm mb-1">{stream.streamerName}</h3>
              <p className="text-gray-300 text-xs flex items-center gap-2">
                <span className="text-red-500">●</span>
                {stream.viewers.toLocaleString()} viewers
              </p>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
