import React from 'react';
import { Crown, Shield, Star, Sparkles } from 'lucide-react';

export interface ChatMessageType {
  id: string;
  username: string;
  display_name?: string;
  message: string;
  badge?: 'VIP' | 'MOD' | 'NEW' | 'STREAMER' | 'SUB';
  timestamp: string;
}

interface ChatMessageProps {
  message: ChatMessageType;
}

export const ChatMessage: React.FC<ChatMessageProps> = ({ message }) => {
  const getBadgeIcon = (badge?: string) => {
    switch (badge) {
      case 'STREAMER': return <Crown className="w-4 h-4 text-yellow-400" />;
      case 'MOD': return <Shield className="w-4 h-4 text-green-400" />;
      case 'VIP': return <Star className="w-4 h-4 text-pink-400" />;
      case 'SUB': return <Sparkles className="w-4 h-4 text-purple-400" />;
      case 'NEW': return <span className="bg-blue-500 text-white text-xs px-1.5 py-0.5 rounded font-bold">NEW</span>;
      default: return null;
    }
  };

  const getUsernameColor = (badge?: string) => {
    switch (badge) {
      case 'STREAMER': return 'text-yellow-400';
      case 'MOD': return 'text-green-400';
      case 'VIP': return 'text-pink-400';
      case 'SUB': return 'text-purple-400';
      default: return 'text-purple-400';
    }
  };

  return (
    <div className="flex items-start gap-2 p-2 hover:bg-white/5 rounded transition-colors">
      <div className="flex-1 min-w-0">
        <span className="inline-flex items-center gap-1">
          {getBadgeIcon(message.badge)}
          <span className={`${getUsernameColor(message.badge)} font-semibold text-sm`}>
            {message.display_name || message.username}:
          </span>
        </span>
        <span className="text-gray-200 text-sm ml-1">{message.message}</span>
      </div>
    </div>
  );
};
