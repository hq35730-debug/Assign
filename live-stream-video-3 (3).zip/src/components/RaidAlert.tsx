import React, { useEffect, useState } from 'react';
import { Zap, Users, X } from 'lucide-react';

interface Raid {
  id: string;
  raider_name: string;
  viewer_count: number;
  created_at: string;
}

interface RaidAlertProps {
  raid: Raid | null;
  onDismiss: () => void;
}

export function RaidAlert({ raid, onDismiss }: RaidAlertProps) {
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    if (raid) {
      setVisible(true);
      const timer = setTimeout(() => {
        setVisible(false);
        setTimeout(onDismiss, 300);
      }, 10000);
      return () => clearTimeout(timer);
    }
  }, [raid, onDismiss]);

  if (!raid) return null;

  return (
    <div className={`fixed top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 z-50 transition-all duration-500 ${visible ? 'opacity-100 scale-100' : 'opacity-0 scale-75'}`}>
      <div className="bg-gradient-to-r from-yellow-600 via-orange-500 to-red-500 rounded-2xl p-1 shadow-2xl shadow-yellow-500/50 animate-pulse">
        <div className="bg-[#1a1a2e] rounded-xl p-8 text-center relative">
          <button onClick={onDismiss} className="absolute top-3 right-3 text-gray-400 hover:text-white">
            <X className="w-5 h-5" />
          </button>
          <div className="w-20 h-20 mx-auto mb-4 bg-gradient-to-br from-yellow-500 to-orange-600 rounded-full flex items-center justify-center animate-bounce">
            <Zap className="w-10 h-10 text-white" />
          </div>
          <h2 className="text-3xl font-bold text-white mb-2">INCOMING RAID!</h2>
          <p className="text-xl text-yellow-400 font-semibold mb-4">{raid.raider_name}</p>
          <div className="flex items-center justify-center gap-2 text-white text-lg">
            <Users className="w-6 h-6" />
            <span className="font-bold">{raid.viewer_count.toLocaleString()}</span>
            <span className="text-gray-400">viewers</span>
          </div>
          <p className="text-gray-400 text-sm mt-4">Welcome raiders!</p>
        </div>
      </div>
    </div>
  );
}
