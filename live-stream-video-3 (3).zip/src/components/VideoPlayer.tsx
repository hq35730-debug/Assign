import React, { useState, useEffect } from 'react';
import { Stream } from '../data/streamData';
import { GiftButton } from './GiftButton';
import { LiveChat } from './LiveChat';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/contexts/AuthContext';
import { useStream } from '@/contexts/StreamContext';

interface VideoPlayerProps {
  stream: Stream;
  onClose: () => void;
  liveStreamId?: string;
}

export const VideoPlayer: React.FC<VideoPlayerProps> = ({ stream, onClose, liveStreamId }) => {
  const { user } = useAuth();
  const { joinStream, leaveStream } = useStream();
  const [isFollowing, setIsFollowing] = useState(false);

  useEffect(() => {
    // Record watch history
    if (user) {
      supabase.from('streaming_history').insert({
        user_id: user.user_id,
        stream_id: stream.id,
        streamer_name: stream.streamerName,
        stream_title: stream.title,
        stream_thumbnail: stream.thumbnail
      });
    }
    // Join stream for viewer count
    if (liveStreamId) {
      joinStream(liveStreamId);
      return () => { leaveStream(liveStreamId); };
    }
  }, [stream, liveStreamId]);

  const handleSendGift = (gift: any) => {
    console.log('Gift sent:', gift);
  };

  return (
    <div className="fixed inset-0 bg-black/95 z-50 flex">
      <div className="flex-1 flex flex-col">
        <div className="flex items-center justify-between p-4 bg-[#16213e]">
          <div className="flex items-center gap-4">
            <button onClick={onClose} className="text-white hover:text-purple-400">
              <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
              </svg>
            </button>
            <div>
              <h2 className="text-white font-bold text-lg">{stream.streamerName}</h2>
              <p className="text-gray-400 text-sm">{stream.title}</p>
            </div>
          </div>
          <div className="flex items-center gap-3">
            <GiftButton onSendGift={handleSendGift} />
            <button onClick={() => setIsFollowing(!isFollowing)}
              className={`px-6 py-2 rounded-full font-semibold ${isFollowing ? 'bg-gray-600' : 'bg-purple-600'} text-white`}>
              {isFollowing ? 'Following' : 'Follow'}
            </button>
          </div>
        </div>
        <div className="flex-1 bg-black flex items-center justify-center">
          <img src={stream.thumbnail} alt={stream.streamerName} className="max-h-full" />
        </div>
      </div>
      <div className="w-96 bg-[#16213e] flex flex-col">
        <div className="p-4 border-b border-gray-700 flex items-center justify-between">
          <h3 className="text-white font-bold">Live Chat</h3>
          <span className="text-gray-400 text-sm">{stream.viewers.toLocaleString()} watching</span>
        </div>
        {liveStreamId ? (
          <LiveChat streamId={liveStreamId} streamerId={stream.id} />
        ) : (
          <div className="flex-1 flex items-center justify-center text-gray-500">
            <p>Chat available for live streams only</p>
          </div>
        )}
      </div>
    </div>
  );
};
