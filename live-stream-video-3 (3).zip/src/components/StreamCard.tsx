import React from 'react';
import { Monitor } from 'lucide-react';
import { Stream } from '../data/streamData';

interface StreamCardProps {
  stream: Stream & { is_screen_sharing?: boolean };
  onClick: () => void;
}

export const StreamCard: React.FC<StreamCardProps> = ({ stream, onClick }) => {
  return (
    <div 
      onClick={onClick}
      className="group relative bg-[#16213e] rounded-xl overflow-hidden cursor-pointer transform transition-all duration-300 hover:scale-105 hover:shadow-2xl hover:shadow-purple-500/30"
    >
      <div className="relative aspect-[3/4] overflow-hidden">
        <img 
          src={stream.thumbnail} 
          alt={stream.streamerName}
          className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-110"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent" />
        
        <div className="absolute top-3 left-3 flex items-center gap-2">
          {stream.isLive && (
            <div className="flex items-center gap-2 bg-red-600 px-3 py-1 rounded-full animate-pulse">
              <div className="w-2 h-2 bg-white rounded-full" />
              <span className="text-white text-xs font-bold">LIVE</span>
            </div>
          )}
          
          {/* Screen Share Indicator */}
          {stream.is_screen_sharing && (
            <div className="flex items-center gap-1 bg-blue-600 px-2 py-1 rounded-full">
              <Monitor className="w-3 h-3 text-white" />
              <span className="text-white text-xs font-bold">SCREEN</span>
            </div>
          )}
        </div>
        
        <div className="absolute top-3 right-3 bg-black/70 px-2 py-1 rounded text-white text-xs font-semibold">
          {stream.viewers.toLocaleString()}
        </div>
        
        <div className="absolute bottom-0 left-0 right-0 p-4">
          <h3 className="text-white font-bold text-lg mb-1 line-clamp-1">{stream.streamerName}</h3>
          <p className="text-gray-300 text-sm mb-2 line-clamp-2">{stream.title}</p>
          <div className="flex items-center gap-2">
            <span className="bg-purple-600 px-2 py-1 rounded text-white text-xs">{stream.category}</span>
            <span className="text-gray-400 text-xs">{stream.duration}</span>
            {stream.is_screen_sharing && (
              <span className="flex items-center gap-1 text-blue-400 text-xs">
                <Monitor className="w-3 h-3" /> Sharing
              </span>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
