
import React from 'react';
import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';

interface DataPoint {
  date: string;
  donations_total: number;
  donations_count: number;
  new_subscribers: number;
}

interface Props {
  data: DataPoint[];
  loading: boolean;
}

export function RevenueChart({ data, loading }: Props) {
  const formatted = data.map(d => ({
    date: new Date(d.date).toLocaleDateString('en-US', { month: 'short', day: 'numeric' }),
    'Donations': (d.donations_total || 0) / 100,
    'Tip Count': d.donations_count || 0,
    'Sub Revenue': (d.new_subscribers || 0) * 4.99
  }));

  if (loading) {
    return (
      <div className="bg-[#16213e] rounded-xl p-6 border border-gray-800">
        <div className="h-6 w-40 bg-gray-700 rounded animate-pulse mb-4" />
        <div className="h-64 bg-gray-700/50 rounded animate-pulse" />
      </div>
    );
  }

  return (
    <div className="bg-[#16213e] rounded-xl p-6 border border-gray-800">
      <h3 className="text-lg font-bold text-white mb-4">Revenue Trends</h3>
      <div className="h-64">
        <ResponsiveContainer width="100%" height="100%">
          <AreaChart data={formatted}>
            <defs>
              <linearGradient id="donationGrad" x1="0" y1="0" x2="0" y2="1">
                <stop offset="5%" stopColor="#10B981" stopOpacity={0.8}/>
                <stop offset="95%" stopColor="#10B981" stopOpacity={0}/>
              </linearGradient>
              <linearGradient id="subGrad" x1="0" y1="0" x2="0" y2="1">
                <stop offset="5%" stopColor="#8B5CF6" stopOpacity={0.8}/>
                <stop offset="95%" stopColor="#8B5CF6" stopOpacity={0}/>
              </linearGradient>
            </defs>
            <CartesianGrid strokeDasharray="3 3" stroke="#374151" />
            <XAxis dataKey="date" stroke="#9CA3AF" fontSize={12} />
            <YAxis stroke="#9CA3AF" fontSize={12} tickFormatter={(v) => `$${v}`} />
            <Tooltip contentStyle={{ backgroundColor: '#1a1a2e', border: '1px solid #374151', borderRadius: '8px' }} labelStyle={{ color: '#fff' }} formatter={(v: number) => [`$${v.toFixed(2)}`, '']} />
            <Area type="monotone" dataKey="Donations" stroke="#10B981" fillOpacity={1} fill="url(#donationGrad)" />
            <Area type="monotone" dataKey="Sub Revenue" stroke="#8B5CF6" fillOpacity={1} fill="url(#subGrad)" />
          </AreaChart>
        </ResponsiveContainer>
      </div>
    </div>
  );
}
