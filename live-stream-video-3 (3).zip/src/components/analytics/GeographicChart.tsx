import React from 'react';
import { Globe } from 'lucide-react';
import { getFlag, getName } from '@/data/countries';

interface GeoData {
  country_code: string;
  country_name: string;
  viewer_count: number;
}

interface Props {
  data: GeoData[];
  loading: boolean;
}

export function GeographicChart({ data, loading }: Props) {
  const maxViewers = Math.max(...data.map(d => d.viewer_count), 1);

  if (loading) {
    return (
      <div className="bg-[#16213e] rounded-xl p-6 border border-gray-800">
        <div className="h-6 w-48 bg-gray-700 rounded animate-pulse mb-4" />
        <div className="space-y-3">
          {[...Array(5)].map((_, i) => (
            <div key={i} className="h-10 bg-gray-700/50 rounded animate-pulse" />
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="bg-[#16213e] rounded-xl p-6 border border-gray-800">
      <h3 className="text-lg font-bold text-white mb-4 flex items-center gap-2">
        <Globe className="w-5 h-5 text-purple-400" /> Viewer Distribution (107 Countries)
      </h3>
      {data.length === 0 ? (
        <p className="text-gray-500 text-center py-8">No geographic data yet</p>
      ) : (
        <div className="space-y-3 max-h-96 overflow-y-auto">
          {data.map((item, i) => (
            <div key={i} className="flex items-center gap-3">
              <span className="text-xl">{getFlag(item.country_code)}</span>
              <div className="flex-1">
                <div className="flex justify-between mb-1">
                  <span className="text-white text-sm">{item.country_name || getName(item.country_code)}</span>
                  <span className="text-gray-400 text-sm">{item.viewer_count.toLocaleString()}</span>
                </div>
                <div className="h-2 bg-gray-700 rounded-full overflow-hidden">
                  <div 
                    className="h-full bg-gradient-to-r from-purple-500 to-pink-500 rounded-full transition-all"
                    style={{ width: `${(item.viewer_count / maxViewers) * 100}%` }}
                  />
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
