
import React from 'react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend } from 'recharts';

interface DataPoint {
  date: string;
  total_chat_messages: number;
  new_followers: number;
  new_subscribers: number;
}

interface Props {
  data: DataPoint[];
  loading: boolean;
}

export function EngagementChart({ data, loading }: Props) {
  const formatted = data.map(d => ({
    date: new Date(d.date).toLocaleDateString('en-US', { month: 'short', day: 'numeric' }),
    'Chat Messages': d.total_chat_messages,
    'New Followers': d.new_followers,
    'New Subscribers': d.new_subscribers
  }));

  if (loading) {
    return (
      <div className="bg-[#16213e] rounded-xl p-6 border border-gray-800">
        <div className="h-6 w-40 bg-gray-700 rounded animate-pulse mb-4" />
        <div className="h-64 bg-gray-700/50 rounded animate-pulse" />
      </div>
    );
  }

  return (
    <div className="bg-[#16213e] rounded-xl p-6 border border-gray-800">
      <h3 className="text-lg font-bold text-white mb-4">Engagement & Growth</h3>
      <div className="h-64">
        <ResponsiveContainer width="100%" height="100%">
          <BarChart data={formatted}>
            <CartesianGrid strokeDasharray="3 3" stroke="#374151" />
            <XAxis dataKey="date" stroke="#9CA3AF" fontSize={12} />
            <YAxis stroke="#9CA3AF" fontSize={12} />
            <Tooltip contentStyle={{ backgroundColor: '#1a1a2e', border: '1px solid #374151', borderRadius: '8px' }} labelStyle={{ color: '#fff' }} />
            <Legend />
            <Bar dataKey="Chat Messages" fill="#8B5CF6" radius={[4, 4, 0, 0]} />
            <Bar dataKey="New Followers" fill="#10B981" radius={[4, 4, 0, 0]} />
            <Bar dataKey="New Subscribers" fill="#F59E0B" radius={[4, 4, 0, 0]} />
          </BarChart>
        </ResponsiveContainer>
      </div>
    </div>
  );
}
