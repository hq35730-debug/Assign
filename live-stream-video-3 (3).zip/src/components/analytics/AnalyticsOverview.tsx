
import React from 'react';
import { Users, Eye, Clock, MessageSquare, UserPlus, Star, Gift, Radio } from 'lucide-react';

interface OverviewData {
  totalViewers: number;
  uniqueViewers: number;
  peakConcurrent: number;
  avgWatchTime: number;
  chatMessages: number;
  newFollowers: number;
  newSubscribers: number;
  donations: number;
  streamHours: number;
}

interface Props {
  data: OverviewData;
  loading: boolean;
}

export function AnalyticsOverview({ data, loading }: Props) {
  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    if (mins < 60) return `${mins}m`;
    return `${Math.floor(mins / 60)}h ${mins % 60}m`;
  };

  const stats = [
    { label: 'Total Views', value: data.totalViewers.toLocaleString(), icon: Eye, color: 'from-blue-500 to-cyan-500' },
    { label: 'Unique Viewers', value: data.uniqueViewers.toLocaleString(), icon: Users, color: 'from-purple-500 to-pink-500' },
    { label: 'Peak Concurrent', value: data.peakConcurrent.toLocaleString(), icon: Radio, color: 'from-red-500 to-orange-500' },
    { label: 'Avg Watch Time', value: formatTime(data.avgWatchTime), icon: Clock, color: 'from-green-500 to-emerald-500' },
    { label: 'Chat Messages', value: data.chatMessages.toLocaleString(), icon: MessageSquare, color: 'from-yellow-500 to-amber-500' },
    { label: 'New Followers', value: data.newFollowers.toLocaleString(), icon: UserPlus, color: 'from-indigo-500 to-violet-500' },
    { label: 'New Subscribers', value: data.newSubscribers.toLocaleString(), icon: Star, color: 'from-pink-500 to-rose-500' },
    { label: 'Donations', value: `$${(data.donations / 100).toFixed(0)}`, icon: Gift, color: 'from-teal-500 to-cyan-500' },
  ];

  return (
    <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
      {stats.map((stat, i) => (
        <div key={i} className="bg-[#16213e] rounded-xl p-4 border border-gray-800">
          <div className={`w-10 h-10 rounded-lg bg-gradient-to-br ${stat.color} flex items-center justify-center mb-3`}>
            <stat.icon className="w-5 h-5 text-white" />
          </div>
          {loading ? (
            <div className="h-8 bg-gray-700 rounded animate-pulse mb-1" />
          ) : (
            <p className="text-2xl font-bold text-white">{stat.value}</p>
          )}
          <p className="text-gray-400 text-sm">{stat.label}</p>
        </div>
      ))}
    </div>
  );
}
