
import React from 'react';
import { Calendar } from 'lucide-react';

interface Props {
  startDate: string;
  endDate: string;
  onStartChange: (date: string) => void;
  onEndChange: (date: string) => void;
  onPresetSelect: (preset: string) => void;
}

export function DateRangeFilter({ startDate, endDate, onStartChange, onEndChange, onPresetSelect }: Props) {
  const presets = [
    { label: '7 Days', value: '7d' },
    { label: '30 Days', value: '30d' },
    { label: '90 Days', value: '90d' },
    { label: 'This Year', value: 'year' },
  ];

  return (
    <div className="flex flex-wrap items-center gap-4">
      <div className="flex items-center gap-2 bg-[#16213e] rounded-lg p-1 border border-gray-700">
        {presets.map((preset) => (
          <button
            key={preset.value}
            onClick={() => onPresetSelect(preset.value)}
            className="px-3 py-1.5 text-sm rounded-md text-gray-300 hover:text-white hover:bg-purple-600/30 transition-colors"
          >
            {preset.label}
          </button>
        ))}
      </div>
      
      <div className="flex items-center gap-2">
        <div className="relative">
          <Calendar className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
          <input
            type="date"
            value={startDate}
            onChange={(e) => onStartChange(e.target.value)}
            className="bg-[#16213e] text-white pl-10 pr-3 py-2 rounded-lg border border-gray-700 focus:border-purple-500 focus:outline-none text-sm"
          />
        </div>
        <span className="text-gray-400">to</span>
        <input
          type="date"
          value={endDate}
          onChange={(e) => onEndChange(e.target.value)}
          className="bg-[#16213e] text-white px-3 py-2 rounded-lg border border-gray-700 focus:border-purple-500 focus:outline-none text-sm"
        />
      </div>
    </div>
  );
}
