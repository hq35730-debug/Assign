
import React from 'react';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend } from 'recharts';

interface DataPoint {
  date: string;
  total_viewers: number;
  unique_viewers: number;
  peak_concurrent: number;
}

interface Props {
  data: DataPoint[];
  loading: boolean;
}

export function ViewerChart({ data, loading }: Props) {
  const formatted = data.map(d => ({
    date: new Date(d.date).toLocaleDateString('en-US', { month: 'short', day: 'numeric' }),
    'Total Views': d.total_viewers,
    'Unique Viewers': d.unique_viewers,
    'Peak Concurrent': d.peak_concurrent
  }));

  if (loading) {
    return (
      <div className="bg-[#16213e] rounded-xl p-6 border border-gray-800">
        <div className="h-6 w-40 bg-gray-700 rounded animate-pulse mb-4" />
        <div className="h-64 bg-gray-700/50 rounded animate-pulse" />
      </div>
    );
  }

  return (
    <div className="bg-[#16213e] rounded-xl p-6 border border-gray-800">
      <h3 className="text-lg font-bold text-white mb-4">Viewer Statistics</h3>
      <div className="h-64">
        <ResponsiveContainer width="100%" height="100%">
          <LineChart data={formatted}>
            <CartesianGrid strokeDasharray="3 3" stroke="#374151" />
            <XAxis dataKey="date" stroke="#9CA3AF" fontSize={12} />
            <YAxis stroke="#9CA3AF" fontSize={12} />
            <Tooltip contentStyle={{ backgroundColor: '#1a1a2e', border: '1px solid #374151', borderRadius: '8px' }} labelStyle={{ color: '#fff' }} />
            <Legend />
            <Line type="monotone" dataKey="Total Views" stroke="#8B5CF6" strokeWidth={2} dot={false} />
            <Line type="monotone" dataKey="Unique Viewers" stroke="#EC4899" strokeWidth={2} dot={false} />
            <Line type="monotone" dataKey="Peak Concurrent" stroke="#F59E0B" strokeWidth={2} dot={false} />
          </LineChart>
        </ResponsiveContainer>
      </div>
    </div>
  );
}
