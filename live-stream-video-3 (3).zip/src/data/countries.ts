// Comprehensive list of 100+ countries with flags and names
export interface Country {
  code: string;
  name: string;
  flag: string;
  region: string;
}

export const countries: Country[] = [
  // North America
  { code: 'US', name: 'United States', flag: '🇺🇸', region: 'North America' },
  { code: 'CA', name: 'Canada', flag: '🇨🇦', region: 'North America' },
  { code: 'MX', name: 'Mexico', flag: '🇲🇽', region: 'North America' },
  // Central America & Caribbean
  { code: 'GT', name: 'Guatemala', flag: '🇬🇹', region: 'Central America' },
  { code: 'BZ', name: 'Belize', flag: '🇧🇿', region: 'Central America' },
  { code: 'HN', name: 'Honduras', flag: '🇭🇳', region: 'Central America' },
  { code: 'SV', name: 'El Salvador', flag: '🇸🇻', region: 'Central America' },
  { code: 'NI', name: 'Nicaragua', flag: '🇳🇮', region: 'Central America' },
  { code: 'CR', name: 'Costa Rica', flag: '🇨🇷', region: 'Central America' },
  { code: 'PA', name: 'Panama', flag: '🇵🇦', region: 'Central America' },
  { code: 'CU', name: 'Cuba', flag: '🇨🇺', region: 'Caribbean' },
  { code: 'JM', name: 'Jamaica', flag: '🇯🇲', region: 'Caribbean' },
  { code: 'HT', name: 'Haiti', flag: '🇭🇹', region: 'Caribbean' },
  { code: 'DO', name: 'Dominican Republic', flag: '🇩🇴', region: 'Caribbean' },
  { code: 'PR', name: 'Puerto Rico', flag: '🇵🇷', region: 'Caribbean' },
  { code: 'TT', name: 'Trinidad and Tobago', flag: '🇹🇹', region: 'Caribbean' },
  // South America
  { code: 'BR', name: 'Brazil', flag: '🇧🇷', region: 'South America' },
  { code: 'AR', name: 'Argentina', flag: '🇦🇷', region: 'South America' },
  { code: 'CO', name: 'Colombia', flag: '🇨🇴', region: 'South America' },
  { code: 'PE', name: 'Peru', flag: '🇵🇪', region: 'South America' },
  { code: 'VE', name: 'Venezuela', flag: '🇻🇪', region: 'South America' },
  { code: 'CL', name: 'Chile', flag: '🇨🇱', region: 'South America' },
  { code: 'EC', name: 'Ecuador', flag: '🇪🇨', region: 'South America' },
  { code: 'BO', name: 'Bolivia', flag: '🇧🇴', region: 'South America' },
  { code: 'PY', name: 'Paraguay', flag: '🇵🇾', region: 'South America' },
  { code: 'UY', name: 'Uruguay', flag: '🇺🇾', region: 'South America' },
  // Europe
  { code: 'GB', name: 'United Kingdom', flag: '🇬🇧', region: 'Europe' },
  { code: 'DE', name: 'Germany', flag: '🇩🇪', region: 'Europe' },
  { code: 'FR', name: 'France', flag: '🇫🇷', region: 'Europe' },
  { code: 'IT', name: 'Italy', flag: '🇮🇹', region: 'Europe' },
  { code: 'ES', name: 'Spain', flag: '🇪🇸', region: 'Europe' },
  { code: 'PT', name: 'Portugal', flag: '🇵🇹', region: 'Europe' },
  { code: 'NL', name: 'Netherlands', flag: '🇳🇱', region: 'Europe' },
  { code: 'BE', name: 'Belgium', flag: '🇧🇪', region: 'Europe' },
  { code: 'AT', name: 'Austria', flag: '🇦🇹', region: 'Europe' },
  { code: 'CH', name: 'Switzerland', flag: '🇨🇭', region: 'Europe' },
  { code: 'SE', name: 'Sweden', flag: '🇸🇪', region: 'Europe' },
  { code: 'NO', name: 'Norway', flag: '🇳🇴', region: 'Europe' },
  { code: 'DK', name: 'Denmark', flag: '🇩🇰', region: 'Europe' },
  { code: 'FI', name: 'Finland', flag: '🇫🇮', region: 'Europe' },
  { code: 'IE', name: 'Ireland', flag: '🇮🇪', region: 'Europe' },
  { code: 'PL', name: 'Poland', flag: '🇵🇱', region: 'Europe' },
  { code: 'CZ', name: 'Czech Republic', flag: '🇨🇿', region: 'Europe' },
  { code: 'HU', name: 'Hungary', flag: '🇭🇺', region: 'Europe' },
  { code: 'RO', name: 'Romania', flag: '🇷🇴', region: 'Europe' },
  { code: 'GR', name: 'Greece', flag: '🇬🇷', region: 'Europe' },
  { code: 'UA', name: 'Ukraine', flag: '🇺🇦', region: 'Europe' },
  { code: 'RU', name: 'Russia', flag: '🇷🇺', region: 'Europe' },
  { code: 'SK', name: 'Slovakia', flag: '🇸🇰', region: 'Europe' },
  { code: 'BG', name: 'Bulgaria', flag: '🇧🇬', region: 'Europe' },
  { code: 'HR', name: 'Croatia', flag: '🇭🇷', region: 'Europe' },
  { code: 'RS', name: 'Serbia', flag: '🇷🇸', region: 'Europe' },
  { code: 'SI', name: 'Slovenia', flag: '🇸🇮', region: 'Europe' },
  { code: 'LT', name: 'Lithuania', flag: '🇱🇹', region: 'Europe' },
  { code: 'LV', name: 'Latvia', flag: '🇱🇻', region: 'Europe' },
  { code: 'EE', name: 'Estonia', flag: '🇪🇪', region: 'Europe' },
];

import { extendedCountries } from './countriesExtended';

export const allCountries: Country[] = [...countries, ...extendedCountries];
export const countryMap = Object.fromEntries(allCountries.map(c => [c.code, c]));
export const getFlag = (code: string) => countryMap[code]?.flag || '🌍';
export const getName = (code: string) => countryMap[code]?.name || code;
export const getRegions = () => [...new Set(allCountries.map(c => c.region))];
export const getCountriesByRegion = (region: string) => allCountries.filter(c => c.region === region);
