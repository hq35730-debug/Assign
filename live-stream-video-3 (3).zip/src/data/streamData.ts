export interface Stream {
  id: string;
  streamerName: string;
  title: string;
  category: string;
  viewers: number;
  thumbnail: string;
  isLive: boolean;
  duration: string;
  tags: string[];
}

export const streams: Stream[] = [
  { id: '1', streamerName: 'GamerGirl_Luna', title: 'Late Night Valorant Ranked!', category: 'Gaming', viewers: 12453, thumbnail: 'https://d64gsuwffb70l.cloudfront.net/6927ca8790687cc18bcac914_1764215525326_147203fe.webp', isLive: true, duration: '2h 15m', tags: ['Valorant', 'FPS'] },
  { id: '2', streamerName: 'ProGamer_Max', title: 'League of Legends Challenger Climb', category: 'Gaming', viewers: 8921, thumbnail: 'https://d64gsuwffb70l.cloudfront.net/6927ca8790687cc18bcac914_1764215533917_2ad83a94.webp', isLive: true, duration: '3h 42m', tags: ['LoL', 'MOBA'] },
  { id: '3', streamerName: 'MusicMaven_Sarah', title: 'Acoustic Guitar Covers & Chill', category: 'Music', viewers: 5632, thumbnail: 'https://d64gsuwffb70l.cloudfront.net/6927ca8790687cc18bcac914_1764215542525_621b32df.webp', isLive: true, duration: '1h 28m', tags: ['Acoustic', 'Covers'] },
  { id: '4', streamerName: 'BeautyQueen_Mia', title: 'Full Glam Makeup Tutorial', category: 'Beauty', viewers: 4521, thumbnail: 'https://d64gsuwffb70l.cloudfront.net/6927ca8790687cc18bcac914_1764215547348_fd831570.webp', isLive: true, duration: '45m', tags: ['Makeup', 'Tutorial'] },
  { id: '5', streamerName: 'StreamQueen_Bella', title: 'Just Chatting with You!', category: 'Talk', viewers: 9876, thumbnail: 'https://d64gsuwffb70l.cloudfront.net/6927ca8790687cc18bcac914_1764215527246_28c9e4ec.webp', isLive: true, duration: '1h 12m', tags: ['Chatting', 'Q&A'] },
  { id: '6', streamerName: 'TechGuru_Jake', title: 'Fortnite Arena Mode Grind', category: 'Gaming', viewers: 7234, thumbnail: 'https://d64gsuwffb70l.cloudfront.net/6927ca8790687cc18bcac914_1764215535904_4d69387b.webp', isLive: true, duration: '2h 55m', tags: ['Fortnite', 'Battle Royale'] },
  { id: '7', streamerName: 'DJ_Vibes', title: 'Electronic Music Mix Live', category: 'Music', viewers: 3421, thumbnail: 'https://d64gsuwffb70l.cloudfront.net/6927ca8790687cc18bcac914_1764215544447_fbcca59c.webp', isLive: true, duration: '1h 05m', tags: ['EDM', 'DJ'] },
  { id: '8', streamerName: 'CasualGamer_Amy', title: 'Minecraft Building Stream', category: 'Gaming', viewers: 6543, thumbnail: 'https://d64gsuwffb70l.cloudfront.net/6927ca8790687cc18bcac914_1764215529149_eeba0eb3.webp', isLive: true, duration: '3h 20m', tags: ['Minecraft', 'Creative'] },
  { id: '9', streamerName: 'FitnessCoach_Dan', title: 'Morning Workout Session', category: 'Talent', viewers: 2876, thumbnail: 'https://d64gsuwffb70l.cloudfront.net/6927ca8790687cc18bcac914_1764215537785_fdcd8c0a.webp', isLive: true, duration: '52m', tags: ['Fitness', 'Health'] },
  { id: '10', streamerName: 'ArtistAlice', title: 'Digital Painting Tutorial', category: 'Talent', viewers: 4123, thumbnail: 'https://d64gsuwffb70l.cloudfront.net/6927ca8790687cc18bcac914_1764215550028_f1ed153c.webp', isLive: true, duration: '2h 10m', tags: ['Art', 'Digital'] },
  { id: '11', streamerName: 'ProShooter_Chris', title: 'CS:GO Competitive Ranked', category: 'Gaming', viewers: 11234, thumbnail: 'https://d64gsuwffb70l.cloudfront.net/6927ca8790687cc18bcac914_1764215539686_65902754.webp', isLive: true, duration: '4h 15m', tags: ['CS:GO', 'FPS'] },
  { id: '12', streamerName: 'SingingStar_Emma', title: 'Karaoke Night with Fans!', category: 'Music', viewers: 5987, thumbnail: 'https://d64gsuwffb70l.cloudfront.net/6927ca8790687cc18bcac914_1764215546360_fc5e6709.webp', isLive: true, duration: '1h 35m', tags: ['Singing', 'Karaoke'] },
  { id: '13', streamerName: 'MakeupPro_Lisa', title: 'Evening Glam Look', category: 'Beauty', viewers: 3654, thumbnail: 'https://d64gsuwffb70l.cloudfront.net/6927ca8790687cc18bcac914_1764215552440_2d1207f0.webp', isLive: true, duration: '58m', tags: ['Makeup', 'Beauty'] },
  { id: '14', streamerName: 'ChillStreamer_Tom', title: 'Late Night Chat & Games', category: 'Talk', viewers: 7821, thumbnail: 'https://d64gsuwffb70l.cloudfront.net/6927ca8790687cc18bcac914_1764215541574_d37a9f85.webp', isLive: true, duration: '2h 48m', tags: ['Chatting', 'Variety'] },
  { id: '15', streamerName: 'GamerGirl_Zoe', title: 'Apex Legends Ranked Push', category: 'Gaming', viewers: 9432, thumbnail: 'https://d64gsuwffb70l.cloudfront.net/6927ca8790687cc18bcac914_1764215531062_cf8c893b.webp', isLive: true, duration: '3h 05m', tags: ['Apex', 'Battle Royale'] },
  { id: '16', streamerName: 'CookingChef_Marco', title: 'Italian Pasta Making Live', category: 'Talent', viewers: 4567, thumbnail: 'https://d64gsuwffb70l.cloudfront.net/6927ca8790687cc18bcac914_1764215532997_3d7da1bb.webp', isLive: true, duration: '1h 22m', tags: ['Cooking', 'Food'] },
];
