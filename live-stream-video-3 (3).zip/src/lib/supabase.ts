import { createClient } from '@supabase/supabase-js';


// Initialize database client
const supabaseUrl = 'https://yttrbtxmumvjfmkphiqt.databasepad.com';
const supabaseKey = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6IjAwY2Y1N2RiLTY2ZjEtNGNmOC04MDEyLTQ4ZmRiNjRlMzIyYiJ9.eyJwcm9qZWN0SWQiOiJ5dHRyYnR4bXVtdmpmbWtwaGlxdCIsInJvbGUiOiJhbm9uIiwiaWF0IjoxNzY0MjE1NDU3LCJleHAiOjIwNzk1NzU0NTcsImlzcyI6ImZhbW91cy5kYXRhYmFzZXBhZCIsImF1ZCI6ImZhbW91cy5jbGllbnRzIn0.dmec764tgkCP1enMG6kfNdMFeoevHyiLUHA4R4zXDag';
const supabase = createClient(supabaseUrl, supabaseKey);


export { supabase };