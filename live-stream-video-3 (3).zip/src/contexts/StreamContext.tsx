import React, { createContext, useContext, useState, useEffect } from 'react';
import { supabase } from '@/lib/supabase';
import { useAuth } from './AuthContext';

export interface LiveStream {
  id: string;
  user_id: string;
  streamer_name: string;
  title: string;
  category: string;
  thumbnail_url: string;
  viewer_count: number;
  is_live: boolean;
  started_at: string;
  stream_key: string;
  is_screen_sharing?: boolean;
}

interface StreamContextType {
  liveStreams: LiveStream[];
  currentStream: LiveStream | null;
  isStreaming: boolean;
  mediaStream: MediaStream | null;
  screenStream: MediaStream | null;
  isScreenSharing: boolean;
  setMediaStream: (stream: MediaStream | null) => void;
  setScreenStream: (stream: MediaStream | null) => void;
  setIsScreenSharing: (sharing: boolean) => void;
  startStream: (title: string, category: string, thumbnailUrl: string) => Promise<LiveStream>;
  endStream: () => Promise<void>;
  joinStream: (streamId: string) => Promise<void>;
  leaveStream: (streamId: string) => Promise<void>;
  refreshStreams: () => Promise<void>;
  updateStreamScreenShare: (isSharing: boolean) => Promise<void>;
}

const StreamContext = createContext<StreamContextType | null>(null);

export const useStream = () => {
  const context = useContext(StreamContext);
  if (!context) throw new Error('useStream must be used within StreamProvider');
  return context;
};

export const StreamProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [liveStreams, setLiveStreams] = useState<LiveStream[]>([]);
  const [currentStream, setCurrentStream] = useState<LiveStream | null>(null);
  const [isStreaming, setIsStreaming] = useState(false);
  const [mediaStream, setMediaStream] = useState<MediaStream | null>(null);
  const [screenStream, setScreenStream] = useState<MediaStream | null>(null);
  const [isScreenSharing, setIsScreenSharing] = useState(false);
  const { user } = useAuth();

  const refreshStreams = async () => {
    try {
      const { data, error } = await supabase.functions.invoke('stream-manager', {
        body: { action: 'get_live_streams' }
      });
      const streamsData = Array.isArray(data?.streams) ? data.streams : [];
      setLiveStreams(streamsData);
    } catch (e) {
      console.log('Using local streams');
    }
  };

  useEffect(() => {
    refreshStreams();
    const interval = setInterval(refreshStreams, 10000);
    return () => clearInterval(interval);
  }, []);

  const startStream = async (title: string, category: string, thumbnailUrl: string): Promise<LiveStream> => {
    if (!user) throw new Error('Please sign in to start streaming');
    
    try {
      const { data, error } = await supabase.functions.invoke('stream-manager', {
        body: { action: 'start_stream', user_id: user.user_id, streamer_name: user.display_name || user.username, title, category, thumbnail_url: thumbnailUrl }
      });
      
      if (data?.stream) {
        setCurrentStream(data.stream);
        setIsStreaming(true);
        await refreshStreams();
        return data.stream;
      }
    } catch (e) {
      console.log('Edge function unavailable, using local stream');
    }
    
    const localStream: LiveStream = {
      id: `local_${Date.now()}`,
      user_id: user.user_id,
      streamer_name: user.display_name || user.username,
      title,
      category,
      thumbnail_url: thumbnailUrl,
      viewer_count: 0,
      is_live: true,
      started_at: new Date().toISOString(),
      stream_key: `sk_${Math.random().toString(36).substring(7)}`,
      is_screen_sharing: false
    };
    
    setCurrentStream(localStream);
    setIsStreaming(true);
    setLiveStreams(prev => {
      const safePrev = Array.isArray(prev) ? prev : [];
      return [...safePrev, localStream];
    });
    return localStream;
  };

  const endStream = async () => {
    if (!currentStream || !user) return;
    
    // Stop camera stream
    if (mediaStream) {
      mediaStream.getTracks().forEach(track => track.stop());
      setMediaStream(null);
    }
    
    // Stop screen stream
    if (screenStream) {
      screenStream.getTracks().forEach(track => track.stop());
      setScreenStream(null);
    }
    
    setIsScreenSharing(false);
    
    try {
      await supabase.functions.invoke('stream-manager', {
        body: { action: 'end_stream', stream_id: currentStream.id, user_id: user.user_id }
      });
    } catch (e) {
      console.log('Using local end stream');
    }
    setLiveStreams(prev => {
      const safePrev = Array.isArray(prev) ? prev : [];
      return safePrev.filter(s => s.id !== currentStream.id);
    });
    setCurrentStream(null);
    setIsStreaming(false);
  };

  const joinStream = async (streamId: string) => {
    const viewerId = user?.user_id || `anon_${Date.now()}`;
    try {
      await supabase.functions.invoke('stream-manager', { body: { action: 'join_stream', stream_id: streamId, viewer_id: viewerId } });
    } catch (e) {}
  };

  const leaveStream = async (streamId: string) => {
    const viewerId = user?.user_id || `anon_${Date.now()}`;
    try {
      await supabase.functions.invoke('stream-manager', { body: { action: 'leave_stream', stream_id: streamId, viewer_id: viewerId } });
    } catch (e) {}
  };

  // Update stream's screen sharing status
  const updateStreamScreenShare = async (isSharing: boolean) => {
    if (!currentStream || !user) return;
    
    try {
      await supabase.functions.invoke('stream-manager', {
        body: { 
          action: 'update_screen_share', 
          stream_id: currentStream.id, 
          user_id: user.user_id,
          is_screen_sharing: isSharing
        }
      });
      
      // Update local state
      setCurrentStream(prev => prev ? { ...prev, is_screen_sharing: isSharing } : null);
      setIsScreenSharing(isSharing);
    } catch (e) {
      console.log('Failed to update screen share status');
    }
  };

  return (
    <StreamContext.Provider value={{ 
      liveStreams, 
      currentStream, 
      isStreaming, 
      mediaStream, 
      screenStream,
      isScreenSharing,
      setMediaStream, 
      setScreenStream,
      setIsScreenSharing,
      startStream, 
      endStream, 
      joinStream, 
      leaveStream, 
      refreshStreams,
      updateStreamScreenShare
    }}>
      {children}
    </StreamContext.Provider>
  );
};
