import React, { createContext, useContext, useState, useEffect } from 'react';
import { supabase } from '@/lib/supabase';

export interface UserProfile {
  id: string;
  user_id: string;
  username: string;
  email: string;
  display_name: string;
  bio: string;
  avatar_url: string;
  created_at: string;
  phone_number?: string;
  unique_id?: number;
}

interface AuthContextType {
  user: UserProfile | null;
  loading: boolean;
  signUp: (email: string, password: string, username: string) => Promise<{ error: string | null; success?: boolean }>;
  signIn: (email: string, password: string) => Promise<{ error: string | null }>;
  signOut: () => Promise<void>;
  updateProfile: (updates: Partial<UserProfile>) => Promise<{ error: string | null }>;
  refreshProfile: () => Promise<void>;
}

const AuthContext = createContext<AuthContextType | null>(null);

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) throw new Error('useAuth must be used within AuthProvider');
  return context;
};

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<UserProfile | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const stored = localStorage.getItem('assigned_user');
    if (stored) {
      setUser(JSON.parse(stored));
    }
    setLoading(false);
  }, []);

  const signUp = async (email: string, password: string, username: string) => {
    try {
      console.log('Starting signup process for:', { email, username });
      
      // Check if email or username already exists
      const { data: existingEmail } = await supabase
        .from('profiles')
        .select('id')
        .eq('email', email)
        .maybeSingle();
      
      if (existingEmail) {
        console.log('Email already exists');
        return { error: 'Email already exists' };
      }

      const { data: existingUsername } = await supabase
        .from('profiles')
        .select('id')
        .eq('username', username)
        .maybeSingle();
      
      if (existingUsername) {
        console.log('Username already exists');
        return { error: 'Username already exists' };
      }
      
      const userId = crypto.randomUUID();
      console.log('Generated user ID:', userId);
      
      const profileData = {
        user_id: userId,
        username: username.toLowerCase().trim(),
        email: email.toLowerCase().trim(),
        display_name: username,
        bio: '',
        avatar_url: `https://api.dicebear.com/7.x/avataaars/svg?seed=${username}`
      };
      
      console.log('Inserting profile:', profileData);
      
      const { data: insertedProfile, error: insertError } = await supabase
        .from('profiles')
        .insert(profileData)
        .select()
        .single();
      
      if (insertError) {
        console.error('Profile insert error:', insertError);
        return { error: insertError.message };
      }
      
      console.log('Profile created successfully:', insertedProfile);
      
      // Assign phone number and unique ID via phone-manager
      console.log('Assigning phone number and unique ID...');
      try {
        const { data: phoneData, error: phoneError } = await supabase.functions.invoke('phone-manager', {
          body: { action: 'assign_phone_number', user_id: userId }
        });
        
        if (phoneError) {
          console.error('Phone assignment error:', phoneError);
        } else if (phoneData) {
          console.log('Phone assignment result:', phoneData);
          // Update the inserted profile with phone data
          if (phoneData.phone_number) {
            insertedProfile.phone_number = phoneData.phone_number;
          }
          if (phoneData.unique_id) {
            insertedProfile.unique_id = phoneData.unique_id;
          }
        }
      } catch (phoneErr) {
        console.error('Phone assignment exception:', phoneErr);
        // Continue with signup even if phone assignment fails
      }
      
      if (insertedProfile) {
        setUser(insertedProfile);
        localStorage.setItem('assigned_user', JSON.stringify(insertedProfile));
        console.log('User logged in and stored in localStorage');
        return { error: null, success: true };
      }
      
      // Fallback: try to fetch the profile if insert didn't return it
      const { data: profile, error: fetchError } = await supabase
        .from('profiles')
        .select('*')
        .eq('user_id', userId)
        .single();
      
      if (fetchError) {
        console.error('Profile fetch error:', fetchError);
        return { error: 'Profile created but could not be retrieved' };
      }
      
      if (profile) {
        console.log('Profile fetched successfully:', profile);
        setUser(profile);
        localStorage.setItem('assigned_user', JSON.stringify(profile));
        return { error: null, success: true };
      }
      
      return { error: 'Failed to create profile' };
    } catch (e: any) {
      console.error('Signup exception:', e);
      return { error: e.message };
    }
  };

  const signIn = async (email: string, password: string) => {
    try {
      console.log('Attempting sign in for:', email);
      const { data: profile, error } = await supabase
        .from('profiles')
        .select('*')
        .eq('email', email.toLowerCase().trim())
        .single();
      
      if (error || !profile) {
        console.error('Sign in error:', error);
        return { error: 'Invalid credentials' };
      }
      
      console.log('Sign in successful:', profile);
      setUser(profile);
      localStorage.setItem('assigned_user', JSON.stringify(profile));
      return { error: null };
    } catch (e: any) {
      console.error('Sign in exception:', e);
      return { error: e.message };
    }
  };

  const signOut = async () => {
    console.log('Signing out user');
    setUser(null);
    localStorage.removeItem('assigned_user');
  };

  const updateProfile = async (updates: Partial<UserProfile>) => {
    if (!user) return { error: 'Not logged in' };
    console.log('Updating profile:', updates);
    const { error } = await supabase
      .from('profiles')
      .update(updates)
      .eq('user_id', user.user_id);
    if (error) {
      console.error('Profile update error:', error);
      return { error: error.message };
    }
    await refreshProfile();
    return { error: null };
  };

  const refreshProfile = async () => {
    if (!user) return;
    console.log('Refreshing profile for:', user.user_id);
    const { data } = await supabase
      .from('profiles')
      .select('*')
      .eq('user_id', user.user_id)
      .single();
    if (data) {
      console.log('Profile refreshed:', data);
      setUser(data);
      localStorage.setItem('assigned_user', JSON.stringify(data));
    }
  };

  return (
    <AuthContext.Provider value={{ user, loading, signUp, signIn, signOut, updateProfile, refreshProfile }}>
      {children}
    </AuthContext.Provider>
  );
};
