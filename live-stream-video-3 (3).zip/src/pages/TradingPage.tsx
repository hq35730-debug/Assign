import { useState, useEffect, useCallback } from 'react';
import { Link } from 'react-router-dom';
import { 
  ArrowLeft, 
  Home, 
  TrendingUp, 
  TrendingDown, 
  Activity, 
  BarChart3,
  Coins,
  RefreshCw,
  Info,
  Bot,
  Key,
  LineChart,
  Bell,
  BellOff,
  Wallet,
  History
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { PriceChart } from '@/components/trading/PriceChart';
import { OrderBook } from '@/components/trading/OrderBook';
import { TradeHistory } from '@/components/trading/TradeHistory';
import { TradingInterface } from '@/components/trading/TradingInterface';
import { OpenOrders } from '@/components/trading/OpenOrders';
import { TradingBotPanel } from '@/components/trading/TradingBotPanel';
import { APIKeyManager } from '@/components/trading/APIKeyManager';
import { BacktestingPanel } from '@/components/trading/BacktestingPanel';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/contexts/AuthContext';
import { useToast } from '@/hooks/use-toast';


export default function TradingPage() {
  const { user } = useAuth();
  const { toast } = useToast();
  const [userId, setUserId] = useState('');
  const [selectedPrice, setSelectedPrice] = useState<number | undefined>();
  const [refreshTrigger, setRefreshTrigger] = useState(0);
  const [activeTab, setActiveTab] = useState(() => {
    const params = new URLSearchParams(window.location.search);
    return params.get('tab') || 'trading';
  });
  const [marketStats, setMarketStats] = useState({
    last_price: 100,
    change_24h: 0,
    change_percent_24h: 0,
    high_24h: 100,
    low_24h: 100,
    volume_24h: 0,
    trades_24h: 0,
    best_bid: 99,
    best_ask: 101
  });
  const [userBalances, setUserBalances] = useState({
    stc_balance: 0,
    stc_available: 0,
    coins_balance: 0,
    coins_available: 0
  });
  const [loading, setLoading] = useState(true);
  const [liveUpdates, setLiveUpdates] = useState(true);
  const [lastUpdate, setLastUpdate] = useState<Date | null>(null);
  const [priceAlert, setPriceAlert] = useState<{ type: 'up' | 'down' | null; oldPrice: number }>({ type: null, oldPrice: 0 });

  useEffect(() => {
    if (user) {
      setUserId(user.user_id || user.id);
    } else {
      setUserId('demo-user-' + Math.random().toString(36).substr(2, 9));
    }
  }, [user]);

  useEffect(() => {
    if (userId) {
      fetchMarketStats();
      fetchUserBalances();
    }
  }, [userId]);

  // Real-time market updates
  useEffect(() => {
    if (!liveUpdates) return;
    
    const timer = setInterval(() => {
      fetchMarketStats();
      if (userId) fetchUserBalances();
    }, 5000);
    
    return () => clearInterval(timer);
  }, [liveUpdates, userId]);

  const fetchMarketStats = useCallback(async () => {
    try {
      const { data, error } = await supabase.functions.invoke('trading-manager', {
        body: { action: 'get_market_stats' }
      });

      if (!error && data?.stats) {
        const newPrice = data.stats.last_price;
        const oldPrice = marketStats.last_price;
        
        if (newPrice !== oldPrice && lastUpdate) {
          setPriceAlert({
            type: newPrice > oldPrice ? 'up' : 'down',
            oldPrice
          });
          setTimeout(() => setPriceAlert({ type: null, oldPrice: 0 }), 2000);
        }
        
        setMarketStats(data.stats);
        setLastUpdate(new Date());
      }
    } catch (err) {
      console.error('Failed to fetch market stats:', err);
    } finally {
      setLoading(false);
    }
  }, [marketStats.last_price, lastUpdate]);

  const fetchUserBalances = async () => {
    if (!userId) return;
    try {
      const { data, error } = await supabase.functions.invoke('trading-manager', {
        body: { action: 'get_user_balances', user_id: userId }
      });

      if (!error && data) {
        setUserBalances(data);
      }
    } catch (err) {
      console.error('Failed to fetch balances:', err);
    }
  };

  const handleOrderPlaced = () => {
    setRefreshTrigger(prev => prev + 1);
    fetchMarketStats();
    fetchUserBalances();
    toast({ title: 'Order Placed', description: 'Your order has been submitted successfully.' });
  };

  const handlePriceSelect = (price: number) => {
    setSelectedPrice(price);
  };

  const handleManualRefresh = () => {
    fetchMarketStats();
    fetchUserBalances();
    setRefreshTrigger(prev => prev + 1);
    toast({ title: 'Refreshed', description: 'Market data has been updated.' });
  };

  const isPositive = marketStats.change_24h >= 0;
  const spread = marketStats.best_ask - marketStats.best_bid;
  const spreadPercent = marketStats.best_bid > 0 ? (spread / marketStats.best_bid) * 100 : 0;

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="bg-card border-b sticky top-0 z-40">
        <div className="max-w-7xl mx-auto px-4 py-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <Link to="/mining">
                <Button variant="ghost" size="sm" className="gap-2">
                  <ArrowLeft className="w-4 h-4" />
                  Back
                </Button>
              </Link>
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-full bg-gradient-to-br from-amber-400 to-orange-500 flex items-center justify-center">
                  <BarChart3 className="w-5 h-5 text-white" />
                </div>
                <div>
                  <h1 className="font-bold text-lg">STC Trading</h1>
                  <p className="text-xs text-muted-foreground">StreamCoin Marketplace</p>
                </div>
              </div>
            </div>
            <div className="flex items-center gap-2">
              <Button
                variant="outline"
                size="sm"
                onClick={() => setLiveUpdates(!liveUpdates)}
                className={liveUpdates ? 'text-green-500 border-green-500/50' : ''}
              >
                {liveUpdates ? <Bell className="w-4 h-4 mr-1" /> : <BellOff className="w-4 h-4 mr-1" />}
                {liveUpdates ? 'Live' : 'Paused'}
              </Button>
              <Button 
                variant="outline" 
                size="sm" 
                className="gap-2"
                onClick={handleManualRefresh}
              >
                <RefreshCw className="w-4 h-4" />
                Refresh
              </Button>
              <Link to="/">
                <Button variant="outline" size="sm" className="gap-2">
                  <Home className="w-4 h-4" />
                  Home
                </Button>
              </Link>
            </div>
          </div>
        </div>
      </header>

      {/* Market Stats Bar */}
      <div className="bg-card/50 border-b">
        <div className="max-w-7xl mx-auto px-4 py-3">
          <div className="flex items-center gap-6 overflow-x-auto">
            {/* Trading Pair */}
            <div className="flex items-center gap-3">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-full bg-gradient-to-br from-amber-400 to-orange-500 flex items-center justify-center">
                  <Coins className="w-4 h-4 text-white" />
                </div>
                <span className="font-bold text-lg">STC/COINS</span>
              </div>
              <Badge variant="outline" className={`${liveUpdates ? 'bg-green-500/10 text-green-500 border-green-500/30' : 'bg-gray-500/10 text-gray-500'}`}>
                <Activity className="w-3 h-3 mr-1" />
                {liveUpdates ? 'Live' : 'Paused'}
              </Badge>
            </div>

            {/* Price with animation */}
            <div className="flex items-center gap-2">
              <span className={`text-2xl font-bold transition-colors ${priceAlert.type === 'up' ? 'text-green-500' : priceAlert.type === 'down' ? 'text-red-500' : ''}`}>
                {marketStats.last_price.toFixed(2)}
              </span>
              <div className={`flex items-center gap-1 ${isPositive ? 'text-green-500' : 'text-red-500'}`}>
                {isPositive ? <TrendingUp className="w-4 h-4" /> : <TrendingDown className="w-4 h-4" />}
                <span className="text-sm font-medium">
                  {isPositive ? '+' : ''}{marketStats.change_percent_24h.toFixed(2)}%
                </span>
              </div>
            </div>

            {/* Stats */}
            <div className="flex items-center gap-6 text-sm">
              <div>
                <span className="text-muted-foreground">24h High</span>
                <p className="font-mono text-green-500">{marketStats.high_24h.toFixed(2)}</p>
              </div>
              <div>
                <span className="text-muted-foreground">24h Low</span>
                <p className="font-mono text-red-500">{marketStats.low_24h.toFixed(2)}</p>
              </div>
              <div>
                <span className="text-muted-foreground">Bid</span>
                <p className="font-mono text-green-500">{marketStats.best_bid?.toFixed(2) || '-'}</p>
              </div>
              <div>
                <span className="text-muted-foreground">Ask</span>
                <p className="font-mono text-red-500">{marketStats.best_ask?.toFixed(2) || '-'}</p>
              </div>
              <div>
                <span className="text-muted-foreground">Spread</span>
                <p className="font-mono">{spread.toFixed(2)} ({spreadPercent.toFixed(2)}%)</p>
              </div>
              <div>
                <span className="text-muted-foreground">24h Volume</span>
                <p className="font-mono">{marketStats.volume_24h.toFixed(2)} STC</p>
              </div>
              <div>
                <span className="text-muted-foreground">24h Trades</span>
                <p className="font-mono">{marketStats.trades_24h}</p>
              </div>
            </div>
          </div>
          {lastUpdate && (
            <p className="text-xs text-muted-foreground mt-1">
              Last updated: {lastUpdate.toLocaleTimeString()}
            </p>
          )}
        </div>
      </div>

      {/* User Balances Bar */}
      {user && (
        <div className="bg-gradient-to-r from-amber-500/5 to-purple-500/5 border-b">
          <div className="max-w-7xl mx-auto px-4 py-2">
            <div className="flex items-center gap-6 text-sm">
              <div className="flex items-center gap-2">
                <Wallet className="w-4 h-4 text-muted-foreground" />
                <span className="text-muted-foreground">Your Balances:</span>
              </div>
              <div>
                <span className="text-muted-foreground">STC:</span>
                <span className="font-mono ml-1">{userBalances.stc_balance.toFixed(4)}</span>
                <span className="text-xs text-muted-foreground ml-1">({userBalances.stc_available.toFixed(4)} available)</span>
              </div>
              <div>
                <span className="text-muted-foreground">Coins:</span>
                <span className="font-mono ml-1">{userBalances.coins_balance.toLocaleString()}</span>
                <span className="text-xs text-muted-foreground ml-1">({userBalances.coins_available.toLocaleString()} available)</span>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Main Content with Tabs */}
      <div className="p-4 lg:p-6">
        <div className="max-w-7xl mx-auto">
          <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
            <TabsList className="grid w-full max-w-lg grid-cols-4">
              <TabsTrigger value="trading" className="gap-2">
                <LineChart className="w-4 h-4" />
                Trading
              </TabsTrigger>
              <TabsTrigger value="bots" className="gap-2">
                <Bot className="w-4 h-4" />
                Bots
              </TabsTrigger>
              <TabsTrigger value="backtest" className="gap-2">
                <History className="w-4 h-4" />
                Backtest
              </TabsTrigger>
              <TabsTrigger value="api" className="gap-2">
                <Key className="w-4 h-4" />
                API
              </TabsTrigger>
            </TabsList>


            {/* Trading Tab */}
            <TabsContent value="trading" className="space-y-6">
              {/* Info Banner */}
              <Card className="bg-gradient-to-r from-amber-500/10 to-orange-500/10 border-amber-500/20">
                <CardContent className="py-4">
                  <div className="flex items-start gap-3">
                    <Info className="w-5 h-5 text-amber-500 flex-shrink-0 mt-0.5" />
                    <div>
                      <h3 className="font-semibold text-amber-500">Welcome to STC Trading</h3>
                      <p className="text-sm text-muted-foreground">
                        Trade StreamCoin (STC) with other users using limit or market orders. 
                        Click on prices in the order book or chart to quickly set your order price.
                        Trading fee is 0.5% per trade. {liveUpdates ? 'Real-time updates are enabled.' : 'Real-time updates are paused.'}
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <div className="grid lg:grid-cols-4 gap-6">
                {/* Left Column - Chart & Trade History */}
                <div className="lg:col-span-3 space-y-6">
                  {/* Price Chart */}
                  <PriceChart onPriceSelect={handlePriceSelect} />

                  {/* Bottom Row - Order Book & Trade History */}
                  <div className="grid md:grid-cols-2 gap-6">
                    <OrderBook onPriceSelect={handlePriceSelect} />
                    <TradeHistory userId={userId} />
                  </div>
                </div>

                {/* Right Column - Trading Interface & Orders */}
                <div className="space-y-6">
                  <TradingInterface 
                    userId={userId} 
                    selectedPrice={selectedPrice}
                    onOrderPlaced={handleOrderPlaced}
                  />
                  <OpenOrders userId={userId} refreshTrigger={refreshTrigger} />
                </div>
              </div>

              {/* Trading Info */}
              <div className="grid md:grid-cols-3 gap-6">
                <Card className="bg-card/50 backdrop-blur border-border/50">
                  <CardContent className="pt-6">
                    <div className="flex items-center gap-3 mb-3">
                      <div className="w-10 h-10 rounded-full bg-green-500/10 flex items-center justify-center">
                        <TrendingUp className="w-5 h-5 text-green-500" />
                      </div>
                      <h3 className="font-semibold">Limit Orders</h3>
                    </div>
                    <p className="text-sm text-muted-foreground">
                      Set your own price and wait for the market to match. Your order stays open until filled or cancelled.
                    </p>
                  </CardContent>
                </Card>

                <Card className="bg-card/50 backdrop-blur border-border/50">
                  <CardContent className="pt-6">
                    <div className="flex items-center gap-3 mb-3">
                      <div className="w-10 h-10 rounded-full bg-blue-500/10 flex items-center justify-center">
                        <Activity className="w-5 h-5 text-blue-500" />
                      </div>
                      <h3 className="font-semibold">Market Orders</h3>
                    </div>
                    <p className="text-sm text-muted-foreground">
                      Execute immediately at the best available price. Perfect for quick trades when you need instant execution.
                    </p>
                  </CardContent>
                </Card>

                <Card className="bg-card/50 backdrop-blur border-border/50">
                  <CardContent className="pt-6">
                    <div className="flex items-center gap-3 mb-3">
                      <div className="w-10 h-10 rounded-full bg-amber-500/10 flex items-center justify-center">
                        <Coins className="w-5 h-5 text-amber-500" />
                      </div>
                      <h3 className="font-semibold">Low Fees</h3>
                    </div>
                    <p className="text-sm text-muted-foreground">
                      Only 0.5% trading fee per transaction. Fees are split between buyer and seller (0.25% each).
                    </p>
                  </CardContent>
                </Card>
              </div>
            </TabsContent>

            {/* Trading Bots Tab */}
            <TabsContent value="bots">
              <TradingBotPanel userId={userId} />
            </TabsContent>

            {/* Backtesting Tab */}
            <TabsContent value="backtest">
              <BacktestingPanel userId={userId} />
            </TabsContent>

            {/* API Keys Tab */}
            <TabsContent value="api">
              <APIKeyManager userId={userId} />
            </TabsContent>
          </Tabs>

        </div>
      </div>
    </div>
  );
}
