import React, { useState } from 'react';
import { Link, useNavigate, useSearchParams } from 'react-router-dom';
import { useAuth } from '@/contexts/AuthContext';
import { useToast } from '@/hooks/use-toast';
import { Eye, EyeOff, Mail, Lock, User, CheckCircle, Loader2, Phone, Hash, QrCode, Share2, Smartphone, MessageSquare } from 'lucide-react';
import { QRCodeDisplay } from '@/components/qr/QRCodeDisplay';
import { SendSignInSMS } from '@/components/phone/SendSignInSMS';

export default function SignupPage() {
  const [searchParams] = useSearchParams();
  const referralId = searchParams.get('ref');
  
  const [email, setEmail] = useState('');
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const [success, setSuccess] = useState(false);
  const [assignedPhone, setAssignedPhone] = useState('');
  const [assignedId, setAssignedId] = useState<number | null>(null);
  const [showQR, setShowQR] = useState(false);
  const [showSMSModal, setShowSMSModal] = useState(false);
  const [signedUpUserId, setSignedUpUserId] = useState('');
  const { signUp } = useAuth();
  const { toast } = useToast();
  const navigate = useNavigate();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setSuccess(false);
    
    if (password !== confirmPassword) {
      setError('Passwords do not match');
      return;
    }
    if (password.length < 6) {
      setError('Password must be at least 6 characters');
      return;
    }
    if (username.length < 3) {
      setError('Username must be at least 3 characters');
      return;
    }
    if (!/^[a-zA-Z0-9_]+$/.test(username)) {
      setError('Username can only contain letters, numbers, and underscores');
      return;
    }
    
    setLoading(true);
    console.log('Submitting signup form...');
    
    const result = await signUp(email, password, username);
    
    setLoading(false);
    
    if (result.error) {
      console.error('Signup failed:', result.error);
      setError(result.error);
      toast({
        title: "Signup Failed",
        description: result.error,
        variant: "destructive",
      });
    } else if (result.success) {
      console.log('Signup successful!');
      setSuccess(true);
      
      const storedUser = localStorage.getItem('assigned_user');
      if (storedUser) {
        const userData = JSON.parse(storedUser);
        setAssignedPhone(userData.phone_number || '');
        setAssignedId(userData.unique_id || null);
        setSignedUpUserId(userData.user_id || '');
      }
      
      toast({
        title: "Account Created!",
        description: `Welcome to Assigned, ${username}! Your profile has been created successfully.`,
      });
      
      // Extended redirect to give time for SMS sending
      setTimeout(() => {
        navigate('/');
      }, 15000);
    }
  };

  const formatPhoneNumber = (phone: string) => {
    const cleaned = phone.replace(/\D/g, '');
    if (cleaned.length === 11 && cleaned.startsWith('1')) {
      return `+1 (${cleaned.slice(1, 4)}) ${cleaned.slice(4, 7)}-${cleaned.slice(7)}`;
    }
    if (cleaned.length === 10) {
      return `(${cleaned.slice(0, 3)}) ${cleaned.slice(3, 6)}-${cleaned.slice(6)}`;
    }
    return phone;
  };

  const signupUrl = window.location.origin + '/signup';

  return (
    <div className="min-h-screen bg-[#1a1a2e] flex items-center justify-center px-4 py-8">
      <div className="w-full max-w-lg">
        <div className="text-center mb-8">
          <Link to="/" className="text-4xl font-bold bg-gradient-to-r from-purple-500 to-pink-500 bg-clip-text text-transparent">
            Assigned
          </Link>
          <p className="text-gray-400 mt-2">Create your account to start streaming</p>
        </div>

        {/* Referral Banner */}
        {referralId && (
          <div className="bg-gradient-to-r from-cyan-500/10 to-blue-500/10 rounded-xl p-4 mb-4 border border-cyan-500/20">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-full bg-cyan-500/20 flex items-center justify-center flex-shrink-0">
                <User className="w-5 h-5 text-cyan-400" />
              </div>
              <div>
                <p className="text-cyan-300 text-sm font-medium">Referred by User #{referralId}</p>
                <p className="text-gray-400 text-xs">You were invited to join Assigned!</p>
              </div>
            </div>
          </div>
        )}

        <div className="bg-[#16213e] rounded-2xl p-8 border border-gray-800">
          {success ? (
            <div className="text-center py-4">
              <div className="w-20 h-20 bg-green-500/20 rounded-full flex items-center justify-center mx-auto mb-4">
                <CheckCircle className="w-12 h-12 text-green-500" />
              </div>
              <h2 className="text-2xl font-bold text-white mb-2">Account Created!</h2>
              <p className="text-gray-400 mb-6">
                Welcome to Assigned, <span className="text-purple-400 font-semibold">{username}</span>!
              </p>
              
              {/* Display assigned credentials */}
              <div className="space-y-4 mb-6">
                {assignedId && (
                  <div className="bg-gradient-to-r from-purple-500/20 to-pink-500/20 rounded-xl p-4 border border-purple-500/30">
                    <div className="flex items-center justify-center gap-2 mb-2">
                      <Hash className="w-5 h-5 text-purple-400" />
                      <span className="text-gray-300 text-sm">Your Unique ID</span>
                    </div>
                    <p className="text-2xl font-mono font-bold text-purple-400">{assignedId}</p>
                  </div>
                )}
                
                {assignedPhone && (
                  <div className="bg-gradient-to-r from-green-500/20 to-emerald-500/20 rounded-xl p-4 border border-green-500/30">
                    <div className="flex items-center justify-center gap-2 mb-2">
                      <Phone className="w-5 h-5 text-green-400" />
                      <span className="text-gray-300 text-sm">Your Phone Number</span>
                    </div>
                    <p className="text-xl font-mono font-bold text-green-400">{formatPhoneNumber(assignedPhone)}</p>
                  </div>
                )}
              </div>

              {/* SMS Sign-In Info Button - Prominent CTA */}
              <div className="mb-6">
                <div className="bg-gradient-to-r from-green-500/10 to-emerald-500/10 rounded-xl p-5 border border-green-500/20">
                  <div className="flex items-center justify-center gap-2 mb-3">
                    <Smartphone className="w-5 h-5 text-green-400" />
                    <span className="text-green-300 font-medium text-sm">Save Your Sign-In Info</span>
                  </div>
                  <p className="text-gray-400 text-xs mb-4">
                    Send your account credentials to your phone via SMS so you never lose access to your account.
                  </p>
                  <button
                    onClick={() => setShowSMSModal(true)}
                    className="w-full bg-gradient-to-r from-green-600 to-emerald-600 text-white py-3 rounded-xl font-semibold hover:shadow-lg hover:shadow-green-500/30 transition-all flex items-center justify-center gap-2"
                  >
                    <MessageSquare className="w-5 h-5" />
                    Text Me My Sign-In Info
                  </button>
                </div>
              </div>

              {/* Share QR Code after signup */}
              {assignedId && (
                <div className="mb-6">
                  <button
                    onClick={() => setShowQR(!showQR)}
                    className="flex items-center gap-2 mx-auto px-4 py-2 rounded-lg bg-purple-600/20 text-purple-400 hover:bg-purple-600/30 transition-colors text-sm font-medium"
                  >
                    <QrCode className="w-4 h-4" />
                    {showQR ? 'Hide' : 'Show'} Your Referral QR Code
                  </button>
                  {showQR && (
                    <div className="mt-4">
                      <QRCodeDisplay
                        url={`${window.location.origin}/signup?ref=${assignedId}`}
                        size={180}
                        label="Share this QR code to invite friends"
                        logoText="Assigned"
                      />
                    </div>
                  )}
                </div>
              )}
              
              <p className="text-gray-500 text-sm">Redirecting you to the homepage...</p>
              <div className="mt-4 flex items-center justify-center gap-3">
                <Loader2 className="w-5 h-5 text-purple-500 animate-spin" />
                <button
                  onClick={() => navigate('/')}
                  className="text-purple-400 hover:text-purple-300 text-sm underline transition-colors"
                >
                  Go now
                </button>
              </div>
            </div>
          ) : (
            <>
              <h2 className="text-2xl font-bold text-white mb-6">Create Account</h2>
              
              {error && (
                <div className="bg-red-500/20 border border-red-500 text-red-400 px-4 py-3 rounded-lg mb-4">
                  {error}
                </div>
              )}

              {/* Info banner about phone assignment */}
              <div className="bg-gradient-to-r from-purple-500/10 to-pink-500/10 rounded-lg p-4 mb-6 border border-purple-500/20">
                <div className="flex items-start gap-3">
                  <div className="flex-shrink-0">
                    <Phone className="w-5 h-5 text-purple-400 mt-0.5" />
                  </div>
                  <div>
                    <p className="text-purple-300 text-sm font-medium">Phone Number Assignment</p>
                    <p className="text-gray-400 text-xs mt-1">
                      When you create an account, you'll be assigned a unique phone number and ID for messaging and calls.
                    </p>
                  </div>
                </div>
              </div>

              {/* SMS delivery info */}
              <div className="bg-gradient-to-r from-green-500/10 to-emerald-500/10 rounded-lg p-4 mb-6 border border-green-500/20">
                <div className="flex items-start gap-3">
                  <div className="flex-shrink-0">
                    <Smartphone className="w-5 h-5 text-green-400 mt-0.5" />
                  </div>
                  <div>
                    <p className="text-green-300 text-sm font-medium">SMS Sign-In Delivery</p>
                    <p className="text-gray-400 text-xs mt-1">
                      After creating your account, you can have your sign-in credentials sent to your phone via text message for safekeeping.
                    </p>
                  </div>
                </div>
              </div>

              <form onSubmit={handleSubmit} className="space-y-4">
                <div>
                  <label className="text-gray-300 text-sm mb-2 block">Username</label>
                  <div className="relative">
                    <User className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-500" />
                    <input
                      type="text"
                      value={username}
                      onChange={(e) => setUsername(e.target.value)}
                      className="w-full bg-[#1a1a2e] text-white pl-11 pr-4 py-3 rounded-lg border border-gray-700 focus:border-purple-500 focus:outline-none transition-colors"
                      placeholder="Choose username"
                      required
                      disabled={loading}
                    />
                  </div>
                  <p className="text-gray-500 text-xs mt-1">Letters, numbers, and underscores only</p>
                </div>

                <div>
                  <label className="text-gray-300 text-sm mb-2 block">Email</label>
                  <div className="relative">
                    <Mail className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-500" />
                    <input
                      type="email"
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      className="w-full bg-[#1a1a2e] text-white pl-11 pr-4 py-3 rounded-lg border border-gray-700 focus:border-purple-500 focus:outline-none transition-colors"
                      placeholder="your@email.com"
                      required
                      disabled={loading}
                    />
                  </div>
                </div>

                <div>
                  <label className="text-gray-300 text-sm mb-2 block">Password</label>
                  <div className="relative">
                    <Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-500" />
                    <input
                      type={showPassword ? 'text' : 'password'}
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      className="w-full bg-[#1a1a2e] text-white pl-11 pr-11 py-3 rounded-lg border border-gray-700 focus:border-purple-500 focus:outline-none transition-colors"
                      placeholder="Create password"
                      required
                      disabled={loading}
                    />
                    <button
                      type="button"
                      onClick={() => setShowPassword(!showPassword)}
                      className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-500 hover:text-gray-300 transition-colors"
                      disabled={loading}
                    >
                      {showPassword ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
                    </button>
                  </div>
                  <p className="text-gray-500 text-xs mt-1">Minimum 6 characters</p>
                </div>

                <div>
                  <label className="text-gray-300 text-sm mb-2 block">Confirm Password</label>
                  <div className="relative">
                    <Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-500" />
                    <input
                      type="password"
                      value={confirmPassword}
                      onChange={(e) => setConfirmPassword(e.target.value)}
                      className="w-full bg-[#1a1a2e] text-white pl-11 pr-4 py-3 rounded-lg border border-gray-700 focus:border-purple-500 focus:outline-none transition-colors"
                      placeholder="Confirm password"
                      required
                      disabled={loading}
                    />
                  </div>
                </div>

                <button
                  type="submit"
                  disabled={loading}
                  className="w-full bg-gradient-to-r from-purple-600 to-pink-600 text-white py-3 rounded-lg font-semibold hover:shadow-lg hover:shadow-purple-500/50 transition-all disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2"
                >
                  {loading ? (
                    <>
                      <Loader2 className="w-5 h-5 animate-spin" />
                      Creating account...
                    </>
                  ) : (
                    'Create Account'
                  )}
                </button>
              </form>

              <div className="mt-6 pt-6 border-t border-gray-700">
                <p className="text-gray-500 text-xs text-center mb-4">
                  By creating an account, you agree to our Terms of Service and Privacy Policy
                </p>
              </div>

              <p className="text-gray-400 text-center">
                Already have an account?{' '}
                <Link to="/login" className="text-purple-400 hover:text-purple-300 transition-colors">
                  Sign in
                </Link>
              </p>
            </>
          )}
        </div>

        {/* QR Code Section below the form */}
        <div className="mt-6 bg-[#16213e] rounded-2xl p-6 border border-gray-800">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-3">
              <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-purple-500 to-pink-500 flex items-center justify-center">
                <QrCode className="w-4 h-4 text-white" />
              </div>
              <div>
                <h3 className="text-white font-semibold text-sm">Scan to Sign Up</h3>
                <p className="text-gray-400 text-xs">Share this QR code with friends</p>
              </div>
            </div>
            <button
              onClick={() => setShowQR(!showQR)}
              className="text-purple-400 hover:text-purple-300 text-sm font-medium transition-colors"
            >
              {showQR ? 'Hide' : 'Show QR'}
            </button>
          </div>
          
          {showQR && (
            <div className="pt-4 border-t border-gray-700">
              <QRCodeDisplay
                url={signupUrl}
                size={180}
                label="Scan with your phone camera to sign up"
                logoText="Assigned"
              />
            </div>
          )}

          {!showQR && (
            <div className="flex items-center gap-3 text-gray-400 text-xs">
              <Share2 className="w-4 h-4" />
              <span>Click "Show QR" to generate a scannable signup QR code</span>
            </div>
          )}
        </div>
      </div>

      {/* SMS Sign-In Modal */}
      <SendSignInSMS
        isOpen={showSMSModal}
        onClose={() => setShowSMSModal(false)}
        prefillData={{
          username: username,
          email: email,
          unique_id: assignedId || undefined,
          phone_number: assignedPhone || undefined,
          user_id: signedUpUserId
        }}
      />
    </div>
  );
}
