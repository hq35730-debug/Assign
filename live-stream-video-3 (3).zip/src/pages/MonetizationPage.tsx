import React, { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '@/contexts/AuthContext';
import { supabase } from '@/lib/supabase';
import { ArrowLeft, DollarSign, TrendingUp, Star, MessageSquare, Ticket, Target, ShoppingBag, Play, Handshake, Wallet, Loader2, Rocket } from 'lucide-react';
import { SubscriptionTiers } from '@/components/monetization/SubscriptionTiers';
import { SuperChatSettings } from '@/components/monetization/SuperChatSettings';
import { PPVManager } from '@/components/monetization/PPVManager';
import { TipGoals } from '@/components/monetization/TipGoals';
import { MerchStore } from '@/components/monetization/MerchStore';
import { AdRevenuePanel } from '@/components/monetization/AdRevenuePanel';
import { SponsorshipTracker } from '@/components/monetization/SponsorshipTracker';
import { PromotionDashboard } from '@/components/promotions/PromotionDashboard';

type Tab = 'overview' | 'subscriptions' | 'superchats' | 'ppv' | 'goals' | 'merch' | 'ads' | 'sponsors' | 'promotions';


export default function MonetizationPage() {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [activeTab, setActiveTab] = useState<Tab>('overview');
  const [stats, setStats] = useState({ total: 0, subscriptions: 0, tips: 0, gifts: 0, ppv: 0, ads: 0, merch: 0, sponsors: 0 });
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!user) { navigate('/login'); return; }
    loadStats();
  }, [user]);

  const loadStats = async () => {
    if (!user) return;
    setLoading(true);
    const { data } = await supabase.functions.invoke('monetization-manager', {
      body: { action: 'get_overview', streamer_id: user.user_id }
    });
    if (data) setStats(data);
    setLoading(false);
  };

  if (!user) return null;

  const tabs = [
    { id: 'overview', label: 'Overview', icon: TrendingUp },
    { id: 'subscriptions', label: 'Subscriptions', icon: Star },
    { id: 'superchats', label: 'Super Chats', icon: MessageSquare },
    { id: 'ppv', label: 'Pay-Per-View', icon: Ticket },
    { id: 'goals', label: 'Tip Goals', icon: Target },
    { id: 'merch', label: 'Merchandise', icon: ShoppingBag },
    { id: 'ads', label: 'Ad Revenue', icon: Play },
    { id: 'sponsors', label: 'Sponsors', icon: Handshake },
    { id: 'promotions', label: 'Promotions', icon: Rocket },
  ];


  const revenueCards = [
    { label: 'Subscriptions', value: stats.subscriptions, icon: Star, color: 'from-purple-500 to-pink-500' },
    { label: 'Tips & Donations', value: stats.tips, icon: DollarSign, color: 'from-yellow-500 to-orange-500' },
    { label: 'Gifts', value: stats.gifts, icon: Target, color: 'from-pink-500 to-red-500' },
    { label: 'PPV Events', value: stats.ppv, icon: Ticket, color: 'from-blue-500 to-cyan-500' },
    { label: 'Ad Revenue', value: stats.ads, icon: Play, color: 'from-green-500 to-emerald-500' },
    { label: 'Merchandise', value: stats.merch, icon: ShoppingBag, color: 'from-indigo-500 to-purple-500' },
    { label: 'Sponsorships', value: stats.sponsors, icon: Handshake, color: 'from-cyan-500 to-teal-500' },
  ];

  return (
    <div className="min-h-screen bg-[#1a1a2e]">
      <header className="bg-[#16213e] border-b border-gray-800 sticky top-0 z-40">
        <div className="max-w-6xl mx-auto px-4 py-4 flex items-center gap-4">
          <Link to="/profile" className="text-gray-400 hover:text-white"><ArrowLeft className="w-6 h-6" /></Link>
          <h1 className="text-xl font-bold bg-gradient-to-r from-green-400 to-emerald-500 bg-clip-text text-transparent flex items-center gap-2">
            <DollarSign className="w-5 h-5 text-green-400" /> Monetization Hub
          </h1>
          <Link to="/earnings" className="ml-auto bg-green-600 hover:bg-green-700 text-white px-4 py-2 rounded-lg flex items-center gap-2 text-sm">
            <Wallet className="w-4 h-4" /> Withdraw
          </Link>
        </div>
      </header>

      <div className="max-w-6xl mx-auto px-4 py-6">
        <div className="flex gap-2 overflow-x-auto pb-4 mb-6">
          {tabs.map(tab => (
            <button key={tab.id} onClick={() => setActiveTab(tab.id as Tab)} className={`flex items-center gap-2 px-4 py-2 rounded-lg whitespace-nowrap transition-colors ${activeTab === tab.id ? 'bg-purple-600 text-white' : 'bg-[#16213e] text-gray-400 hover:text-white'}`}>
              <tab.icon className="w-4 h-4" /> {tab.label}
            </button>
          ))}
        </div>

        {activeTab === 'overview' && (
          <div className="space-y-6">
            <div className="bg-gradient-to-r from-green-600 to-emerald-600 rounded-2xl p-6">
              <p className="text-green-100 text-sm mb-1">Total Lifetime Earnings</p>
              <p className="text-4xl font-bold text-white">${(stats.total / 100).toFixed(2)}</p>
            </div>

            {loading ? (
              <div className="flex justify-center py-12"><Loader2 className="w-8 h-8 animate-spin text-purple-400" /></div>
            ) : (
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                {revenueCards.map(card => (
                  <div key={card.label} className="bg-[#16213e] rounded-xl p-4 border border-gray-800">
                    <div className={`w-10 h-10 rounded-lg bg-gradient-to-br ${card.color} flex items-center justify-center mb-3`}>
                      <card.icon className="w-5 h-5 text-white" />
                    </div>
                    <p className="text-2xl font-bold text-white">${(card.value / 100).toFixed(2)}</p>
                    <p className="text-gray-400 text-sm">{card.label}</p>
                  </div>
                ))}
              </div>
            )}

            <div className="bg-[#16213e] rounded-2xl p-6 border border-gray-800">
              <h3 className="text-lg font-bold text-white mb-4">Quick Actions</h3>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                <button onClick={() => setActiveTab('subscriptions')} className="p-4 bg-[#1a1a2e] rounded-xl hover:bg-purple-600/20 transition-colors text-left">
                  <Star className="w-6 h-6 text-purple-400 mb-2" />
                  <p className="text-white font-medium">Manage Tiers</p>
                  <p className="text-gray-400 text-xs">Set subscription prices</p>
                </button>
                <button onClick={() => setActiveTab('ppv')} className="p-4 bg-[#1a1a2e] rounded-xl hover:bg-pink-600/20 transition-colors text-left">
                  <Ticket className="w-6 h-6 text-pink-400 mb-2" />
                  <p className="text-white font-medium">Create PPV</p>
                  <p className="text-gray-400 text-xs">Exclusive paid events</p>
                </button>
                <button onClick={() => setActiveTab('goals')} className="p-4 bg-[#1a1a2e] rounded-xl hover:bg-orange-600/20 transition-colors text-left">
                  <Target className="w-6 h-6 text-orange-400 mb-2" />
                  <p className="text-white font-medium">Set Goals</p>
                  <p className="text-gray-400 text-xs">Motivate your viewers</p>
                </button>
                <button onClick={() => setActiveTab('merch')} className="p-4 bg-[#1a1a2e] rounded-xl hover:bg-blue-600/20 transition-colors text-left">
                  <ShoppingBag className="w-6 h-6 text-blue-400 mb-2" />
                  <p className="text-white font-medium">Add Merch</p>
                  <p className="text-gray-400 text-xs">Sell your products</p>
                </button>
              </div>
            </div>
          </div>
        )}

        {activeTab === 'subscriptions' && <SubscriptionTiers userId={user.user_id} />}
        {activeTab === 'superchats' && <SuperChatSettings userId={user.user_id} />}
        {activeTab === 'ppv' && <PPVManager userId={user.user_id} />}
        {activeTab === 'goals' && <TipGoals userId={user.user_id} />}
        {activeTab === 'merch' && <MerchStore userId={user.user_id} />}
        {activeTab === 'ads' && <AdRevenuePanel userId={user.user_id} />}
        {activeTab === 'sponsors' && <SponsorshipTracker userId={user.user_id} />}
        {activeTab === 'promotions' && <PromotionDashboard />}
      </div>

    </div>
  );
}
