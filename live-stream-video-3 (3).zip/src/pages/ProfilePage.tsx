import React, { useState, useEffect } from 'react';
import { useParams, useNavigate, Link } from 'react-router-dom';
import { useAuth, UserProfile } from '@/contexts/AuthContext';
import { supabase } from '@/lib/supabase';
import ProfileHeader from '@/components/ProfileHeader';
import { SubscribeButton } from '@/components/SubscribeButton';
import { DonationLeaderboard } from '@/components/DonationLeaderboard';
import { ClipCard } from '@/components/ClipCard';
import { ClipModal } from '@/components/ClipModal';
import { VODCard, VOD } from '@/components/VODCard';
import { VODPlayer } from '@/components/VODPlayer';
import { VODEditModal } from '@/components/VODEditModal';
import { PointsLeaderboard } from '@/components/PointsLeaderboard';
import { RewardCreator } from '@/components/RewardCreator';
import { HostModePanel } from '@/components/HostModePanel';
import { AutoHostSettings } from '@/components/AutoHostSettings';
import { ScheduleCreator } from '@/components/ScheduleCreator';
import { ScheduleCalendar } from '@/components/ScheduleCalendar';
import { StoryHighlights } from '@/components/stories/StoryHighlights';
import { PhoneCapabilities } from '@/components/phone/PhoneCapabilities';
import { SendSignInSMS } from '@/components/phone/SendSignInSMS';
import { SignupQRModal } from '@/components/qr/SignupQRModal';
import { QRCodeDisplay } from '@/components/qr/QRCodeDisplay';
import { ArrowLeft, Clock, Settings, History, Radio, Users, Star, Trophy, Wallet, Scissors, Video, Sparkles, Plus, Gift, Zap, Monitor, Calendar, DollarSign, Phone, Hash, QrCode, Smartphone } from 'lucide-react';


import { Button } from '@/components/ui/button';



interface StreamHistory { id: string; stream_id: string; streamer_name: string; stream_title: string; stream_thumbnail: string; watched_at: string; }
interface BroadcastHistory { id: string; title: string; category: string; viewer_count: number; started_at: string; ended_at: string; thumbnail_url: string; is_live?: boolean; }
interface Subscription { id: string; subscriber_id: string; streamer_id: string; status: string; started_at: string; }
interface Clip { id: string; title: string; streamer_name: string; creator_name: string; thumbnail_url: string; video_url: string; duration: number; views: number; likes: number; shares: number; created_at: string; }
interface Raid { id: string; raider_id: string; raider_name: string; target_id: string; target_name: string; viewer_count: number; created_at: string; }

export default function ProfilePage() {
  const { username } = useParams();
  const { user } = useAuth();
  const navigate = useNavigate();
  const [profile, setProfile] = useState<UserProfile | null>(null);
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState<'history' | 'broadcasts' | 'clips' | 'vods' | 'raids' | 'subscribers' | 'rewards' | 'schedule' | 'settings'>('history');
  const [showScheduleCreator, setShowScheduleCreator] = useState(false);
  const [editingSchedule, setEditingSchedule] = useState<any>(null);
  const [showPhoneCapabilities, setShowPhoneCapabilities] = useState(false);
  const [showQRModal, setShowQRModal] = useState(false);
  const [showProfileQR, setShowProfileQR] = useState(false);
  const [showSMSSignIn, setShowSMSSignIn] = useState(false);


  const [history, setHistory] = useState<StreamHistory[]>([]);
  const [broadcasts, setBroadcasts] = useState<BroadcastHistory[]>([]);
  const [followers, setFollowers] = useState<string[]>([]);
  const [following, setFollowing] = useState<string[]>([]);
  const [isFollowing, setIsFollowing] = useState(false);
  const [subscribers, setSubscribers] = useState<Subscription[]>([]);
  const [subCount, setSubCount] = useState(0);
  const [scheduleKey, setScheduleKey] = useState(0);

  const isOwnProfile = user?.username === username || (!username && !!user);
  const targetUsername = username || user?.username;

  useEffect(() => {
    if (!targetUsername) { navigate('/login'); return; }
    loadProfile();
  }, [targetUsername]);

  const loadProfile = async () => {
    setLoading(true);
    const { data: profileData } = await supabase.from('profiles').select('*').eq('username', targetUsername).single();
    if (profileData) {
      setProfile(profileData);
      const { data: historyData } = await supabase.from('streaming_history').select('*').eq('user_id', profileData.user_id).order('watched_at', { ascending: false }).limit(20);
      setHistory(historyData || []);
      const { data: broadcastData } = await supabase.from('live_streams').select('*').eq('user_id', profileData.user_id).order('started_at', { ascending: false }).limit(20);
      setBroadcasts(broadcastData || []);
      const { data: followersData } = await supabase.from('followers').select('follower_id').eq('following_id', profileData.user_id);
      const { data: followingData } = await supabase.from('followers').select('following_id').eq('follower_id', profileData.user_id);
      setFollowers(followersData?.map(f => f.follower_id) || []);
      setFollowing(followingData?.map(f => f.following_id) || []);
      if (user) setIsFollowing(followersData?.some(f => f.follower_id === user.user_id) || false);
      const { data: subData } = await supabase.functions.invoke('subscription-manager', { body: { action: 'get_subscribers', streamer_id: profileData.user_id } });
      setSubscribers(subData?.subscribers || []);
      setSubCount(subData?.count || 0);
    }
    setLoading(false);
  };


  const handleFollow = async () => {
    if (!user || !profile) return;
    if (isFollowing) {
      await supabase.from('followers').delete().eq('follower_id', user.user_id).eq('following_id', profile.user_id);
      setIsFollowing(false);
      setFollowers(prev => prev.filter(id => id !== user.user_id));
    } else {
      await supabase.from('followers').insert({ follower_id: user.user_id, following_id: profile.user_id });
      setIsFollowing(true);
      setFollowers(prev => [...prev, user.user_id]);
    }
  };

  if (loading) return <div className="min-h-screen bg-[#1a1a2e] flex items-center justify-center"><div className="text-purple-400 text-xl">Loading...</div></div>;
  if (!profile) return <div className="min-h-screen bg-[#1a1a2e] flex items-center justify-center"><div className="text-gray-400 text-xl">Profile not found</div></div>;

  return (
    <div className="min-h-screen bg-[#1a1a2e]">
      <header className="bg-[#16213e] border-b border-gray-800 sticky top-0 z-40">
        <div className="max-w-4xl mx-auto px-4 py-4 flex items-center gap-4">
          <Link to="/" className="text-gray-400 hover:text-white"><ArrowLeft className="w-6 h-6" /></Link>
          <h1 className="text-xl font-bold bg-gradient-to-r from-purple-500 to-pink-500 bg-clip-text text-transparent">Profile</h1>
        </div>
      </header>

      <div className="max-w-4xl mx-auto px-4 py-8 space-y-6">
        <ProfileHeader profile={profile} isOwnProfile={isOwnProfile} followersCount={followers.length} followingCount={following.length} isFollowing={isFollowing} onFollow={handleFollow} />
        
        {/* Story Highlights Section */}
        <StoryHighlights userId={profile.user_id} isOwnProfile={isOwnProfile} />

        {!isOwnProfile && profile && (
          <div className="flex items-center gap-4">
            <SubscribeButton streamerId={profile.user_id} streamerName={profile.display_name || profile.username} />
            <span className="text-purple-400 text-sm"><Star className="w-4 h-4 inline mr-1" />{subCount} subscribers</span>
          </div>
        )}

        {isOwnProfile && (
          <div className="flex gap-3 flex-wrap">
            <Link to="/monetization" className="flex items-center gap-3 bg-gradient-to-r from-yellow-500 to-orange-500 text-white px-6 py-3 rounded-xl font-semibold hover:shadow-lg hover:shadow-yellow-500/30 transition-all">
              <DollarSign className="w-5 h-5" /> Monetization
            </Link>
            <Link to="/earnings" className="flex items-center gap-3 bg-gradient-to-r from-green-600 to-emerald-600 text-white px-6 py-3 rounded-xl font-semibold hover:shadow-lg hover:shadow-green-500/30 transition-all">
              <Wallet className="w-5 h-5" /> Earnings
            </Link>
            <Link to="/analytics" className="flex items-center gap-3 bg-gradient-to-r from-purple-600 to-blue-600 text-white px-6 py-3 rounded-xl font-semibold hover:shadow-lg hover:shadow-purple-500/30 transition-all">
              <Trophy className="w-5 h-5" /> Analytics
            </Link>
            {user?.phone_number && (
              <button 
                onClick={() => setShowPhoneCapabilities(true)}
                className="flex items-center gap-3 bg-gradient-to-r from-cyan-600 to-teal-600 text-white px-6 py-3 rounded-xl font-semibold hover:shadow-lg hover:shadow-cyan-500/30 transition-all"
              >
                <Phone className="w-5 h-5" /> Phone
              </button>
            )}
            <button 
              onClick={() => setShowQRModal(true)}
              className="flex items-center gap-3 bg-gradient-to-r from-violet-600 to-indigo-600 text-white px-6 py-3 rounded-xl font-semibold hover:shadow-lg hover:shadow-violet-500/30 transition-all"
            >
              <QrCode className="w-5 h-5" /> QR Code
            </button>
            <button 
              onClick={() => setShowSMSSignIn(true)}
              className="flex items-center gap-3 bg-gradient-to-r from-green-600 to-emerald-600 text-white px-6 py-3 rounded-xl font-semibold hover:shadow-lg hover:shadow-green-500/30 transition-all"
            >
              <Smartphone className="w-5 h-5" /> Text Sign-In Info
            </button>
          </div>
        )}


        {/* Profile QR Code Section */}
        <div className="bg-[#16213e] rounded-2xl p-6 border border-gray-800">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-3">
              <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-purple-500 to-pink-500 flex items-center justify-center">
                <QrCode className="w-4 h-4 text-white" />
              </div>
              <div>
                <h3 className="text-white font-semibold">Profile QR Code</h3>
                <p className="text-gray-400 text-xs">Share this profile via QR code</p>
              </div>
            </div>
            <button
              onClick={() => setShowProfileQR(!showProfileQR)}
              className="text-purple-400 hover:text-purple-300 text-sm font-medium transition-colors px-3 py-1.5 rounded-lg hover:bg-purple-500/10"
            >
              {showProfileQR ? 'Hide' : 'Show QR'}
            </button>
          </div>
          {showProfileQR && (
            <div className="pt-4 border-t border-gray-700">
              <QRCodeDisplay
                url={`${window.location.origin}/profile/${profile.username}`}
                size={200}
                label={`@${profile.username}'s Profile`}
                logoText="Assigned"
              />
            </div>
          )}
        </div>




        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <DonationLeaderboard streamerId={profile.user_id} />
          <PointsLeaderboard channelId={profile.user_id} />
        </div>

        <div className="flex gap-2 border-b border-gray-800 pb-2 overflow-x-auto">
          <button onClick={() => setActiveTab('history')} className={`flex items-center gap-2 px-4 py-2 rounded-lg transition-colors whitespace-nowrap ${activeTab === 'history' ? 'bg-purple-600 text-white' : 'text-gray-400 hover:text-white'}`}><History className="w-4 h-4" /> History</button>
          <button onClick={() => setActiveTab('broadcasts')} className={`flex items-center gap-2 px-4 py-2 rounded-lg transition-colors whitespace-nowrap ${activeTab === 'broadcasts' ? 'bg-purple-600 text-white' : 'text-gray-400 hover:text-white'}`}><Radio className="w-4 h-4" /> Broadcasts</button>
          <button onClick={() => setActiveTab('schedule')} className={`flex items-center gap-2 px-4 py-2 rounded-lg transition-colors whitespace-nowrap ${activeTab === 'schedule' ? 'bg-purple-600 text-white' : 'text-gray-400 hover:text-white'}`}><Calendar className="w-4 h-4" /> Schedule</button>
          <button onClick={() => setActiveTab('vods')} className={`flex items-center gap-2 px-4 py-2 rounded-lg transition-colors whitespace-nowrap ${activeTab === 'vods' ? 'bg-purple-600 text-white' : 'text-gray-400 hover:text-white'}`}><Video className="w-4 h-4" /> VODs</button>
          <button onClick={() => setActiveTab('clips')} className={`flex items-center gap-2 px-4 py-2 rounded-lg transition-colors whitespace-nowrap ${activeTab === 'clips' ? 'bg-purple-600 text-white' : 'text-gray-400 hover:text-white'}`}><Scissors className="w-4 h-4" /> Clips</button>
          {isOwnProfile && (
            <>
              <button onClick={() => setActiveTab('subscribers')} className={`flex items-center gap-2 px-4 py-2 rounded-lg transition-colors whitespace-nowrap ${activeTab === 'subscribers' ? 'bg-purple-600 text-white' : 'text-gray-400 hover:text-white'}`}><Star className="w-4 h-4" /> Subscribers</button>
              <button onClick={() => setActiveTab('rewards')} className={`flex items-center gap-2 px-4 py-2 rounded-lg transition-colors whitespace-nowrap ${activeTab === 'rewards' ? 'bg-purple-600 text-white' : 'text-gray-400 hover:text-white'}`}><Gift className="w-4 h-4" /> Rewards</button>
              <button onClick={() => setActiveTab('settings')} className={`flex items-center gap-2 px-4 py-2 rounded-lg transition-colors whitespace-nowrap ${activeTab === 'settings' ? 'bg-purple-600 text-white' : 'text-gray-400 hover:text-white'}`}><Settings className="w-4 h-4" /> Settings</button>
            </>
          )}
        </div>

        {activeTab === 'schedule' && (
          <div className="space-y-4">
            {isOwnProfile && (
              <div className="flex justify-end">
                <Button onClick={() => setShowScheduleCreator(true)} className="bg-purple-600 hover:bg-purple-700">
                  <Plus className="w-4 h-4 mr-2" /> Schedule Stream
                </Button>
              </div>
            )}
            <ScheduleCalendar 
              key={scheduleKey} 
              channelId={profile.user_id} 
              isOwnProfile={isOwnProfile} 
              onEdit={(schedule) => { setEditingSchedule(schedule); setShowScheduleCreator(true); }} 
            />
            <ScheduleCreator 
              channelId={profile.user_id} 
              isOpen={showScheduleCreator} 
              onClose={() => { setShowScheduleCreator(false); setEditingSchedule(null); }} 
              onCreated={() => setScheduleKey(k => k + 1)} 
              editSchedule={editingSchedule} 
            />
          </div>
        )}

        {activeTab === 'vods' && <VODsTab userId={profile.user_id} isOwnProfile={isOwnProfile} />}
        {activeTab === 'clips' && <ClipsTab streamerId={profile.user_id} />}
        {activeTab === 'rewards' && isOwnProfile && <RewardsTab userId={profile.user_id} username={profile.display_name || profile.username} />}





        {activeTab === 'history' && (
          <div className="bg-[#16213e] rounded-2xl p-6 border border-gray-800">
            <h2 className="text-xl font-bold text-white mb-4 flex items-center gap-2"><Clock className="w-5 h-5 text-purple-400" /> Recent Streams Watched</h2>
            {history.length === 0 ? <p className="text-gray-400 text-center py-8">No watch history yet.</p> : (
              <div className="space-y-3">
                {history.map(item => (
                  <div key={item.id} className="flex gap-4 p-3 rounded-lg bg-[#1a1a2e] hover:bg-[#1f1f3a] transition-colors">
                    <div className="w-24 h-16 rounded-lg overflow-hidden bg-gray-800 flex-shrink-0">{item.stream_thumbnail && <img src={item.stream_thumbnail} alt="" className="w-full h-full object-cover" />}</div>
                    <div className="flex-1 min-w-0"><p className="text-white font-medium truncate">{item.stream_title}</p><p className="text-gray-400 text-sm">{item.streamer_name}</p><p className="text-gray-500 text-xs">{new Date(item.watched_at).toLocaleDateString()}</p></div>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {activeTab === 'broadcasts' && (
          <div className="bg-[#16213e] rounded-2xl p-6 border border-gray-800">
            <h2 className="text-xl font-bold text-white mb-4 flex items-center gap-2"><Radio className="w-5 h-5 text-red-400" /> Broadcast History</h2>
            {broadcasts.length === 0 ? <p className="text-gray-400 text-center py-8">No broadcasts yet.</p> : (
              <div className="space-y-3">
                {broadcasts.map(item => (
                  <div key={item.id} className="flex gap-4 p-3 rounded-lg bg-[#1a1a2e] hover:bg-[#1f1f3a] transition-colors">
                    <div className="w-24 h-16 rounded-lg overflow-hidden bg-gray-800 flex-shrink-0">{item.thumbnail_url ? <img src={item.thumbnail_url} alt="" className="w-full h-full object-cover" /> : <div className="w-full h-full flex items-center justify-center"><Radio className="w-6 h-6 text-gray-600" /></div>}</div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2"><p className="text-white font-medium truncate">{item.title}</p>{item.is_live && <span className="bg-red-600 text-white text-xs px-2 py-0.5 rounded">LIVE</span>}</div>
                      <p className="text-gray-400 text-sm">{item.category} • {item.viewer_count} peak viewers</p>
                      <p className="text-gray-500 text-xs">{new Date(item.started_at).toLocaleDateString()}</p>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {activeTab === 'subscribers' && isOwnProfile && (
          <div className="bg-[#16213e] rounded-2xl p-6 border border-gray-800">
            <h2 className="text-xl font-bold text-white mb-4 flex items-center gap-2"><Star className="w-5 h-5 text-purple-400" /> Your Subscribers ({subCount})</h2>
            {subscribers.length === 0 ? <p className="text-gray-400 text-center py-8">No subscribers yet. Go live and grow your community!</p> : (
              <div className="space-y-3">
                {subscribers.map(sub => (
                  <div key={sub.id} className="flex items-center gap-4 p-3 rounded-lg bg-[#1a1a2e]">
                    <div className="w-10 h-10 rounded-full bg-gradient-to-br from-purple-500 to-pink-500 flex items-center justify-center"><Star className="w-5 h-5 text-white" /></div>
                    <div className="flex-1"><p className="text-white font-medium">Subscriber</p><p className="text-gray-500 text-xs">Since {new Date(sub.started_at).toLocaleDateString()}</p></div>
                    <span className="text-green-400 text-sm">$4.99/mo</span>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {activeTab === 'settings' && isOwnProfile && <SettingsTab />}

      </div>

      {/* Phone Capabilities Modal */}
      <PhoneCapabilities isOpen={showPhoneCapabilities} onClose={() => setShowPhoneCapabilities(false)} />
      {/* Signup QR Modal */}
      <SignupQRModal isOpen={showQRModal} onClose={() => setShowQRModal(false)} />
      {/* SMS Sign-In Info Modal */}
      <SendSignInSMS isOpen={showSMSSignIn} onClose={() => setShowSMSSignIn(false)} />
    </div>
  );
}



function ClipsTab({ streamerId }: { streamerId: string }) {
  const [clips, setClips] = useState<Clip[]>([]);
  const [selectedClip, setSelectedClip] = useState<Clip | null>(null);
  useEffect(() => {
    const fetchClips = async () => {
      const { data } = await supabase.functions.invoke('clips-manager', { body: { action: 'get_streamer_clips', streamer_id: streamerId } });
      setClips(data?.clips || []);
    };
    fetchClips();
  }, [streamerId]);
  return (
    <div className="bg-[#16213e] rounded-2xl p-6 border border-gray-800">
      <h2 className="text-xl font-bold text-white mb-4 flex items-center gap-2"><Scissors className="w-5 h-5 text-purple-400" /> Clips</h2>
      {clips.length === 0 ? <p className="text-gray-400 text-center py-8">No clips yet.</p> : (
        <div className="grid grid-cols-2 md:grid-cols-3 gap-4">{clips.map(clip => <ClipCard key={clip.id} clip={clip} onClick={() => setSelectedClip(clip)} />)}</div>
      )}
      <ClipModal clip={selectedClip} isOpen={!!selectedClip} onClose={() => setSelectedClip(null)} />
    </div>
  );
}

function VODsTab({ userId, isOwnProfile }: { userId: string; isOwnProfile: boolean }) {

  const [vods, setVods] = useState<VOD[]>([]);
  const [selectedVod, setSelectedVod] = useState<VOD | null>(null);
  const [editingVod, setEditingVod] = useState<VOD | null>(null);
  const [deleting, setDeleting] = useState<string | null>(null);

  useEffect(() => {
    const fetchVods = async () => {
      const { data } = await supabase.functions.invoke('vod-manager', { body: { action: 'get_vods', user_id: userId } });
      setVods(data?.vods || []);
    };
    fetchVods();
  }, [userId]);

  const handleDelete = async (vodId: string) => {
    if (!confirm('Are you sure you want to delete this VOD?')) return;
    setDeleting(vodId);
    await supabase.functions.invoke('vod-manager', { body: { action: 'delete_vod', vod_id: vodId, user_id: userId } });
    setVods(prev => prev.filter(v => v.id !== vodId));
    setDeleting(null);
  };

  const handleSave = (updatedVod: VOD) => {
    setVods(prev => prev.map(v => v.id === updatedVod.id ? updatedVod : v));
  };

  return (
    <div className="bg-[#16213e] rounded-2xl p-6 border border-gray-800">
      <h2 className="text-xl font-bold text-white mb-4 flex items-center gap-2"><Video className="w-5 h-5 text-purple-400" /> Videos</h2>
      {vods.length === 0 ? <p className="text-gray-400 text-center py-8">No VODs yet. Past broadcasts will appear here.</p> : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {vods.map(vod => (
            <VODCard key={vod.id} vod={vod} onClick={() => setSelectedVod(vod)} showActions={isOwnProfile} onEdit={() => setEditingVod(vod)} onDelete={() => handleDelete(vod.id)} />
          ))}
        </div>
      )}
      <VODPlayer vod={selectedVod!} isOpen={!!selectedVod} onClose={() => setSelectedVod(null)} />
      <VODEditModal vod={editingVod} isOpen={!!editingVod} onClose={() => setEditingVod(null)} onSave={handleSave} />
    </div>
  );
}

function RewardsTab({ userId, username }: { userId: string; username: string }) {
  const [rewards, setRewards] = useState<any[]>([]);
  const [showCreator, setShowCreator] = useState(false);
  const [redemptions, setRedemptions] = useState<any[]>([]);

  useEffect(() => {
    fetchRewards();
    fetchRedemptions();
  }, [userId]);

  const fetchRewards = async () => {
    const { data } = await supabase.functions.invoke('points-manager', { body: { action: 'get_rewards', channel_id: userId } });
    setRewards(data?.data || []);
  };

  const fetchRedemptions = async () => {
    const { data } = await supabase.functions.invoke('points-manager', { body: { action: 'get_redemptions', channel_id: userId } });
    setRedemptions(data?.data || []);
  };

  const handleStatusUpdate = async (id: string, status: string) => {
    await supabase.functions.invoke('points-manager', { body: { action: 'update_redemption', redemption_id: id, status } });
    setRedemptions(prev => prev.map(r => r.id === id ? { ...r, status } : r));
  };

  return (
    <div className="space-y-4">
      <div className="bg-[#16213e] rounded-2xl p-6 border border-gray-800">
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-xl font-bold text-white flex items-center gap-2"><Gift className="w-5 h-5 text-purple-400" /> Channel Rewards</h2>
          <Button onClick={() => setShowCreator(true)} className="bg-purple-600 hover:bg-purple-700"><Plus className="w-4 h-4 mr-1" /> Create Reward</Button>
        </div>
        {rewards.length === 0 ? <p className="text-gray-400 text-center py-8">No rewards yet. Create rewards for your viewers!</p> : (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            {rewards.map(reward => (
              <div key={reward.id} className="bg-[#1a1a2e] rounded-lg p-3 border border-gray-700">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-lg flex items-center justify-center" style={{ backgroundColor: reward.color + '30' }}>
                    <Sparkles className="w-5 h-5" style={{ color: reward.color }} />
                  </div>
                  <div className="flex-1">
                    <p className="text-white font-semibold">{reward.title}</p>
                    <p className="text-yellow-400 text-sm">{reward.cost} points</p>
                  </div>
                  <span className="text-gray-500 text-xs">{reward.redemption_count} redeemed</span>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
      <div className="bg-[#16213e] rounded-2xl p-6 border border-gray-800">
        <h2 className="text-xl font-bold text-white mb-4">Recent Redemptions</h2>
        {redemptions.length === 0 ? <p className="text-gray-400 text-center py-4">No redemptions yet</p> : (
          <div className="space-y-2 max-h-64 overflow-y-auto">
            {redemptions.slice(0, 20).map(r => (
              <div key={r.id} className="flex items-center gap-3 p-2 bg-[#1a1a2e] rounded-lg">
                <div className="flex-1">
                  <p className="text-white text-sm"><span className="font-semibold">{r.username}</span> redeemed <span className="text-purple-400">{r.reward_title}</span></p>
                  {r.user_input && <p className="text-gray-400 text-xs">"{r.user_input}"</p>}
                </div>
                <span className={`text-xs px-2 py-0.5 rounded ${r.status === 'completed' ? 'bg-green-500/20 text-green-400' : r.status === 'rejected' ? 'bg-red-500/20 text-red-400' : 'bg-yellow-500/20 text-yellow-400'}`}>{r.status}</span>
              </div>
            ))}
          </div>
        )}
      </div>
      <RewardCreator channelId={userId} streamerName={username} isOpen={showCreator} onClose={() => setShowCreator(false)} onCreated={fetchRewards} />
    </div>
  );
}

function SettingsTab() {
  const { user, signOut } = useAuth();
  const navigate = useNavigate();
  const handleSignOut = async () => { await signOut(); navigate('/'); };
  
  return (
    <div className="space-y-6">
      <div className="bg-[#16213e] rounded-2xl p-6 border border-gray-800 space-y-6">
        <h2 className="text-xl font-bold text-white flex items-center gap-2"><Settings className="w-5 h-5 text-purple-400" /> Account Settings</h2>
        
        {/* Account Info */}
        <div>
          <label className="text-gray-300 text-sm mb-2 block">Email</label>
          <input type="email" value={user?.email || ''} disabled className="w-full bg-[#1a1a2e] text-gray-400 px-4 py-3 rounded-lg border border-gray-700" />
          <p className="text-gray-500 text-xs mt-1">Email cannot be changed</p>
        </div>

        {/* Unique ID */}
        {user?.unique_id && (
          <div>
            <label className="text-gray-300 text-sm mb-2 block flex items-center gap-2">
              <Hash className="w-4 h-4 text-purple-400" />
              Your Unique ID
            </label>
            <div className="flex items-center gap-2">
              <input 
                type="text" 
                value={user.unique_id.toString()} 
                disabled 
                className="flex-1 bg-[#1a1a2e] text-purple-400 font-mono px-4 py-3 rounded-lg border border-purple-500/30" 
              />
            </div>
            <p className="text-gray-500 text-xs mt-1">This is your unique numerical identifier</p>
          </div>
        )}

        {/* Phone Number */}
        {user?.phone_number && (
          <div>
            <label className="text-gray-300 text-sm mb-2 block flex items-center gap-2">
              <Phone className="w-4 h-4 text-green-400" />
              Your Phone Number
            </label>
            <div className="flex items-center gap-2">
              <input 
                type="text" 
                value={user.phone_number} 
                disabled 
                className="flex-1 bg-[#1a1a2e] text-green-400 font-mono px-4 py-3 rounded-lg border border-green-500/30" 
              />
            </div>
            <p className="text-gray-500 text-xs mt-1">Your assigned phone number for SMS and calls</p>
          </div>
        )}
        
        <div className="pt-4 border-t border-gray-700">
          <button onClick={handleSignOut} className="bg-red-600 hover:bg-red-500 text-white px-6 py-2 rounded-lg font-semibold transition-colors">Sign Out</button>
        </div>
      </div>
      
      <div className="bg-[#16213e] rounded-2xl p-6 border border-gray-800">
        <AutoHostSettings />
      </div>
    </div>
  );
}
