import { useState, useEffect, useCallback } from 'react';
import { MessageCircle, ArrowLeft, Users, Mail, Bell, Shield, Trash2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Tabs, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';
import { ConversationList } from '@/components/messages/ConversationList';
import { MessageThread } from '@/components/messages/MessageThread';
import { MessageInput } from '@/components/messages/MessageInput';
import { NewMessageModal } from '@/components/messages/NewMessageModal';
import { DialogueList } from '@/components/messages/DialogueList';
import { DialogueThreadWithReport } from '@/components/messages/DialogueThreadWithReport';

import { CreateDialogueModal } from '@/components/messages/CreateDialogueModal';
import { PublicDialoguesModal } from '@/components/messages/PublicDialoguesModal';
import { InviteToDialogueModal } from '@/components/messages/InviteToDialogueModal';
import { ModerationDashboard } from '@/components/moderation/ModerationDashboard';
import { useAuth } from '@/contexts/AuthContext';
import { supabase } from '@/lib/supabase';


interface Conversation {
  id: string; participant_1: string; participant_2: string; last_message_at: string;
  last_message_preview: string; other_user?: { username: string; avatar_url?: string; display_name?: string; user_id: string };
}

interface Dialogue {
  id: string; name: string; description?: string; avatar_url?: string; is_public: boolean;
  last_message_at: string; last_message_preview?: string; member_count?: number; userRole?: string;
}

interface Member { user_id: string; role: string; is_muted?: boolean; profile: { username: string; avatar_url?: string; display_name?: string }; }

export default function MessagesPage() {
  const { user } = useAuth();
  const [tab, setTab] = useState<'dm' | 'dialogues' | 'moderation'>('dm');

  const [conversations, setConversations] = useState<Conversation[]>([]);
  const [dialogues, setDialogues] = useState<Dialogue[]>([]);
  const [selectedConv, setSelectedConv] = useState<Conversation | null>(null);
  const [selectedDialogue, setSelectedDialogue] = useState<Dialogue | null>(null);
  const [messages, setMessages] = useState<any[]>([]);
  const [dialogueMessages, setDialogueMessages] = useState<any[]>([]);
  const [dialogueMembers, setDialogueMembers] = useState<Member[]>([]);
  const [showNewMessage, setShowNewMessage] = useState(false);
  const [showCreateDialogue, setShowCreateDialogue] = useState(false);
  const [showPublicDialogues, setShowPublicDialogues] = useState(false);
  const [showInvite, setShowInvite] = useState(false);
  const [pendingInvites, setPendingInvites] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  
  // Get userId - may be undefined if not authenticated
  const userId = user?.id;

  // Define all callbacks unconditionally (they just won't do anything if userId is undefined)
  const loadConversations = useCallback(async () => {
    if (!userId) return;
    const { data } = await supabase.functions.invoke('messages-manager', { body: { action: 'get_conversations', user_id: userId } });
    const convs = data?.conversations || [];
    const enriched = await Promise.all(convs.map(async (c: Conversation) => {
      const otherId = c.participant_1 === userId ? c.participant_2 : c.participant_1;
      const { data: profile } = await supabase.functions.invoke('messages-manager', { body: { action: 'get_user_profile', user_id: otherId } });
      return { ...c, other_user: profile?.profile || { username: 'User', user_id: otherId } };
    }));
    setConversations(enriched);
  }, [userId]);

  const loadDialogues = useCallback(async () => {
    if (!userId) return;
    const { data } = await supabase.functions.invoke('messages-manager', { body: { action: 'get_user_dialogues', user_id: userId } });
    setDialogues(data?.dialogues || []);
  }, [userId]);

  const loadPendingInvites = useCallback(async () => {
    if (!userId) return;
    const { data } = await supabase.functions.invoke('messages-manager', { body: { action: 'get_pending_invites', user_id: userId } });
    setPendingInvites(data?.invites || []);
  }, [userId]);

  // Load data when userId is available
  useEffect(() => {
    if (!userId) {
      setLoading(false);
      return;
    }
    Promise.all([loadConversations(), loadDialogues(), loadPendingInvites()]).finally(() => setLoading(false));
  }, [userId, loadConversations, loadDialogues, loadPendingInvites]);

  // Load messages when conversation is selected
  useEffect(() => {
    if (selectedConv && userId) {
      supabase.functions.invoke('messages-manager', { body: { action: 'get_messages', conversation_id: selectedConv.id, user_id: userId } })
        .then(({ data }) => setMessages(data?.messages || []));
    }
  }, [selectedConv, userId]);

  // Load dialogue messages and members when dialogue is selected
  useEffect(() => {
    if (selectedDialogue && userId) {
      supabase.functions.invoke('messages-manager', { body: { action: 'get_dialogue_messages', dialogue_id: selectedDialogue.id, user_id: userId } })
        .then(({ data }) => setDialogueMessages(data?.messages || []));
      supabase.functions.invoke('messages-manager', { body: { action: 'get_dialogue_members', dialogue_id: selectedDialogue.id } })
        .then(({ data }) => setDialogueMembers(data?.members || []));
      const channel = supabase.channel(`dialogue-${selectedDialogue.id}`)
        .on('postgres_changes', { event: 'INSERT', schema: 'public', table: 'dialogue_messages', filter: `dialogue_id=eq.${selectedDialogue.id}` },
          (payload) => setDialogueMessages(prev => [...prev, payload.new]))
        .subscribe();
      return () => { supabase.removeChannel(channel); };
    }
  }, [selectedDialogue, userId]);

  const handleSendDM = async (content: string) => {
    if (!selectedConv?.other_user || !userId) return;
    await supabase.functions.invoke('messages-manager', { body: { action: 'send_message', sender_id: userId, receiver_id: selectedConv.other_user.user_id, content } });
    const { data } = await supabase.functions.invoke('messages-manager', { body: { action: 'get_messages', conversation_id: selectedConv.id, user_id: userId } });
    setMessages(data?.messages || []);
    loadConversations();
  };

  const handleSendDialogue = async (content: string) => {
    if (!selectedDialogue || !userId) return;
    await supabase.functions.invoke('messages-manager', { body: { action: 'send_dialogue_message', dialogue_id: selectedDialogue.id, sender_id: userId, content } });
    loadDialogues();
  };

  const handleCreateDialogue = async (data: { name: string; description: string; is_public: boolean }) => {
    if (!userId) return;
    const { data: result } = await supabase.functions.invoke('messages-manager', { body: { action: 'create_dialogue', creator_id: userId, ...data } });
    if (result?.dialogue) { loadDialogues(); setSelectedDialogue(result.dialogue); }
  };

  const handleJoinDialogue = async (dialogueId: string) => {
    if (!userId) return;
    await supabase.functions.invoke('messages-manager', { body: { action: 'join_dialogue', dialogue_id: dialogueId, user_id: userId } });
    loadDialogues();
  };

  const handleRespondInvite = async (inviteId: string, accept: boolean) => {
    if (!userId) return;
    await supabase.functions.invoke('messages-manager', { body: { action: 'respond_to_invite', invite_id: inviteId, user_id: userId, accept } });
    loadPendingInvites(); if (accept) loadDialogues();
  };

  // If not authenticated, show login prompt (AFTER all hooks)
  if (!user || !userId) {
    return (
      <div className="h-[calc(100vh-64px)] flex items-center justify-center bg-gray-900">
        <div className="text-center space-y-4 p-8">
          <MessageCircle className="h-16 w-16 mx-auto text-purple-500 opacity-50" />
          <h2 className="text-2xl font-bold text-white">Sign In Required</h2>
          <p className="text-gray-400 max-w-md">Please sign in to access your messages and dialogues.</p>
          <Button onClick={() => window.location.href = '/login'} className="bg-purple-600 hover:bg-purple-700">
            Sign In
          </Button>
        </div>
      </div>
    );
  }

  if (loading) return <div className="flex items-center justify-center h-screen"><div className="animate-spin rounded-full h-12 w-12 border-b-2 border-purple-500" /></div>;

  const showMobileList = tab === 'dm' ? !selectedConv : !selectedDialogue;

  const hasModeratorDialogues = dialogues.some(d => d.userRole === 'owner' || d.userRole === 'admin');

  return (
    <div className="h-[calc(100vh-64px)] flex flex-col bg-gray-900">
      <div className="p-3 border-b border-gray-800 flex items-center justify-between">
        <Tabs value={tab} onValueChange={(v) => { setTab(v as any); setSelectedConv(null); setSelectedDialogue(null); }}>
          <TabsList className="bg-gray-800">
            <TabsTrigger value="dm" className="gap-2"><Mail className="h-4 w-4" />Messages</TabsTrigger>
            <TabsTrigger value="dialogues" className="gap-2"><Users className="h-4 w-4" />Dialogues</TabsTrigger>
            {hasModeratorDialogues && <TabsTrigger value="moderation" className="gap-2"><Shield className="h-4 w-4" />Moderation</TabsTrigger>}
          </TabsList>
        </Tabs>
        {pendingInvites.length > 0 && <Badge className="bg-red-500">{pendingInvites.length} invites</Badge>}
      </div>
      <div className="flex-1 flex overflow-hidden">
        {tab === 'moderation' ? (
          <div className="flex-1 p-6 overflow-y-auto"><ModerationDashboard /></div>
        ) : (
          <>
            <div className={`w-full md:w-80 ${!showMobileList ? 'hidden md:block' : ''}`}>
              {tab === 'dm' ? <ConversationList conversations={conversations} selectedId={selectedConv?.id || null} onSelect={setSelectedConv} onNewMessage={() => setShowNewMessage(true)} currentUserId={userId} /> : <DialogueList dialogues={dialogues} selectedId={selectedDialogue?.id || null} onSelect={setSelectedDialogue} onCreateNew={() => setShowCreateDialogue(true)} onBrowsePublic={() => setShowPublicDialogues(true)} />}
            </div>
            <div className={`flex-1 flex flex-col ${showMobileList ? 'hidden md:flex' : ''}`}>
              {tab === 'dm' && selectedConv ? (
                <>
                  <div className="p-4 border-b border-gray-800 flex items-center gap-3">
                    <Button variant="ghost" size="icon" className="md:hidden" onClick={() => setSelectedConv(null)}><ArrowLeft className="h-5 w-5" /></Button>
                    <Avatar><AvatarImage src={selectedConv.other_user?.avatar_url} /><AvatarFallback className="bg-purple-600">{selectedConv.other_user?.username?.[0]?.toUpperCase()}</AvatarFallback></Avatar>
                    <div><p className="font-medium text-white">{selectedConv.other_user?.display_name || selectedConv.other_user?.username}</p></div>
                  </div>
                  <MessageThread messages={messages} currentUserId={userId} otherUser={selectedConv.other_user} />
                  <MessageInput onSend={handleSendDM} />
                </>
              ) : tab === 'dialogues' && selectedDialogue ? (
                <>
                  <div className="p-4 border-b border-gray-800 flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <Button variant="ghost" size="icon" className="md:hidden" onClick={() => setSelectedDialogue(null)}><ArrowLeft className="h-5 w-5" /></Button>
                      <Avatar><AvatarFallback className="bg-gradient-to-br from-purple-600 to-pink-600">{selectedDialogue.name.substring(0, 2).toUpperCase()}</AvatarFallback></Avatar>
                      <div><p className="font-medium text-white">{selectedDialogue.name}</p><p className="text-sm text-gray-400">{dialogueMembers.length} members</p></div>
                    </div>
                    <Button size="sm" variant="outline" onClick={() => setShowInvite(true)} className="border-gray-700">Invite</Button>
                  </div>
                  <DialogueThreadWithReport messages={dialogueMessages} members={dialogueMembers} currentUserId={userId} currentUsername={user?.username || 'User'} dialogueId={selectedDialogue.id} userRole={selectedDialogue.userRole || 'member'} />
                  <MessageInput onSend={handleSendDialogue} isMuted={dialogueMembers.find(m => m.user_id === userId)?.is_muted} />
                </>
              ) : (
                <div className="flex-1 flex items-center justify-center"><div className="text-center text-gray-400"><MessageCircle className="h-16 w-16 mx-auto mb-4 opacity-50" /><p className="text-xl">{tab === 'dm' ? 'Select a conversation' : 'Select a dialogue'}</p></div></div>
              )}
            </div>
          </>

        )}
      </div>
      <NewMessageModal open={showNewMessage} onClose={() => setShowNewMessage(false)} onSelectUser={(u) => { setSelectedConv({ id: '', participant_1: userId, participant_2: u.user_id, last_message_at: new Date().toISOString(), last_message_preview: '', other_user: u }); setShowNewMessage(false); }} />
      <CreateDialogueModal open={showCreateDialogue} onClose={() => setShowCreateDialogue(false)} onCreate={handleCreateDialogue} />
      <PublicDialoguesModal open={showPublicDialogues} onClose={() => setShowPublicDialogues(false)} onJoin={handleJoinDialogue} userDialogueIds={dialogues.map(d => d.id)} />
      {selectedDialogue && <InviteToDialogueModal open={showInvite} onClose={() => setShowInvite(false)} dialogueId={selectedDialogue.id} dialogueName={selectedDialogue.name} currentUserId={userId} existingMemberIds={dialogueMembers.map(m => m.user_id)} />}
    </div>
  );
}
