import React, { useEffect, useState, useCallback } from 'react';
import { useParams, useNavigate, useSearchParams } from 'react-router-dom';
import { Radio, Users, Heart, Share2, Gift, Settings, Palette, Rocket, MessageSquare, MessageSquareOff, PanelRightClose, PanelRight, Layers, LayoutGrid, Layout, Monitor } from 'lucide-react';
import { LiveChat } from '@/components/LiveChat';
import { StreamChatOverlay } from '@/components/StreamChatOverlay';
import { DonationButton } from '@/components/DonationButton';
import { DonationAlert } from '@/components/DonationAlert';
import { SubscribeButton } from '@/components/SubscribeButton';
import { PointsDisplay } from '@/components/PointsDisplay';
import { RewardsPanel } from '@/components/RewardsPanel';
import { RedemptionAlert } from '@/components/RedemptionAlert';
import { RaidAlert } from '@/components/RaidAlert';
import { GiftButton } from '@/components/GiftButton';
import { GiftOverlay, triggerGift } from '@/components/gifts/GiftOverlay';
import { StreamGiftFeed } from '@/components/gifts/StreamGiftFeed';
import { SuperChatButton } from '@/components/monetization/SuperChatButton';
import { VideoQualitySettings, VideoSettings } from '@/components/video/VideoQualitySettings';
import { VideoFilters, FilterSettings } from '@/components/video/VideoFilters';
import { SponsorPromotionModal } from '@/components/promotions/SponsorPromotionModal';
import { useAuth } from '@/contexts/AuthContext';
import { useStream } from '@/contexts/StreamContext';
import { supabase } from '@/lib/supabase';

interface Donation { id: string; donor_username: string; donor_display_name?: string; amount: number; message?: string; }
interface Redemption { id: string; username: string; reward_title: string; cost: number; user_input?: string; status: string; }
interface Raid { id: string; raider_name: string; viewer_count: number; created_at: string; }

type ChatMode = 'side' | 'overlay' | 'both' | 'none';

export default function WatchPage() {
  const { streamId } = useParams();
  const [searchParams] = useSearchParams();
  const navigate = useNavigate();
  const { user } = useAuth();
  const { joinStream, leaveStream, liveStreams } = useStream();
  const [stream, setStream] = useState<any>(null);
  const [isFollowing, setIsFollowing] = useState(false);
  const [viewerCount, setViewerCount] = useState(0);
  const [subOnlyMode, setSubOnlyMode] = useState(false);
  const [currentDonation, setCurrentDonation] = useState<Donation | null>(null);
  const [donationQueue, setDonationQueue] = useState<Donation[]>([]);
  const [userPoints, setUserPoints] = useState(0);
  const [showRewards, setShowRewards] = useState(false);
  const [redemptions, setRedemptions] = useState<Redemption[]>([]);
  const [currentRaid, setCurrentRaid] = useState<Raid | null>(null);
  const [showQuality, setShowQuality] = useState(false);
  const [showFilters, setShowFilters] = useState(false);
  const [showPromo, setShowPromo] = useState(false);
  const [videoSettings, setVideoSettings] = useState<VideoSettings>({ resolution: '1080p', bitrate: 8000, frameRate: 60, hdrEnabled: false, lowLatency: true, adaptiveQuality: true });
  const [filterSettings, setFilterSettings] = useState<FilterSettings>({ brightness: 100, contrast: 100, saturation: 100, preset: 'none', beautyMode: 0, backgroundBlur: 0 });
  
  // Chat display modes
  const [chatMode, setChatMode] = useState<ChatMode>('overlay');
  const [showChatModeMenu, setShowChatModeMenu] = useState(false);

  const getFilterStyle = () => ({ filter: `brightness(${filterSettings.brightness}%) contrast(${filterSettings.contrast}%) saturate(${filterSettings.saturation}%)` });

  const toggleChatMode = () => {
    const modes: ChatMode[] = ['overlay', 'both', 'side', 'none'];
    const currentIndex = modes.indexOf(chatMode);
    setChatMode(modes[(currentIndex + 1) % modes.length]);
  };

  const getChatModeIcon = () => {
    switch (chatMode) {
      case 'side': return <PanelRight className="w-5 h-5 text-white" />;
      case 'overlay': return <Layers className="w-5 h-5 text-white" />;
      case 'both': return <LayoutGrid className="w-5 h-5 text-white" />;
      case 'none': return <MessageSquareOff className="w-5 h-5 text-white" />;
    }
  };

  const getChatModeLabel = () => {
    switch (chatMode) {
      case 'side': return 'Side Chat';
      case 'overlay': return 'Stream Overlay';
      case 'both': return 'Both Chats';
      case 'none': return 'Chat Hidden';
    }
  };

  useEffect(() => {
    if (!streamId) { navigate('/'); return; }
    loadStream(); joinStream(streamId);
    const interval = setInterval(loadStream, 5000);
    const donationChannel = supabase.channel(`donations:${streamId}`).on('postgres_changes', { event: 'INSERT', schema: 'public', table: 'donations', filter: `stream_id=eq.${streamId}` }, (p) => setDonationQueue(prev => [...(Array.isArray(prev) ? prev : []), p.new as Donation])).subscribe();
    const giftChannel = supabase.channel(`gifts:${streamId}`).on('postgres_changes', { event: 'INSERT', schema: 'public', table: 'gift_transactions', filter: `stream_id=eq.${streamId}` }, async (p) => { try { const tx = p.new as any; const { data } = await supabase.functions.invoke('gifts-manager', { body: { action: 'get_gift_types' } }); const gift = (data?.gifts || []).find((g: any) => g.id === tx.gift_type_id); if (gift) triggerGift(gift, tx.quantity, tx.sender_id?.slice(0, 8) || 'User'); } catch {} }).subscribe();
    return () => { leaveStream(streamId); clearInterval(interval); supabase.removeChannel(donationChannel); supabase.removeChannel(giftChannel); };
  }, [streamId]);

  useEffect(() => { if (!currentDonation && donationQueue.length > 0) { setCurrentDonation(donationQueue[0]); setDonationQueue(prev => prev.slice(1)); } }, [currentDonation, donationQueue]);
  const handleDonationComplete = useCallback(() => setCurrentDonation(null), []);
  const loadStream = async () => { 
    // Use edge function to get inflated viewer count
    try {
      const { data: edgeData } = await supabase.functions.invoke('stream-manager', {
        body: { action: 'get_stream', stream_id: streamId }
      });
      if (edgeData?.stream) {
        setStream(edgeData.stream);
        setViewerCount(edgeData.stream.viewer_count);
        return;
      }
    } catch {}
    // Fallback to direct query if edge function fails
    const { data } = await supabase.from('live_streams').select('*').eq('id', streamId).single(); 
    if (data) { 
      // Apply inflation multiplier (1 real = 201 displayed)
      const inflatedCount = (data.viewer_count || 0) * 201;
      setStream({ ...data, viewer_count: inflatedCount }); 
      setViewerCount(inflatedCount); 
    } else { 
      const found = liveStreams.find(s => s.id === streamId); 
      if (found) { 
        setStream(found); 
        setViewerCount(found.viewer_count); 
      } 
    } 
  };

  const handleFollow = async () => { if (!user || !stream) return; if (isFollowing) await supabase.from('followers').delete().eq('follower_id', user.user_id).eq('following_id', stream.user_id); else await supabase.from('followers').insert({ follower_id: user.user_id, following_id: stream.user_id }); setIsFollowing(!isFollowing); };

  if (!stream) return <div className="min-h-screen bg-[#1a1a2e] flex items-center justify-center"><Radio className="w-16 h-16 text-purple-500 animate-pulse" /></div>;

  const showSideChatPanel = chatMode === 'side' || chatMode === 'both';
  const showOverlayChatPanel = chatMode === 'overlay' || chatMode === 'both';

  return (
    <div className="min-h-screen bg-[#1a1a2e] flex flex-col lg:flex-row">
      <GiftOverlay /><DonationAlert donation={currentDonation} onComplete={handleDonationComplete} /><RaidAlert raid={currentRaid} onDismiss={() => setCurrentRaid(null)} />
      <VideoQualitySettings isOpen={showQuality} onClose={() => setShowQuality(false)} onApply={setVideoSettings} />
      <VideoFilters isOpen={showFilters} onClose={() => setShowFilters(false)} onApply={setFilterSettings} />
      <SponsorPromotionModal isOpen={showPromo} onClose={() => setShowPromo(false)} contentType="stream" contentId={streamId!} contentTitle={stream.title} onSubmit={(c) => console.log('Promotion:', c)} />
      <div className={`flex-1 flex flex-col ${showSideChatPanel ? '' : 'lg:mr-0'}`}>
        <div className="relative aspect-video bg-black" style={getFilterStyle()}>
          {stream.thumbnail_url ? <img src={stream.thumbnail_url} alt="" className="w-full h-full object-cover" /> : <div className="w-full h-full flex items-center justify-center"><Radio className="w-24 h-24 text-gray-700" /></div>}
          
          {/* Live Badge with Screen Share Indicator */}
          <div className="absolute top-4 left-4 flex items-center gap-2">
            <span className="bg-red-600 text-white text-sm px-3 py-1 rounded-full font-semibold flex items-center gap-2">
              <span className="w-2 h-2 bg-white rounded-full animate-pulse" /> LIVE
            </span>
            {stream.is_screen_sharing && (
              <span className="bg-blue-600 text-white text-sm px-3 py-1 rounded-full font-semibold flex items-center gap-2">
                <Monitor className="w-4 h-4" /> Screen Share
              </span>
            )}
          </div>
          
          <div className="absolute top-4 right-4 flex gap-2">
            <button onClick={() => setShowQuality(true)} className="p-2 bg-black/60 hover:bg-black/80 rounded-full transition-colors" title="Quality"><Settings className="w-5 h-5 text-white" /></button>
            <button onClick={() => setShowFilters(true)} className="p-2 bg-black/60 hover:bg-black/80 rounded-full transition-colors" title="Filters"><Palette className="w-5 h-5 text-white" /></button>
            <div className="relative">
              <button 
                onClick={toggleChatMode}
                onContextMenu={(e) => { e.preventDefault(); setShowChatModeMenu(!showChatModeMenu); }}
                className="p-2 bg-black/60 hover:bg-black/80 rounded-full transition-colors flex items-center gap-1" 
                title={`${getChatModeLabel()} (right-click for options)`}
              >
                {getChatModeIcon()}
              </button>
              {/* Chat Mode Dropdown */}
              {showChatModeMenu && (
                <div className="absolute top-full mt-2 right-0 bg-[#16213e] border border-gray-700 rounded-lg shadow-xl overflow-hidden z-50">
                  {[
                    { mode: 'overlay' as ChatMode, label: 'Stream Overlay', icon: <Layers className="w-4 h-4" />, desc: 'Chat scrolls over video' },
                    { mode: 'both' as ChatMode, label: 'Both Chats', icon: <LayoutGrid className="w-4 h-4" />, desc: 'Overlay + Side panel' },
                    { mode: 'side' as ChatMode, label: 'Side Chat', icon: <Layout className="w-4 h-4" />, desc: 'Traditional sidebar' },
                    { mode: 'none' as ChatMode, label: 'Hide Chat', icon: <MessageSquareOff className="w-4 h-4" />, desc: 'No chat visible' },
                  ].map((option) => (
                    <button
                      key={option.mode}
                      onClick={() => { setChatMode(option.mode); setShowChatModeMenu(false); }}
                      className={`w-full px-4 py-3 flex items-center gap-3 text-left whitespace-nowrap ${chatMode === option.mode ? 'bg-purple-600 text-white' : 'text-gray-300 hover:bg-gray-700'}`}
                    >
                      {option.icon}
                      <div>
                        <div className="text-sm font-medium">{option.label}</div>
                        <div className="text-xs opacity-70">{option.desc}</div>
                      </div>
                    </button>
                  ))}
                </div>
              )}
            </div>
            <button onClick={() => setShowPromo(true)} className="p-2 bg-gradient-to-r from-yellow-500 to-orange-500 rounded-full transition-colors" title="Promote"><Rocket className="w-5 h-5 text-white" /></button>
          </div>
          <div className="absolute bottom-4 left-4 flex items-center gap-2 bg-black/70 px-3 py-1 rounded-full pointer-events-none"><Users className="w-4 h-4 text-white" /><span className="text-white text-sm">{viewerCount.toLocaleString()}</span></div>
          <div className="absolute bottom-4 right-4 bg-black/70 px-2 py-1 rounded text-xs text-white pointer-events-none flex items-center gap-2">
            {stream.is_screen_sharing && <Monitor className="w-3 h-3 text-blue-400" />}
            {videoSettings.resolution} • {videoSettings.frameRate}fps
          </div>
          
          {/* Stream Chat Overlay - Messages scroll up over video */}
          {showOverlayChatPanel && (
            <StreamChatOverlay
              streamId={streamId!}
              streamerId={stream.user_id}
              showInput={true}
            />
          )}
        </div>
        <div className="bg-[#16213e] p-4 border-b border-gray-800">
          <div className="flex flex-wrap items-start justify-between gap-4">
            <div className="flex items-center gap-4">
              <div className="w-14 h-14 rounded-full bg-gradient-to-br from-purple-500 to-pink-500 flex items-center justify-center"><span className="text-white font-bold text-xl">{stream.streamer_name?.[0]?.toUpperCase()}</span></div>
              <div>
                <h1 className="text-white text-xl font-bold flex items-center gap-2">
                  {stream.title}
                  {stream.is_screen_sharing && (
                    <span className="text-xs bg-blue-600/30 text-blue-400 px-2 py-0.5 rounded-full flex items-center gap-1">
                      <Monitor className="w-3 h-3" /> Sharing Screen
                    </span>
                  )}
                </h1>
                <p className="text-purple-400">{stream.streamer_name}</p>
              </div>
            </div>
            <div className="flex flex-wrap items-center gap-2">
              {user && <PointsDisplay channelId={stream.user_id} userId={user.user_id} onPointsUpdate={setUserPoints} />}
              {user && <button onClick={() => setShowRewards(!showRewards)} className="p-2 bg-purple-600 hover:bg-purple-700 rounded-full"><Gift className="w-5 h-5 text-white" /></button>}
              {user && <GiftButton streamerId={stream.user_id} streamId={streamId} streamerName={stream.streamer_name} />}
              {user && <SuperChatButton streamerId={stream.user_id} streamId={streamId!} streamerName={stream.streamer_name} />}
              <SubscribeButton streamerId={stream.user_id} streamerName={stream.streamer_name} />
              <DonationButton streamerId={stream.user_id} streamerName={stream.streamer_name} streamId={streamId!} />
              <button onClick={handleFollow} className={`px-4 py-2 rounded-full font-semibold flex items-center gap-2 ${isFollowing ? 'bg-gray-600' : 'bg-purple-600 hover:bg-purple-700'} text-white`}><Heart className={`w-4 h-4 ${isFollowing ? 'fill-current' : ''}`} />{isFollowing ? 'Following' : 'Follow'}</button>
              <button className="p-2 bg-gray-700 hover:bg-gray-600 rounded-full"><Share2 className="w-5 h-5 text-white" /></button>
            </div>
          </div>
          {user && showRewards && <RewardsPanel channelId={stream.user_id} userId={user.user_id} username={user.username} userPoints={userPoints} isOpen={showRewards} onClose={() => setShowRewards(false)} onPointsUpdate={setUserPoints} />}
        </div>
        <div className="p-4 flex items-center justify-between">
          <button onClick={() => navigate('/')} className="text-purple-400 hover:text-purple-300">← Back</button>
          <div className="flex items-center gap-2">
            <span className="text-gray-400 text-sm">Chat Mode:</span>
            <button 
              onClick={toggleChatMode}
              className="px-3 py-1.5 bg-gray-700 hover:bg-gray-600 rounded-lg text-sm text-white flex items-center gap-2 transition-colors"
            >
              {getChatModeIcon()}
              <span>{getChatModeLabel()}</span>
            </button>
          </div>
        </div>
      </div>
      {showSideChatPanel && (
        <div className="w-full lg:w-96 bg-[#16213e] border-l border-gray-800 flex flex-col h-[600px] lg:h-auto">
          <div className="p-4 border-b border-gray-800 flex justify-between items-center">
            <h3 className="text-white font-bold">Live Chat</h3>
            <div className="flex items-center gap-2">
              <span className="text-gray-400 text-sm">{viewerCount}</span>
              <button 
                onClick={() => setChatMode(chatMode === 'both' ? 'overlay' : 'none')}
                className="p-1.5 hover:bg-gray-700 rounded transition-colors"
                title="Hide side chat"
              >
                <PanelRightClose className="w-4 h-4 text-gray-400" />
              </button>
            </div>
          </div>
          <div className="flex-1 overflow-hidden"><LiveChat streamId={streamId!} streamerId={stream.user_id} subOnlyMode={subOnlyMode} onToggleSubOnly={() => setSubOnlyMode(!subOnlyMode)} /></div>
          <div className="border-t border-gray-700 p-3"><StreamGiftFeed streamId={streamId!} maxItems={5} /></div>
        </div>
      )}
    </div>
  );
}
