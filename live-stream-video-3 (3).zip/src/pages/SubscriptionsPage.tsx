
import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { Star, Calendar, CreditCard, X, Loader2, User } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/contexts/AuthContext';

interface Subscription {
  id: string;
  streamer_id: string;
  streamer_name?: string;
  status: string;
  tier: string;
  started_at: string;
  expires_at: string;
}

export default function SubscriptionsPage() {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [subscriptions, setSubscriptions] = useState<Subscription[]>([]);
  const [loading, setLoading] = useState(true);
  const [cancelling, setCancelling] = useState<string | null>(null);

  useEffect(() => {
    if (!user) { navigate('/login'); return; }
    loadSubscriptions();
  }, [user]);

  const loadSubscriptions = async () => {
    setLoading(true);
    const { data } = await supabase.functions.invoke('subscription-manager', {
      body: { action: 'get_subscriptions', user_id: user?.user_id }
    });
    setSubscriptions(data?.subscriptions || []);
    setLoading(false);
  };

  const cancelSubscription = async (subId: string) => {
    if (!confirm('Are you sure you want to cancel this subscription?')) return;
    setCancelling(subId);
    await supabase.functions.invoke('subscription-manager', {
      body: { action: 'cancel_subscription', subscription_id: subId }
    });
    setSubscriptions(prev => prev.filter(s => s.id !== subId));
    setCancelling(null);
  };

  const formatDate = (date: string) => new Date(date).toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' });

  return (
    <div className="min-h-screen bg-[#1a1a2e] py-8 px-4">
      <div className="max-w-4xl mx-auto">
        <div className="flex items-center gap-3 mb-8">
          <Star className="w-8 h-8 text-purple-500" />
          <h1 className="text-3xl font-bold text-white">My Subscriptions</h1>
        </div>
        {loading ? (
          <div className="flex justify-center py-12"><Loader2 className="w-8 h-8 animate-spin text-purple-500" /></div>
        ) : subscriptions.length === 0 ? (
          <div className="bg-[#16213e] rounded-xl p-12 text-center">
            <Star className="w-16 h-16 text-gray-600 mx-auto mb-4" />
            <h2 className="text-xl font-semibold text-white mb-2">No Active Subscriptions</h2>
            <p className="text-gray-400 mb-6">Subscribe to your favorite streamers to get exclusive perks!</p>
            <button onClick={() => navigate('/')} className="px-6 py-3 bg-purple-600 hover:bg-purple-700 text-white rounded-lg font-semibold">Browse Streamers</button>
          </div>
        ) : (
          <div className="space-y-4">
            {subscriptions.map(sub => (
              <div key={sub.id} className="bg-[#16213e] rounded-xl p-6 flex items-center justify-between">
                <div className="flex items-center gap-4">
                  <div className="w-14 h-14 rounded-full bg-gradient-to-br from-purple-500 to-pink-500 flex items-center justify-center">
                    <User className="w-7 h-7 text-white" />
                  </div>
                  <div>
                    <h3 className="text-white font-semibold text-lg">Streamer</h3>
                    <div className="flex items-center gap-4 text-sm text-gray-400">
                      <span className="flex items-center gap-1"><Calendar className="w-4 h-4" /> Since {formatDate(sub.started_at)}</span>
                      <span className="flex items-center gap-1"><CreditCard className="w-4 h-4" /> $4.99/month</span>
                    </div>
                  </div>
                </div>
                <div className="flex items-center gap-3">
                  <span className="px-3 py-1 bg-purple-600/30 text-purple-400 rounded-full text-sm font-medium">Tier 1</span>
                  <button onClick={() => cancelSubscription(sub.id)} disabled={cancelling === sub.id} className="p-2 bg-red-600/20 hover:bg-red-600/40 text-red-400 rounded-lg">
                    {cancelling === sub.id ? <Loader2 className="w-5 h-5 animate-spin" /> : <X className="w-5 h-5" />}
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}
        <div className="mt-8 bg-gradient-to-r from-purple-900/50 to-pink-900/50 rounded-xl p-6 border border-purple-500/30">
          <h3 className="text-white font-bold text-lg mb-3">Subscriber Benefits</h3>
          <ul className="grid grid-cols-2 gap-3 text-gray-300">
            <li className="flex items-center gap-2"><Star className="w-4 h-4 text-purple-400" /> Subscriber badge in chat</li>
            <li className="flex items-center gap-2"><Star className="w-4 h-4 text-purple-400" /> Access to sub-only chat</li>
            <li className="flex items-center gap-2"><Star className="w-4 h-4 text-purple-400" /> Custom channel emotes</li>
            <li className="flex items-center gap-2"><Star className="w-4 h-4 text-purple-400" /> Ad-free viewing</li>
          </ul>
        </div>
      </div>
    </div>
  );
}
