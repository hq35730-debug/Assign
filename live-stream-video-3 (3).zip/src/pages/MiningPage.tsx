import { useState, useEffect } from 'react';
import { useSearchParams, Link } from 'react-router-dom';
import { Pickaxe, Blocks, Bot, Sparkles, ArrowLeft, Home, BarChart3, ArrowUpDown } from 'lucide-react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { MiningDashboard } from '@/components/mining/MiningDashboard';
import { BlockchainExplorer } from '@/components/mining/BlockchainExplorer';
import { AIChat } from '@/components/ai/AIChat';
import { AIContentGenerator } from '@/components/ai/AIContentGenerator';

export default function MiningPage() {
  const [searchParams] = useSearchParams();
  const tabParam = searchParams.get('tab');
  const [activeTab, setActiveTab] = useState(tabParam || 'mining');

  // Update tab when URL param changes
  useEffect(() => {
    if (tabParam && ['mining', 'explorer', 'trading', 'ai-chat', 'ai-tools'].includes(tabParam)) {
      setActiveTab(tabParam);
    }
  }, [tabParam]);

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="bg-card border-b sticky top-0 z-40">
        <div className="max-w-7xl mx-auto px-4 py-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <Link to="/">
                <Button variant="ghost" size="sm" className="gap-2">
                  <ArrowLeft className="w-4 h-4" />
                  Back
                </Button>
              </Link>
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-full bg-gradient-to-br from-amber-400 to-orange-500 flex items-center justify-center">
                  <Pickaxe className="w-5 h-5 text-white" />
                </div>
                <div>
                  <h1 className="font-bold text-lg">StreamCoin & AI</h1>
                  <p className="text-xs text-muted-foreground">Blockchain Mining & AI Tools</p>
                </div>
              </div>
            </div>
            <div className="flex items-center gap-2">
              <Link to="/trading">
                <Button variant="outline" size="sm" className="gap-2">
                  <BarChart3 className="w-4 h-4" />
                  Trade STC
                </Button>
              </Link>
              <Link to="/">
                <Button variant="outline" size="sm" className="gap-2">
                  <Home className="w-4 h-4" />
                  Home
                </Button>
              </Link>
            </div>
          </div>
        </div>
      </header>

      <div className="p-6">
        <div className="max-w-7xl mx-auto">
          <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
            <TabsList className="grid w-full grid-cols-5 lg:w-auto lg:inline-grid">
              <TabsTrigger value="mining" className="gap-2">
                <Pickaxe className="w-4 h-4" />
                <span className="hidden sm:inline">Mining</span>
              </TabsTrigger>
              <TabsTrigger value="explorer" className="gap-2">
                <Blocks className="w-4 h-4" />
                <span className="hidden sm:inline">Explorer</span>
              </TabsTrigger>
              <TabsTrigger value="trading" className="gap-2">
                <ArrowUpDown className="w-4 h-4" />
                <span className="hidden sm:inline">Trading</span>
              </TabsTrigger>
              <TabsTrigger value="ai-chat" className="gap-2">
                <Bot className="w-4 h-4" />
                <span className="hidden sm:inline">AI Chat</span>
              </TabsTrigger>
              <TabsTrigger value="ai-tools" className="gap-2">
                <Sparkles className="w-4 h-4" />
                <span className="hidden sm:inline">AI Tools</span>
              </TabsTrigger>
            </TabsList>

            <TabsContent value="mining">
              <MiningDashboard />
            </TabsContent>

            <TabsContent value="explorer">
              <BlockchainExplorer />
            </TabsContent>

            <TabsContent value="trading">
              <div className="space-y-6">
                {/* Trading Promo Card */}
                <Card className="bg-gradient-to-br from-amber-500/10 via-orange-500/10 to-red-500/10 border-amber-500/20">
                  <CardContent className="pt-6">
                    <div className="flex flex-col md:flex-row items-center gap-6">
                      <div className="w-20 h-20 rounded-full bg-gradient-to-br from-amber-400 to-orange-500 flex items-center justify-center flex-shrink-0">
                        <BarChart3 className="w-10 h-10 text-white" />
                      </div>
                      <div className="flex-1 text-center md:text-left">
                        <h2 className="text-2xl font-bold mb-2">STC Trading Marketplace</h2>
                        <p className="text-muted-foreground mb-4">
                          Trade StreamCoin (STC) with other users in our peer-to-peer marketplace. 
                          Place limit or market orders, view real-time price charts, and track your trading history.
                        </p>
                        <div className="flex flex-wrap gap-4 justify-center md:justify-start">
                          <div className="text-center">
                            <p className="text-2xl font-bold text-amber-500">0.5%</p>
                            <p className="text-xs text-muted-foreground">Trading Fee</p>
                          </div>
                          <div className="text-center">
                            <p className="text-2xl font-bold text-green-500">24/7</p>
                            <p className="text-xs text-muted-foreground">Trading</p>
                          </div>
                          <div className="text-center">
                            <p className="text-2xl font-bold text-blue-500">P2P</p>
                            <p className="text-xs text-muted-foreground">Marketplace</p>
                          </div>
                        </div>
                      </div>
                      <div className="flex-shrink-0">
                        <Link to="/trading">
                          <Button size="lg" className="gap-2 bg-gradient-to-r from-amber-500 to-orange-500 hover:from-amber-600 hover:to-orange-600">
                            <BarChart3 className="w-5 h-5" />
                            Open Trading
                          </Button>
                        </Link>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                {/* Trading Features */}
                <div className="grid md:grid-cols-3 gap-6">
                  <Card className="bg-card/50 backdrop-blur border-border/50">
                    <CardContent className="pt-6">
                      <div className="flex items-center gap-3 mb-3">
                        <div className="w-10 h-10 rounded-full bg-green-500/10 flex items-center justify-center">
                          <ArrowUpDown className="w-5 h-5 text-green-500" />
                        </div>
                        <h3 className="font-semibold">Limit Orders</h3>
                      </div>
                      <p className="text-sm text-muted-foreground">
                        Set your own price and wait for the market to match. Your order stays open until filled or cancelled.
                      </p>
                    </CardContent>
                  </Card>

                  <Card className="bg-card/50 backdrop-blur border-border/50">
                    <CardContent className="pt-6">
                      <div className="flex items-center gap-3 mb-3">
                        <div className="w-10 h-10 rounded-full bg-blue-500/10 flex items-center justify-center">
                          <BarChart3 className="w-5 h-5 text-blue-500" />
                        </div>
                        <h3 className="font-semibold">Price Charts</h3>
                      </div>
                      <p className="text-sm text-muted-foreground">
                        View real-time candlestick charts with multiple timeframes. Track STC price movements and volume.
                      </p>
                    </CardContent>
                  </Card>

                  <Card className="bg-card/50 backdrop-blur border-border/50">
                    <CardContent className="pt-6">
                      <div className="flex items-center gap-3 mb-3">
                        <div className="w-10 h-10 rounded-full bg-purple-500/10 flex items-center justify-center">
                          <Blocks className="w-5 h-5 text-purple-500" />
                        </div>
                        <h3 className="font-semibold">Order Book</h3>
                      </div>
                      <p className="text-sm text-muted-foreground">
                        See all open buy and sell orders in real-time. Click on prices to quickly set your order price.
                      </p>
                    </CardContent>
                  </Card>
                </div>

                {/* How It Works */}
                <Card className="bg-card/50 backdrop-blur border-border/50">
                  <CardContent className="pt-6">
                    <h3 className="font-semibold mb-4">How Trading Works</h3>
                    <div className="grid md:grid-cols-4 gap-4">
                      <div className="text-center p-4 rounded-lg bg-muted/30">
                        <div className="w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center mx-auto mb-2">
                          <span className="text-primary font-bold">1</span>
                        </div>
                        <h4 className="font-medium text-sm mb-1">Mine STC</h4>
                        <p className="text-xs text-muted-foreground">
                          Mine StreamCoin using your computing power
                        </p>
                      </div>
                      <div className="text-center p-4 rounded-lg bg-muted/30">
                        <div className="w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center mx-auto mb-2">
                          <span className="text-primary font-bold">2</span>
                        </div>
                        <h4 className="font-medium text-sm mb-1">Place Order</h4>
                        <p className="text-xs text-muted-foreground">
                          Create a buy or sell order at your price
                        </p>
                      </div>
                      <div className="text-center p-4 rounded-lg bg-muted/30">
                        <div className="w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center mx-auto mb-2">
                          <span className="text-primary font-bold">3</span>
                        </div>
                        <h4 className="font-medium text-sm mb-1">Match</h4>
                        <p className="text-xs text-muted-foreground">
                          Orders are matched automatically
                        </p>
                      </div>
                      <div className="text-center p-4 rounded-lg bg-muted/30">
                        <div className="w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center mx-auto mb-2">
                          <span className="text-primary font-bold">4</span>
                        </div>
                        <h4 className="font-medium text-sm mb-1">Trade</h4>
                        <p className="text-xs text-muted-foreground">
                          Balances updated instantly on trade
                        </p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </TabsContent>

            <TabsContent value="ai-chat">
              <div className="grid lg:grid-cols-3 gap-6">
                <div className="lg:col-span-2">
                  <AIChat feature="chat" />
                </div>
                <div className="space-y-4">
                  <div className="bg-gradient-to-br from-violet-500/10 to-purple-600/10 rounded-xl p-6 border border-violet-500/20">
                    <div className="flex items-center gap-3 mb-4">
                      <div className="w-10 h-10 rounded-full bg-gradient-to-br from-violet-500 to-purple-600 flex items-center justify-center">
                        <Bot className="w-5 h-5 text-white" />
                      </div>
                      <div>
                        <h3 className="font-semibold">StreamAI</h3>
                        <p className="text-sm text-muted-foreground">Your AI Assistant</p>
                      </div>
                    </div>
                    <p className="text-sm text-muted-foreground mb-4">
                      StreamAI is powered by advanced language models including GPT-5, Gemini Pro, and Claude. Get help with:
                    </p>
                    <ul className="space-y-2 text-sm">
                      <li className="flex items-center gap-2">
                        <span className="w-1.5 h-1.5 rounded-full bg-violet-500" />
                        Stream ideas and content planning
                      </li>
                      <li className="flex items-center gap-2">
                        <span className="w-1.5 h-1.5 rounded-full bg-violet-500" />
                        Technical streaming advice
                      </li>
                      <li className="flex items-center gap-2">
                        <span className="w-1.5 h-1.5 rounded-full bg-violet-500" />
                        Audience engagement strategies
                      </li>
                      <li className="flex items-center gap-2">
                        <span className="w-1.5 h-1.5 rounded-full bg-violet-500" />
                        Monetization tips
                      </li>
                      <li className="flex items-center gap-2">
                        <span className="w-1.5 h-1.5 rounded-full bg-violet-500" />
                        Chat moderation guidance
                      </li>
                    </ul>
                  </div>

                  <div className="bg-gradient-to-br from-amber-500/10 to-orange-600/10 rounded-xl p-6 border border-amber-500/20">
                    <h4 className="font-semibold mb-2 flex items-center gap-2">
                      <Sparkles className="w-4 h-4 text-amber-400" />
                      AI Models Available
                    </h4>
                    <div className="space-y-2 text-sm">
                      <div className="flex justify-between">
                        <span>Gemini Flash</span>
                        <span className="text-muted-foreground">Fast & balanced</span>
                      </div>
                      <div className="flex justify-between">
                        <span>Gemini Pro</span>
                        <span className="text-muted-foreground">Advanced reasoning</span>
                      </div>
                      <div className="flex justify-between">
                        <span>GPT-5</span>
                        <span className="text-muted-foreground">Most intelligent</span>
                      </div>
                      <div className="flex justify-between">
                        <span>Claude Opus</span>
                        <span className="text-muted-foreground">Best analysis</span>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </TabsContent>

            <TabsContent value="ai-tools">
              <div className="grid lg:grid-cols-2 gap-6">
                <AIContentGenerator />
                
                <div className="space-y-6">
                  <div className="bg-gradient-to-br from-pink-500/10 to-rose-600/10 rounded-xl p-6 border border-pink-500/20">
                    <h3 className="font-semibold mb-4 flex items-center gap-2">
                      <Sparkles className="w-5 h-5 text-pink-400" />
                      AI Content Tools
                    </h3>
                    <p className="text-sm text-muted-foreground mb-4">
                      Generate professional content for your streams with AI assistance:
                    </p>
                    <div className="grid grid-cols-2 gap-3">
                      <div className="p-3 rounded-lg bg-background/50 border">
                        <h4 className="font-medium text-sm">Stream Titles</h4>
                        <p className="text-xs text-muted-foreground">Catchy titles that attract viewers</p>
                      </div>
                      <div className="p-3 rounded-lg bg-background/50 border">
                        <h4 className="font-medium text-sm">Descriptions</h4>
                        <p className="text-xs text-muted-foreground">Compelling stream descriptions</p>
                      </div>
                      <div className="p-3 rounded-lg bg-background/50 border">
                        <h4 className="font-medium text-sm">Social Posts</h4>
                        <p className="text-xs text-muted-foreground">Promote on social media</p>
                      </div>
                      <div className="p-3 rounded-lg bg-background/50 border">
                        <h4 className="font-medium text-sm">Hashtags</h4>
                        <p className="text-xs text-muted-foreground">Relevant tags for discovery</p>
                      </div>
                    </div>
                  </div>

                  <div className="bg-gradient-to-br from-cyan-500/10 to-blue-600/10 rounded-xl p-6 border border-cyan-500/20">
                    <h3 className="font-semibold mb-4">Pro Tips</h3>
                    <ul className="space-y-3 text-sm">
                      <li className="flex items-start gap-2">
                        <span className="w-5 h-5 rounded-full bg-cyan-500/20 flex items-center justify-center text-cyan-400 text-xs font-bold flex-shrink-0">1</span>
                        <span>Be specific about your stream topic for better results</span>
                      </li>
                      <li className="flex items-start gap-2">
                        <span className="w-5 h-5 rounded-full bg-cyan-500/20 flex items-center justify-center text-cyan-400 text-xs font-bold flex-shrink-0">2</span>
                        <span>Add context like your audience type or stream style</span>
                      </li>
                      <li className="flex items-start gap-2">
                        <span className="w-5 h-5 rounded-full bg-cyan-500/20 flex items-center justify-center text-cyan-400 text-xs font-bold flex-shrink-0">3</span>
                        <span>Generate multiple options and pick the best ones</span>
                      </li>
                      <li className="flex items-start gap-2">
                        <span className="w-5 h-5 rounded-full bg-cyan-500/20 flex items-center justify-center text-cyan-400 text-xs font-bold flex-shrink-0">4</span>
                        <span>Customize AI-generated content to match your voice</span>
                      </li>
                    </ul>
                  </div>
                </div>
              </div>
            </TabsContent>
          </Tabs>
        </div>
      </div>
    </div>
  );
}
