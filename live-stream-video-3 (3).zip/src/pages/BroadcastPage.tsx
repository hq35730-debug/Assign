import React, { useEffect, useRef, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Video, VideoOff, Mic, MicOff, Monitor, MonitorOff, Settings, Users, StopCircle, MessageSquare, UserPlus, Lock, Zap, Calendar, Loader2, AlertCircle, Palette, Rocket, Layout, LayoutGrid, Layers, Pickaxe, Sparkles, Camera, X } from 'lucide-react';
import { useStream } from '@/contexts/StreamContext';
import { useAuth } from '@/contexts/AuthContext';
import { LiveChat } from '@/components/LiveChat';
import { StreamChatOverlay } from '@/components/StreamChatOverlay';
import { RaidModal } from '@/components/RaidModal';
import { ScheduleCreator } from '@/components/ScheduleCreator';
import { VideoQualitySettings, VideoSettings } from '@/components/video/VideoQualitySettings';
import { VideoFilters, FilterSettings } from '@/components/video/VideoFilters';
import { SponsorPromotionModal } from '@/components/promotions/SponsorPromotionModal';
import { ActiveMiningIndicator } from '@/components/mining/ActiveMiningIndicator';
import { CrystalClearSettings, StreamQualitySettings } from '@/components/streaming/CrystalClearSettings';
import { supabase } from '@/lib/supabase';
import { useToast } from '@/hooks/use-toast';

type ChatMode = 'side' | 'overlay' | 'both' | 'hidden';
type StreamSource = 'camera' | 'screen' | 'both';

export default function BroadcastPage() {
  const navigate = useNavigate();
  const { user } = useAuth();
  const { toast } = useToast();
  const { currentStream, endStream, isStreaming, mediaStream, setMediaStream } = useStream();
  const videoRef = useRef<HTMLVideoElement>(null);
  const pipVideoRef = useRef<HTMLVideoElement>(null);
  const [videoEnabled, setVideoEnabled] = useState(true);
  const [audioEnabled, setAudioEnabled] = useState(true);
  const [cameraLoading, setCameraLoading] = useState(true);
  const [cameraError, setCameraError] = useState('');
  const [showModModal, setShowModModal] = useState(false);
  const [showRaidModal, setShowRaidModal] = useState(false);
  const [showScheduleModal, setShowScheduleModal] = useState(false);
  const [showQuality, setShowQuality] = useState(false);
  const [showFilters, setShowFilters] = useState(false);
  const [showPromo, setShowPromo] = useState(false);
  const [showCrystalClear, setShowCrystalClear] = useState(false);
  const [modUsername, setModUsername] = useState('');
  const [subOnlyMode, setSubOnlyMode] = useState(false);
  const [raidTarget, setRaidTarget] = useState<any>(null);
  const [raidCountdown, setRaidCountdown] = useState<number | null>(null);
  const [videoSettings, setVideoSettings] = useState<VideoSettings>({ resolution: '1080p', bitrate: 8000, frameRate: 60, hdrEnabled: false, lowLatency: true, adaptiveQuality: true });
  const [filterSettings, setFilterSettings] = useState<FilterSettings>({ brightness: 100, contrast: 100, saturation: 100, preset: 'none', beautyMode: 0, backgroundBlur: 0 });
  const [chatMode, setChatMode] = useState<ChatMode>('overlay');
  const [showChatModeMenu, setShowChatModeMenu] = useState(false);
  const [crystalClearEnabled, setCrystalClearEnabled] = useState(false);
  const [streamQualitySettings, setStreamQualitySettings] = useState<StreamQualitySettings | null>(null);
  
  // Screen sharing state
  const [screenStream, setScreenStream] = useState<MediaStream | null>(null);
  const [isScreenSharing, setIsScreenSharing] = useState(false);
  const [streamSource, setStreamSource] = useState<StreamSource>('camera');
  const [cameraStream, setCameraStream] = useState<MediaStream | null>(null);
  const [showScreenShareMenu, setShowScreenShareMenu] = useState(false);
  const [pipPosition, setPipPosition] = useState<'top-left' | 'top-right' | 'bottom-left' | 'bottom-right'>('bottom-right');
  const [isDraggingPip, setIsDraggingPip] = useState(false);
  
  // Mining state
  const [miningSession, setMiningSession] = useState<any>(null);
  const [miningActive, setMiningActive] = useState(false);

  const getFilterStyle = () => ({ filter: `brightness(${filterSettings.brightness}%) contrast(${filterSettings.contrast}%) saturate(${filterSettings.saturation}%)` });

  useEffect(() => { if (!user || !isStreaming) navigate('/'); }, [user, isStreaming, navigate]);

  // Auto-start mining when stream starts
  useEffect(() => {
    if (isStreaming && currentStream && user?.user_id && !miningActive) {
      startMining();
    }
  }, [isStreaming, currentStream, user?.user_id]);

  // Update mining progress periodically
  useEffect(() => {
    if (!miningActive || !miningSession) return;

    const interval = setInterval(async () => {
      try {
        const { data } = await supabase.functions.invoke('mining-manager', {
          body: {
            action: 'update_mining',
            user_id: user?.user_id,
            viewer_count: currentStream?.viewer_count || 0
          }
        });
        if (data) {
          setMiningSession((prev: any) => ({
            ...prev,
            coins_mined: data.coins_mined,
            blocks_mined: data.blocks_mined,
            duration_minutes: data.duration_minutes
          }));
        }
      } catch (error) {
        console.error('Failed to update mining:', error);
      }
    }, 60000);

    return () => clearInterval(interval);
  }, [miningActive, miningSession, currentStream?.viewer_count]);

  const startMining = async () => {
    if (!user?.user_id || !currentStream) return;
    
    try {
      const { data, error } = await supabase.functions.invoke('mining-manager', {
        body: {
          action: 'start_mining',
          user_id: user.user_id,
          stream_id: currentStream.id
        }
      });

      if (data?.success) {
        setMiningSession(data.session);
        setMiningActive(true);
        toast({ 
          title: 'Mining Started!', 
          description: 'You are now mining StreamCoin while streaming!' 
        });
      } else if (data?.session) {
        setMiningSession(data.session);
        setMiningActive(true);
      }
    } catch (error) {
      console.error('Failed to start mining:', error);
    }
  };

  const stopMining = async () => {
    if (!user?.user_id || !miningActive) return;

    try {
      const { data } = await supabase.functions.invoke('mining-manager', {
        body: { action: 'stop_mining', user_id: user.user_id }
      });

      if (data?.success) {
        setMiningActive(false);
        setMiningSession(null);
        toast({
          title: 'Mining Complete!',
          description: `You earned ${data.rewards.total.toFixed(8)} STC`
        });
      }
    } catch (error) {
      console.error('Failed to stop mining:', error);
    }
  };

  // Initialize camera stream
  useEffect(() => {
    const attachStream = async () => {
      if (!videoRef.current) return;
      setCameraLoading(true); 
      setCameraError('');
      
      if (mediaStream) { 
        try { 
          // Store camera stream reference
          setCameraStream(mediaStream);
          videoRef.current.srcObject = mediaStream; 
          await videoRef.current.play(); 
          setCameraLoading(false); 
          return; 
        } catch {} 
      }
      
      try { 
        const stream = await navigator.mediaDevices.getUserMedia({ video: true, audio: true }); 
        setMediaStream(stream);
        setCameraStream(stream);
        if (videoRef.current) { 
          videoRef.current.srcObject = stream; 
          await videoRef.current.play(); 
        } 
        setCameraLoading(false); 
      } catch (err: any) { 
        setCameraError(err.name === 'NotAllowedError' ? 'Camera access denied' : 'Camera error'); 
        setCameraLoading(false); 
      }
    };
    if (isStreaming) attachStream();
  }, [isStreaming, mediaStream, setMediaStream]);

  // Handle PiP video for camera when screen sharing
  useEffect(() => {
    if (pipVideoRef.current && cameraStream && isScreenSharing && streamSource === 'both') {
      pipVideoRef.current.srcObject = cameraStream;
      pipVideoRef.current.play().catch(() => {});
    }
  }, [cameraStream, isScreenSharing, streamSource]);

  useEffect(() => { 
    if (raidCountdown !== null && raidCountdown > 0) { 
      const t = setTimeout(() => setRaidCountdown(raidCountdown - 1), 1000); 
      return () => clearTimeout(t); 
    } else if (raidCountdown === 0 && raidTarget) {
      handleEndStreamWithRaid(); 
    }
  }, [raidCountdown, raidTarget]);

  // Start screen sharing
  const startScreenShare = async (withCamera: boolean = false) => {
    try {
      const displayStream = await navigator.mediaDevices.getDisplayMedia({
        video: {
          cursor: 'always',
          displaySurface: 'monitor'
        } as any,
        audio: {
          echoCancellation: true,
          noiseSuppression: true,
          sampleRate: 44100
        }
      });

      // Handle when user stops sharing via browser controls
      displayStream.getVideoTracks()[0].onended = () => {
        stopScreenShare();
      };

      setScreenStream(displayStream);
      setIsScreenSharing(true);
      setStreamSource(withCamera ? 'both' : 'screen');

      // Switch main video to screen share
      if (videoRef.current) {
        videoRef.current.srcObject = displayStream;
        await videoRef.current.play();
      }

      // If showing camera too, set up PiP
      if (withCamera && cameraStream) {
        // Camera will be shown in PiP overlay
      }

      toast({
        title: 'Screen Sharing Started',
        description: withCamera ? 'Sharing screen with camera overlay' : 'Sharing your screen with viewers'
      });

      setShowScreenShareMenu(false);
    } catch (err: any) {
      if (err.name !== 'AbortError') {
        toast({
          title: 'Screen Share Failed',
          description: err.message || 'Could not start screen sharing',
          variant: 'destructive'
        });
      }
    }
  };

  // Stop screen sharing
  const stopScreenShare = async () => {
    if (screenStream) {
      screenStream.getTracks().forEach(track => track.stop());
      setScreenStream(null);
    }

    setIsScreenSharing(false);
    setStreamSource('camera');

    // Switch back to camera
    if (videoRef.current && cameraStream) {
      videoRef.current.srcObject = cameraStream;
      await videoRef.current.play();
    }

    toast({
      title: 'Screen Sharing Stopped',
      description: 'Switched back to camera'
    });
  };

  // Toggle screen share
  const toggleScreenShare = () => {
    if (isScreenSharing) {
      stopScreenShare();
    } else {
      setShowScreenShareMenu(true);
    }
  };

  // Switch between screen only and screen + camera
  const togglePipCamera = () => {
    if (streamSource === 'screen') {
      setStreamSource('both');
    } else if (streamSource === 'both') {
      setStreamSource('screen');
    }
  };

  // Cycle PiP position
  const cyclePipPosition = () => {
    const positions: typeof pipPosition[] = ['bottom-right', 'bottom-left', 'top-left', 'top-right'];
    const currentIndex = positions.indexOf(pipPosition);
    setPipPosition(positions[(currentIndex + 1) % positions.length]);
  };

  const getPipPositionClasses = () => {
    switch (pipPosition) {
      case 'top-left': return 'top-4 left-4';
      case 'top-right': return 'top-4 right-4';
      case 'bottom-left': return 'bottom-20 left-4';
      case 'bottom-right': return 'bottom-20 right-4';
    }
  };

  const toggleVideo = () => { 
    if (cameraStream) { 
      cameraStream.getVideoTracks().forEach(t => t.enabled = !videoEnabled); 
      setVideoEnabled(!videoEnabled); 
    } 
  };
  
  const toggleAudio = () => { 
    // Toggle audio on both camera and screen streams
    if (cameraStream) { 
      cameraStream.getAudioTracks().forEach(t => t.enabled = !audioEnabled); 
    }
    if (screenStream) {
      screenStream.getAudioTracks().forEach(t => t.enabled = !audioEnabled);
    }
    setAudioEnabled(!audioEnabled); 
  };
  
  const toggleSubOnlyMode = async () => { 
    if (!currentStream) return; 
    await supabase.from('live_streams').update({ sub_only_chat: !subOnlyMode }).eq('id', currentStream.id); 
    setSubOnlyMode(!subOnlyMode); 
  };
  
  const handleRaid = (target: any) => { setRaidTarget(target); setRaidCountdown(10); };
  const cancelRaid = () => { setRaidTarget(null); setRaidCountdown(null); };
  
  const handleEndStreamWithRaid = async () => { 
    await stopMining();
    if (screenStream) {
      screenStream.getTracks().forEach(track => track.stop());
    }
    await endStream(); 
    if (raidTarget) navigate(`/watch/${raidTarget.id}`); 
    else navigate('/'); 
  };
  
  const handleEndStream = async () => { 
    await stopMining();
    if (screenStream) {
      screenStream.getTracks().forEach(track => track.stop());
    }
    await endStream(); 
    navigate('/'); 
  };
  
  const addModerator = async () => { 
    if (!modUsername.trim() || !currentStream || !user) return; 
    const { data } = await supabase.from('profiles').select('user_id').eq('username', modUsername.trim()).single(); 
    if (data) { 
      await supabase.functions.invoke('chat-manager', { 
        body: { action: 'add_moderator', stream_id: currentStream.id, user_id: user.user_id, target_user_id: data.user_id } 
      }); 
      setModUsername(''); 
      setShowModModal(false); 
    } 
  };

  const handleCrystalClearApply = (settings: StreamQualitySettings) => {
    setStreamQualitySettings(settings);
    setCrystalClearEnabled(settings.mode === 'crystal_clear');
    
    setVideoSettings(prev => ({
      ...prev,
      resolution: settings.resolution,
      bitrate: settings.bitrate,
      frameRate: settings.frameRate,
      hdrEnabled: settings.hdr,
      lowLatency: settings.lowLatency,
      adaptiveQuality: settings.adaptiveBitrate
    }));

    toast({
      title: settings.mode === 'crystal_clear' ? 'Crystal Clear Enabled!' : 'Quality Settings Applied',
      description: `Streaming at ${settings.resolution} @ ${settings.frameRate}fps with ${(settings.bitrate / 1000).toFixed(1)} Mbps`
    });
  };

  const showSideChat = chatMode === 'side' || chatMode === 'both';
  const showOverlayChat = chatMode === 'overlay' || chatMode === 'both';

  const cycleChatMode = () => {
    const modes: ChatMode[] = ['overlay', 'both', 'side', 'hidden'];
    const currentIndex = modes.indexOf(chatMode);
    setChatMode(modes[(currentIndex + 1) % modes.length]);
  };

  const getChatModeIcon = () => {
    switch (chatMode) {
      case 'both': return <LayoutGrid className="w-6 h-6 text-white" />;
      case 'side': return <Layout className="w-6 h-6 text-white" />;
      case 'overlay': return <Layers className="w-6 h-6 text-white" />;
      case 'hidden': return <MessageSquare className="w-6 h-6 text-white opacity-50" />;
    }
  };

  const getChatModeLabel = () => {
    switch (chatMode) {
      case 'both': return 'Both Chats';
      case 'side': return 'Side Chat';
      case 'overlay': return 'Stream Overlay';
      case 'hidden': return 'Chat Hidden';
    }
  };

  if (!currentStream) return null;

  return (
    <div className="min-h-screen bg-[#1a1a2e] flex">
      <VideoQualitySettings isOpen={showQuality} onClose={() => setShowQuality(false)} onApply={setVideoSettings} />
      <VideoFilters isOpen={showFilters} onClose={() => setShowFilters(false)} onApply={setFilterSettings} />
      <SponsorPromotionModal isOpen={showPromo} onClose={() => setShowPromo(false)} contentType="stream" contentId={currentStream.id} contentTitle={currentStream.title} onSubmit={(c) => console.log('Promo:', c)} />
      <CrystalClearSettings 
        isOpen={showCrystalClear} 
        onClose={() => setShowCrystalClear(false)} 
        onApply={handleCrystalClearApply}
        currentSettings={streamQualitySettings || undefined}
      />
      
      <div className={`flex-1 flex flex-col ${showSideChat ? '' : 'w-full'}`}>
        {/* Header */}
        <div className="bg-[#16213e] border-b border-gray-800 p-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-3 h-3 bg-red-500 rounded-full animate-pulse" />
            <span className="text-white font-semibold">LIVE</span>
            <span className="text-gray-400">|</span>
            <span className="text-white">{currentStream.title}</span>
            
            {/* Screen Share Indicator */}
            {isScreenSharing && (
              <>
                <span className="text-gray-400">|</span>
                <div className="flex items-center gap-2 bg-gradient-to-r from-blue-500/20 to-cyan-500/20 px-3 py-1 rounded-full border border-blue-500/30">
                  <Monitor className="w-4 h-4 text-blue-400" />
                  <span className="text-blue-300 text-sm font-medium">Screen Sharing</span>
                </div>
              </>
            )}
            
            {/* Crystal Clear Indicator */}
            {crystalClearEnabled && (
              <>
                <span className="text-gray-400">|</span>
                <div className="flex items-center gap-2 bg-gradient-to-r from-purple-500/20 to-pink-500/20 px-3 py-1 rounded-full border border-purple-500/30">
                  <Sparkles className="w-4 h-4 text-purple-400" />
                  <span className="text-purple-300 text-sm font-medium">Crystal Clear</span>
                </div>
              </>
            )}
            
            {/* Mining Indicator */}
            {miningActive && (
              <>
                <span className="text-gray-400">|</span>
                <div className="flex items-center gap-2 bg-amber-500/20 px-3 py-1 rounded-full">
                  <Pickaxe className="w-4 h-4 text-amber-400 animate-bounce" />
                  <span className="text-amber-400 text-sm font-medium">Mining STC</span>
                </div>
              </>
            )}
          </div>
          <div className="flex items-center gap-2">
            <div className="flex items-center gap-2 text-gray-300 mr-2">
              <Users className="w-5 h-5" />
              <span>{currentStream.viewer_count}</span>
            </div>
            <button onClick={() => setShowPromo(true)} className="bg-gradient-to-r from-yellow-500 to-orange-500 text-white px-3 py-2 rounded-lg flex items-center gap-2 text-sm">
              <Rocket className="w-4 h-4" /> Promote
            </button>
            <button onClick={() => setShowScheduleModal(true)} className="bg-blue-600 hover:bg-blue-700 text-white px-3 py-2 rounded-lg flex items-center gap-2 text-sm">
              <Calendar className="w-4 h-4" />
            </button>
            <button onClick={() => setShowModModal(true)} className="bg-green-600 hover:bg-green-700 text-white px-3 py-2 rounded-lg flex items-center gap-2 text-sm">
              <UserPlus className="w-4 h-4" />
            </button>
            <button onClick={() => setShowRaidModal(true)} className="bg-yellow-600 hover:bg-yellow-700 text-white px-3 py-2 rounded-lg flex items-center gap-2 text-sm">
              <Zap className="w-4 h-4" />
            </button>
            <button onClick={handleEndStream} className="bg-red-600 hover:bg-red-700 text-white px-4 py-2 rounded-lg flex items-center gap-2">
              <StopCircle className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Mining Status Bar */}
        {miningActive && miningSession && (
          <div className="px-4 py-2 bg-gradient-to-r from-amber-500/10 to-orange-500/10 border-b border-amber-500/20">
            <ActiveMiningIndicator session={miningSession} currencySymbol="STC" />
          </div>
        )}

        {/* Video Preview with Stream Chat Overlay */}
        <div className="flex-1 relative bg-black" style={getFilterStyle()}>
          <video 
            ref={videoRef} 
            autoPlay 
            muted 
            playsInline 
            className={`w-full h-full object-contain ${cameraLoading || cameraError ? 'hidden' : ''}`} 
          />
          
          {/* Picture-in-Picture Camera Overlay when Screen Sharing */}
          {isScreenSharing && streamSource === 'both' && cameraStream && (
            <div 
              className={`absolute ${getPipPositionClasses()} z-20 group cursor-move`}
              onClick={cyclePipPosition}
            >
              <div className="relative">
                <video 
                  ref={pipVideoRef}
                  autoPlay 
                  muted 
                  playsInline 
                  className="w-48 h-36 object-cover rounded-xl border-2 border-purple-500 shadow-lg"
                />
                <div className="absolute inset-0 bg-black/50 opacity-0 group-hover:opacity-100 transition-opacity rounded-xl flex items-center justify-center">
                  <span className="text-white text-xs">Click to move</span>
                </div>
                <button 
                  onClick={(e) => { e.stopPropagation(); togglePipCamera(); }}
                  className="absolute -top-2 -right-2 bg-red-500 hover:bg-red-600 text-white rounded-full p-1 opacity-0 group-hover:opacity-100 transition-opacity"
                >
                  <X className="w-3 h-3" />
                </button>
                <div className="absolute bottom-1 left-1 bg-black/70 px-2 py-0.5 rounded text-xs text-white flex items-center gap-1">
                  <Camera className="w-3 h-3" />
                  Camera
                </div>
              </div>
            </div>
          )}
          
          {cameraLoading && (
            <div className="absolute inset-0 flex flex-col items-center justify-center">
              <Loader2 className="w-12 h-12 text-purple-400 animate-spin mb-3" />
              <p className="text-gray-400">Connecting...</p>
            </div>
          )}
          
          {cameraError && !cameraLoading && (
            <div className="absolute inset-0 flex flex-col items-center justify-center">
              <AlertCircle className="w-12 h-12 text-red-400 mb-3" />
              <p className="text-red-400">{cameraError}</p>
            </div>
          )}
          
          {!cameraLoading && !cameraError && !videoEnabled && !isScreenSharing && (
            <div className="absolute inset-0 flex items-center justify-center bg-gray-900">
              <VideoOff className="w-20 h-20 text-gray-600" />
            </div>
          )}
          
          {/* Raid Countdown Overlay */}
          {raidCountdown !== null && (
            <div className="absolute inset-0 bg-black/80 flex items-center justify-center z-30">
              <div className="text-center">
                <Zap className="w-16 h-16 text-yellow-400 mx-auto mb-4 animate-bounce" />
                <p className="text-2xl text-white font-bold mb-2">Raiding {raidTarget?.streamer_name}</p>
                <p className="text-6xl text-yellow-400 font-bold mb-4">{raidCountdown}</p>
                <button onClick={cancelRaid} className="px-6 py-2 bg-red-600 text-white rounded-lg">Cancel</button>
              </div>
            </div>
          )}

          {/* Stream Chat Overlay */}
          {showOverlayChat && (
            <StreamChatOverlay
              streamId={currentStream.id}
              streamerId={currentStream.user_id}
              isStreamer={true}
              showInput={true}
            />
          )}

          {/* Video Info Overlay */}
          <div className="absolute top-4 right-4 bg-black/70 px-3 py-2 rounded-lg text-xs text-white flex items-center gap-3 z-10 pointer-events-none">
            {isScreenSharing && <Monitor className="w-4 h-4 text-blue-400" />}
            {crystalClearEnabled && <Sparkles className="w-4 h-4 text-purple-400" />}
            <span>{videoSettings.resolution} • {videoSettings.frameRate}fps</span>
            {filterSettings.preset !== 'none' && (
              <span className="text-purple-400">Filter: {filterSettings.preset}</span>
            )}
          </div>

          {/* Chat Mode Indicator */}
          <div className="absolute top-4 left-4 bg-black/70 px-3 py-2 rounded-lg text-xs text-white flex items-center gap-2 z-10 pointer-events-none">
            <MessageSquare className="w-4 h-4 text-purple-400" />
            <span>{getChatModeLabel()}</span>
          </div>
        </div>

        {/* Controls */}
        <div className="bg-[#16213e] border-t border-gray-800 p-4 flex items-center justify-center gap-3 flex-wrap">
          <button 
            onClick={toggleVideo} 
            className={`p-4 rounded-full ${videoEnabled ? 'bg-gray-700 hover:bg-gray-600' : 'bg-red-600'}`} 
            title={videoEnabled ? 'Turn off camera' : 'Turn on camera'}
          >
            {videoEnabled ? <Video className="w-6 h-6 text-white" /> : <VideoOff className="w-6 h-6 text-white" />}
          </button>
          
          <button 
            onClick={toggleAudio} 
            className={`p-4 rounded-full ${audioEnabled ? 'bg-gray-700 hover:bg-gray-600' : 'bg-red-600'}`} 
            title={audioEnabled ? 'Mute microphone' : 'Unmute microphone'}
          >
            {audioEnabled ? <Mic className="w-6 h-6 text-white" /> : <MicOff className="w-6 h-6 text-white" />}
          </button>
          
          {/* Screen Share Button with Menu */}
          <div className="relative">
            <button 
              onClick={toggleScreenShare}
              className={`p-4 rounded-full ${isScreenSharing ? 'bg-gradient-to-r from-blue-600 to-cyan-600' : 'bg-gray-700 hover:bg-gray-600'}`} 
              title={isScreenSharing ? 'Stop screen sharing' : 'Share screen'}
            >
              {isScreenSharing ? <MonitorOff className="w-6 h-6 text-white" /> : <Monitor className="w-6 h-6 text-white" />}
            </button>
            
            {/* Screen Share Options Menu */}
            {showScreenShareMenu && (
              <div className="absolute bottom-full mb-2 left-1/2 -translate-x-1/2 bg-[#16213e] border border-gray-700 rounded-lg shadow-xl overflow-hidden z-50 min-w-[220px]">
                <div className="px-4 py-2 border-b border-gray-700">
                  <span className="text-white text-sm font-medium">Share Screen</span>
                </div>
                <button
                  onClick={() => startScreenShare(false)}
                  className="w-full px-4 py-3 flex items-center gap-3 text-left text-gray-300 hover:bg-gray-700"
                >
                  <Monitor className="w-5 h-5 text-blue-400" />
                  <div>
                    <div className="text-sm font-medium">Screen Only</div>
                    <div className="text-xs opacity-70">Share your screen without camera</div>
                  </div>
                </button>
                <button
                  onClick={() => startScreenShare(true)}
                  className="w-full px-4 py-3 flex items-center gap-3 text-left text-gray-300 hover:bg-gray-700"
                >
                  <div className="relative">
                    <Monitor className="w-5 h-5 text-blue-400" />
                    <Camera className="w-3 h-3 text-purple-400 absolute -bottom-1 -right-1" />
                  </div>
                  <div>
                    <div className="text-sm font-medium">Screen + Camera</div>
                    <div className="text-xs opacity-70">Picture-in-picture with your camera</div>
                  </div>
                </button>
                <button
                  onClick={() => setShowScreenShareMenu(false)}
                  className="w-full px-4 py-2 text-center text-gray-400 hover:text-white text-sm border-t border-gray-700"
                >
                  Cancel
                </button>
              </div>
            )}
          </div>
          
          {/* Toggle PiP Camera when screen sharing */}
          {isScreenSharing && (
            <button 
              onClick={togglePipCamera}
              className={`p-4 rounded-full ${streamSource === 'both' ? 'bg-purple-600' : 'bg-gray-700 hover:bg-gray-600'}`}
              title={streamSource === 'both' ? 'Hide camera overlay' : 'Show camera overlay'}
            >
              <Camera className="w-6 h-6 text-white" />
            </button>
          )}
          
          <button 
            onClick={toggleSubOnlyMode} 
            className={`p-4 rounded-full ${subOnlyMode ? 'bg-purple-600' : 'bg-gray-700 hover:bg-gray-600'}`} 
            title={subOnlyMode ? 'Disable subscriber-only mode' : 'Enable subscriber-only mode'}
          >
            <Lock className="w-6 h-6 text-white" />
          </button>
          
          {/* Crystal Clear Button */}
          <button 
            onClick={() => setShowCrystalClear(true)}
            className={`p-4 rounded-full ${crystalClearEnabled ? 'bg-gradient-to-r from-purple-600 to-pink-600' : 'bg-gray-700 hover:bg-gray-600'}`}
            title="Crystal Clear Streaming Settings"
          >
            <Sparkles className={`w-6 h-6 text-white ${crystalClearEnabled ? 'animate-pulse' : ''}`} />
          </button>
          
          {/* Mining Toggle Button */}
          <button 
            onClick={miningActive ? stopMining : startMining}
            className={`p-4 rounded-full ${miningActive ? 'bg-gradient-to-r from-amber-500 to-orange-500' : 'bg-gray-700 hover:bg-gray-600'}`}
            title={miningActive ? 'Stop mining' : 'Start mining'}
          >
            <Pickaxe className={`w-6 h-6 text-white ${miningActive ? 'animate-bounce' : ''}`} />
          </button>
          
          {/* Chat Mode Toggle */}
          <div className="relative">
            <button 
              onClick={cycleChatMode}
              onContextMenu={(e) => { e.preventDefault(); setShowChatModeMenu(!showChatModeMenu); }}
              className={`p-4 rounded-full ${chatMode !== 'hidden' ? 'bg-purple-600' : 'bg-gray-700 hover:bg-gray-600'}`}
              title={`Chat: ${getChatModeLabel()} (right-click for options)`}
            >
              {getChatModeIcon()}
            </button>
            
            {showChatModeMenu && (
              <div className="absolute bottom-full mb-2 left-1/2 -translate-x-1/2 bg-[#16213e] border border-gray-700 rounded-lg shadow-xl overflow-hidden z-50">
                {[
                  { mode: 'overlay' as ChatMode, label: 'Stream Overlay', icon: <Layers className="w-4 h-4" />, desc: 'Chat scrolls over video' },
                  { mode: 'both' as ChatMode, label: 'Both Chats', icon: <LayoutGrid className="w-4 h-4" />, desc: 'Overlay + Side panel' },
                  { mode: 'side' as ChatMode, label: 'Side Chat', icon: <Layout className="w-4 h-4" />, desc: 'Traditional sidebar' },
                  { mode: 'hidden' as ChatMode, label: 'Hide Chat', icon: <MessageSquare className="w-4 h-4 opacity-50" />, desc: 'No chat visible' },
                ].map((option) => (
                  <button
                    key={option.mode}
                    onClick={() => { setChatMode(option.mode); setShowChatModeMenu(false); }}
                    className={`w-full px-4 py-3 flex items-center gap-3 text-left ${chatMode === option.mode ? 'bg-purple-600 text-white' : 'text-gray-300 hover:bg-gray-700'}`}
                  >
                    {option.icon}
                    <div>
                      <div className="text-sm font-medium">{option.label}</div>
                      <div className="text-xs opacity-70">{option.desc}</div>
                    </div>
                  </button>
                ))}
              </div>
            )}
          </div>

          <button onClick={() => setShowQuality(true)} className="p-4 rounded-full bg-gray-700 hover:bg-gray-600" title="Quality settings">
            <Settings className="w-6 h-6 text-white" />
          </button>
          <button onClick={() => setShowFilters(true)} className="p-4 rounded-full bg-gradient-to-r from-pink-600 to-purple-600" title="Video filters">
            <Palette className="w-6 h-6 text-white" />
          </button>
        </div>
      </div>

      {/* Side Chat Panel */}
      {showSideChat && (
        <div className="w-80 bg-[#16213e] border-l border-gray-800 flex flex-col">
          <div className="p-4 border-b border-gray-800 flex items-center justify-between">
            <h3 className="text-white font-semibold flex items-center gap-2">
              <MessageSquare className="w-5 h-5" /> Live Chat
            </h3>
            {subOnlyMode && (
              <span className="text-xs bg-purple-600/30 text-purple-400 px-2 py-1 rounded flex items-center gap-1">
                <Lock className="w-3 h-3" /> Sub Only
              </span>
            )}
          </div>
          <LiveChat 
            streamId={currentStream.id} 
            streamerId={currentStream.user_id} 
            isStreamer={true} 
            subOnlyMode={subOnlyMode} 
            onToggleSubOnly={toggleSubOnlyMode} 
          />
        </div>
      )}

      {/* Moderator Modal */}
      {showModModal && (
        <div className="fixed inset-0 bg-black/70 flex items-center justify-center z-50">
          <div className="bg-[#16213e] rounded-xl p-6 w-96">
            <h3 className="text-white text-lg font-semibold mb-4">Add Moderator</h3>
            <input 
              value={modUsername} 
              onChange={(e) => setModUsername(e.target.value)} 
              placeholder="Username" 
              className="w-full bg-[#1a1a2e] text-white px-4 py-2 rounded-lg border border-gray-700 mb-4" 
            />
            <div className="flex gap-3">
              <button onClick={() => setShowModModal(false)} className="flex-1 py-2 bg-gray-700 text-white rounded-lg">Cancel</button>
              <button onClick={addModerator} className="flex-1 py-2 bg-green-600 text-white rounded-lg">Add</button>
            </div>
          </div>
        </div>
      )}

      <RaidModal isOpen={showRaidModal} onClose={() => setShowRaidModal(false)} currentStreamerId={user?.user_id || ''} currentStreamerName={user?.display_name || user?.username || ''} viewerCount={currentStream.viewer_count} onRaid={handleRaid} />
      <ScheduleCreator channelId={user?.user_id || ''} isOpen={showScheduleModal} onClose={() => setShowScheduleModal(false)} onCreated={() => setShowScheduleModal(false)} />
    </div>
  );
}
