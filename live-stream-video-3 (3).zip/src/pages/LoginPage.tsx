import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '@/contexts/AuthContext';
import { useToast } from '@/hooks/use-toast';
import { Eye, EyeOff, Mail, Lock, Loader2, CheckCircle, Smartphone, MessageSquare, Phone, ArrowLeft } from 'lucide-react';
import { supabase } from '@/lib/supabase';

export default function LoginPage() {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const [success, setSuccess] = useState(false);
  const [showSMSRecovery, setShowSMSRecovery] = useState(false);
  const [recoveryEmail, setRecoveryEmail] = useState('');
  const [recoveryPhone, setRecoveryPhone] = useState('');
  const [recoverySending, setRecoverySending] = useState(false);
  const [recoveryResult, setRecoveryResult] = useState<{ success: boolean; message: string } | null>(null);
  const { signIn } = useAuth();
  const { toast } = useToast();
  const navigate = useNavigate();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setLoading(true);
    
    const result = await signIn(email, password);
    
    setLoading(false);
    
    if (result.error) {
      setError(result.error);
      toast({
        title: "Login Failed",
        description: result.error,
        variant: "destructive",
      });
    } else {
      setSuccess(true);
      toast({
        title: "Welcome Back!",
        description: "You have been signed in successfully.",
      });
      
      setTimeout(() => {
        navigate('/');
      }, 1000);
    }
  };

  const formatPhoneInput = (value: string) => {
    const digits = value.replace(/\D/g, '');
    if (digits.length === 0) return '';
    if (digits.length <= 1) return `+${digits}`;
    if (digits.length <= 4) return `+${digits.slice(0, 1)} (${digits.slice(1)}`;
    if (digits.length <= 7) return `+${digits.slice(0, 1)} (${digits.slice(1, 4)}) ${digits.slice(4)}`;
    return `+${digits.slice(0, 1)} (${digits.slice(1, 4)}) ${digits.slice(4, 7)}-${digits.slice(7, 11)}`;
  };

  const getRawPhoneNumber = (formatted: string) => {
    const digits = formatted.replace(/\D/g, '');
    return `+${digits}`;
  };

  const handleSMSRecovery = async () => {
    if (!recoveryEmail || !recoveryPhone) return;
    
    setRecoverySending(true);
    setRecoveryResult(null);

    try {
      // Look up the user by email first
      const { data: profile, error: profileError } = await supabase
        .from('profiles')
        .select('user_id, username, email, unique_id, phone_number')
        .eq('email', recoveryEmail.toLowerCase().trim())
        .single();

      if (profileError || !profile) {
        setRecoveryResult({ success: false, message: 'No account found with that email address.' });
        setRecoverySending(false);
        return;
      }

      // Send the sign-in info via SMS
      const rawPhone = getRawPhoneNumber(recoveryPhone);
      const loginUrl = `${window.location.origin}/login`;

      const { data, error } = await supabase.functions.invoke('phone-manager', {
        body: {
          action: 'send_signin_sms',
          user_id: profile.user_id,
          to_number: rawPhone,
          login_url: loginUrl
        }
      });

      if (error) throw error;

      if (data?.success) {
        setRecoveryResult({ 
          success: true, 
          message: 'Your sign-in information has been sent via SMS! Check your phone.' 
        });
      } else {
        setRecoveryResult({ 
          success: false, 
          message: data?.error || 'Failed to send SMS. Please check the phone number and try again.' 
        });
      }
    } catch (err: any) {
      setRecoveryResult({ 
        success: false, 
        message: err.message || 'An error occurred. Please try again.' 
      });
    } finally {
      setRecoverySending(false);
    }
  };

  return (
    <div className="min-h-screen bg-[#1a1a2e] flex items-center justify-center px-4">
      <div className="w-full max-w-md">
        <div className="text-center mb-8">
          <Link to="/" className="text-4xl font-bold bg-gradient-to-r from-purple-500 to-pink-500 bg-clip-text text-transparent">
            Assigned
          </Link>
          <p className="text-gray-400 mt-2">Welcome back! Sign in to continue</p>
        </div>

        <div className="bg-[#16213e] rounded-2xl p-8 border border-gray-800">
          {success ? (
            <div className="text-center py-8">
              <div className="w-20 h-20 bg-green-500/20 rounded-full flex items-center justify-center mx-auto mb-4">
                <CheckCircle className="w-12 h-12 text-green-500" />
              </div>
              <h2 className="text-2xl font-bold text-white mb-2">Welcome Back!</h2>
              <p className="text-gray-400 mb-4">You have been signed in successfully.</p>
              <p className="text-gray-500 text-sm">Redirecting you to the homepage...</p>
              <div className="mt-4">
                <Loader2 className="w-6 h-6 text-purple-500 animate-spin mx-auto" />
              </div>
            </div>
          ) : showSMSRecovery ? (
            /* SMS Recovery View */
            <div>
              <button
                onClick={() => {
                  setShowSMSRecovery(false);
                  setRecoveryResult(null);
                }}
                className="flex items-center gap-2 text-gray-400 hover:text-white text-sm mb-6 transition-colors"
              >
                <ArrowLeft className="w-4 h-4" />
                Back to Sign In
              </button>

              <div className="flex items-center gap-3 mb-6">
                <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-green-500 to-emerald-600 flex items-center justify-center">
                  <Smartphone className="w-5 h-5 text-white" />
                </div>
                <div>
                  <h2 className="text-xl font-bold text-white">Get Sign-In Info via SMS</h2>
                  <p className="text-gray-400 text-xs">We'll text your account details to your phone</p>
                </div>
              </div>

              {/* Info Banner */}
              <div className="bg-gradient-to-r from-blue-500/10 to-cyan-500/10 rounded-xl p-4 mb-6 border border-blue-500/20">
                <p className="text-blue-300 text-xs">
                  Enter the email associated with your account and a phone number where you'd like to receive your sign-in credentials.
                </p>
              </div>

              <div className="space-y-4">
                <div>
                  <label className="text-gray-300 text-sm mb-2 block">Account Email</label>
                  <div className="relative">
                    <Mail className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-500" />
                    <input
                      type="email"
                      value={recoveryEmail}
                      onChange={(e) => { setRecoveryEmail(e.target.value); setRecoveryResult(null); }}
                      className="w-full bg-[#1a1a2e] text-white pl-11 pr-4 py-3 rounded-lg border border-gray-700 focus:border-green-500 focus:outline-none transition-colors"
                      placeholder="your@email.com"
                      disabled={recoverySending}
                    />
                  </div>
                </div>

                <div>
                  <label className="text-gray-300 text-sm mb-2 block">Send To Phone Number</label>
                  <div className="relative">
                    <Phone className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-500" />
                    <input
                      type="tel"
                      value={recoveryPhone}
                      onChange={(e) => { setRecoveryPhone(formatPhoneInput(e.target.value)); setRecoveryResult(null); }}
                      className="w-full bg-[#1a1a2e] text-white pl-11 pr-4 py-3 rounded-lg border border-gray-700 focus:border-green-500 focus:outline-none transition-colors font-mono"
                      placeholder="+1 (555) 123-4567"
                      disabled={recoverySending}
                    />
                  </div>
                  <p className="text-gray-500 text-xs mt-1">Enter the phone number where you want to receive your credentials</p>
                </div>

                {/* Result */}
                {recoveryResult && (
                  <div className={`flex items-start gap-3 p-4 rounded-xl ${
                    recoveryResult.success 
                      ? 'bg-green-500/10 border border-green-500/20' 
                      : 'bg-red-500/10 border border-red-500/20'
                  }`}>
                    {recoveryResult.success ? (
                      <CheckCircle className="w-5 h-5 text-green-400 mt-0.5 flex-shrink-0" />
                    ) : (
                      <div className="w-5 h-5 rounded-full bg-red-500/20 flex items-center justify-center mt-0.5 flex-shrink-0">
                        <span className="text-red-400 text-xs font-bold">!</span>
                      </div>
                    )}
                    <p className={`text-sm ${recoveryResult.success ? 'text-green-400' : 'text-red-400'}`}>
                      {recoveryResult.message}
                    </p>
                  </div>
                )}

                <button
                  onClick={handleSMSRecovery}
                  disabled={recoverySending || !recoveryEmail || recoveryPhone.replace(/\D/g, '').length < 10}
                  className="w-full bg-gradient-to-r from-green-600 to-emerald-600 text-white py-3 rounded-lg font-semibold hover:shadow-lg hover:shadow-green-500/30 transition-all disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2"
                >
                  {recoverySending ? (
                    <>
                      <Loader2 className="w-5 h-5 animate-spin" />
                      Sending...
                    </>
                  ) : (
                    <>
                      <MessageSquare className="w-5 h-5" />
                      Send Sign-In Info via SMS
                    </>
                  )}
                </button>
              </div>

              {/* Security Note */}
              <div className="mt-4 flex items-start gap-2 px-3 py-2 rounded-lg bg-yellow-500/10 border border-yellow-500/20">
                <Smartphone className="w-4 h-4 text-yellow-400 mt-0.5 flex-shrink-0" />
                <p className="text-yellow-300/80 text-xs">
                  Only request your sign-in info to a phone number you own. Standard SMS rates may apply.
                </p>
              </div>
            </div>
          ) : (
            <>
              <h2 className="text-2xl font-bold text-white mb-6">Sign In</h2>
              
              {error && (
                <div className="bg-red-500/20 border border-red-500 text-red-400 px-4 py-3 rounded-lg mb-4">
                  {error}
                </div>
              )}

              <form onSubmit={handleSubmit} className="space-y-5">
                <div>
                  <label className="text-gray-300 text-sm mb-2 block">Email</label>
                  <div className="relative">
                    <Mail className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-500" />
                    <input
                      type="email"
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      className="w-full bg-[#1a1a2e] text-white pl-11 pr-4 py-3 rounded-lg border border-gray-700 focus:border-purple-500 focus:outline-none transition-colors"
                      placeholder="your@email.com"
                      required
                      disabled={loading}
                    />
                  </div>
                </div>

                <div>
                  <label className="text-gray-300 text-sm mb-2 block">Password</label>
                  <div className="relative">
                    <Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-500" />
                    <input
                      type={showPassword ? 'text' : 'password'}
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      className="w-full bg-[#1a1a2e] text-white pl-11 pr-11 py-3 rounded-lg border border-gray-700 focus:border-purple-500 focus:outline-none transition-colors"
                      placeholder="Enter password"
                      required
                      disabled={loading}
                    />
                    <button
                      type="button"
                      onClick={() => setShowPassword(!showPassword)}
                      className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-500 hover:text-gray-300 transition-colors"
                      disabled={loading}
                    >
                      {showPassword ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
                    </button>
                  </div>
                </div>

                <div className="flex items-center justify-between">
                  <label className="flex items-center gap-2 cursor-pointer">
                    <input
                      type="checkbox"
                      className="w-4 h-4 rounded border-gray-600 bg-[#1a1a2e] text-purple-500 focus:ring-purple-500 focus:ring-offset-0"
                    />
                    <span className="text-gray-400 text-sm">Remember me</span>
                  </label>
                  <button 
                    type="button" 
                    onClick={() => setShowSMSRecovery(true)}
                    className="text-purple-400 hover:text-purple-300 text-sm transition-colors"
                  >
                    Forgot password?
                  </button>
                </div>

                <button
                  type="submit"
                  disabled={loading}
                  className="w-full bg-gradient-to-r from-purple-600 to-pink-600 text-white py-3 rounded-lg font-semibold hover:shadow-lg hover:shadow-purple-500/50 transition-all disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2"
                >
                  {loading ? (
                    <>
                      <Loader2 className="w-5 h-5 animate-spin" />
                      Signing in...
                    </>
                  ) : (
                    'Sign In'
                  )}
                </button>
              </form>

              {/* SMS Sign-In Info Option */}
              <div className="mt-5 pt-5 border-t border-gray-700">
                <button
                  onClick={() => setShowSMSRecovery(true)}
                  className="w-full flex items-center justify-center gap-3 bg-gradient-to-r from-green-500/10 to-emerald-500/10 text-green-400 py-3 rounded-xl border border-green-500/20 hover:border-green-500/40 hover:bg-green-500/20 transition-all text-sm font-medium"
                >
                  <Smartphone className="w-5 h-5" />
                  Get Sign-In Info via SMS
                </button>
                <p className="text-gray-500 text-xs text-center mt-2">
                  Receive your account credentials via text message
                </p>
              </div>

              <p className="text-gray-400 text-center mt-6">
                Don't have an account?{' '}
                <Link to="/signup" className="text-purple-400 hover:text-purple-300 transition-colors">
                  Sign up
                </Link>
              </p>
            </>
          )}
        </div>
      </div>
    </div>
  );
}
