import React, { useState, useEffect } from 'react';
import { Link, useNavigate, useSearchParams } from 'react-router-dom';
import { useAuth } from '@/contexts/AuthContext';
import { supabase } from '@/lib/supabase';
import { EarningsOverview } from '@/components/EarningsOverview';
import { BankAccountSettings } from '@/components/wallet/BankAccountSettings';
import { 
  ArrowLeft, 
  Wallet, 
  CheckCircle, 
  Clock, 
  ArrowUpRight, 
  Gift, 
  Building2,
  TrendingUp,
  DollarSign,
  Users,
  Calendar
} from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

interface Transaction { 
  type: string; 
  amount: number; 
  from?: string; 
  message?: string; 
  status?: string; 
  date: string; 
}

interface Payout { 
  id: string; 
  amount: number; 
  status: string; 
  requested_at: string; 
  processed_at?: string;
  payout_type?: string;
}

export default function EarningsPage() {
  const { user } = useAuth();
  const navigate = useNavigate();
  const { toast } = useToast();
  const [searchParams] = useSearchParams();
  const [activeTab, setActiveTab] = useState<'overview' | 'bank' | 'transactions' | 'payouts'>('overview');
  const [earnings, setEarnings] = useState({ 
    donations: 0, 
    subscriptions: 0, 
    total: 0, 
    platformFee: 0, 
    paidOut: 0, 
    available: 0, 
    subCount: 0 
  });
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [payouts, setPayouts] = useState<Payout[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!user) { 
      navigate('/login'); 
      return; 
    }
    loadData();
    if (searchParams.get('connected')) {
      toast({ 
        title: 'Account Connected!', 
        description: 'Your bank account has been set up successfully.' 
      });
      setActiveTab('bank');
    }
  }, [user]);

  const loadData = async () => {
    if (!user) return;
    setLoading(true);
    const [earningsRes, transRes, payoutsRes] = await Promise.all([
      supabase.functions.invoke('earnings-manager', { 
        body: { action: 'get_earnings', streamer_id: user.user_id } 
      }),
      supabase.functions.invoke('earnings-manager', { 
        body: { action: 'get_transactions', streamer_id: user.user_id } 
      }),
      supabase.functions.invoke('earnings-manager', { 
        body: { action: 'get_payouts', streamer_id: user.user_id } 
      })
    ]);
    if (earningsRes.data) setEarnings(earningsRes.data);
    if (transRes.data) setTransactions(transRes.data.transactions || []);
    if (payoutsRes.data) setPayouts(payoutsRes.data.payouts || []);
    setLoading(false);
  };

  if (!user) return null;

  const tabs = [
    { id: 'overview', label: 'Overview', icon: TrendingUp },
    { id: 'bank', label: 'Bank Account', icon: Building2 },
    { id: 'transactions', label: 'Transactions', icon: DollarSign },
    { id: 'payouts', label: 'Payouts', icon: ArrowUpRight }
  ];

  return (
    <div className="min-h-screen bg-[#1a1a2e]">
      {/* Header */}
      <header className="bg-[#16213e] border-b border-gray-800 sticky top-0 z-40">
        <div className="max-w-6xl mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <Link to="/profile" className="text-gray-400 hover:text-white transition-colors">
                <ArrowLeft className="w-6 h-6" />
              </Link>
              <h1 className="text-xl font-bold bg-gradient-to-r from-green-400 to-emerald-500 bg-clip-text text-transparent flex items-center gap-2">
                <Wallet className="w-5 h-5 text-green-400" /> 
                Earnings Dashboard
              </h1>
            </div>
            <div className="flex items-center gap-2 text-sm">
              <span className="text-gray-400">Available:</span>
              <span className="text-green-400 font-bold text-lg">
                ${(earnings.available / 100).toFixed(2)}
              </span>
            </div>
          </div>

          {/* Tabs */}
          <div className="flex gap-1 mt-4 overflow-x-auto pb-1">
            {tabs.map((tab) => {
              const Icon = tab.icon;
              return (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id as any)}
                  className={`flex items-center gap-2 px-4 py-2 rounded-lg font-medium transition-all whitespace-nowrap ${
                    activeTab === tab.id
                      ? 'bg-gradient-to-r from-green-600 to-emerald-600 text-white'
                      : 'text-gray-400 hover:text-white hover:bg-gray-800'
                  }`}
                >
                  <Icon className="w-4 h-4" />
                  {tab.label}
                </button>
              );
            })}
          </div>
        </div>
      </header>

      <div className="max-w-6xl mx-auto px-4 py-8">
        {/* Overview Tab */}
        {activeTab === 'overview' && (
          <div className="space-y-8">
            <EarningsOverview earnings={earnings} loading={loading} />

            {/* Quick Stats */}
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              <div className="bg-[#16213e] rounded-xl p-4 border border-gray-800">
                <div className="flex items-center gap-2 text-gray-400 mb-2">
                  <Gift className="w-4 h-4" />
                  <span className="text-sm">Tips Received</span>
                </div>
                <p className="text-2xl font-bold text-white">
                  ${(earnings.donations / 100).toFixed(2)}
                </p>
              </div>
              <div className="bg-[#16213e] rounded-xl p-4 border border-gray-800">
                <div className="flex items-center gap-2 text-gray-400 mb-2">
                  <Users className="w-4 h-4" />
                  <span className="text-sm">Subscribers</span>
                </div>
                <p className="text-2xl font-bold text-white">{earnings.subCount}</p>
              </div>
              <div className="bg-[#16213e] rounded-xl p-4 border border-gray-800">
                <div className="flex items-center gap-2 text-gray-400 mb-2">
                  <DollarSign className="w-4 h-4" />
                  <span className="text-sm">Sub Revenue</span>
                </div>
                <p className="text-2xl font-bold text-white">
                  ${(earnings.subscriptions / 100).toFixed(2)}
                </p>
              </div>
              <div className="bg-[#16213e] rounded-xl p-4 border border-gray-800">
                <div className="flex items-center gap-2 text-gray-400 mb-2">
                  <ArrowUpRight className="w-4 h-4" />
                  <span className="text-sm">Total Paid Out</span>
                </div>
                <p className="text-2xl font-bold text-white">
                  ${(earnings.paidOut / 100).toFixed(2)}
                </p>
              </div>
            </div>

            {/* Recent Activity */}
            <div className="grid md:grid-cols-2 gap-6">
              <div className="bg-[#16213e] rounded-2xl p-6 border border-gray-800">
                <h3 className="text-lg font-bold text-white mb-4 flex items-center gap-2">
                  <Gift className="w-5 h-5 text-purple-400" />
                  Recent Tips
                </h3>
                {transactions.filter(t => t.type === 'donation').length === 0 ? (
                  <p className="text-gray-500 text-center py-8">No tips yet</p>
                ) : (
                  <div className="space-y-3 max-h-64 overflow-y-auto">
                    {transactions.filter(t => t.type === 'donation').slice(0, 5).map((t, i) => (
                      <div key={i} className="flex items-center gap-3 p-3 rounded-lg bg-[#1a1a2e]">
                        <div className="w-10 h-10 rounded-full bg-gradient-to-r from-purple-600 to-pink-600 flex items-center justify-center text-white font-bold">
                          {t.from?.charAt(0).toUpperCase() || '?'}
                        </div>
                        <div className="flex-1 min-w-0">
                          <p className="text-white text-sm font-medium truncate">{t.from}</p>
                          {t.message && (
                            <p className="text-gray-500 text-xs truncate">{t.message}</p>
                          )}
                        </div>
                        <span className="text-green-400 font-semibold">
                          +${(t.amount / 100).toFixed(2)}
                        </span>
                      </div>
                    ))}
                  </div>
                )}
              </div>

              <div className="bg-[#16213e] rounded-2xl p-6 border border-gray-800">
                <h3 className="text-lg font-bold text-white mb-4 flex items-center gap-2">
                  <ArrowUpRight className="w-5 h-5 text-green-400" />
                  Recent Payouts
                </h3>
                {payouts.length === 0 ? (
                  <p className="text-gray-500 text-center py-8">No payouts yet</p>
                ) : (
                  <div className="space-y-3 max-h-64 overflow-y-auto">
                    {payouts.slice(0, 5).map((p) => (
                      <div key={p.id} className="flex items-center gap-3 p-3 rounded-lg bg-[#1a1a2e]">
                        <div className={`w-10 h-10 rounded-full flex items-center justify-center ${
                          p.status === 'completed' ? 'bg-green-600/20' : 'bg-yellow-600/20'
                        }`}>
                          {p.status === 'completed' ? (
                            <CheckCircle className="w-5 h-5 text-green-400" />
                          ) : (
                            <Clock className="w-5 h-5 text-yellow-400" />
                          )}
                        </div>
                        <div className="flex-1">
                          <p className="text-white text-sm font-medium">
                            ${(p.amount / 100).toFixed(2)}
                          </p>
                          <p className="text-gray-500 text-xs">
                            {new Date(p.requested_at).toLocaleDateString()}
                          </p>
                        </div>
                        <span className={`text-xs px-2 py-1 rounded ${
                          p.status === 'completed' 
                            ? 'bg-green-600/20 text-green-400' 
                            : 'bg-yellow-600/20 text-yellow-400'
                        }`}>
                          {p.status}
                        </span>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </div>
          </div>
        )}

        {/* Bank Account Tab */}
        {activeTab === 'bank' && (
          <BankAccountSettings 
            userId={user.user_id} 
            email={user.email}
            onAccountConnected={loadData}
          />
        )}

        {/* Transactions Tab */}
        {activeTab === 'transactions' && (
          <div className="bg-[#16213e] rounded-2xl p-6 border border-gray-800">
            <h3 className="text-lg font-bold text-white mb-6 flex items-center gap-2">
              <DollarSign className="w-5 h-5 text-green-400" />
              All Transactions
            </h3>
            {transactions.length === 0 ? (
              <div className="text-center py-12">
                <DollarSign className="w-12 h-12 text-gray-600 mx-auto mb-4" />
                <p className="text-gray-500">No transactions yet</p>
                <p className="text-gray-600 text-sm mt-1">
                  Transactions will appear here when you receive tips or subscriptions
                </p>
              </div>
            ) : (
              <div className="space-y-3">
                {transactions.map((t, i) => (
                  <div key={i} className="flex items-center gap-4 p-4 rounded-xl bg-[#1a1a2e] hover:bg-[#1a1a2e]/80 transition-colors">
                    <div className={`w-12 h-12 rounded-full flex items-center justify-center ${
                      t.type === 'donation' ? 'bg-purple-600/20' : 'bg-gray-600/20'
                    }`}>
                      {t.type === 'donation' ? (
                        <Gift className="w-6 h-6 text-purple-400" />
                      ) : (
                        <ArrowUpRight className="w-6 h-6 text-gray-400" />
                      )}
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="text-white font-medium">
                        {t.type === 'donation' ? `Tip from ${t.from}` : 'Payout'}
                      </p>
                      {t.message && (
                        <p className="text-gray-500 text-sm truncate">{t.message}</p>
                      )}
                      <p className="text-gray-600 text-xs mt-1">
                        {new Date(t.date).toLocaleString()}
                      </p>
                    </div>
                    <div className="text-right">
                      <span className={`text-lg font-bold ${
                        t.amount > 0 ? 'text-green-400' : 'text-gray-400'
                      }`}>
                        {t.amount > 0 ? '+' : ''}${(Math.abs(t.amount) / 100).toFixed(2)}
                      </span>
                      {t.status && (
                        <p className={`text-xs mt-1 ${
                          t.status === 'completed' ? 'text-green-400' : 'text-yellow-400'
                        }`}>
                          {t.status}
                        </p>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {/* Payouts Tab */}
        {activeTab === 'payouts' && (
          <div className="bg-[#16213e] rounded-2xl p-6 border border-gray-800">
            <h3 className="text-lg font-bold text-white mb-6 flex items-center gap-2">
              <ArrowUpRight className="w-5 h-5 text-green-400" />
              Payout History
            </h3>
            {payouts.length === 0 ? (
              <div className="text-center py-12">
                <ArrowUpRight className="w-12 h-12 text-gray-600 mx-auto mb-4" />
                <p className="text-gray-500">No payouts yet</p>
                <p className="text-gray-600 text-sm mt-1">
                  Request a payout from the Bank Account tab when you have available balance
                </p>
              </div>
            ) : (
              <div className="space-y-3">
                {payouts.map((p) => (
                  <div key={p.id} className="flex items-center gap-4 p-4 rounded-xl bg-[#1a1a2e]">
                    <div className={`w-12 h-12 rounded-full flex items-center justify-center ${
                      p.status === 'completed' ? 'bg-green-600/20' : 'bg-yellow-600/20'
                    }`}>
                      {p.status === 'completed' ? (
                        <CheckCircle className="w-6 h-6 text-green-400" />
                      ) : (
                        <Clock className="w-6 h-6 text-yellow-400" />
                      )}
                    </div>
                    <div className="flex-1">
                      <p className="text-white font-medium">
                        ${(p.amount / 100).toFixed(2)}
                      </p>
                      <div className="flex items-center gap-2 mt-1">
                        <Calendar className="w-3 h-3 text-gray-500" />
                        <p className="text-gray-500 text-sm">
                          Requested: {new Date(p.requested_at).toLocaleDateString()}
                        </p>
                      </div>
                      {p.processed_at && (
                        <p className="text-gray-600 text-xs mt-1">
                          Processed: {new Date(p.processed_at).toLocaleDateString()}
                        </p>
                      )}
                    </div>
                    <div className="text-right">
                      <span className={`text-sm px-3 py-1 rounded-full ${
                        p.status === 'completed' 
                          ? 'bg-green-600/20 text-green-400' 
                          : p.status === 'pending'
                          ? 'bg-yellow-600/20 text-yellow-400'
                          : 'bg-gray-600/20 text-gray-400'
                      }`}>
                        {p.status.charAt(0).toUpperCase() + p.status.slice(1)}
                      </span>
                      {p.payout_type && (
                        <p className="text-gray-500 text-xs mt-2">
                          {p.payout_type === 'instant' ? 'Instant' : 'Standard'}
                        </p>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
}
