import React, { useState, useEffect, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '@/contexts/AuthContext';
import { supabase } from '@/lib/supabase';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Radio, Calendar, Video, Scissors, Users, ArrowLeft, Image, Film, Sparkles } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { FeedLiveStreams } from '@/components/feed/FeedLiveStreams';
import { FeedSchedules } from '@/components/feed/FeedSchedules';
import { FeedVODs } from '@/components/feed/FeedVODs';
import { FeedClips } from '@/components/feed/FeedClips';
import { MediaUpload } from '@/components/feed/MediaUpload';
import { VideoUpload } from '@/components/feed/VideoUpload';
import { MediaFeed } from '@/components/feed/MediaFeed';
import { VODPlayer } from '@/components/VODPlayer';
import { ClipModal } from '@/components/ClipModal';
import { StoriesBar } from '@/components/stories/StoriesBar';

export default function FeedPage() {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [loading, setLoading] = useState(true);
  const [streams, setStreams] = useState([]);
  const [schedules, setSchedules] = useState([]);
  const [vods, setVods] = useState([]);
  const [clips, setClips] = useState([]);
  const [followedCount, setFollowedCount] = useState(0);
  const [subscribedIds, setSubscribedIds] = useState<string[]>([]);
  const [vodsOffset, setVodsOffset] = useState(0);
  const [clipsOffset, setClipsOffset] = useState(0);
  const [hasMoreVods, setHasMoreVods] = useState(true);
  const [hasMoreClips, setHasMoreClips] = useState(true);
  const [loadingMore, setLoadingMore] = useState(false);
  const [selectedVod, setSelectedVod] = useState(null);
  const [selectedClip, setSelectedClip] = useState(null);
  const [mediaFilter, setMediaFilter] = useState<'all' | 'image' | 'video'>('all');
  const [mediaRefreshKey, setMediaRefreshKey] = useState(0);
  const [storiesRefreshKey, setStoriesRefreshKey] = useState(0);

  useEffect(() => {
    if (!user) { navigate('/login'); return; }
    loadFeed();
  }, [user]);

  const loadFeed = async () => {
    if (!user) return;
    setLoading(true);
    const { data } = await supabase.functions.invoke('feed-manager', { body: { action: 'get_full_feed', user_id: user.user_id } });
    if (data) {
      setStreams(data.streams || []); setSchedules(data.schedules || []); setVods(data.vods || []); setClips(data.clips || []);
      setFollowedCount(data.followedCount || 0); setVodsOffset(data.vods?.length || 0); setClipsOffset(data.clips?.length || 0);
    }
    setLoading(false);
  };

  const loadMoreVods = useCallback(async () => {
    if (loadingMore || !hasMoreVods || !user) return;
    setLoadingMore(true);
    const { data } = await supabase.functions.invoke('feed-manager', { body: { action: 'get_followed_vods', user_id: user.user_id, limit: 12, offset: vodsOffset } });
    if (data?.vods) { setVods(prev => [...prev, ...data.vods]); setVodsOffset(prev => prev + data.vods.length); setHasMoreVods(data.hasMore); }
    setLoadingMore(false);
  }, [user, vodsOffset, hasMoreVods, loadingMore]);

  const loadMoreClips = useCallback(async () => {
    if (loadingMore || !hasMoreClips || !user) return;
    setLoadingMore(true);
    const { data } = await supabase.functions.invoke('feed-manager', { body: { action: 'get_followed_clips', user_id: user.user_id, limit: 12, offset: clipsOffset } });
    if (data?.clips) { setClips(prev => [...prev, ...data.clips]); setClipsOffset(prev => prev + data.clips.length); setHasMoreClips(data.hasMore); }
    setLoadingMore(false);
  }, [user, clipsOffset, hasMoreClips, loadingMore]);

  const toggleNotification = async (scheduleId: string) => {
    if (!user) return;
    if (subscribedIds.includes(scheduleId)) { setSubscribedIds(prev => prev.filter(id => id !== scheduleId)); }
    else {
      await supabase.functions.invoke('schedule-manager', { body: { action: 'subscribe_notification', schedule_id: scheduleId, user_id: user.user_id, notification_time: 15 } });
      setSubscribedIds(prev => [...prev, scheduleId]);
    }
  };

  if (!user) return null;

  return (
    <div className="min-h-screen bg-[#0a0f1c]">
      <div className="max-w-7xl mx-auto px-4 py-6">
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center gap-4">
            <Button variant="ghost" size="icon" onClick={() => navigate('/')}><ArrowLeft className="w-5 h-5" /></Button>
            <div>
              <h1 className="text-2xl font-bold text-white">Your Feed</h1>
              <p className="text-gray-400 text-sm flex items-center gap-2"><Users className="w-4 h-4" /> Following {followedCount} channels</p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <VideoUpload onVideoUploaded={() => setMediaRefreshKey(k => k + 1)} />
            <MediaUpload onPostCreated={() => setMediaRefreshKey(k => k + 1)} />
          </div>
        </div>

        {/* Stories Bar */}
        <StoriesBar refreshKey={storiesRefreshKey} />

        <Tabs defaultValue="media" className="space-y-6">
          <TabsList className="bg-gray-800/50 p-1">
            <TabsTrigger value="media" className="data-[state=active]:bg-purple-600 flex items-center gap-2"><Image className="w-4 h-4" /> Posts</TabsTrigger>
            <TabsTrigger value="live" className="data-[state=active]:bg-purple-600 flex items-center gap-2"><Radio className="w-4 h-4" /> Live <span className="bg-red-500 text-white text-xs px-1.5 rounded-full ml-1">{streams.length}</span></TabsTrigger>
            <TabsTrigger value="schedule" className="data-[state=active]:bg-purple-600 flex items-center gap-2"><Calendar className="w-4 h-4" /> Upcoming</TabsTrigger>
            <TabsTrigger value="vods" className="data-[state=active]:bg-purple-600 flex items-center gap-2"><Video className="w-4 h-4" /> VODs</TabsTrigger>
            <TabsTrigger value="clips" className="data-[state=active]:bg-purple-600 flex items-center gap-2"><Scissors className="w-4 h-4" /> Clips</TabsTrigger>
          </TabsList>
          
          <TabsContent value="media">
            <div className="mb-6">
              <div className="flex items-center gap-2 mb-4">
                <Button 
                  variant={mediaFilter === 'all' ? 'default' : 'outline'} 
                  size="sm"
                  onClick={() => setMediaFilter('all')}
                >
                  All
                </Button>
                <Button 
                  variant={mediaFilter === 'image' ? 'default' : 'outline'} 
                  size="sm"
                  onClick={() => setMediaFilter('image')}
                  className="gap-1"
                >
                  <Image className="w-4 h-4" /> Photos
                </Button>
                <Button 
                  variant={mediaFilter === 'video' ? 'default' : 'outline'} 
                  size="sm"
                  onClick={() => setMediaFilter('video')}
                  className="gap-1"
                >
                  <Film className="w-4 h-4" /> Videos
                </Button>
              </div>
              <MediaFeed key={mediaRefreshKey} filter={mediaFilter} />
            </div>
          </TabsContent>
          
          <TabsContent value="live"><FeedLiveStreams streams={streams} loading={loading} /></TabsContent>
          <TabsContent value="schedule"><FeedSchedules schedules={schedules} loading={loading} subscribedIds={subscribedIds} onToggleNotification={toggleNotification} /></TabsContent>
          <TabsContent value="vods"><FeedVODs vods={vods} loading={loading || loadingMore} hasMore={hasMoreVods} onLoadMore={loadMoreVods} onSelect={setSelectedVod} /></TabsContent>
          <TabsContent value="clips"><FeedClips clips={clips} loading={loading || loadingMore} hasMore={hasMoreClips} onLoadMore={loadMoreClips} onSelect={setSelectedClip} /></TabsContent>
        </Tabs>
      </div>
      {selectedVod && <VODPlayer vod={selectedVod} isOpen={!!selectedVod} onClose={() => setSelectedVod(null)} />}
      {selectedClip && <ClipModal clip={selectedClip} isOpen={!!selectedClip} onClose={() => setSelectedClip(null)} />}
    </div>
  );
}
