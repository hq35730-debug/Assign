import React, { useState, useEffect, useCallback } from 'react';
import { Link, useNavigate, useParams } from 'react-router-dom';
import { Mic, Plus, RefreshCw, Users, ArrowLeft, Phone, Hash } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/contexts/AuthContext';
import { VoiceRoomCard } from '@/components/voice/VoiceRoomCard';
import { CreateVoiceRoomModal } from '@/components/voice/CreateVoiceRoomModal';
import { ActiveVoiceRoom } from '@/components/voice/ActiveVoiceRoom';

interface VoiceRoom {
  id: string;
  name: string;
  description?: string;
  host_id: string;
  is_private: boolean;
  is_active: boolean;
  max_participants: number;
  participant_count: number;
  created_at: string;
  host?: {
    id: string;
    username: string;
    avatar_url?: string;
    unique_id?: string;
  };
}

export default function VoiceRoomsPage() {
  const navigate = useNavigate();
  const { roomId } = useParams();
  const { user } = useAuth();
  const [rooms, setRooms] = useState<VoiceRoom[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [showCreateModal, setShowCreateModal] = useState(false);
  const [activeRoomId, setActiveRoomId] = useState<string | null>(roomId || null);
  const [isRefreshing, setIsRefreshing] = useState(false);

  const userId = user?.id || user?.user_id;

  // Load active rooms
  const loadRooms = useCallback(async () => {
    try {
      const { data, error } = await supabase.functions.invoke('voice-room-manager', {
        body: { action: 'get_active_rooms' }
      });

      if (error) throw error;
      if (data?.error) throw new Error(data.error);

      setRooms(data.rooms || []);
    } catch (err) {
      console.error('Failed to load rooms:', err);
    } finally {
      setIsLoading(false);
      setIsRefreshing(false);
    }
  }, []);

  useEffect(() => {
    loadRooms();
    const interval = setInterval(loadRooms, 10000);
    return () => clearInterval(interval);
  }, [loadRooms]);

  // Handle room ID from URL
  useEffect(() => {
    if (roomId) {
      setActiveRoomId(roomId);
    }
  }, [roomId]);

  // Join a room
  const handleJoinRoom = async (roomId: string) => {
    if (!user) {
      navigate('/login');
      return;
    }

    try {
      const { data, error } = await supabase.functions.invoke('voice-room-manager', {
        body: {
          action: 'join_room',
          user_id: userId,
          room_id: roomId
        }
      });

      if (error) throw error;
      if (data?.error) throw new Error(data.error);

      setActiveRoomId(roomId);
      navigate(`/voice/${roomId}`);
    } catch (err: any) {
      alert(err.message || 'Failed to join room');
    }
  };

  // Handle room created
  const handleRoomCreated = (newRoomId: string) => {
    setActiveRoomId(newRoomId);
    navigate(`/voice/${newRoomId}`);
    loadRooms();
  };

  // Handle leaving room
  const handleLeaveRoom = () => {
    setActiveRoomId(null);
    navigate('/voice');
    loadRooms();
  };

  // Refresh rooms
  const handleRefresh = () => {
    setIsRefreshing(true);
    loadRooms();
  };

  // If in an active room, show the active room view
  if (activeRoomId) {
    return <ActiveVoiceRoom roomId={activeRoomId} onLeave={handleLeaveRoom} />;
  }

  return (
    <div className="min-h-screen bg-[#1a1a2e]">
      {/* Header */}
      <header className="bg-[#16213e] border-b border-gray-800 sticky top-0 z-40">
        <div className="max-w-7xl mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <Link to="/" className="text-gray-400 hover:text-white transition-colors">
                <ArrowLeft className="w-6 h-6" />
              </Link>
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-gradient-to-br from-purple-500 to-pink-500 rounded-xl flex items-center justify-center">
                  <Mic className="w-5 h-5 text-white" />
                </div>
                <div>
                  <h1 className="text-white font-bold text-xl">Voice Rooms</h1>
                  <p className="text-gray-400 text-sm">Join live voice conversations</p>
                </div>
              </div>
            </div>

            <div className="flex items-center gap-3">
              <button
                onClick={handleRefresh}
                disabled={isRefreshing}
                className="p-2 text-gray-400 hover:text-white hover:bg-white/10 rounded-lg transition-colors disabled:opacity-50"
              >
                <RefreshCw className={`w-5 h-5 ${isRefreshing ? 'animate-spin' : ''}`} />
              </button>

              {user && (
                <button
                  onClick={() => setShowCreateModal(true)}
                  className="flex items-center gap-2 bg-gradient-to-r from-purple-600 to-pink-600 text-white px-4 py-2 rounded-full font-semibold hover:shadow-lg hover:shadow-purple-500/30 transition-all"
                >
                  <Plus className="w-5 h-5" />
                  Create Room
                </button>
              )}
            </div>
          </div>
        </div>
      </header>

      {/* User Phone Info */}
      {user && user.phone_number && (
        <div className="bg-gradient-to-r from-green-500/10 to-emerald-500/10 border-b border-green-500/20">
          <div className="max-w-7xl mx-auto px-4 py-3 flex items-center justify-center gap-4">
            <Phone className="w-4 h-4 text-green-400" />
            <span className="text-green-400 text-sm">Your phone: <span className="font-mono">{user.phone_number}</span></span>
            {user.unique_id && (
              <>
                <span className="text-gray-600">|</span>
                <Hash className="w-4 h-4 text-purple-400" />
                <span className="text-purple-400 text-sm">ID: <span className="font-mono">{user.unique_id}</span></span>
              </>
            )}
          </div>
        </div>
      )}

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 py-8">
        {/* Stats */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
          <div className="bg-[#16213e] rounded-xl p-4 border border-gray-700">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-purple-500/20 rounded-lg flex items-center justify-center">
                <Mic className="w-5 h-5 text-purple-400" />
              </div>
              <div>
                <p className="text-2xl font-bold text-white">{rooms.length}</p>
                <p className="text-gray-400 text-sm">Active Rooms</p>
              </div>
            </div>
          </div>
          <div className="bg-[#16213e] rounded-xl p-4 border border-gray-700">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-green-500/20 rounded-lg flex items-center justify-center">
                <Users className="w-5 h-5 text-green-400" />
              </div>
              <div>
                <p className="text-2xl font-bold text-white">
                  {rooms.reduce((sum, r) => sum + r.participant_count, 0)}
                </p>
                <p className="text-gray-400 text-sm">People Talking</p>
              </div>
            </div>
          </div>
          <div className="bg-[#16213e] rounded-xl p-4 border border-gray-700">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-blue-500/20 rounded-lg flex items-center justify-center">
                <Phone className="w-5 h-5 text-blue-400" />
              </div>
              <div>
                <p className="text-2xl font-bold text-white">Twilio</p>
                <p className="text-gray-400 text-sm">Conference Calls</p>
              </div>
            </div>
          </div>
          <div className="bg-[#16213e] rounded-xl p-4 border border-gray-700">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-amber-500/20 rounded-lg flex items-center justify-center">
                <span className="text-amber-400 text-lg">HD</span>
              </div>
              <div>
                <p className="text-2xl font-bold text-white">Clear</p>
                <p className="text-gray-400 text-sm">Audio Quality</p>
              </div>
            </div>
          </div>
        </div>

        {/* Rooms List */}
        <div className="mb-6">
          <h2 className="text-xl font-bold text-white mb-4 flex items-center gap-2">
            <span className="w-2 h-2 bg-green-400 rounded-full animate-pulse" />
            Live Voice Rooms
          </h2>
        </div>

        {isLoading ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {[1, 2, 3, 4, 5, 6].map((i) => (
              <div key={i} className="bg-[#16213e] rounded-xl border border-gray-700 p-4 animate-pulse">
                <div className="h-6 bg-gray-700 rounded w-3/4 mb-2" />
                <div className="h-4 bg-gray-700 rounded w-1/2 mb-4" />
                <div className="flex items-center gap-3 mb-4">
                  <div className="w-10 h-10 bg-gray-700 rounded-full" />
                  <div className="h-4 bg-gray-700 rounded w-24" />
                </div>
                <div className="h-10 bg-gray-700 rounded" />
              </div>
            ))}
          </div>
        ) : rooms.length > 0 ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {rooms.map((room) => (
              <VoiceRoomCard
                key={room.id}
                room={room}
                onJoin={handleJoinRoom}
              />
            ))}
          </div>
        ) : (
          <div className="text-center py-16 bg-[#16213e] rounded-xl border border-gray-700">
            <div className="w-20 h-20 bg-purple-500/20 rounded-full flex items-center justify-center mx-auto mb-4">
              <Mic className="w-10 h-10 text-purple-400" />
            </div>
            <h3 className="text-xl font-bold text-white mb-2">No Active Voice Rooms</h3>
            <p className="text-gray-400 mb-6">Be the first to start a conversation!</p>
            {user ? (
              <button
                onClick={() => setShowCreateModal(true)}
                className="inline-flex items-center gap-2 bg-gradient-to-r from-purple-600 to-pink-600 text-white px-6 py-3 rounded-full font-semibold hover:shadow-lg hover:shadow-purple-500/30 transition-all"
              >
                <Plus className="w-5 h-5" />
                Create Voice Room
              </button>
            ) : (
              <Link
                to="/login"
                className="inline-flex items-center gap-2 bg-gradient-to-r from-purple-600 to-pink-600 text-white px-6 py-3 rounded-full font-semibold hover:shadow-lg hover:shadow-purple-500/30 transition-all"
              >
                Sign In to Create Room
              </Link>
            )}
          </div>
        )}

        {/* How It Works */}
        <div className="mt-12 bg-gradient-to-br from-purple-500/10 to-pink-500/10 rounded-2xl border border-purple-500/20 p-6">
          <h3 className="text-xl font-bold text-white mb-6 text-center">How Voice Rooms Work</h3>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="text-center">
              <div className="w-14 h-14 bg-purple-500/20 rounded-full flex items-center justify-center mx-auto mb-3">
                <Plus className="w-7 h-7 text-purple-400" />
              </div>
              <h4 className="text-white font-semibold mb-2">1. Create or Join</h4>
              <p className="text-gray-400 text-sm">
                Start your own voice room or join an existing one
              </p>
            </div>
            <div className="text-center">
              <div className="w-14 h-14 bg-green-500/20 rounded-full flex items-center justify-center mx-auto mb-3">
                <Phone className="w-7 h-7 text-green-400" />
              </div>
              <h4 className="text-white font-semibold mb-2">2. Connect via Phone</h4>
              <p className="text-gray-400 text-sm">
                Your assigned phone number connects you to the conference
              </p>
            </div>
            <div className="text-center">
              <div className="w-14 h-14 bg-pink-500/20 rounded-full flex items-center justify-center mx-auto mb-3">
                <Users className="w-7 h-7 text-pink-400" />
              </div>
              <h4 className="text-white font-semibold mb-2">3. Talk & Interact</h4>
              <p className="text-gray-400 text-sm">
                Mute/unmute, see who's speaking, and manage participants
              </p>
            </div>
          </div>
        </div>
      </main>

      {/* Create Room Modal */}
      <CreateVoiceRoomModal
        isOpen={showCreateModal}
        onClose={() => setShowCreateModal(false)}
        onRoomCreated={handleRoomCreated}
      />
    </div>
  );
}
