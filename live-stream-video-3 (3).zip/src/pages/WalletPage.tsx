import { useState, useEffect, useCallback } from 'react';
import { useSearchParams, useNavigate } from 'react-router-dom';
import { Coins, Wallet, ArrowDownToLine, Gift, ShoppingCart, Heart, Star, LogIn, Pickaxe, ArrowRightLeft, RefreshCw, Bell, BellOff, TrendingUp, TrendingDown } from 'lucide-react';
import { Card } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { CoinPackages } from '@/components/wallet/CoinPackages';
import { TransactionHistory } from '@/components/wallet/TransactionHistory';
import { CashoutForm } from '@/components/wallet/CashoutForm';
import { GiftersLeaderboard } from '@/components/wallet/GiftersLeaderboard';
import { EarnersLeaderboard } from '@/components/wallet/EarnersLeaderboard';
import { VIPProgress } from '@/components/wallet/VIPProgress';
import { VIPBenefits } from '@/components/wallet/VIPBenefits';
import { VIPBadge } from '@/components/wallet/VIPBadge';
import { GiftHistory } from '@/components/gifts/GiftHistory';
import { MiningDashboard } from '@/components/mining/MiningDashboard';
import { STCConverter } from '@/components/mining/STCConverter';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/contexts/AuthContext';
import { useToast } from '@/hooks/use-toast';

export default function WalletPage() {
  const { user } = useAuth();
  const { toast } = useToast();
  const navigate = useNavigate();
  const [searchParams, setSearchParams] = useSearchParams();
  const [wallet, setWallet] = useState<any>(null);
  const [vipData, setVipData] = useState<any>(null);
  const [miningWallet, setMiningWallet] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [liveUpdates, setLiveUpdates] = useState(true);
  const [lastUpdate, setLastUpdate] = useState<Date | null>(null);
  const [walletChange, setWalletChange] = useState<{ type: 'increase' | 'decrease' | null; amount: number }>({ type: null, amount: 0 });

  useEffect(() => {
    const success = searchParams.get('success');
    const canceled = searchParams.get('canceled');
    const coins = searchParams.get('coins');

    if (success === 'true' && coins) {
      toast({ title: 'Purchase Successful!', description: `${parseInt(coins).toLocaleString()} coins have been added to your wallet.` });
      setSearchParams({});
      loadWallet();
    } else if (canceled === 'true') {
      toast({ title: 'Purchase Canceled', description: 'Your purchase was canceled.', variant: 'destructive' });
      setSearchParams({});
    }
  }, [searchParams]);

  useEffect(() => {
    if (user?.id || user?.user_id) {
      loadWallet();
      loadVIPStatus();
      loadMiningWallet();
    } else {
      setLoading(false);
    }
  }, [user?.id, user?.user_id]);

  // Real-time wallet updates
  useEffect(() => {
    if (!liveUpdates || !user) return;

    const userId = user.user_id || user.id;
    
    // Poll for updates every 10 seconds
    const interval = setInterval(() => {
      refreshWalletData();
    }, 10000);

    return () => clearInterval(interval);
  }, [liveUpdates, user]);

  const userId = user?.user_id || user?.id;

  const loadWallet = async () => {
    if (!userId) return;
    const { data } = await supabase.functions.invoke('coins-manager', { body: { action: 'get_wallet', user_id: userId } });
    if (data?.wallet) {
      setWallet(data.wallet);
      setLastUpdate(new Date());
    }
    setLoading(false);
  };

  const loadVIPStatus = async () => {
    if (!userId) return;
    const { data } = await supabase.functions.invoke('vip-manager', { body: { action: 'get_user_vip', user_id: userId } });
    if (data) setVipData(data);
  };

  const loadMiningWallet = async () => {
    if (!userId) return;
    try {
      const { data } = await supabase.functions.invoke('mining-manager', { body: { action: 'get_wallet', user_id: userId } });
      if (data?.wallet) setMiningWallet(data.wallet);
    } catch (error) {
      console.error('Failed to load mining wallet:', error);
    }
  };

  const refreshWalletData = useCallback(async () => {
    if (!userId) return;
    
    try {
      const [walletRes, miningRes] = await Promise.all([
        supabase.functions.invoke('coins-manager', { body: { action: 'get_wallet', user_id: userId } }),
        supabase.functions.invoke('mining-manager', { body: { action: 'get_wallet', user_id: userId } })
      ]);

      if (walletRes.data?.wallet) {
        const newBalance = walletRes.data.wallet.coins_balance;
        const oldBalance = wallet?.coins_balance || 0;
        
        if (newBalance !== oldBalance) {
          const diff = newBalance - oldBalance;
          setWalletChange({
            type: diff > 0 ? 'increase' : 'decrease',
            amount: Math.abs(diff)
          });
          
          // Clear the change indicator after 3 seconds
          setTimeout(() => setWalletChange({ type: null, amount: 0 }), 3000);
          
          // Show toast for significant changes
          if (Math.abs(diff) >= 10) {
            toast({
              title: diff > 0 ? 'Coins Received!' : 'Coins Spent',
              description: `${diff > 0 ? '+' : ''}${diff.toLocaleString()} coins`,
            });
          }
        }
        
        setWallet(walletRes.data.wallet);
      }

      if (miningRes.data?.wallet) {
        setMiningWallet(miningRes.data.wallet);
      }

      setLastUpdate(new Date());
    } catch (error) {
      console.error('Failed to refresh wallet:', error);
    }
  }, [userId, wallet?.coins_balance, toast]);

  const handleManualRefresh = () => {
    refreshWalletData();
    loadVIPStatus();
    toast({ title: 'Wallet Refreshed', description: 'Your wallet data has been updated.' });
  };

  if (!user) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center p-6">
        <Card className="p-8 max-w-md text-center space-y-4">
          <Wallet className="w-16 h-16 text-purple-500 mx-auto" />
          <h2 className="text-2xl font-bold">Sign In Required</h2>
          <p className="text-muted-foreground">Please sign in to access your wallet and manage your coins.</p>
          <Button onClick={() => navigate('/login')} className="w-full gap-2">
            <LogIn className="w-4 h-4" /> Sign In
          </Button>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background p-6">
      <div className="max-w-6xl mx-auto space-y-6">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <Wallet className="w-8 h-8 text-purple-500" />
            <h1 className="text-3xl font-bold">My Wallet</h1>
            {vipData?.status?.current_tier && <VIPBadge tier={vipData.status.current_tier} size="lg" showLabel />}
          </div>
          <div className="flex items-center gap-2">
            <Button
              variant="outline"
              size="sm"
              onClick={() => setLiveUpdates(!liveUpdates)}
              className={liveUpdates ? 'text-green-500 border-green-500/50' : ''}
            >
              {liveUpdates ? <Bell className="w-4 h-4 mr-1" /> : <BellOff className="w-4 h-4 mr-1" />}
              {liveUpdates ? 'Live' : 'Paused'}
            </Button>
            <Button variant="outline" size="sm" onClick={handleManualRefresh}>
              <RefreshCw className="w-4 h-4 mr-1" />
              Refresh
            </Button>
            {lastUpdate && (
              <span className="text-xs text-muted-foreground">
                Updated {lastUpdate.toLocaleTimeString()}
              </span>
            )}
          </div>
        </div>

        {vipData && (
          <Card className="p-6 bg-gradient-to-br from-purple-900/30 to-pink-900/20 border-purple-500/30">
            <VIPProgress currentTier={vipData.status?.current_tier} nextTier={vipData.nextTier}
              totalSpent={vipData.status?.total_coins_spent || 0} progressPercent={vipData.progressPercent || 0}
              coinsToNext={vipData.coinsToNext || 0} />
          </Card>
        )}

        <div className="grid grid-cols-1 md:grid-cols-6 gap-4">
          <Card className={`p-6 bg-gradient-to-br from-purple-500/20 to-purple-600/10 relative overflow-hidden transition-all ${walletChange.type === 'increase' ? 'ring-2 ring-green-500' : walletChange.type === 'decrease' ? 'ring-2 ring-red-500' : ''}`}>
            <div className="flex items-center gap-3">
              <Coins className="w-8 h-8 text-yellow-500" />
              <div>
                <p className="text-sm text-muted-foreground">Balance</p>
                <p className="text-2xl font-bold">{wallet?.coins_balance?.toLocaleString() || 0}</p>
              </div>
            </div>
            {walletChange.type && (
              <div className={`absolute top-2 right-2 flex items-center gap-1 text-sm font-medium ${walletChange.type === 'increase' ? 'text-green-500' : 'text-red-500'}`}>
                {walletChange.type === 'increase' ? <TrendingUp className="w-4 h-4" /> : <TrendingDown className="w-4 h-4" />}
                {walletChange.type === 'increase' ? '+' : '-'}{walletChange.amount.toLocaleString()}
              </div>
            )}
            {liveUpdates && (
              <Badge variant="outline" className="absolute bottom-2 right-2 text-xs bg-green-500/10 text-green-500 border-green-500/30">
                <span className="w-2 h-2 rounded-full bg-green-500 mr-1 animate-pulse" />
                Live
              </Badge>
            )}
          </Card>
          <Card className="p-6">
            <div className="flex items-center gap-3">
              <ShoppingCart className="w-8 h-8 text-green-500" />
              <div><p className="text-sm text-muted-foreground">Purchased</p><p className="text-2xl font-bold">{wallet?.total_purchased?.toLocaleString() || 0}</p></div>
            </div>
          </Card>
          <Card className="p-6">
            <div className="flex items-center gap-3">
              <Gift className="w-8 h-8 text-pink-500" />
              <div><p className="text-sm text-muted-foreground">Spent on Gifts</p><p className="text-2xl font-bold">{wallet?.total_spent?.toLocaleString() || 0}</p></div>
            </div>
          </Card>
          <Card className="p-6">
            <div className="flex items-center gap-3">
              <Heart className="w-8 h-8 text-red-500" />
              <div><p className="text-sm text-muted-foreground">Earned</p><p className="text-2xl font-bold">{wallet?.total_earned?.toLocaleString() || 0}</p></div>
            </div>
          </Card>
          <Card className="p-6">
            <div className="flex items-center gap-3">
              <Star className="w-8 h-8 text-blue-500" />
              <div><p className="text-sm text-muted-foreground">Available</p><p className="text-2xl font-bold">{wallet?.coins_balance?.toLocaleString() || 0}</p></div>
            </div>
          </Card>
          {/* Mining Wallet Card with Convert Button */}
          <Card className="p-6 bg-gradient-to-br from-amber-500/20 to-orange-500/10 border-amber-500/30 relative overflow-hidden">
            <div className="flex items-center gap-3">
              <Pickaxe className="w-8 h-8 text-amber-500" />
              <div>
                <p className="text-sm text-muted-foreground">StreamCoin</p>
                <p className="text-2xl font-bold text-amber-400">
                  {miningWallet?.balance?.toFixed(4) || '0.0000'}
                </p>
              </div>
            </div>
            {miningWallet?.balance > 0 && (
              <Button 
                size="sm" 
                variant="ghost" 
                className="absolute top-2 right-2 text-xs text-amber-400 hover:text-amber-300 hover:bg-amber-500/20"
                onClick={() => {
                  const tabsList = document.querySelector('[data-state="active"][value="convert"]');
                  if (!tabsList) {
                    const convertTab = document.querySelector('[value="convert"]') as HTMLElement;
                    if (convertTab) convertTab.click();
                  }
                }}
              >
                <ArrowRightLeft className="w-3 h-3 mr-1" />
                Convert
              </Button>
            )}
          </Card>
        </div>

        <Tabs defaultValue="buy" className="space-y-6">
          <TabsList className="grid w-full grid-cols-8">
            <TabsTrigger value="buy">Buy Coins</TabsTrigger>
            <TabsTrigger value="mining" className="gap-1">
              <Pickaxe className="w-3 h-3" />
              Mining
            </TabsTrigger>
            <TabsTrigger value="convert" className="gap-1">
              <ArrowRightLeft className="w-3 h-3" />
              Convert
            </TabsTrigger>
            <TabsTrigger value="gifts">Gift History</TabsTrigger>
            <TabsTrigger value="vip">VIP Benefits</TabsTrigger>
            <TabsTrigger value="cashout">Cash Out</TabsTrigger>
            <TabsTrigger value="history">Transactions</TabsTrigger>
            <TabsTrigger value="leaderboard">Leaderboard</TabsTrigger>
          </TabsList>
          <TabsContent value="buy"><CoinPackages onPurchase={() => { loadWallet(); loadVIPStatus(); }} /></TabsContent>
          <TabsContent value="mining"><MiningDashboard /></TabsContent>
          <TabsContent value="convert">
            <Card className="p-6">
              <div className="flex items-center gap-3 mb-6">
                <div className="w-12 h-12 rounded-full bg-gradient-to-br from-amber-400 to-orange-500 flex items-center justify-center">
                  <ArrowRightLeft className="w-6 h-6 text-white" />
                </div>
                <div>
                  <h2 className="text-xl font-bold">STC to Coins Converter</h2>
                  <p className="text-muted-foreground">Exchange your mined StreamCoin for platform coins</p>
                </div>
              </div>
              <STCConverter />
            </Card>
          </TabsContent>
          <TabsContent value="gifts"><Card className="p-6"><GiftHistory /></Card></TabsContent>
          <TabsContent value="vip">{vipData?.allTiers && <VIPBenefits tiers={vipData.allTiers} currentTierLevel={vipData.status?.current_tier?.tier_level || 0} />}</TabsContent>
          <TabsContent value="cashout"><CashoutForm userId={userId} balance={wallet?.coins_balance || 0} onSuccess={loadWallet} /></TabsContent>
          <TabsContent value="history"><TransactionHistory userId={userId} /></TabsContent>
          <TabsContent value="leaderboard"><div className="grid md:grid-cols-2 gap-6"><GiftersLeaderboard /><EarnersLeaderboard /></div></TabsContent>
        </Tabs>
      </div>
    </div>
  );
}
