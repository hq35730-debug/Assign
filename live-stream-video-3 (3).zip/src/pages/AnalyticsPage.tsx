
import React, { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '@/contexts/AuthContext';
import { supabase } from '@/lib/supabase';
import { AnalyticsOverview } from '@/components/analytics/AnalyticsOverview';
import { ViewerChart } from '@/components/analytics/ViewerChart';
import { EngagementChart } from '@/components/analytics/EngagementChart';
import { RevenueChart } from '@/components/analytics/RevenueChart';
import { GeographicChart } from '@/components/analytics/GeographicChart';
import { DateRangeFilter } from '@/components/analytics/DateRangeFilter';
import { ArrowLeft, BarChart3, RefreshCw } from 'lucide-react';

const getDateRange = (preset: string) => {
  const end = new Date();
  const start = new Date();
  if (preset === '7d') start.setDate(end.getDate() - 7);
  else if (preset === '30d') start.setDate(end.getDate() - 30);
  else if (preset === '90d') start.setDate(end.getDate() - 90);
  else if (preset === 'year') start.setMonth(0, 1);
  return { start: start.toISOString().split('T')[0], end: end.toISOString().split('T')[0] };
};

export default function AnalyticsPage() {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [loading, setLoading] = useState(true);
  const [startDate, setStartDate] = useState(getDateRange('30d').start);
  const [endDate, setEndDate] = useState(getDateRange('30d').end);
  const [overview, setOverview] = useState({ totalViewers: 0, uniqueViewers: 0, peakConcurrent: 0, avgWatchTime: 0, chatMessages: 0, newFollowers: 0, newSubscribers: 0, donations: 0, streamHours: 0 });
  const [viewerData, setViewerData] = useState([]);
  const [engagementData, setEngagementData] = useState([]);
  const [revenueData, setRevenueData] = useState([]);
  const [geoData, setGeoData] = useState([]);

  useEffect(() => { if (!user) navigate('/login'); }, [user]);
  useEffect(() => { if (user) loadAnalytics(); }, [user, startDate, endDate]);

  const loadAnalytics = async () => {
    if (!user) return;
    setLoading(true);
    const [overviewRes, viewerRes, engageRes, revRes, geoRes] = await Promise.all([
      supabase.functions.invoke('analytics-manager', { body: { action: 'get_overview', streamer_id: user.user_id, start_date: startDate, end_date: endDate } }),
      supabase.functions.invoke('analytics-manager', { body: { action: 'get_viewer_chart', streamer_id: user.user_id, start_date: startDate, end_date: endDate } }),
      supabase.functions.invoke('analytics-manager', { body: { action: 'get_engagement_chart', streamer_id: user.user_id, start_date: startDate, end_date: endDate } }),
      supabase.functions.invoke('analytics-manager', { body: { action: 'get_revenue_chart', streamer_id: user.user_id, start_date: startDate, end_date: endDate } }),
      supabase.functions.invoke('analytics-manager', { body: { action: 'get_geographic', streamer_id: user.user_id } })
    ]);
    if (overviewRes.data?.overview) setOverview(overviewRes.data.overview);
    if (viewerRes.data?.data) setViewerData(viewerRes.data.data);
    if (engageRes.data?.data) setEngagementData(engageRes.data.data);
    if (revRes.data?.data) setRevenueData(revRes.data.data);
    if (geoRes.data?.data) setGeoData(geoRes.data.data);
    setLoading(false);
  };

  const handlePreset = (preset: string) => {
    const { start, end } = getDateRange(preset);
    setStartDate(start);
    setEndDate(end);
  };

  if (!user) return null;

  return (
    <div className="min-h-screen bg-[#1a1a2e]">
      <header className="bg-[#16213e] border-b border-gray-800 sticky top-0 z-40">
        <div className="max-w-6xl mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center gap-4">
            <Link to="/profile" className="text-gray-400 hover:text-white"><ArrowLeft className="w-6 h-6" /></Link>
            <h1 className="text-xl font-bold bg-gradient-to-r from-purple-400 to-pink-500 bg-clip-text text-transparent flex items-center gap-2">
              <BarChart3 className="w-5 h-5 text-purple-400" /> Analytics Dashboard
            </h1>
          </div>
          <button onClick={loadAnalytics} className="text-gray-400 hover:text-white p-2 rounded-lg hover:bg-gray-800">
            <RefreshCw className={`w-5 h-5 ${loading ? 'animate-spin' : ''}`} />
          </button>
        </div>
      </header>

      <div className="max-w-6xl mx-auto px-4 py-8 space-y-8">
        <DateRangeFilter startDate={startDate} endDate={endDate} onStartChange={setStartDate} onEndChange={setEndDate} onPresetSelect={handlePreset} />
        <AnalyticsOverview data={overview} loading={loading} />
        <div className="grid lg:grid-cols-2 gap-6">
          <ViewerChart data={viewerData} loading={loading} />
          <EngagementChart data={engagementData} loading={loading} />
        </div>
        <div className="grid lg:grid-cols-2 gap-6">
          <RevenueChart data={revenueData} loading={loading} />
          <GeographicChart data={geoData} loading={loading} />
        </div>
      </div>
    </div>
  );
}
